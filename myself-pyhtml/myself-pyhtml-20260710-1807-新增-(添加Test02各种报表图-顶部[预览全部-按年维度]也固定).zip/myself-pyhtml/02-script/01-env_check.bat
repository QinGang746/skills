cd /d "%~dp0.."
where python >nul 2>nul || (echo Python not found. Run 02-script\01-env_install.bat first. & pause & exit /b 1)
python 02-script\01-env_setup.py
pause

