cd /d "%~dp0.."
python 02-script\02-fetch_data.py
pause

