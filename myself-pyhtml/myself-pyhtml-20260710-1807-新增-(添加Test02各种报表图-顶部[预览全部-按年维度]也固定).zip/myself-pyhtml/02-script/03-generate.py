# -*- coding: utf-8 -*-
"""
myself-pyhtml 一键生成脚本
双击运行 generate.py（或 run.bat），自动合并 txt → Excel → HTML
"""
import json
import os
import sys
import subprocess
from datetime import datetime, date

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, '01-data')
TEMPLATE_DIR = os.path.join(DATA_DIR, '01-template')
TXT_DIR = os.path.join(DATA_DIR, '02-txt-source')
OUT_DIR = os.path.join(BASE_DIR, 'output')
MERGE_JSON = os.path.join(OUT_DIR, 'merged.json')
XLSX_OUT = os.path.join(OUT_DIR, '开奖记录-全年份合并.xlsx')

SCRIPT_DIR = os.path.join(BASE_DIR, '02-script')

TXT2EXCEL_ARGS = [
    '--format', 'json',
    '--split', 'num,shengxiao,wuxing',
    '--split-prefixes', '平码,平肖,平五行',
    '--split-special', '特码,特肖,特五行',
    '--lunar-date',
    '--bose-table', os.path.join(TEMPLATE_DIR, '波色号码对照表.xlsx'),
    '--sheet-name', '开奖明细',
]


def load_txt_files():
    all_rows = []
    txt_files = sorted(f for f in os.listdir(TXT_DIR) if f.endswith('.txt'))
    for f in txt_files:
        with open(os.path.join(TXT_DIR, f), encoding='utf-8') as fh:
            all_rows.extend(json.load(fh))
    all_rows.sort(key=lambda r: r.get('date', ''), reverse=True)
    return all_rows, txt_files


def get_existing_max_date():
    if not os.path.exists(XLSX_OUT):
        return None
    try:
        import openpyxl
        wb = openpyxl.load_workbook(XLSX_OUT, data_only=True)
        if '开奖明细' not in wb.sheetnames:
            wb.close()
            return None
        ws = wb['开奖明细']
        max_date = str(ws.cell(2, 4).value)
        wb.close()
        return max_date
    except Exception:
        return None


def run_cmd(cmd_args, timeout=None):
    print('  $', ' '.join(cmd_args))
    result = subprocess.run(cmd_args, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        print('ERROR:', result.stderr.strip())
        return
    print('  ', result.stdout.strip())


def need_fetch():
    """检查当前年份 txt 最新日期是否已到当天，没到就需要拉取"""
    cur_year = date.today().year
    target = os.path.join(TXT_DIR, '临时测试-%d.txt' % cur_year)
    if not os.path.exists(target):
        return True  # 当年文件不存在，需要拉取
    try:
        with open(target, encoding='utf-8') as f:
            rows = json.load(f)
        if not rows:
            return True
        latest = max(r.get('date', '') for r in rows)
        today_str = date.today().strftime('%Y-%m-%d')
        return latest < today_str
    except Exception:
        return True


def main():
    print('=' * 60)
    print('  myself-pyhtml  开奖数据 -> HTML 一键生成')
    print('  %s' % datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print('=' * 60)

    # 智能拉取：当年数据未到当天 → 调接口，否则跳过
    fetch_script = os.path.join(SCRIPT_DIR, '02-fetch_data.py')
    if os.path.exists(fetch_script):
        if need_fetch():
            print('[拉取] 数据未到当天，从接口获取最新数据...')
            run_cmd([sys.executable, fetch_script], timeout=600)
        else:
            print('[拉取] 数据已最新（%s），跳过接口调用' % date.today())
    print()

    need_full = False
    existing_date = get_existing_max_date()
    all_rows, txt_files = load_txt_files()

    if existing_date is None:
        print('[首次] 未找到已有 Excel，全量合并 %d 个文件...' % len(txt_files))
        need_full = True
    else:
        print('[增量] 已有 Excel 最新日期: %s' % existing_date)
        new_rows = [r for r in all_rows if r.get('date', '') > existing_date]
        if not new_rows:
            print('[跳过] 无新数据，直接生成 HTML...')
        else:
            print('[增量] 发现 %d 条新记录' % len(new_rows))
            need_full = True

    if need_full:
        with open(MERGE_JSON, 'w', encoding='utf-8') as fh:
            json.dump(all_rows, fh, ensure_ascii=False)
        print('[合并] 总计 %d 条记录' % len(all_rows))
        print('[Excel] 正在生成...')
        run_cmd([sys.executable, os.path.join(SCRIPT_DIR, 'txt2excel.py'),
                 MERGE_JSON, XLSX_OUT] + TXT2EXCEL_ARGS)

    print('[HTML] 正在生成...')
    run_cmd([sys.executable, os.path.join(SCRIPT_DIR, 'excel2html_lottery.py'), XLSX_OUT])

    # 显示产物
    html_files = sorted(
        [f for f in os.listdir(OUT_DIR) if f.endswith('.html')],
        key=lambda f: os.path.getmtime(os.path.join(OUT_DIR, f))
    )
    print()
    print('[产物列表]')
    for f in os.listdir(OUT_DIR):
        path = os.path.join(OUT_DIR, f)
        size_kb = os.path.getsize(path) / 1024
        print('  %s (%.1f KB)' % (f, size_kb))
    print()
    print('[完成] HTML 文件可用浏览器直接打开。')
    if html_files:
        print('  ', os.path.join(OUT_DIR, html_files[-1]))


if __name__ == '__main__':
    main()
