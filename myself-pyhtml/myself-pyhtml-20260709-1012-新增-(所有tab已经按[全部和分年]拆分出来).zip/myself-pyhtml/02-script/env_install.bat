cd /d "%~dp0.."
echo ========================================
echo   myself-pyhtml - Env Installer
echo ========================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python not found.
    echo   Download: https://www.python.org/downloads/
    echo   Important: Check 'Add Python to PATH'
    pause
    exit /b 1
)

echo Python found:
python --version
echo.

python -m pip --version >nul 2>nul || (
    echo Installing pip...
    python -m ensurepip --default-pip
    python -m pip install --upgrade pip -q
)

echo Installing dependencies...
python -m pip install -r 02-script\requirements.txt -q
if %errorlevel% neq 0 (
    echo [ERROR] Install failed. Check network.
    pause
    exit /b 1
)

echo.
echo ========================================
echo   Environment ready!
echo ========================================
pause

