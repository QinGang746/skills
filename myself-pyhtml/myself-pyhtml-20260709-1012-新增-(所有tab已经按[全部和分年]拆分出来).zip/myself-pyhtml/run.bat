cd /d "%~dp0"
where python >nul 2>nul || (echo Python not found. Run 02-script\env_install.bat first. & pause & exit /b 1)
python 02-script\env_setup.py
if %errorlevel% neq 0 (pause & exit /b 1)
python 02-script\generate.py
pause

