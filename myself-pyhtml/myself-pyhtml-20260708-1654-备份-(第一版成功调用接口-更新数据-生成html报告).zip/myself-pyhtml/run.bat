@echo off
cd /d "%~dp0"

where python >nul 2>nul || (echo Python not found. Run 02-script\env_install.bat first. & pause & exit /b 1)

python 02-script\env_setup.py
if %errorlevel% neq 0 (pause & exit /b 1)

echo.
python 02-script\fetch_data.py
if %errorlevel% neq 0 echo [WARN] Fetch failed, using existing data.

echo.
python 02-script\generate.py

pause

