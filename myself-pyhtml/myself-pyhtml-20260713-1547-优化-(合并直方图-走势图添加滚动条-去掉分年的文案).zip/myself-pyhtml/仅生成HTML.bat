@echo off
cd /d "%~dp0"
python 02-script\03-generate.py --no-fetch
pause
