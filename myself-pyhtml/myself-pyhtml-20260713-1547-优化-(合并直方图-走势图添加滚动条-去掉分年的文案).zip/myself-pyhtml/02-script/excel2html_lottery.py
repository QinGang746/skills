# -*- coding: utf-8 -*-
"""
开奖记录明细 Excel -> 交互式 HTML 仪表盘
参考 excel2html_formula.py 的浅色 Tab 风格；数据从「开奖明细」sheet 重算（口径已验证）。
只用特码维度。纯离线 HTML，无 CDN。
用法: python 02-script/excel2html_lottery.py [xlsx路径]
"""
import os
import sys
import json
from datetime import datetime, date
from collections import Counter, defaultdict
import openpyxl

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, 'output')
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT_DIR, '开奖记录-全年份合并-v5.xlsx')

PRIME = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47}
QIN = set('牛马羊鸡狗猪')
ZODIAC = list('鼠牛虎兔龙蛇马羊猴鸡狗猪')
WX = list('金木水火土')
WEEK = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
BOSE_TABLE = os.path.join(BASE_DIR, '01-data', '01-template', '波色号码对照表.xlsx')


def load_zodiac_map():
    """从波色号码对照表提取 年份 → {号码1-49: 生肖} 映射"""
    import re
    wb = openpyxl.load_workbook(BOSE_TABLE, data_only=True)
    ws = wb.worksheets[0]
    out = {}
    for r in range(5, ws.max_row, 2):
        label = str(ws.cell(r, 1).value or '')
        m = re.search(r'(\d{4})', label)
        if not m:
            continue
        year = int(m.group(1))
        zmap = {}
        for c in range(2, ws.max_column + 1):
            num = c - 1  # col2→号码1, col3→号码2, ...
            zmap[num] = str(ws.cell(r, c).value)
        out[year] = zmap
    wb.close()
    return out


def load_rows(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    if '开奖明细' in wb.sheetnames:
        ws = wb['开奖明细']
    else:
        ws = wb.worksheets[0]
    rows = []
    for r in range(2, ws.max_row + 1):
        tema = ws.cell(r, 12).value
        if tema is None or str(tema).strip() == '':
            continue
        rows.append({
            'tema': int(str(tema).strip()),
            'id': ws.cell(r, 1).value,
            'tx': str(ws.cell(r, 20).value),
            'wx': str(ws.cell(r, 27).value),
            'bose': str(ws.cell(r, 13).value),
            'year': ws.cell(r, 2).value,
            'qishu': ws.cell(r, 3).value,
            'date': str(ws.cell(r, 4).value),
            'plain': [int(str(ws.cell(r, c).value).strip()) for c in range(6, 12)],
        })
    wb.close()
    return rows


def attrs_of(rows):
    temas = [r['tema'] for r in rows]
    return {
        'tema': temas,
        'tx': [r['tx'] for r in rows],
        'wx': [r['wx'] for r in rows],
        'bose': [r['bose'] for r in rows],
        'dx': ['大' if t >= 25 else '小' for t in temas],
        'ds': ['单' if t % 2 else '双' for t in temas],
        'combo': [('大' if t >= 25 else '小') + ('单' if t % 2 else '双') for t in temas],
        'tou': [str(t // 10) for t in temas],
        'wei': [str(t % 10) for t in temas],
        'qs': ['家禽' if r['tx'] in QIN else '野兽' for r in rows],
        'hs': ['质' if t in PRIME else '合' for t in temas],
        'yqd': [(r['year'], r['qishu'], r['date']) for r in rows],
        'plain': [r['plain'] for r in rows],
    }


def freq_table(seq, keys):
    n = len(seq)
    c = Counter(seq)
    return [{'k': k, 'n': c.get(k, 0), 'p': (c.get(k, 0) / n if n else 0)} for k in keys]


def gap_now(seq, key):
    for i, v in enumerate(seq):
        if v == key:
            return i
    return len(seq)


def gap_max(seq, key):
    mx = cur = 0
    for v in seq:
        if v == key:
            mx = max(mx, cur); cur = 0
        else:
            cur += 1
    return max(mx, cur)


def gap_max_at(seq, key, yqd, n):
    """返回 (最大遗漏期数, 最大遗漏结束时的期号+日期)
    最大遗漏结束 = 该遗漏后第一次出现 key 的那一期"""
    mx = cur = 0
    last_seen = (-1, '', '')  # 上一次出现 key 的位置
    mx_at = ('', '')
    for i, v in enumerate(seq):
        if v == key:
            if cur > mx and last_seen[0] >= 0:
                mx = cur
                mx_at = (str(yqd[last_seen[0]][1]) + '期', yqd[last_seen[0]][2])
            cur = 0
            last_seen = (i, str(yqd[i][1]) + '期' if i < n else '', yqd[i][2] if i < n else '')
        else:
            cur += 1
    if cur > mx and last_seen[0] >= 0:
        mx = cur
        mx_at = (str(yqd[last_seen[0]][1]) + '期', yqd[last_seen[0]][2])
    return mx, mx_at


def miss_rows(seq, keys, yqd, keyfmt=None):
    n = len(seq)
    out = []
    for k in keys:
        g = gap_now(seq, k)
        last = yqd[g] if g < n else ('', '', '')
        mx_val, mx_at = gap_max_at(seq, k, yqd, n)
        out.append({
            'k': keyfmt(k) if keyfmt else k,
            'gap': g,
            'cnt': sum(1 for v in seq if v == k),
            'mx': mx_val,
            'mx_last': [mx_at[0], mx_at[1]],
            'last': [last[1], last[2]],
        })
    return out


def build_stats(rows):
    a = attrs_of(rows)
    n = len(rows)
    yqd = a['yqd']
    latest = yqd[0]

    ATTR_DEFS = [('大小', a['dx'], ['大', '小']), ('单双', a['ds'], ['单', '双']),
                 ('波色', a['bose'], ['红波', '蓝波', '绿波']),
                 ('号头', a['tou'], ['0', '1', '2', '3', '4']),
                 ('号尾', a['wei'], [str(i) for i in range(10)])]

    freqs = [
        {'title': '大小', 'note': '特码 ≥25 记"大"、≤24 记"小"', 'rows': freq_table(a['dx'], ['大', '小'])},
        {'title': '单双', 'note': '特码奇数记"单"、偶数记"双"', 'rows': freq_table(a['ds'], ['单', '双'])},
        {'title': '大小单双组合', 'note': '大小×单双 组合', 'rows': freq_table(a['combo'], ['大单', '大双', '小单', '小双'])},
        {'title': '波色', 'note': '按特码当年波色（红/蓝/绿）', 'rows': freq_table(a['bose'], ['红波', '蓝波', '绿波'])},
        {'title': '质合', 'note': '质数记"质"否则"合"', 'rows': freq_table(a['hs'], ['质', '合'])},
        {'title': '家禽野兽', 'note': '家禽 牛马羊鸡狗猪 / 野兽 鼠虎兔龙蛇猴', 'rows': freq_table(a['qs'], ['家禽', '野兽'])},
        {'title': '五行', 'note': '按特码五行', 'rows': freq_table(a['wx'], WX)},
        {'title': '号头(0-4)', 'note': '号头=特码十位', 'rows': freq_table(a['tou'], ['0', '1', '2', '3', '4'])},
        {'title': '生肖', 'note': '按特码生肖', 'rows': freq_table(a['tx'], ZODIAC)},
        {'title': '号尾(0-9)', 'note': '号尾=特码个位', 'rows': freq_table(a['wei'], [str(i) for i in range(10)])},
    ]

    miss_num = miss_rows(a['tema'], list(range(1, 50)), yqd, keyfmt=lambda x: '%02d' % x)
    miss_zod = miss_rows(a['tx'], ZODIAC, yqd)
    miss_attr = []
    for label, seq, keys in ATTR_DEFS:
        for k in keys:
            g = gap_now(seq, k); last = yqd[g] if g < n else ('', '', '')
            mxv, mx_at = gap_max_at(seq, k, yqd, n)
            miss_attr.append({'k': '%s=%s' % (label, k), 'gap': g,
                              'cnt': sum(1 for v in seq if v == k), 'mx': mxv,
                              'mx_last': [mx_at[0], mx_at[1]],
                              'last': [last[1], last[2]]})

    # 热温冷
    num_gap = {x: gap_now(a['tema'], x) for x in range(1, 50)}
    avg = sum(num_gap.values()) / 49.0
    hotcold = []
    for x in range(1, 50):
        g = num_gap[x]
        lvl = '热' if g < avg else ('冷' if g > avg else '温')
        hotcold.append({'k': '%02d' % x, 'gap': g,
                        'cnt': sum(1 for t in a['tema'] if t == x), 'lvl': lvl})

    rank_num = sorted([{'k': '%02d' % x, 'gap': num_gap[x], 'mx': gap_max(a['tema'], x),
                         'mx_last': gap_max_at(a['tema'], x, yqd, n)[1],
                         'last': [yqd[num_gap[x]][1] if num_gap[x] < n else '', yqd[num_gap[x]][2] if num_gap[x] < n else '']}
                        for x in range(1, 50)], key=lambda r: r['gap'], reverse=True)
    zg = {z: gap_now(a['tx'], z) for z in ZODIAC}
    rank_zod = sorted([{'k': z, 'gap': zg[z], 'mx': gap_max(a['tx'], z),
                        'mx_last': gap_max_at(a['tx'], z, yqd, n)[1],
                        'last': [yqd[zg[z]][1] if zg[z] < n else '', yqd[zg[z]][2] if zg[z] < n else '']} for z in ZODIAC],
                      key=lambda r: r['gap'], reverse=True)
    rank_attr = sorted([{'k': m['k'], 'gap': m['gap'], 'mx': m['mx'], 'mx_last': m['mx_last'], 'last': m['last']} for m in miss_attr],
                       key=lambda r: r['gap'], reverse=True)

    # 连开/重号
    rep = tema_in_prev = 0
    overlaps = []
    for i in range(n - 1):
        if a['tema'][i] == a['tema'][i + 1]:
            rep += 1
        cur_p = set(a['plain'][i]); prv_p = set(a['plain'][i + 1])
        overlaps.append(len(cur_p & prv_p))
        if a['tema'][i] in prv_p:
            tema_in_prev += 1
    m = n - 1
    oc = Counter(overlaps)
    liankai = {
        'm': m,
        'rep': rep, 'rep_p': rep / m if m else 0,
        'tip': tema_in_prev, 'tip_p': tema_in_prev / m if m else 0,
        'overlap': [{'k': k, 'n': oc[k], 'p': oc[k] / m if m else 0} for k in sorted(oc)],
    }

    # 概览
    fc = Counter(a['tema'])
    hot5 = sorted(range(1, 50), key=lambda x: fc.get(x, 0), reverse=True)[:5]
    cold5 = sorted(range(1, 50), key=lambda x: fc.get(x, 0))[:5]
    most_missing = max(range(1, 50), key=lambda x: num_gap[x])
    overview = {
        'total': n,
        'date_from': yqd[-1][2], 'date_to': yqd[0][2],
        'latest': [latest[0], latest[1], latest[2]],
        'hot5': [{'k': '%02d' % x, 'n': fc.get(x, 0)} for x in hot5],
        'cold5': [{'k': '%02d' % x, 'n': fc.get(x, 0)} for x in cold5],
        'most_missing': {'k': '%02d' % most_missing, 'gap': num_gap[most_missing]},
        'dist': {
            'dx': freq_table(a['dx'], ['大', '小']),
            'ds': freq_table(a['ds'], ['单', '双']),
            'bose': freq_table(a['bose'], ['红波', '蓝波', '绿波']),
            'qs': freq_table(a['qs'], ['家禽', '野兽']),
        },
    }

    # 走势图数据：各属性序列（新→旧），期数标签 + 阳历日期
    trend = {
        'labels': ['%s期' % q for (_, q, _) in yqd],   # 新→旧
        'dates': [d for (_, _, d) in yqd],             # 阳历日期 YYYY-MM-DD
        'dx': a['dx'], 'ds': a['ds'], 'bose': a['bose'], 'qs': a['qs'],
        'wx': a['wx'], 'tou': a['tou'], 'wei': a['wei'],
        'tema': a['tema'],                             # 每期特码号码（新→旧）
    }

    # 遗漏热力图数据：最近200期，每期每个号码的遗漏值（新→旧）
    MAX_GAP_HIST = min(200, len(a['tema']))
    # 取窗口数据，转为旧→新处理
    subset = a['tema'][:MAX_GAP_HIST][::-1]   # 旧→新（窗口内）
    # 初始化：查窗口之前每个号码的最后出现位置
    num_gap_init = {}
    for x in range(1, 50):
        found = False
        for pos, t in enumerate(a['tema'][MAX_GAP_HIST:], start=MAX_GAP_HIST):
            if t == x:
                num_gap_init[x] = pos - MAX_GAP_HIST
                found = True
                break
        if not found:
            num_gap_init[x] = MAX_GAP_HIST
    # 逐期计算遗漏值（旧→新）
    gap_hist = []   # 每项是49个遗漏值（号码1→49）
    cur_gap = dict(num_gap_init)
    for t in subset:
        row = [min(cur_gap[x], 99) for x in range(1, 50)]
        gap_hist.append(row)
        for x in range(1, 50):
            cur_gap[x] += 1
        cur_gap[t] = 0
    trend['gap_history'] = {'periods': MAX_GAP_HIST, 'nums': 49,
                             'labels': trend['labels'][:MAX_GAP_HIST],
                             'dates': trend['dates'][:MAX_GAP_HIST],
                             'grid': gap_hist[::-1]}   # 恢复 新→旧

    # 冷热转换统计：每期判断每个号码热(当前遗漏<均值)或冷(>均值)，统计相邻两期间状态变化次数
    hc_avg = sum(num_gap.values()) / 49.0
    prev_state = {x: '热' if num_gap[x] < hc_avg else ('冷' if num_gap[x] > hc_avg else '温') for x in range(1, 50)}
    trans = {'hotCold': 0, 'coldHot': 0, 'hotHot': 0, 'coldCold': 0}
    temas = a['tema']
    for i in range(1, len(temas)):
        t = temas[i]
        cur_gap = num_gap.copy()
        cur_state = {x: '热' if cur_gap[x] < hc_avg else ('冷' if cur_gap[x] > hc_avg else '温') for x in range(1, 50)}
        # 对于本期开出的号码 t，其在当前期是热（gap=0 < avg）
        # 更新 num_gap：本期开出 t，重置 t 的 gap 为 0，其他号码 gap+1
        for x in range(1, 50):
            if x == t:
                num_gap[x] = 0
            else:
                num_gap[x] += 1
        # 统计状态变化
        for x in range(1, 50):
            old_s = prev_state[x]
            new_gap = num_gap[x]
            new_s = '热' if new_gap < hc_avg else ('冷' if new_gap > hc_avg else '温')
            if old_s == '热' and new_s == '冷':
                trans['hotCold'] += 1
            elif old_s == '冷' and new_s == '热':
                trans['coldHot'] += 1
            elif old_s == '热' and new_s == '热':
                trans['hotHot'] += 1
            elif old_s == '冷' and new_s == '冷':
                trans['coldCold'] += 1
        prev_state = {x: '热' if num_gap[x] < hc_avg else ('冷' if num_gap[x] > hc_avg else '温') for x in range(1, 50)}

    # 连肖统计：同一生肖连续出现次数（新→旧序列，按连续段统计）
    lian_xiao = {z: {'cnt2': 0, 'cnt3': 0, 'history': [], 'cur_gap': 0, 'max_gap': 0} for z in ZODIAC}
    tx_seq = a['tx']  # 新→旧
    tx_dates = [d for (_, _, d) in yqd]
    segs = []
    i = 0
    while i < len(tx_seq):
        z = tx_seq[i]; run = 1
        while i + run < len(tx_seq) and tx_seq[i + run] == z:
            run += 1
        if run >= 2:
            segs.append({'zod': z, 'len': run, 'end_date': tx_dates[i]})
        i += run
    for z in ZODIAC:
        zsegs = [s for s in segs if s['zod'] == z]
        for s2 in zsegs:
            if s2['len'] >= 4: lian_xiao[z]['cnt3'] += 1  # 4连+归入3连+
            elif s2['len'] == 3: lian_xiao[z]['cnt3'] += 1
            elif s2['len'] == 2: lian_xiao[z]['cnt2'] += 1
        lian_xiao[z]['history'] = [s2['end_date'] for s2 in zsegs]
        if zsegs:
            last_seg_end_idx = next((j for j, v in enumerate(tx_seq) if v == z and j > 0 and tx_seq[j - 1] == z), -1)
            lian_xiao[z]['cur_gap'] = last_seg_end_idx if last_seg_end_idx >= 0 else len(tx_seq)
        else:
            lian_xiao[z]['cur_gap'] = n
        all_zidx = [j for j, v in enumerate(tx_seq) if v == z]
        if len(all_zidx) >= 2:
            mg = 0
            for k in range(len(all_zidx) - 1):
                g = all_zidx[k + 1] - all_zidx[k] - 1
                if g > mg: mg = g
            lian_xiao[z]['max_gap'] = mg

    return {
        'overview': overview,
        'freqs': freqs,
        'miss_num': miss_num, 'miss_zod': miss_zod, 'miss_attr': miss_attr,
        'hotcold': hotcold, 'hc_avg': round(avg, 1),
        'rank_num': rank_num, 'rank_zod': rank_zod, 'rank_attr': rank_attr,
        'liankai': liankai,
        'trend': trend,
        'transitions': trans,
        'lian_xiao': lian_xiao,
    }


def build_year_stats(rows):
    years = sorted(set(r['year'] for r in rows))
    out = []
    for Y in years:
        yrows = [r for r in rows if r['year'] == Y]
        s = build_stats(yrows)
        out.append({'year': Y, 'n': len(yrows),
                    'from': yrows[-1]['date'], 'to': yrows[0]['date'],
                    'stats': s})
    return out


# ---------------- HTML 模板 ----------------
def render_html(title, data):
    data_json = json.dumps(data, ensure_ascii=False)
    return HTML_TEMPLATE.replace('__TITLE__', title).replace('__DATA__', data_json)


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__</title>
<style>
:root{ --primary:#1a73e8; --navh:51px; --bg:#f0f2f5; --card:#fff; }
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Microsoft YaHei",Arial,sans-serif;background:var(--bg);color:#333;}
.tab-nav{position:sticky;top:44px;z-index:20;background:#fff;
  box-shadow:0 2px 8px rgba(0,0,0,.08);}
.mode-bar{position:sticky;top:0;z-index:21;display:flex;justify-content:center;padding:7px 0;background:#f5f7fa;border-bottom:1px solid #e8ecf1;}
.mode-btn{padding:6px 24px;border:1px solid #cdd8ea;background:#fff;cursor:pointer;font-size:13px;color:#666;
  margin:0 4px;border-radius:20px;}
.mode-btn:first-child{border-radius:20px 0 0 20px;margin-right:0;}
.mode-btn:last-child{border-radius:0 20px 20px 0;margin-left:0;}
.mode-btn:not(:first-child):not(:last-child){border-radius:0;margin:0;}
.mode-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.tab-row{display:flex;flex-wrap:wrap;padding:0 20px;}
.tab-btn{padding:14px 20px;border:none;background:none;cursor:pointer;font-size:14px;color:#666;
  border-bottom:3px solid transparent;}
.tab-btn:hover{color:var(--primary);}
.tab-btn.active{color:var(--primary);border-bottom-color:var(--primary);font-weight:bold;}
.tab-page{display:none;padding:20px;width:98%;margin:0 auto;}
.tab-page.active{display:block;}
.card{background:var(--card);border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);
  padding:18px;margin-bottom:20px;}
.card h2{font-size:16px;margin-bottom:6px;color:#1a3a6b;}
.note{font-size:12px;color:#888;font-style:italic;margin-bottom:10px;}
.stat-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;}
.stat-card{background:linear-gradient(135deg,#e8f0fe,#fff);border-radius:12px;padding:16px;
  box-shadow:0 2px 8px rgba(0,0,0,.05);}
.stat-card .lbl{font-size:12px;color:#888;}
.stat-card .val{font-size:22px;font-weight:bold;color:var(--primary);margin-top:6px;}
.stat-card .sub{font-size:12px;color:#666;margin-top:4px;}
.stat-card .hot5-sub{font-size:11px;color:#555;margin-top:6px;line-height:1.6;word-spacing:6px;}
.hotcold-row{display:flex;gap:16px;flex-wrap:wrap;}
.hotcold-box{flex:1;min-width:260px;background:#fff;border-radius:10px;padding:14px;
  border-left:5px solid #e74c3c;}
.hotcold-box.cold{border-left-color:#1a73e8;}
.hotcold-box h3{font-size:14px;margin-bottom:10px;}
.hc-cards{display:flex;gap:8px;flex-wrap:wrap;}
.hc-card{width:52px;text-align:center;background:#f6f8fc;border-radius:8px;padding:8px 4px;}
.hc-card .num{font-size:18px;font-weight:bold;color:#333;}
.hc-card .cnt{font-size:11px;color:#999;}
.wave-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:720px){.wave-grid{grid-template-columns:1fr;}}
.wc-box{background:#fafbfe;border-radius:10px;padding:12px;}
.wc-box h4{font-size:13px;margin-bottom:8px;color:#555;}
.wc-cards{display:flex;gap:8px;flex-wrap:wrap;}
.wc-card{flex:1;min-width:70px;text-align:center;border-radius:8px;padding:10px 6px;}
.wc-card .k{font-size:13px;font-weight:bold;}
.wc-card .p{font-size:12px;margin-top:2px;}
table{border-collapse:collapse;width:100%;font-size:13px;}
th,td{border:1px solid #e3e6ea;padding:7px 10px;text-align:center;white-space:nowrap;}
th{background:#f1f5fb;color:#333;cursor:pointer;user-select:none;white-space:nowrap;}
th.sortable:hover{background:#e3ecfa;}
th .arr{color:#b0b8c4;font-size:11px;margin-left:3px;}
th.sortable[data-dir="asc"] .arr,th.sortable[data-dir="desc"] .arr{color:#1a73e8;}
tr:nth-child(even) td{background:#fafbfd;}
tr:hover td{background:#eef4ff;}
.bose-hong{background:#FD7272 !important;}
.bose-lan{background:#2FC8EE !important;}
.bose-lv{background:#65EC74 !important;}
.lvl-hot{background:#fce4d6 !important;}
.lvl-warm{background:#fff2cc !important;}
.lvl-cold{background:#dce9f7 !important;}
.hot-val{color:#e74c3c !important;font-weight:bold;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
@media(max-width:900px){.grid2{grid-template-columns:1fr;}}
.year-btns{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;}
.year-btn{padding:8px 16px;border:1px solid #cdd8ea;border-radius:20px;background:#fff;
  cursor:pointer;font-size:13px;}
.year-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.subttl{font-size:14px;color:#1a3a6b;margin:14px 0 6px;font-weight:bold;}
.zbars{display:flex;flex-direction:column;gap:6px;margin-top:8px;}
.zbar-row{display:flex;align-items:center;gap:8px;}
.zbar-lbl{width:34px;height:30px;line-height:30px;text-align:center;border-radius:6px;font-weight:bold;font-size:14px;flex:none;color:#444;}
.zbar-track{flex:1;background:#eef0f3;border-radius:6px;height:22px;position:relative;overflow:hidden;}
.zbar-fill{height:100%;border-radius:6px;display:flex;align-items:center;min-width:2px;}
.zbar-fill.dev{background:linear-gradient(90deg,#e74c3c,#f0776a);}
.zbar-fill.dev.zero{background:#c9ced6;}
.zbar-fill.freq{background:linear-gradient(90deg,#1a73e8,#5a9cf0);}
.zbar-fill span{color:#fff;font-size:12px;font-weight:bold;padding-left:8px;white-space:nowrap;}
.zbar-val{width:56px;text-align:right;font-size:13px;font-weight:bold;color:#333;flex:none;}
.zbar-tag{width:52px;text-align:center;font-size:11px;padding:3px 0;border-radius:4px;flex:none;color:#555;}
/* 走势图 */
.trend-wrap{display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start;}
/* 走势图 子级tab */
.subtab-bar{display:flex;gap:4px;margin-bottom:12px;border-bottom:1px solid #e3e6ea;padding-bottom:0;}
.subtab-btn{padding:8px 18px;border:1px solid transparent;border-bottom:none;border-radius:6px 6px 0 0;
  background:none;cursor:pointer;font-size:13px;color:#666;margin-bottom:-1px;}
.subtab-btn.active{background:#fff;border-color:#cdd8ea #cdd8ea #fff;color:var(--primary);font-weight:bold;}
/* 号码走势Canvas: 表头sticky + 内容滚动 */
.canvas-wrap{background:#fff;border-radius:8px;border:1px solid #e3e6ea;overflow:hidden;}
.canvas-head-wrap{position:sticky;top:0;z-index:5;background:#fff;overflow:hidden;}
.canvas-head-wrap canvas{display:block;}
.canvas-body-wrap{overflow:auto;max-height:70vh;}
.canvas-body-wrap canvas{display:block;}
/* 遗漏报表 */
.gap-cell{text-align:left;width:160px;}
.gap-bar{display:inline-block;height:14px;border-radius:3px;vertical-align:middle;min-width:4px;}
.trend-col{flex:1;min-width:240px;border:1px solid #e3e6ea;border-radius:10px;overflow:hidden;background:#fff;}
.trend-col.c0{border-top:3px solid #E8A13B;} .trend-col.c1{border-top:3px solid #1a73e8;}
.trend-col.c2{border-top:3px solid #e74c3c;} .trend-col.c3{border-top:3px solid #2e9e5b;}
.trend-col h3{text-align:center;font-size:14px;padding:10px;color:#333;}
.trend-tb{width:100%;border-collapse:collapse;font-size:12px;}
.trend-tb th,.trend-tb td{border:1px solid #eceff3;height:26px;text-align:center;padding:0;}
.trend-tb th{background:#f7f9fc;color:#666;font-weight:normal;font-size:12px;}
.trend-tb td.qi{color:#999;font-size:11px;width:52px;background:#fafbfd;}
.trend-tb td.dt{color:#7a8493;font-size:11px;width:82px;background:#fafbfd;white-space:nowrap;}
.trend-cell{font-weight:bold;font-size:12px;}
#trendSubBody,#trendYearBody{max-height:70vh;overflow-y:auto;}
/* 历史记录 */
.month-btns{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;}
.month-btn{padding:7px 14px;border:1px solid #cdd8ea;border-radius:20px;background:#fff;cursor:pointer;font-size:13px;}
.month-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.hist-wrap{overflow-x:auto;}
.hist-tb{width:100%;border-collapse:collapse;font-size:13px;white-space:nowrap;}
.hist-tb th,.hist-tb td{border:1px solid #e3e6ea;padding:7px 10px;text-align:center;}
.hist-tb th{background:#dce5f0;color:#333;}
.hist-tb tr:nth-child(even) td{background:#fafbfd;}
.hist-tb tr:hover td{background:#eef4ff;}
/* 左侧 sticky 导航 + 右侧内容 通用布局 */
.side-layout{display:flex;gap:18px;align-items:flex-start;}
.side-nav{position:sticky;top:calc(var(--navh) + 12px);flex:none;width:150px;
  background:#fff;border:1px solid #e3e6ea;border-radius:10px;padding:8px;max-height:calc(100vh - var(--navh) - 30px);overflow-y:auto;}
.side-nav .sn-item{display:block;padding:8px 10px;font-size:13px;color:#555;border-radius:6px;cursor:pointer;
  border:none;background:none;width:100%;text-align:left;}
.side-nav .sn-item:hover{background:#eef4ff;color:var(--primary);}
.side-nav .sn-item.active{background:var(--primary);color:#fff;}
.side-nav .sn-group{font-size:11px;color:#999;padding:8px 10px 4px;font-weight:bold;}
.side-body{flex:1;min-width:0;}
.side-body .card{overflow-x:auto;}
@media(max-width:820px){.side-layout{flex-direction:column;}.side-nav{position:static;width:100%;max-height:none;display:flex;flex-wrap:wrap;gap:4px;}}
</style>
</head>
<body>

<div class="tab-nav" id="tabNav"></div>
<div id="pages"></div>
<script>
var DATA = __DATA__;
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function pct(x){return (x*100).toFixed(2)+'%';}
function boseCls(k){return k==='红波'?'bose-hong':k==='蓝波'?'bose-lan':k==='绿波'?'bose-lv':'';}
function lvlCls(l){return l==='热'?'lvl-hot':l==='温'?'lvl-warm':'lvl-cold';}

/* 频率表"类型"列底色：生肖/家禽野兽用 #82C99A/#F1948A，其余柔和浅色 */
var SHOU_SET2={'鼠':1,'虎':1,'兔':1,'龙':1,'蛇':1,'猴':1};
var QIN_SET2={'牛':1,'马':1,'羊':1,'鸡':1,'狗':1,'猪':1};
/* 生肖名加野/家后缀：鼠→鼠(野)、牛→牛(家)（首页概览横条除外） */
function zodLabel(z){z=String(z);return SHOU_SET2[z]?z+'(野)':(QIN_SET2[z]?z+'(家)':z);}
function typeBgStyle(k){
  k=String(k).replace(/\((野|家)\)$/,'');  // 去掉"(野)/(家)"后缀再判色
  if(k==='野兽'||SHOU_SET2[k]) return 'background:#F1948A;color:#fff;font-weight:bold;';
  if(k==='家禽'||QIN_SET2[k]) return 'background:#82C99A;color:#fff;font-weight:bold;';
  var map={
    '大':'#fdebd0','小':'#e8ddf3','单':'#d6eaf8','双':'#fdf3d0',
    '红波':'#FD7272','蓝波':'#2FC8EE','绿波':'#65EC74',
    '质':'#e8f0fb','合':'#f2ece0',
    '大单':'#fce8d5','大双':'#f6e0ee','小单':'#dbeaf6','小双':'#e6f3da',
    '金':'#fdf1cf','木':'#dff0d8','水':'#d6ebf5','火':'#fbe0dc','土':'#efe6d3'
  };
  if(map[k]) return 'background:'+map[k]+';';
  // 号头/号尾（纯数字）用极浅灰蓝交替
  if(/^\d+$/.test(k)) return 'background:'+ (parseInt(k,10)%2 ? '#eef3f9':'#f3f0f7') +';';
  return '';
}

/* 生肖野兽(红底)/家禽(绿底) */
var SHOU_SET={'鼠':1,'虎':1,'兔':1,'龙':1,'蛇':1,'猴':1};
function zodLblStyle(z){return SHOU_SET[z]?'background:#F1948A;color:#fff;':'background:#82C99A;color:#fff;';}
/* 偏差阈值标签：忽略<25≤提醒<30≤可以追 */
function devTag(g){
  if(g>=30) return {t:'可以追',bg:'#c8e6c9'};
  if(g>=25) return {t:'提醒',bg:'#fff3cd'};
  return {t:'忽略',bg:'#e8e8e8'};
}
/* 生肖偏差排行（偏差=当前遗漏期数，降序），横条 */
function zodDevBars(rankZod){
  var max=Math.max.apply(null,rankZod.map(function(r){return r.gap;}))||1;
  var h='<div class="zbars">';
  rankZod.forEach(function(r){
    var w=Math.max(r.gap/max*100,r.gap>0?4:0);
    var tag=devTag(r.gap);
    h+='<div class="zbar-row">';
    h+='<div class="zbar-lbl" style="'+zodLblStyle(r.k)+'">'+r.k+'</div>';
    h+='<div class="zbar-track"><div class="zbar-fill dev'+(r.gap===0?' zero':'')+'" style="width:'+w+'%"></div></div>';
    h+='<div class="zbar-val">+'+r.gap+'</div>';
    h+='<div class="zbar-tag" style="background:'+tag.bg+'">'+tag.t+'</div>';
    h+='</div>';
  });
  return h+'</div>';
}
/* 生肖出现频率横条（次数+占比） */
function zodFreqBars(freqRows){
  var max=Math.max.apply(null,freqRows.map(function(r){return r.n;}))||1;
  var h='<div class="zbars">';
  freqRows.forEach(function(r){
    var w=Math.max(r.n/max*100,4);
    h+='<div class="zbar-row">';
    h+='<div class="zbar-lbl" style="'+zodLblStyle(r.k)+'">'+r.k+'</div>';
    h+='<div class="zbar-track"><div class="zbar-fill freq" style="width:'+w+'%"><span>'+r.n+'</span></div></div>';
    h+='<div class="zbar-val">'+pct(r.p)+'</div>';
    h+='</div>';
  });
  return h+'</div>';
}

/* 可排序表格 */
function tableHtml(headers, rows, opts){
  opts=opts||{};
  var sortable=opts.sortAll ? headers.map(function(_,i){return i;}) : (opts.sortable||[]);
  var boseCol=opts.boseCol;        // 该列值做波色底色
  var lvlCol=opts.lvlCol;          // 热温冷底色列
  var pctCols=opts.pctCols||[];    // 百分比列
  var typeBgCol=opts.typeBgCol;    // "类型"列按取值上底色（inline style）
  var hotFn=opts.hotFn;            // (rowArr,ci,val)=>bool 需加粗标红的单元格
  var htmlCols=opts.htmlCols||[];   // 该列值为原始 HTML（不转义）
  var h='<table><thead><tr>';
  headers.forEach(function(hd,ci){
    var isSort=sortable.indexOf(ci)>=0;
    h+='<th class="'+(isSort?'sortable':'')+'" data-ci="'+ci+'">'+esc(hd)+(isSort?'<span class="arr">⇅</span>':'')+'</th>';
  });
  h+='</tr></thead><tbody>';
  rows.forEach(function(r){
    h+='<tr>';
    r.forEach(function(v,ci){
      var cls='', sty='';
      if(boseCol!==undefined && ci===boseCol) cls=boseCls(String(v));
      if(lvlCol!==undefined && ci===lvlCol) cls=lvlCls(String(v));
      if(typeBgCol!==undefined && ci===typeBgCol) sty=typeBgStyle(v);
      if(hotFn && hotFn(r,ci,v)) cls+=(cls?' ':'')+'hot-val';
      var disp=v;
      if(pctCols.indexOf(ci)>=0 && typeof v==='number') disp=pct(v);
      var isHtml=htmlCols.indexOf(ci)>=0;
      h+='<td class="'+cls+'"'+(sty?' style="'+sty+'"':'')+'>'+(isHtml?disp:esc(disp))+'</td>';
    });
    h+='</tr>';
  });
  h+='</tbody></table>';
  return h;
}

/* 构造 hotFn：标红「当前遗漏≥30 或 属于gapTop3」的遗漏列 + 「历史最大遗漏∈mxTop3」列
   cfg: {gapCol, gapTop3:Set, mxCol, mxTop3:Set, lvlCol, coldMark} */
function makeMissHot(rows, cfg){
  cfg=cfg||{};
  function topSet(col, n){
    var vals=rows.map(function(r){return {i:r, v:parseFloat(r[col])};})
      .filter(function(o){return !isNaN(o.v);})
      .sort(function(a,b){return b.v-a.v;});
    var th=vals.length>=n? vals[n-1].v : (vals.length?vals[vals.length-1].v:0);
    return th;
  }
  var gapTh = cfg.gapCol!==undefined ? topSet(cfg.gapCol,3) : null;
  var mxTh  = cfg.mxCol!==undefined ? topSet(cfg.mxCol,3) : null;
  return function(rowArr, ci, val){
    if(cfg.gapCol!==undefined && ci===cfg.gapCol){
      var g=parseFloat(val);
      if(!isNaN(g) && (g>=30 || (gapTh!==null && g>=gapTh))) return true;
    }
    if(cfg.mxCol!==undefined && ci===cfg.mxCol){
      var m=parseFloat(val);
      if(!isNaN(m) && mxTh!==null && m>=mxTh) return true;
    }
    return false;
  };
}

function attachSort(container){
  container.querySelectorAll('th.sortable').forEach(function(th){
    th.addEventListener('click',function(){
      var table=th.closest('table');
      var ci=+th.dataset.ci;
      var tb=table.querySelector('tbody');
      var rows=Array.prototype.slice.call(tb.querySelectorAll('tr'));
      var dir=th.dataset.dir==='asc'?'desc':'asc';
      table.querySelectorAll('th').forEach(function(x){x.dataset.dir='';var a=x.querySelector('.arr');if(a&&x.classList.contains('sortable'))a.textContent='⇅';});
      th.dataset.dir=dir; th.querySelector('.arr').textContent=dir==='asc'?'▲':'▼';
      rows.sort(function(a,b){
        var x=a.children[ci].textContent, y=b.children[ci].textContent;
        var nx=parseFloat(x.replace('%','').replace(/[^\d.\-]/g,'')), ny=parseFloat(y.replace('%','').replace(/[^\d.\-]/g,''));
        if(!isNaN(nx)&&!isNaN(ny)){return dir==='asc'?nx-ny:ny-nx;}
        return dir==='asc'?x.localeCompare(y):y.localeCompare(x);
      });
      rows.forEach(function(r){tb.appendChild(r);});
    });
  });
}

/* ---- 左侧 sticky 锚点导航通用组件 ---- */
/* sections: [{id, label}]，bodyHtml 内各区块须带 id=对应 id */
function withSideNav(sections, bodyHtml){
  var nav='<div class="side-nav">';
  sections.forEach(function(s,i){
    nav+='<button class="sn-item'+(i===0?' active':'')+'" data-target="'+s.id+'">'+esc(s.label)+'</button>';
  });
  nav+='</div>';
  return '<div class="side-layout">'+nav+'<div class="side-body">'+bodyHtml+'</div></div>';
}
/* 绑定：点侧栏项 → 平滑滚到区块；滚动时高亮当前项 */
function attachSideNav(page){
  var nav=page.querySelector('.side-nav'); if(!nav) return;
  var items=[].slice.call(nav.querySelectorAll('.sn-item'));
  items.forEach(function(it){
    it.addEventListener('click',function(){
      var el=page.querySelector('#'+CSS.escape(it.dataset.target));
      if(el){var y=el.getBoundingClientRect().top+window.pageYOffset-60;window.scrollTo({top:y,behavior:'smooth'});}
      items.forEach(function(x){x.classList.remove('active');}); it.classList.add('active');
    });
  });
}

/* ---- 各页渲染 ---- */
function distBox(title, arr, colorMap){
  var b='<div class="wc-box"><h4>'+title+'</h4><div class="wc-cards">';
  arr.forEach(function(x){
    var bg=colorMap[x.k]||'#eef2f9';
    b+='<div class="wc-card" style="background:'+bg+'"><div class="k">'+x.k+'</div><div class="p">'+x.n+' / '+pct(x.p)+'</div></div>';
  });
  return b+'</div></div>';
}
function zodFreqRows(stats){
  var f=stats.freqs.filter(function(x){return x.title==='生肖';})[0];
  return f?f.rows:[];
}
function devCard(ttl, rankZod){
  return '<div class="card"><h2>'+ttl+'</h2>'+
    '<div class="note">按"当前遗漏期数"降序（越久未出越靠前，视为偏差越大）；生肖名野兽=浅红底、家禽=浅绿底；阈值 忽略&lt;25≤提醒&lt;30≤可以追。</div>'+
    zodDevBars(rankZod)+'</div>';
}
function freqCard(ttl, rows){
  return '<div class="card"><h2>'+ttl+'</h2>'+
    '<div class="note">各生肖出现次数与实际占比；生肖名野兽=浅红底、家禽=浅绿底。</div>'+
    zodFreqBars(rows)+'</div>';
}

function renderOverview(s){
  var o=s.overview;
  var h='<div class="card"><h2>数据概览</h2><div class="stat-cards">';
  h+='<div class="stat-card"><div class="lbl">总期数</div><div class="val">'+o.total+'</div><div class="sub">'+o.date_from+' ~ '+o.date_to+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最新一期</div><div class="val">'+o.latest[1]+'期</div><div class="sub">'+o.latest[0]+'年 '+o.latest[2]+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">🔥 热号 Top3</div><div class="val">'+o.hot5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+o.hot5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">❄️ 冷号 Top3</div><div class="val">'+o.cold5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+o.cold5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最久未出</div><div class="val">'+o.most_missing.k+'</div><div class="sub">已遗漏 '+o.most_missing.gap+' 期</div></div>';
  h+='</div></div>';

  h+='<div class="card"><h2>热门 / 冷门号码</h2><div class="hotcold-row">';
  h+='<div class="hotcold-box"><h3>🔥 热门 Top5</h3><div class="hc-cards">';
  o.hot5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div>';
  h+='<div class="hotcold-box cold"><h3>❄️ 冷门 Top5</h3><div class="hc-cards">';
  o.cold5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div></div></div>';

  h+='<div class="card"><h2>基础属性分布</h2><div class="wave-grid">';
  h+=distBox('大小',o.dist.dx,{'大':'#fdebd0','小':'#e8ddf3'});
  h+=distBox('单双',o.dist.ds,{'单':'#d6eaf8','双':'#fdf3d0'});
  h+=distBox('波色',o.dist.bose,{'红波':'#FD7272','蓝波':'#2FC8EE','绿波':'#65EC74'});
  h+=distBox('家禽野兽',o.dist.qs,{'家禽':'#82C99A','野兽':'#F1948A'});
  h+='</div></div>';

  var yr=DATA.years[DATA.years.length-1];
  h+='<div class="grid2">';
  h+=devCard('生肖偏差排行（总览）',s.rank_zod);
  h+=freqCard('生肖出现频率（总览）',zodFreqRows(s));
  h+='</div>';
  h+='<div class="grid2">';
  h+=devCard('生肖偏差排行（'+yr.year+'年·当年）',yr.stats.rank_zod);
  h+=freqCard('生肖出现频率（'+yr.year+'年·当年）',zodFreqRows(yr.stats));
  h+='</div>';
  return h;
}

function renderOverviewYear(){
  return '<div class="card"><h2>首页概览</h2><div class="note">以年为维度查看数据概览。点击年份切换。</div>'+
    '<div class="year-btns" id="overviewYearBtns"></div><div id="overviewYearBody"></div></div>';
}
function fillOverviewYear(idx){
  var y=DATA.years[idx], s=y.stats, o=s.overview, nY=DATA.years.length;
  document.querySelectorAll('#overviewYearBtns .year-btn').forEach(function(b,pos){
    b.classList.toggle('active',(nY-1-pos)===idx);
  });
  var h='<div style="margin:6px 0 12px;color:#666;font-size:13px">'+y.year+'年 共 '+y.n+' 期（'+y.from+' ~ '+y.to+'）</div>';
  h+='<div class="stat-cards" style="margin-bottom:16px">';
  h+='<div class="stat-card"><div class="lbl">期数</div><div class="val">'+o.total+'</div><div class="sub">'+o.date_from+' ~ '+o.date_to+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最新一期</div><div class="val">'+o.latest[1]+'期</div><div class="sub">'+o.latest[2]+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">🔥 热号 Top3</div><div class="val">'+o.hot5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+o.hot5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">❄️ 冷号 Top3</div><div class="val">'+o.cold5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+o.cold5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最久未出</div><div class="val">'+o.most_missing.k+'</div><div class="sub">'+o.most_missing.gap+'期</div></div>';
  h+='</div>';

  h+='<div class="card" style="margin-top:12px"><h2>热门 / 冷门号码</h2><div class="hotcold-row">';
  h+='<div class="hotcold-box"><h3>热门 Top5</h3><div class="hc-cards">';
  o.hot5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div>';
  h+='<div class="hotcold-box cold"><h3>冷门 Top5</h3><div class="hc-cards">';
  o.cold5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div></div></div>';

  h+='<div class="card" style="margin-top:12px"><h2>基础属性分布</h2><div class="wave-grid">';
  h+=distBox('大小',o.dist.dx,{'大':'#fdebd0','小':'#e8ddf3'});
  h+=distBox('单双',o.dist.ds,{'单':'#d6eaf8','双':'#fdf3d0'});
  h+=distBox('波色',o.dist.bose,{'红波':'#FD7272','蓝波':'#2FC8EE','绿波':'#65EC74'});
  h+=distBox('家禽野兽',o.dist.qs,{'家禽':'#82C99A','野兽':'#F1948A'});
  h+='</div></div>';

  h+='<div class="grid2" style="margin-top:12px">';
  h+=devCard('生肖偏差排行（'+y.year+'年）',s.rank_zod);
  h+=freqCard('生肖出现频率（'+y.year+'年）',zodFreqRows(s));
  h+='</div>';
  document.getElementById('overviewYearBody').innerHTML=h;
}

function renderFreq(s){
  var secs=[], body='<div>';
  var LIGHT=['#90b8e8','#ea9595','#8ed8ae','#f0d490','#c0a8dc','#8cd0d0','#f0be88','#8ab8e8','#ea90b8','#88d0dc','#bdd888','#dcb888'];
  var BOSE_COLORS={'红波':'#f87878','蓝波':'#48c8f2','绿波':'#6ce888'};
  s.freqs.forEach(function(f,idx){
    var id='freq-'+idx; secs.push({id:id,label:f.title});
    var isZod=f.title==='生肖';
    // 左栏：数据表
    var leftRows=f.rows.map(function(r){return [isZod?zodLabel(r.k):r.k, r.n, r.p];});
    var avgP=leftRows.length? leftRows.reduce(function(a,r){return a+r[2];},0)/leftRows.length : 0;
    var hotFn=function(rowArr,ci,val){ return ci===2 && avgP>0 && val>avgP*1.3; };
    var leftTbl=tableHtml(['类型','次数','实际占比'],leftRows,{sortAll:true,pctCols:[2],typeBgCol:0,hotFn:hotFn});
    // 右栏：分布条（Test02 风格）
    var maxN=0; f.rows.forEach(function(r){if(r.n>maxN)maxN=r.n;});
    var barRows=[];
    f.rows.forEach(function(r,j){
      var col; if(f.title==='波色'){col=BOSE_COLORS[r.k]||LIGHT[j%12];}else{col=LIGHT[j%12];}
      var label=isZod?'<span style="background:'+(SHOU_SET2[r.k]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+r.k+'</span>':r.k;
      var bar='<div style="text-align:left;width:180px"><span class="gap-bar" style="width:'+Math.max(r.n/maxN*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+r.n+'次</span></div>';
      barRows.push([label,r.n,parseFloat((r.p*100).toFixed(1))+'%',bar]);
    });
    var htmlCols=isZod?[0,3]:[3];
    var rightTbl=tableHtml(['类型','次数','占比','分布'],barRows,{sortAll:true,htmlCols:htmlCols,typeBgCol:0});
    body+='<div class="card" id="'+id+'" style="box-shadow:none;border:1px solid #eee"><h2>'+f.title+'</h2><div class="note">'+esc(f.note)+'</div>'+
      '<div style="display:flex;gap:20px;flex-wrap:wrap"><div style="flex:1;min-width:240px">'+leftTbl+'</div><div style="flex:1;min-width:340px">'+rightTbl+'</div></div></div>';
  });
  body+='</div>';
  return withSideNav(secs, body);
}

function missTable(rows, labelFn){
  var data=rows.map(function(r){
    var ml=r.mx_last||['',''];
    return [labelFn?labelFn(r.k):r.k, r.gap, r.cnt, r.mx,
      (ml[0]||''), (ml[1]||''),
      (r.last[0]?r.last[0]+'期':''), r.last[1]||''];
  });
  return tableHtml(['项','当前遗漏','出现次数','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],
    data,{sortAll:true,hotFn:makeMissHot(data,{gapCol:1,mxCol:3})});
}

/* 属性遗漏按类别拆分：传入 miss_attr（k形如 "大小=大"），按前缀分组 */
function attrMissSplit(missAttr){
  var groups={};
  missAttr.forEach(function(r){
    var cat=r.k.split('=')[0];
    (groups[cat]=groups[cat]||[]).push(r);
  });
  return groups;
}
function attrMissCard(title, rows){
  var data=rows.map(function(r){
    var ml=r.mx_last||['',''];
    return [r.k, r.gap, r.cnt, r.mx,
      (ml[0]||''), (ml[1]||''),
      (r.last[0]?r.last[0]+'期':''), r.last[1]||''];
  });
  return '<div class="card"><h2>'+title+'</h2>'+
    tableHtml(['属性','当前遗漏','出现次数','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],
      data,{sortAll:true,hotFn:makeMissHot(data,{gapCol:1,mxCol:3})})+'</div>';
}

function renderMiss(s){
  var h='';
  // 号码遗漏 与 热温冷 左右各 50%
  h+='<div class="grid2" id="miss-num">';
  h+='<div class="card"><h2>号码遗漏 / 冷热（01-49）</h2><div class="note">当前遗漏=距今多少期未出（0=最新期开出）</div>'+missTable(s.miss_num)+'</div>';
  var hc=s.hotcold.map(function(r){return [r.k,r.gap,r.cnt,r.lvl];});
  var hcHot=function(rowArr,ci,val){
    if(ci===1){ // 冷号 或 遗漏≥30 → 标红遗漏值
      if(String(rowArr[3])==='冷') return true;
      var g=parseFloat(val); return !isNaN(g)&&g>=30;
    }
    return false;
  };
  h+='<div class="card"><h2>号码热温冷分层（平均遗漏 '+s.hc_avg+' 期）</h2><div class="note">当前遗漏 < 平均=热、= 平均=温、> 平均=冷；冷号或遗漏≥30 标红</div>'+
    tableHtml(['号码','当前遗漏','出现次数','热温冷'],hc,{sortAll:true,lvlCol:3,hotFn:hcHot})+'</div>';
  h+='</div>';
  // 生肖遗漏 与 属性遗漏(拆分)
  h+='<div class="grid2" id="miss-zod">';
  h+='<div class="card"><h2>生肖遗漏</h2>'+missTable(s.miss_zod, zodLabel)+'</div>';
  var g=attrMissSplit(s.miss_attr);
  h+=attrMissCard('属性遗漏 · 大小/单双/波色',[].concat(g['大小']||[],g['单双']||[],g['波色']||[]));
  h+='</div>';
  h+='<div class="grid2" id="miss-attr">';
  h+=attrMissCard('属性遗漏 · 号头',g['号头']||[]);
  h+=attrMissCard('属性遗漏 · 号尾',g['号尾']||[]);
  h+='</div>';
  // 排行榜（当前遗漏 col2 / 历史最大 col3 标红）
  var rankHot=function(data){return makeMissHot(data,{gapCol:2,mxCol:3});};
  h+='<div class="grid2" id="miss-rank">';
  var rnum=s.rank_num.map(function(r,i){
    var ml=r.mx_last||['',''];
    return [i+1,r.k,r.gap,r.mx,(ml[0]||''),(ml[1]||''),(r.last[0]?r.last[0]+'期':''),r.last[1]||''];
  });
  h+='<div class="card"><h2>号码遗漏排行榜</h2>'+tableHtml(['排名','号码','当前遗漏','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],
      rnum,{sortAll:true,hotFn:rankHot(rnum)})+'</div>';
  var rzod=s.rank_zod.map(function(r,i){
    var ml=r.mx_last||['',''];
    return [i+1,zodLabel(r.k),r.gap,r.mx,(ml[0]||''),(ml[1]||''),(r.last[0]?r.last[0]+'期':''),r.last[1]||''];
  });
  h+='<div class="card"><h2>生肖遗漏排行榜</h2>'+tableHtml(['排名','生肖','当前遗漏','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],
      rzod,{sortAll:true,hotFn:rankHot(rzod)})+'</div>';
  h+='</div>';
  var secs=[{id:'miss-num',label:'号码遗漏/热温冷'},{id:'miss-zod',label:'生肖/属性遗漏'},
            {id:'miss-attr',label:'号头/号尾遗漏'},{id:'miss-rank',label:'号码/生肖排行榜'}];
  return withSideNav(secs, h);
}

function renderMissYear(){
  var h='<div class="card"><h2>遗漏/冷热</h2><div class="note">每年独立统计（遗漏在该年内计算）。点击年份切换。</div>';
  h+='<div class="year-btns" id="missYearBtns"></div><div id="missYearBody"></div></div>';
  return h;
}
function fillMissYear(idx){
  var y=DATA.years[idx], s=y.stats, nY=DATA.years.length;
  document.querySelectorAll('#missYearBtns .year-btn').forEach(function(b,pos){
    b.classList.toggle('active',(nY-1-pos)===idx);
  });
  var h='<div style="margin:6px 0 12px;color:#666;font-size:13px">'+y.year+'年 共 '+y.n+' 期（'+y.from+' ~ '+y.to+'）</div>';
  h+='<div class="grid2" id="missyr-num">';
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码遗漏 / 冷热（01-49）</h2><div class="note">当前遗漏=距今多少期未出（0=最新期开出）</div>'+missTable(s.miss_num)+'</div>';
  var yhc=s.hotcold.map(function(r){return [r.k,r.gap,r.cnt,r.lvl];});
  var yhcHot=function(rowArr,ci,val){
    if(ci===1){if(String(rowArr[3])==='冷')return true;var g=parseFloat(val);return !isNaN(g)&&g>=30;}return false;
  };
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码热温冷（本年均值 '+s.hc_avg+' 期）</h2>'+
    tableHtml(['号码','当前遗漏','出现次数','热温冷'],yhc,{sortAll:true,lvlCol:3,hotFn:yhcHot})+'</div>';
  h+='</div>';
  h+='<div class="grid2" id="missyr-zod">';
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>生肖遗漏</h2>'+missTable(s.miss_zod,zodLabel)+'</div>';
  var g=attrMissSplit(s.miss_attr);
  h+=attrMissCard('属性遗漏 · 大小/单双/波色',[].concat(g['大小']||[],g['单双']||[],g['波色']||[]));
  h+='</div>';
  h+='<div class="grid2" id="missyr-attr">';
  h+=attrMissCard('属性遗漏 · 号头',g['号头']||[]);
  h+=attrMissCard('属性遗漏 · 号尾',g['号尾']||[]);
  h+='</div>';
  var rankHot=function(data){return makeMissHot(data,{gapCol:2,mxCol:3});};
  h+='<div class="grid2" id="missyr-rank">';
  var rnum=s.rank_num.map(function(r,i){
    var ml=r.mx_last||['',''];
    return [i+1,r.k,r.gap,r.mx,(ml[0]||''),(ml[1]||''),(r.last[0]?r.last[0]+'期':''),r.last[1]||''];
  });
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码遗漏排行榜</h2>'+tableHtml(['排名','号码','当前遗漏','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],rnum,{sortAll:true,hotFn:rankHot(rnum)})+'</div>';
  var rzod=s.rank_zod.map(function(r,i){
    var ml=r.mx_last||['',''];
    return [i+1,zodLabel(r.k),r.gap,r.mx,(ml[0]||''),(ml[1]||''),(r.last[0]?r.last[0]+'期':''),r.last[1]||''];
  });
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>生肖遗漏排行榜</h2>'+tableHtml(['排名','生肖','当前遗漏','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],rzod,{sortAll:true,hotFn:rankHot(rzod)})+'</div>';
  h+='</div>';
  h=withSideNav([{id:'missyr-num',label:'号码遗漏/热温冷'},{id:'missyr-zod',label:'生肖/属性遗漏'},{id:'missyr-attr',label:'号头/号尾遗漏'},{id:'missyr-rank',label:'号码/生肖排行榜'}],h);
  document.getElementById('missYearBody').innerHTML=h;
  attachSort(document.getElementById('missYearBody'));
  attachSideNav(document.getElementById('missYearBody'));
}

function renderGapDistYear(){
  return '<div class="card"><h2>Test - 分析实验</h2>'+
    '<div class="note">遗漏分布+遗漏对比+冷热转换。点击年份切换。每人每年数据独立计算。</div>'+
    '<div class="year-btns" id="gapDistYearBtns"></div><div id="gapDistYearBody"></div></div>';
}
function fillGapDistYear(idx){
  var y=DATA.years[idx], s=y.stats, nY=DATA.years.length;
  document.querySelectorAll('#gapDistYearBtns .year-btn').forEach(function(b,pos){
    b.classList.toggle('active',(nY-1-pos)===idx);
  });
  var h='<div style="margin:6px 0 12px;color:#666;font-size:13px">'+y.year+'年 共 '+y.n+' 期（'+y.from+' ~ '+y.to+'）</div>';
  var gaps=s.miss_num.map(function(r){return r.gap;});
  var n=y.n;

  // ===== stat cards =====
  var total=gaps.length, avg=Math.round(gaps.reduce(function(a,b){return a+b;},0)/total);
  var maxGap=Math.max.apply(null,gaps);
  var maxNum=s.miss_num.filter(function(r){return r.gap===maxGap;})[0]||{};
  var coldCnt=s.miss_num.filter(function(r){return r.gap>avg;}).length;
  var hotCnt=s.miss_num.filter(function(r){return r.gap<avg;}).length;
  h+='<div class="stat-cards" style="margin-bottom:16px">';
  h+='<div class="stat-card"><div class="lbl">遗漏均值</div><div class="val">'+avg+'期</div><div class="sub">冷('+coldCnt+') 热('+hotCnt+') 温('+(49-coldCnt-hotCnt)+')</div></div>';
  h+='<div class="stat-card"><div class="lbl">最长遗漏</div><div class="val">'+maxNum.k+'</div><div class="sub">已漏 '+maxGap+' 期</div></div>';
  h+='<div class="stat-card"><div class="lbl">期数</div><div class="val">'+n+'</div><div class="sub">'+y.year+'年</div></div>';
  h+='</div>';

  // ===== 1. 遗漏分布直方图 =====
  var bins=[{label:'0期(刚出)',min:0,max:0},{label:'1-5期',min:1,max:5},
            {label:'6-10期',min:6,max:10},{label:'11-20期',min:11,max:20},
            {label:'21-30期',min:21,max:30},{label:'30期+',min:31,max:9999}];
  var maxCnt=0; bins.forEach(function(bn){var c=s.miss_num.filter(function(r){return r.gap>=bn.min&&r.gap<=bn.max;}).length;if(c>maxCnt)maxCnt=c;});
  var rows=[];
  bins.forEach(function(bn){
    var nums=s.miss_num.filter(function(r){return r.gap>=bn.min&&r.gap<=bn.max;});
    var col=bn.min>=30?'#e74c3c':bn.min>=15?'#F39C12':'#4CAF50';
    var bar='<div style="text-align:left;width:200px"><span class="gap-bar" style="width:'+Math.max(nums.length/maxCnt*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+nums.length+'个</span></div>';
    rows.push([bn.label,nums.length,bar,parseFloat((nums.length/total*100).toFixed(1))+'%',nums.map(function(r){return r.k;}).join(',')]);
  });
  h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>1. 遗漏分布直方图</h2><div class="note">号码按当前遗漏分组，绿=偏热、黄=温、红=冷</div>'+
    tableHtml(['区间','号码数','分布','占比','号码列表'],rows,{sortAll:true,htmlCols:[2]})+'</div>';

  // ===== 2. 当前遗漏 vs 历史最大遗漏 对比 =====
  var cmp=[]; s.miss_num.forEach(function(r){
    var ratio=r.mx?parseFloat((r.gap/r.mx*100).toFixed(1)):0;
    var warn=ratio>=80?'热-接近历史极值':'';
    var ml=r.mx_last||['',''];
    cmp.push([r.k,r.gap,r.last[1]||'',r.mx,ml[1]||'',ratio+'%',r.cnt,warn]);
  });
  cmp.sort(function(a,b){return b[1]-a[1];}); // 按当前遗漏降序
  h+='<div class="card" id="cmp-card" style="box-shadow:none;border:1px solid #eee"><h2>2. 遗漏对比（当前 vs 历史最大）</h2><div class="note">当前遗漏占历史最大遗漏的百分比，≥80%接近极值标红</div>'+
    tableHtml(['号码','当前遗漏','当前遗漏日期','历史最大','最大遗漏日期','占比','出现次数','状态'],cmp,
      {sortAll:true,hotFn:function(rr,ci,val){var g=parseInt(rr[1]);return ci===1&&g>=30||ci===5&&parseFloat(rr[5])>=80;}})+'</div>';
  // 加深当前遗漏和历史最大表头
  setTimeout(function(){
    var card=document.getElementById('cmp-card'); if(!card) return;
    var ths=card.querySelectorAll('th');
    if(ths[1])ths[1].style.background='#d5dbe8'; if(ths[3])ths[3].style.background='#d5dbe8';
  },50);

  // ===== 3. 冷热转换 ===== REMOVED

  // ===== 3. 连肖统计 =====
  if(s.lian_xiao){
    var zods='鼠牛虎兔龙蛇马羊猴鸡狗猪'.split('');
    var lxRows=[];
    zods.forEach(function(z){
      var lx=s.lian_xiao[z]||{};
      var tag='<span style="background:'+(SHOU_SET2[z]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+z+'</span>';
      lxRows.push([tag,lx.cnt2||0,lx.cnt3||0,(lx.history||[])[0]||'']);
    });
    h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>3. 连肖统计</h2><div class="note">2连=连续2期同肖、3连=连续3期+</div>'+
      tableHtml(['生肖','2连肖','3连+','最新连肖日期'],lxRows,
        {sortAll:true,htmlCols:[0],hotFn:function(rr,ci,val){return (ci===1||ci===2)&&parseInt(val)>0;}})+'</div>';
    // ===== 4. 连肖日期 =====
    var lxDrows=[], maxH=0;
    zods.forEach(function(z){var h=(s.lian_xiao[z]||{}).history||[]; if(h.length>maxH)maxH=h.length;});
    maxH=Math.min(maxH,7);
    var dh=['生肖'];
    for(var k=1;k<=maxH;k++) dh.push('连肖日期'+('0'+k).slice(-2));
    zods.forEach(function(z){
      var hx=(s.lian_xiao[z]||{}).history||[];
      var tag='<span style="background:'+(SHOU_SET2[z]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+z+'</span>';
      var row=[tag];
      for(var k=0;k<maxH;k++) row.push(hx[k]||'');
      lxDrows.push(row);
    });
    h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>4. 连肖日期</h2><div class="note">各生肖所有连肖日期（新→旧），最多展示7次</div>'+
      tableHtml(dh,lxDrows,{sortAll:true,htmlCols:[0]})+'</div>';
  }
  document.getElementById('gapDistYearBody').innerHTML=h;
  attachSort(document.getElementById('gapDistYearBody'));
}

/* ===== Canvas 图表引擎 ===== */
function drawBarChart(container, data, opts){
  opts=opts||{}; var W=opts.w||520, rowH=opts.rowH||22, barH=opts.barH||16;
  var PAD=Math.max.apply(null,data.map(function(d){return String(d.label).length;}))*8+20;
  var H=opts.title?rowH+Math.max(data.length*rowH+20,120):Math.max(data.length*rowH+20,120);
  var mx=Math.max.apply(null,data.map(function(d){return d.val;}))||1;
  var cv=document.createElement('canvas'); cv.width=W; cv.height=H; container.appendChild(cv);
  var ctx=cv.getContext('2d'); var BAR_X=PAD+10, BAR_W=W-PAD-60;
  if(opts.title){ctx.fillStyle='#333';ctx.font='bold 12px "Microsoft YaHei"';ctx.fillText(opts.title,10,16);var topY=rowH;}
  else var topY=8;
  data.forEach(function(d,i){
    var y=topY+i*rowH, w=Math.max(d.val/mx*BAR_W,4);
    ctx.fillStyle='#666';ctx.font='11px "Microsoft YaHei"';ctx.textAlign='right';
    ctx.fillText(d.label,PAD-4,y+rowH/2+3);
    ctx.fillStyle=d.color||'#1a73e8';ctx.fillRect(BAR_X,y+(rowH-barH)/2,w,barH);
    ctx.fillStyle='#333';ctx.textAlign='left';ctx.font='bold 10px "Microsoft YaHei"';
    ctx.fillText(d.val,BAR_X+w+4,y+rowH/2+3);
  });
}
function drawPieChart(container, opts, data){
  opts=opts||{}; var R=opts.r||100, CX=opts.cx||R+20, CY=opts.cy||R+20;
  var W=R*2+160, H=R*2+60;
  var cv=document.createElement('canvas'); cv.width=W; cv.height=H; container.appendChild(cv);
  var ctx=cv.getContext('2d'); ctx.font='12px "Microsoft YaHei"';
  var total=data.reduce(function(s,d){return s+d.val;},0)||1;
  var start=-Math.PI/2;
  data.forEach(function(d,i){
    var slice=d.val/total*Math.PI*2;
    ctx.beginPath();ctx.moveTo(CX,CY);ctx.arc(CX,CY,R,start,start+slice);ctx.closePath();
    ctx.fillStyle=d.color||'#1a73e8';ctx.fill();
    var mid=start+slice/2, lx=CX+Math.cos(mid)*(R+20), ly=CY+Math.sin(mid)*(R+20);
    ctx.fillStyle='#333';ctx.textAlign=mid>Math.PI/2||mid<-Math.PI/2?'right':'left';
    ctx.fillText(d.label+' '+(d.val/total*100).toFixed(0)+'%',lx,ly+4);
    start+=slice;
  });
}
function drawLineChart(container, data, opts){
  opts=opts||{}; var W=opts.w||600, H=opts.h||300, PAD=opts.pad||50;
  var cv=document.createElement('canvas'); cv.width=W; cv.height=H; container.appendChild(cv);
  var ctx=cv.getContext('2d'); var CH=H-PAD-30, CW=W-PAD-20, N=data.length;
  var mx=Math.max.apply(null,data.map(function(d){return d.val;}))||1, mn=0;
  var stepX=CW/(N-1||1), stepY=CH/(mx-mn||1);
  // axes
  ctx.strokeStyle='#ddd';ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(PAD,10);ctx.lineTo(PAD,H-20);ctx.lineTo(W-10,H-20);ctx.stroke();
  // Y labels
  ctx.fillStyle='#999';ctx.font='10px "Microsoft YaHei"';ctx.textAlign='right';
  for(var t=0;t<=4;t++){var v=Math.round(mx*t/4),y=H-20-v*stepY;ctx.fillText(v,PAD-4,y+3);ctx.beginPath();ctx.moveTo(PAD,y);ctx.lineTo(W-10,y);ctx.strokeStyle='#f0f0f0';ctx.stroke();}
  // X labels
  ctx.textAlign='center';var skip=Math.max(1,Math.floor(N/8));
  data.forEach(function(d,i){
    if(i%skip===0||i===N-1){ctx.fillText(d.label,PAD+i*stepX,H-6);}
  });
  // line
  ctx.strokeStyle=opts.color||'#1a73e8';ctx.lineWidth=2;ctx.beginPath();
  data.forEach(function(d,i){var x=PAD+i*stepX,y=H-20-(d.val-mn)*stepY;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();
  // dots
  data.forEach(function(d,i){var x=PAD+i*stepX,y=H-20-(d.val-mn)*stepY;
    ctx.fillStyle=opts.color||'#1a73e8';ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();
  });
}


	/* 遗漏热力图：X=号码1-49, Y=最近期数(上=新→下=旧), 颜色深度=遗漏值 */
	function drawGapHeatmap(container, gh){
	  var CW=12, RH=3, LM=74, TM=28, periods=gh.periods, nums=gh.nums;
	  var W=LM+nums*CW+10, H=TM+periods*RH+6;
	  var cv=document.createElement('canvas'); cv.width=W; cv.height=H; container.appendChild(cv);
	  var ctx=cv.getContext('2d');
	  ctx.fillStyle='#fafbfd'; ctx.fillRect(0,0,W,H);
	  // 号码→波色映射（从频率表取）
	  var boseByNum={};
	  var bt=DATA.all.trend.bose, btt=DATA.all.trend.tema;
	  var seen={};
	  for(var pi=0;pi<btt.length;pi++){var n=btt[pi];if(!seen[n]){seen[n]=true;boseByNum[n]=bt[pi];}}
	  // 顶部号码标签+波色条
	  ctx.font='10px "Microsoft YaHei"'; ctx.textAlign='center';
	  for(var x=1;x<=49;x++){
	    var cx=LM+(x-1)*CW, bs=boseByNum[x]||'', bc=bs==='红波'?'#FD7272':bs==='蓝波'?'#2FC8EE':bs==='绿波'?'#65EC74':'#ddd';
	    ctx.fillStyle=bc; ctx.fillRect(cx,0,CW,5);
	    ctx.fillStyle='#555'; ctx.fillText(x,cx+CW/2,TM-6);
	  }
	  // 色块
	  for(var r=0;r<periods;r++){
	    if(r%20===0||r===periods-1){
	      ctx.fillStyle='#777'; ctx.font='9px "Microsoft YaHei"'; ctx.textAlign='right';
	      ctx.fillText(gh.dates[r]||'',LM-4,TM+r*RH+RH/2+3);
	    }
	    var row=gh.grid[r];
	    for(var c=0;c<nums;c++){
	      var gv=row[c], cr=LM+c*CW, cy=TM+r*RH;
	      var t=Math.min(gv/40,1);
	      var R=Math.round(t<0.5?t*2*255:255), G=Math.round(t<0.5?255:(1-(t-0.5)*2)*200);
	      var B=Math.round(t<0.5?255*(1-t*2):0);
	      ctx.fillStyle='rgb('+R+','+G+','+B+')';
	      ctx.fillRect(cr,cy,CW,RH);
	    }
	  }
	  // 图例
	  var lx=LM+nums*CW+8; ctx.fillStyle='#555'; ctx.font='10px "Microsoft YaHei"'; ctx.textAlign='left';
	  for(var gi=0;gi<=4;gi++){var t2=gi/4, y2=TM+10+gi*14;
	    var R2=Math.round(t2<0.5?t2*2*255:255), G2=Math.round(t2<0.5?255:(1-(t2-0.5)*2)*200);
	    var B2=Math.round(t2<0.5?255*(1-t2*2):0);
	    ctx.fillStyle='rgb('+R2+','+G2+','+B2+')'; ctx.fillRect(lx,y2,14,10);
	    ctx.fillStyle='#777'; ctx.font='9px "Microsoft YaHei"'; ctx.fillText(Math.round(t2*40)+'期',lx+18,y2+9);
	  }
	}

	/* ===== Test02 报表分析 ===== */
var t2St=0, t2Stats=null;
function renderTest02(stats){
  t2St=t2St||0; if(!stats) stats=DATA.all; t2Stats=stats;
  setTimeout(function(){switchT2(0);},10);
  return '<div class="card"><h2>Test02 - 报表分析</h2><div class="note">频率分布、关联分析、统计直方图</div>'+
    '<div class="subtab-bar t2SubTab">'+
      '<button class="subtab-btn'+(t2St===0?' active':'')+'" data-st="0" onclick="switchT2(0)">频率分布</button>'+
      '<button class="subtab-btn'+(t2St===1?' active':'')+'" data-st="1" onclick="switchT2(1)">关联分析</button>'+
      '<button class="subtab-btn'+(t2St===2?' active':'')+'" data-st="2" onclick="switchT2(2)">统计直方图</button>'+
    '</div><div class="t2Body"></div></div>';
}
function renderTest02Year(){
  return '<div class="card"><h2>Test02 - 报表分析</h2><div class="note">每年独立分析。点击年份切换。</div>'+
    '<div class="year-btns t2YearBtns"></div>'+
    '<div class="subtab-bar t2SubTab">'+
      '<button class="subtab-btn active" data-st="0" onclick="switchT2(0)">频率分布</button>'+
      '<button class="subtab-btn" data-st="1" onclick="switchT2(1)">关联分析</button>'+
      '<button class="subtab-btn" data-st="2" onclick="switchT2(2)">统计直方图</button>'+
    '</div><div class="t2Body"></div></div>';
}
function fillTest02Year(idx){
  t2St=0; var y=DATA.years[idx]; t2Stats=y.stats;
  var nY=DATA.years.length;
  var page=document.querySelector('.tab-page.active');
  page.querySelectorAll('.t2YearBtns .year-btn').forEach(function(b,pos){
    b.classList.toggle('active',(nY-1-pos)===idx);
  });
  page.querySelectorAll('.t2SubTab .subtab-btn').forEach(function(b,i){
    b.classList.toggle('active',i===0);
  });
  var body=page.querySelector('.t2Body'); body.innerHTML='';
  renderT2Content(0,t2Stats,body);
}
function switchT2(st){
  t2St=st;
  var page=document.querySelector('.tab-page.active');
  if(!page) return;
  var bar=page.querySelector('.t2SubTab'), body=page.querySelector('.t2Body');
  if(bar) bar.querySelectorAll('.subtab-btn').forEach(function(b){b.classList.toggle('active',parseInt(b.dataset.st)===st);});
  if(body){body.innerHTML='';renderT2Content(st,t2Stats||DATA.all,body);}
}
function renderT2Content(st,s,container){
  var BAR_COLORS=['#1a73e8','#e74c3c','#2e9e5b','#F39C12','#8e44ad','#1abc9c','#e67e22','#3498db','#e91e63','#00bcd4'];
  if(st===0){
    // === 频率分布（表格柱状图风格） ===
    var LIGHT=['#90b8e8','#ea9595','#8ed8ae','#f0d490','#c0a8dc','#8cd0d0','#f0be88','#8ab8e8','#ea90b8','#88d0dc','#bdd888','#dcb888'];
    var BOSE_COLORS={'红波':'#f87878','蓝波':'#48c8f2','绿波':'#6ce888'};
    var h0='<div class="grid2">';
    s.freqs.forEach(function(f,i){
      var rows=[], maxN=0, isZod=f.title==='生肖';
      f.rows.forEach(function(r){if(r.n>maxN)maxN=r.n;});
      f.rows.forEach(function(r,j){
        var col, label;
        if(f.title==='波色'){
          col=BOSE_COLORS[r.k]||LIGHT[j%12];
          label=r.k;
        }else if(isZod){
          col=LIGHT[j%12];
          label='<span style="background:'+(SHOU_SET2[r.k]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+r.k+'</span>';
        }else{
          col=LIGHT[j%12];
          label=r.k;
        }
        var bar='<div style="text-align:left;width:200px"><span class="gap-bar" style="width:'+Math.max(r.n/maxN*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+r.n+'次</span></div>';
        rows.push([label,r.n,parseFloat((r.p*100).toFixed(1))+'%',bar]);
      });
      var note=(f.note||'').replace(/^按特码/,'');
      var htmlCols=isZod?[0,3]:[3];
      h0+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>'+f.title+'</h2><div class="note">'+note+'</div>'+
        tableHtml(['类型','次数','占比','分布'],rows,{sortAll:true,htmlCols:htmlCols})+'</div>';
    });
    h0+='</div>';
    container.innerHTML=h0;
    attachSort(container);
  }else if(st===1){
    // === 关联分析（表格柱状图风格） ===
    var h1='';
    // 1. 冷热转移概率
    if(s.transitions){
      var tr=s.transitions; var sum=tr.hotCold+tr.coldHot+tr.hotHot+tr.coldCold||1;
      var transRows=[
        ['持续热(热→热)',tr.hotHot,parseFloat((tr.hotHot/sum*100).toFixed(1))+'%',
          '<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(tr.hotHot/sum*100,2)+'%;background:#e74c3c"></span><span style="font-size:11px;color:#555;margin-left:6px">'+tr.hotHot+'次</span></div>'],
        ['持续冷(冷→冷)',tr.coldCold,parseFloat((tr.coldCold/sum*100).toFixed(1))+'%',
          '<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(tr.coldCold/sum*100,2)+'%;background:#3498db"></span><span style="font-size:11px;color:#555;margin-left:6px">'+tr.coldCold+'次</span></div>'],
        ['热→冷',tr.hotCold,parseFloat((tr.hotCold/sum*100).toFixed(1))+'%',
          '<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(tr.hotCold/sum*100,2)+'%;background:#F39C12"></span><span style="font-size:11px;color:#555;margin-left:6px">'+tr.hotCold+'次</span></div>'],
        ['冷→热',tr.coldHot,parseFloat((tr.coldHot/sum*100).toFixed(1))+'%',
          '<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(tr.coldHot/sum*100,2)+'%;background:#2e9e5b"></span><span style="font-size:11px;color:#555;margin-left:6px">'+tr.coldHot+'次</span></div>']
      ];
      h1+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>1. 冷热转移概率</h2><div class="note">热=当前遗漏&lt;均值('+s.hc_avg+'期)、冷=当前遗漏&gt;均值。</div>'+
        tableHtml(['状态','次数','占比','分布'],transRows,{sortAll:true,htmlCols:[3]})+'</div>';
    }
    // 2. 连肖次数分布
    if(s.lian_xiao){
      var zods='鼠牛虎兔龙蛇马羊猴鸡狗猪'.split('');
      var lxRows=[], maxW=0;
      zods.forEach(function(z){
        var lx=s.lian_xiao[z]||{}, w=(lx.cnt2||0)+(lx.cnt3||0)*2;
        if(w>maxW)maxW=w;
        var tag='<span style="background:'+(SHOU_SET2[z]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+z+'</span>';
        lxRows.push([tag,lx.cnt2||0,lx.cnt3||0,w]);
      });
      var lxRows2=lxRows.map(function(r){
        var bar='<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(r[3]/maxW*100,2)+'%;background:'+(SHOU_SET2[r[0].match(/>([^<]+)</)[1]]?'#F1948A':'#82C99A')+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+r[3]+'</span></div>';
        return [r[0],r[1],r[2],r[3],bar];
      });
      h1+='<div class="card" style="box-shadow:none;border:1px solid #eee;margin-top:12px"><h2>2. 连肖次数分布</h2><div class="note">加权=2连×1+3连×2，柱长=加权次数，红=野兽、绿=家禽</div>'+
        tableHtml(['生肖','2连肖','3连+','加权次数','分布'],lxRows2,{sortAll:true,htmlCols:[0,4]})+'</div>';
    }
    if(!h1) h1='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>关联分析</h2><div class="note">暂无冷热转移或连肖数据</div></div>';
    container.innerHTML=h1;
    attachSort(container);
  }else if(st===2){
    // === 统计直方图（表格柱状图风格，参考 Test tab） ===
    var total=s.miss_num.length, gaps=s.miss_num.map(function(r){return r.gap;});
    var avg=Math.round(gaps.reduce(function(a,b){return a+b;},0)/total);
    var maxGap=Math.max.apply(null,gaps);
    var maxNum=s.miss_num.sort(function(a,b){return b.cnt-a.cnt;})[0]||{};
    var coldCnt=s.miss_num.filter(function(r){return r.gap>avg;}).length;
    var hotCnt=s.miss_num.filter(function(r){return r.gap<avg;}).length;
    var hc=s.hotcold.slice().sort(function(a,b){return b.cnt-a.cnt;});
    var hotN=hc[0]||{}, coldN=hc[hc.length-1]||{};

    // stat cards
    var h='<div class="stat-cards" style="margin-bottom:16px">';
    h+='<div class="stat-card"><div class="lbl">遗漏均值</div><div class="val">'+avg+'期</div><div class="sub">冷('+coldCnt+') 热('+hotCnt+') 温('+(49-coldCnt-hotCnt)+')</div></div>';
    var hot5h=hc.slice(0,5), cold5h=hc.slice(-5).reverse();
    h+='<div class="stat-card"><div class="lbl">最长遗漏</div><div class="val">'+maxNum.k+'</div><div class="sub">已漏 '+maxGap+' 期</div></div>';
    h+='<div class="stat-card"><div class="lbl">热号 Top5</div><div class="val">'+hotN.k+'</div><div class="hot5-sub">'+hot5h.map(function(x){return x.k+' ('+x.cnt+'次)';}).join('  ')+'</div></div>';
    h+='<div class="stat-card"><div class="lbl">冷号 Top5</div><div class="val">'+coldN.k+'</div><div class="hot5-sub">'+cold5h.map(function(x){return x.k+' ('+x.cnt+'次)';}).join('  ')+'</div></div>';
    h+='</div>';

    // 1. 遗漏分布直方图
    var bins=[{label:'0期(刚出)',min:0,max:0},{label:'1-5期',min:1,max:5},
              {label:'6-10期',min:6,max:10},{label:'11-20期',min:11,max:20},
              {label:'21-30期',min:21,max:30},{label:'30期+',min:31,max:9999}];
    var maxCnt=0; bins.forEach(function(bn){var c=s.miss_num.filter(function(r){return r.gap>=bn.min&&r.gap<=bn.max;}).length;if(c>maxCnt)maxCnt=c;});
    var rows1=[];
    bins.forEach(function(bn){
      var nums=s.miss_num.filter(function(r){return r.gap>=bn.min&&r.gap<=bn.max;});
      var col=bn.min>=30?'#e74c3c':bn.min>=15?'#F39C12':'#4CAF50';
      var bar='<div style="text-align:left;width:200px"><span class="gap-bar" style="width:'+Math.max(nums.length/maxCnt*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+nums.length+'个</span></div>';
      rows1.push([bn.label,nums.length,bar,parseFloat((nums.length/total*100).toFixed(1))+'%',nums.map(function(r){return r.k;}).join(',')]);
    });
    h+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>1. 遗漏分布直方图</h2><div class="note">号码按当前遗漏分组，绿=偏热、黄=温、红=冷</div>'+
      tableHtml(['区间','号码数','分布','占比','号码列表'],rows1,{sortAll:true,htmlCols:[2]})+'</div>';

    // 2. 号码出现分布
    var bins2=[];
    for(var b=1;b<=49;b+=5) bins2.push({label:b+'-'+Math.min(b+4,49),min:b,max:Math.min(b+4,49)});
    var maxCnt2=0; bins2.forEach(function(bn){var c=s.miss_num.filter(function(r){var n=parseInt(r.k);return n>=bn.min&&n<=bn.max;}).reduce(function(ss,r){return ss+r.cnt;},0);if(c>maxCnt2)maxCnt2=c;});
    var rows2=[];
    bins2.forEach(function(bn,i){
      var nums=s.miss_num.filter(function(r){var n=parseInt(r.k);return n>=bn.min&&n<=bn.max;});
      var cnt=nums.reduce(function(ss,r){return ss+r.cnt;},0);
      var col=BAR_COLORS[i%10];
      var bar='<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(cnt/maxCnt2*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+cnt+'次</span></div>';
      rows2.push([bn.label,cnt,bar,parseFloat((cnt/s.overview.total*100).toFixed(1))+'%',nums.map(function(r){return r.k;}).join(',')]);
    });
    h+='<div class="card" style="box-shadow:none;border:1px solid #eee;margin-top:12px"><h2>2. 号码出现分布</h2><div class="note">号码按组距5分组，柱长=出现总次数，观察是否均匀分布</div>'+
      tableHtml(['区间','次数','分布','占比','号码列表'],rows2,{sortAll:true,htmlCols:[2]})+'</div>';

    // 3. 号码出现间隔分布（选出现次数最多的号码）
    if(maxNum){
      var temaSeq=s.trend.tema, gaps3=[], lastIdx=-1, tn=parseInt(maxNum.k);
      for(var ti=0;ti<temaSeq.length;ti++){if(temaSeq[ti]===tn){if(lastIdx>=0)gaps3.push(ti-lastIdx-1);lastIdx=ti;}}
      var bins3=[{label:'1期(连续)',min:1,max:1},{label:'2-5期',min:2,max:5},{label:'6-10期',min:6,max:10},{label:'11-20期',min:11,max:20},{label:'20期+',min:21,max:9999}];
      if(gaps3.length>0){
        var total3=gaps3.length, maxCnt3=0; bins3.forEach(function(bn){var c=gaps3.filter(function(g){return g>=bn.min&&g<=bn.max;}).length;if(c>maxCnt3)maxCnt3=c;});
        var rows3=[];
        bins3.forEach(function(bn,i){
          var cnt=gaps3.filter(function(g){return g>=bn.min&&g<=bn.max;}).length;
          var col=i<2?'#4CAF50':i<4?'#F39C12':'#e74c3c';
          var bar='<div style="text-align:left;width:220px"><span class="gap-bar" style="width:'+Math.max(cnt/maxCnt3*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+cnt+'次</span></div>';
          rows3.push([bn.label,cnt,bar,parseFloat((cnt/total3*100).toFixed(1))+'%']);
        });
        h+='<div class="card" style="box-shadow:none;border:1px solid #eee;margin-top:12px"><h2>3. 号码'+maxNum.k+' 出现间隔分布</h2><div class="note">该号码共出现'+maxNum.cnt+'次，相邻两次间隔共'+total3+'组</div>'+
          tableHtml(['间隔区间','次数','分布','占比'],rows3,{sortAll:true,htmlCols:[2]})+'</div>';
      }
    }
    container.innerHTML=h;
    attachSort(container);
  }
}

function renderLiankai(s){
  var l=s.liankai;
  var rows=[['特码与上期重号',l.rep,l.rep_p],['本期特码在上期平码中',l.tip,l.tip_p]];
  l.overlap.forEach(function(o){rows.push(['平码与上期重叠'+o.k+'个',o.n,o.p]);});
  var h='<div class="card"><h2>连开 / 重号（相邻期比较，共 '+l.m+' 组）</h2>'+
    '<div class="note">占比=次数 ÷ 组数</div>'+
    tableHtml(['指标','次数','占比'],rows,{sortAll:true,pctCols:[2]})+'</div>';
  var rankHot=function(data){return makeMissHot(data,{gapCol:2,mxCol:3});};
  var rattr=s.rank_attr.map(function(r,i){
    var ml=r.mx_last||['',''];
    return [i+1,r.k,r.gap,r.mx,(ml[0]||''),(ml[1]||''),(r.last[0]?r.last[0]+'期':''),r.last[1]||''];
  });
  h+='<div class="card"><h2>属性遗漏排行</h2><div class="note">各属性当前遗漏排名，越靠前越久未出</div>'+
    tableHtml(['排名','属性','当前遗漏','历史最大遗漏','最大·期','最大·日期','最近·期','最近·日期'],rattr,{sortAll:true,hotFn:rankHot(rattr)})+'</div>';
  return h;
}

function renderYear(){
  var h='<div class="card"><h2>频率统计</h2><div class="note">每年独立统计（遗漏在该年内计算）。点击年份切换。</div>';
  h+='<div class="year-btns" id="yearBtns"></div><div id="yearBody"></div></div>';
  return h;
}
function fillYear(idx){
  var y=DATA.years[idx];
  var s=y.stats;
  var nYears=DATA.years.length;
  document.querySelectorAll('#yearBtns .year-btn').forEach(function(b,pos){
    // 按钮是倒序渲染的：DOM 位置 pos 对应 DATA 下标 nYears-1-pos
    b.classList.toggle('active',(nYears-1-pos)===idx);
  });
  var h='<div class="stat-cards" style="margin-bottom:16px">';
  h+='<div class="stat-card"><div class="lbl">'+y.year+'年 期数</div><div class="val">'+y.n+'</div><div class="sub">'+y.from+' ~ '+y.to+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">🔥 热号 Top3</div><div class="val">'+s.overview.hot5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+s.overview.hot5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">❄️ 冷号 Top3</div><div class="val">'+s.overview.cold5.slice(0,3).map(function(x){return x.k;}).join(' ')+'</div><div class="hot5-sub">'+s.overview.cold5.slice(0,3).map(function(x){return x.k+' ('+x.n+'次)';}).join('  ')+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最久未出</div><div class="val">'+s.overview.most_missing.k+'</div><div class="sub">'+s.overview.most_missing.gap+'期</div></div>';
  h+='</div>';
  var body2='';
  var freqNav=[]; freqNav.push({id:'yr-freq',label:'频率统计'});
  body2+='<div class="subttl" id="yr-freq">频率统计</div><div>';
  var LIGHT2=['#90b8e8','#ea9595','#8ed8ae','#f0d490','#c0a8dc','#8cd0d0','#f0be88','#8ab8e8','#ea90b8','#88d0dc','#bdd888','#dcb888'];
  var BOSE_CLRS={'红波':'#f87878','蓝波':'#48c8f2','绿波':'#6ce888'};
  s.freqs.forEach(function(f,fi){
    var fid='yr-freq-'+fi;
    freqNav.push({id:fid,label:f.title});
    var isZodY=f.title==='生肖';
    var frows=f.rows.map(function(r){return [isZodY?zodLabel(r.k):r.k,r.n,r.p];});
    var avgP=frows.length? frows.reduce(function(a,r){return a+r[2];},0)/frows.length : 0;
    var fHot=function(rowArr,ci,val){return ci===2&&avgP>0&&val>avgP*1.3;};
    var leftTbl=tableHtml(['类型','次数','实际占比'],frows,{sortAll:true,pctCols:[2],typeBgCol:0,hotFn:fHot});
    var maxN=0; f.rows.forEach(function(r){if(r.n>maxN)maxN=r.n;});
    var barRows=[];
    f.rows.forEach(function(r,j){
      var col; if(f.title==='波色'){col=BOSE_CLRS[r.k]||LIGHT2[j%12];}else{col=LIGHT2[j%12];}
      var label=isZodY?'<span style="background:'+(SHOU_SET2[r.k]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:12px;font-weight:bold">'+r.k+'</span>':r.k;
      var bar='<div style="text-align:left;width:180px"><span class="gap-bar" style="width:'+Math.max(r.n/maxN*100,2)+'%;background:'+col+'"></span><span style="font-size:11px;color:#555;margin-left:6px">'+r.n+'次</span></div>';
      barRows.push([label,r.n,parseFloat((r.p*100).toFixed(1))+'%',bar]);
    });
    var htmlCols=isZodY?[0,3]:[3];
    var rightTbl=tableHtml(['类型','次数','占比','分布'],barRows,{sortAll:true,htmlCols:htmlCols,typeBgCol:0});
    body2+='<div class="card" id="'+fid+'" style="box-shadow:none;border:1px solid #eee"><h2>'+f.title+'</h2>'+
      '<div style="display:flex;gap:20px;flex-wrap:wrap"><div style="flex:1;min-width:240px">'+leftTbl+'</div><div style="flex:1;min-width:340px">'+rightTbl+'</div></div></div>';
  });
  body2+='</div>';
  // 热温冷 与 遗漏榜 左右各 50%
  body2+='<div class="subttl" id="yr-hot">号码热温冷 / 遗漏榜</div><div class="grid2">';
  var zmYr=DATA.zodiac_map[y.year]||{};
  function zxTag(n){var z=zmYr[n]||''; return '<span style="'+(z?'background:'+(SHOU_SET2[z]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:11px':'')+'">'+z+'</span>';}
  var yhc=s.hotcold.map(function(r){var n=parseInt(r.k); return [r.k,zxTag(n),r.gap,r.cnt,r.lvl];});
  var yhcHot=function(rowArr,ci,val){if(ci===2){if(String(rowArr[4])==='冷')return true;var g=parseFloat(val);return !isNaN(g)&&g>=30;}return false;};
  body2+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码热温冷（本年均值 '+s.hc_avg+' 期）</h2>'+
    tableHtml(['号码','生肖','当前遗漏','出现次数','热温冷'],yhc,{sortAll:true,lvlCol:4,htmlCols:[1],hotFn:yhcHot})+'</div>';
  var yrank=s.rank_num.map(function(r,i){var n=parseInt(r.k); return [i+1,r.k,zxTag(n),r.gap,r.mx];});
  body2+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码遗漏排行榜（本年）</h2>'+
    tableHtml(['排名','号码','生肖','当前遗漏','历史最大遗漏'],yrank,{sortAll:true,htmlCols:[2],hotFn:makeMissHot(yrank,{gapCol:3,mxCol:4})})+'</div>';
  body2+='</div>';
  body2+='<div class="subttl" id="yr-lk">连开 / 重号（本年）</div>';
  var l=s.liankai;var rows=[['特码与上期重号',l.rep,l.rep_p],['本期特码在上期平码中',l.tip,l.tip_p]];
  l.overlap.forEach(function(o){rows.push(['平码与上期重叠'+o.k+'个',o.n,o.p]);});
  body2+=tableHtml(['指标','次数','占比'],rows,{sortAll:true,pctCols:[2]});
  freqNav.push({id:'yr-hot',label:'热温冷/遗漏榜'});
  freqNav.push({id:'yr-lk',label:'连开/重号'});
  h+=withSideNav(freqNav, body2);
  var body=document.getElementById('yearBody');
  body.innerHTML=h;
  attachSort(body);
  attachSideNav(body);
}

/* ---- 走势图 ---- */
var TREND_DEFS=[
  {key:'dx', title:'大小', cols:['大','小'], colors:{'大':'#F8C471','小':'#C39BD3'}},
  {key:'ds', title:'单双', cols:['单','双'], colors:{'单':'#85C1E9','双':'#F7DC6F'}},
  {key:'bose', title:'波色', cols:['红波','蓝波','绿波'], colors:{'红波':'#FD7272','蓝波':'#2FC8EE','绿波':'#65EC74'}},
  {key:'qs', title:'家禽野兽', cols:['家禽','野兽'], colors:{'家禽':'#82C99A','野兽':'#F1948A'}}
];
var TREND_DEFS2=[
  {key:'wx', title:'五行', cols:['金','木','水','火','土'], colors:{'金':'#F9E79F','木':'#ABEBC6','水':'#AED6F1','火':'#F1948A','土':'#D7BDE2'}},
  {key:'tou', title:'号头(0-4)', cols:['0','1','2','3','4'], colors:{'0':'#E8DAEF','1':'#D4E6F1','2':'#D5F5E3','3':'#FCF3CF','4':'#FADBD8'}},
  {key:'wei', title:'号尾(0-9)', cols:['0','1','2','3','4','5','6','7','8','9'], colors:{}}
];
function textColorFor(bg){
  var m=/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(bg); if(!m) return '#333';
  var lum=0.299*parseInt(m[1],16)+0.587*parseInt(m[2],16)+0.114*parseInt(m[3],16);
  return lum>150?'#333':'#fff';
}
var AUTO_COLORS=['#F8C471','#85C1E9','#F1948A','#82C99A','#AED6F1','#D7BDE2','#F9E79F','#ABEBC6','#E8DAEF','#F5B7B1'];
var CI_COLORS=['#E8A13B','#1a73e8','#e74c3c','#2e9e5b'];
function trendColHtml(tr, def, ci){
  var seq=tr[def.key], labels=tr.labels, dates=tr.dates||[];
  var borderColor=CI_COLORS[ci%CI_COLORS.length];
  var h='<div class="trend-col" style="border-top:3px solid '+borderColor+'"><h3 style="color:'+borderColor+'">'+def.title+'</h3>';
  h+='<table class="trend-tb"><thead><tr><th>日期</th><th>期数</th>';
  def.cols.forEach(function(c){h+='<th>'+c+'</th>';});
  h+='</tr></thead><tbody>';
  for(var i=0;i<labels.length;i++){
    h+='<tr><td class="dt">'+(dates[i]||'')+'</td><td class="qi">'+labels[i]+'</td>';
    def.cols.forEach(function(c,ci2){
      if(seq[i]===c){
        var bg=def.colors[c]||AUTO_COLORS[ci2%AUTO_COLORS.length];
        h+='<td class="trend-cell" style="background:'+bg+';color:'+textColorFor(bg)+'">'+c+'</td>';
      }
      else h+='<td></td>';
    });
    h+='</tr>';
  }
  return h+'</tbody></table></div>';
}
function renderTrendBody(tr){
  var h='<div class="trend-wrap">';
  TREND_DEFS.forEach(function(def,ci){h+=trendColHtml(tr,def,ci);});
  return h+'</div>';
}
function renderTrendBody2(tr){
  var h='<div class="trend-wrap">';
  TREND_DEFS2.forEach(function(def,ci){h+=trendColHtml(tr,def,ci);});
  return h+'</div>';
}

/* 号码走势 Canvas: 表头 sticky + 内容滚动, 左侧日期+期数, X=1-49, 上=新→下=旧 */
var NCELL=21, NPAD=140, NDATE=72, NPER=58;
function drawNumTrendHead(canvas, MAX){
  var ctx=canvas.getContext('2d');
  var W=NPAD+49*NCELL+10, H=22;
  canvas.width=W; canvas.height=H;
  ctx.fillStyle='#fff'; ctx.fillRect(0,0,W,H);
  ctx.font='10px "Microsoft YaHei"'; ctx.fillStyle='#333'; ctx.textAlign='center';
  // 左列表头 + 边框
  ctx.strokeStyle='#999'; ctx.lineWidth=1;
  ctx.strokeRect(0,0,NDATE,H); ctx.fillText('日期',NDATE/2,H/2+3);
  ctx.strokeRect(NDATE,0,NPER,H); ctx.fillText('期数',NDATE+NPER/2,H/2+3);
  ctx.strokeRect(NPAD-2,0,49*NCELL+2,H);
  // X轴号码1-49
  for(var x=1;x<=49;x++){
    var cx=NPAD+(x-1)*NCELL;
    ctx.strokeRect(cx,0,NCELL,H); ctx.fillText(x,cx+NCELL/2,H/2+3);
  }
}
function drawNumTrendBody(canvas, tr){
  var CELL=NCELL, PAD=NPAD, MAX=Math.min(tr.labels.length,200);
  var labels=tr.labels, dates=tr.dates||[];
  var ctx=canvas.getContext('2d');
  var W=PAD+49*CELL+10, H=MAX*CELL+2;
  canvas.width=W; canvas.height=H;
  ctx.fillStyle='#fff'; ctx.fillRect(0,0,W,H);
  for(var r=0;r<MAX;r++){
    var idx=r, t=tr.tema[idx], b=tr.bose[idx];
    var cy=r*CELL;
    // 左侧日期+期数（灰底+边框）
    ctx.fillStyle='#fafbfd'; ctx.fillRect(0,cy,NDATE,CELL); ctx.fillRect(NDATE,cy,NPER,CELL);
    ctx.strokeStyle='#999'; ctx.lineWidth=1;
    ctx.strokeRect(0,cy,NDATE,CELL); ctx.strokeRect(NDATE,cy,NPER,CELL);
    ctx.fillStyle='#7a8493'; ctx.font='10px "Microsoft YaHei"'; ctx.textAlign='center';
    var dt=dates[idx]||''; ctx.fillText(dt,NDATE/2,cy+CELL/2+3);
    ctx.fillStyle='#999'; ctx.textAlign='center'; ctx.fillText(labels[idx],NDATE+NPER/2,cy+CELL/2+3);
    // 号码网格
    for(var c=1;c<=49;c++){
      var cx=PAD+(c-1)*CELL, isHit=(c===t);
      var bg=isHit?(b==='红波'?'#FD7272':b==='蓝波'?'#2FC8EE':b==='绿波'?'#65EC74':'#fff'):'#fcfcfc';
      ctx.fillStyle=bg; ctx.fillRect(cx,cy,CELL,CELL);
      ctx.strokeStyle='#999'; ctx.lineWidth=1; ctx.strokeRect(cx,cy,CELL,CELL);
      if(isHit){
        ctx.fillStyle=textColorFor(bg); ctx.font='bold 10px "Microsoft YaHei"'; ctx.textAlign='center';
        ctx.fillText(t,cx+CELL/2,cy+CELL/2+3);
      }
    }
  }
}
function renderNumPanel(tr, MAX){
  MAX=MAX||Math.min(tr.labels.length,200);
  return '<div class="note">X=号码1-49 / Y=期数（上=新→下=旧，最近'+MAX+'期），命中格按波色着色</div>'+
    '<div class="canvas-wrap">'+
    '<div class="canvas-head-wrap"><canvas id="numTrendHead"></canvas></div>'+
    '<div class="canvas-body-wrap"><canvas id="numTrendBody"></canvas></div></div>';
}

/* 遗漏报表：号码当前遗漏 + 横条可视化 + 生肖 + 最近一期 + 可排序 */
function renderGapPanel(s){
  var miss=s.miss_num, mx=Math.max.apply(null,miss.map(function(r){return r.gap;}))||1;
  var latestYear=DATA.years[DATA.years.length-1].year;
  var zm=DATA.zodiac_map[latestYear]||{};
  var rows=miss.map(function(r){
    var pct=r.gap/mx*100, col=r.gap>=30?'#e74c3c':r.gap>=15?'#F39C12':'#4CAF50';
    var bar='<div class="gap-cell"><span class="gap-bar" style="width:'+Math.max(pct,2)+'%;background:'+col+'"></span></div>';
    var last=r.last||['','',''];
    var num=parseInt(r.k);
    var zx=zm[num]||'';
    var zxCol='<span class="zod-tag" style="'+(zx?'background:'+(SHOU_SET2[zx]?'#F1948A':'#82C99A')+';color:#fff;padding:2px 6px;border-radius:3px;font-size:11px':'')+'">'+zx+'</span>';
    return ['<b>'+esc(r.k)+'</b>', zxCol, r.gap+'期', bar, r.cnt+'次', r.mx+'期',
      (last[0]?last[0]+'年':''), (last[1]?last[1]+'期':''), last[2]||''];
  });
  return '<div class="note">号码当前遗漏期数，横条越长/越红表示遗漏越久（点击表头 ⇅ 排序）</div>'+
    tableHtml(['号码','生肖','当前遗漏','遗漏可视化','出现次数','历史最大','最近·年','最近·期','最近·日期'], rows,
      {sortAll:true, htmlCols:[0,1,3], hotFn:function(rr,ci,v){ return ci===2&&parseInt(rr[2])>=30; }});
}

/* 走势图 Tab - 子Tab 切换 */
var trendSt=0, trendYearSt=0, trendYearIdx=0;
function switchTrendSub(st){
  trendSt=st;
  var bar=document.getElementById('trendSubTab'), body=document.getElementById('trendSubBody');
  if(!bar||!body) return;
  bar.querySelectorAll('.subtab-btn').forEach(function(b){b.classList.toggle('active',parseInt(b.dataset.st)===st);});
  var s=DATA.all;
  if(st===1){ var mx1=Math.min(s.trend.labels.length,200); body.innerHTML=renderNumPanel(s.trend,mx1); setTimeout(function(){drawNumTrendHead(document.getElementById('numTrendHead'),mx1);drawNumTrendBody(document.getElementById('numTrendBody'),s.trend);},50); }
  else if(st===2){ body.innerHTML=renderGapPanel(s); attachSort(body); }
  else if(st===3){ body.innerHTML='<div class="note">五行、号头、号尾属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</div>'+renderTrendBody2(s.trend); }
  else{ body.innerHTML='<div class="note">大小、单双、波色、家禽野兽属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</div>'+renderTrendBody(s.trend); }
  body.scrollTop=0;
}
function switchTrendYearSub(st){
  trendYearSt=st;
  fillTrendYear(trendYearIdx,st);
}
function renderTrend(s){
  trendSt=trendSt||0;
  return '<div class="card"><h2>走势图</h2>'+
    '<div class="subtab-bar" id="trendSubTab">'+
      '<button class="subtab-btn'+(trendSt===0?' active':'')+'" data-st="0" onclick="switchTrendSub(0)">属性走势</button>'+
      '<button class="subtab-btn'+(trendSt===3?' active':'')+'" data-st="3" onclick="switchTrendSub(3)">属性走势02</button>'+
      '<button class="subtab-btn'+(trendSt===1?' active':'')+'" data-st="1" onclick="switchTrendSub(1)">号码走势</button>'+
      '<button class="subtab-btn'+(trendSt===2?' active':'')+'" data-st="2" onclick="switchTrendSub(2)">遗漏报表</button>'+
    '</div><div id="trendSubBody">'+renderTrendSub0(s)+'</div></div>';
}
function renderTrendSub0(s){
  if(trendSt===1) return renderNumPanel(s.trend);
  if(trendSt===2) return renderGapPanel(s);
  if(trendSt===3) return '<div class="note">五行、号头、号尾属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</div>'+renderTrendBody2(s.trend);
  return '<div class="note">大小、单双、波色、家禽野兽属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</div>'+renderTrendBody(s.trend);
}
function renderTrendYear(){
  trendYearSt=trendYearSt||0;
  return '<div class="card"><h2>走势图</h2>'+
    '<div class="note">按年查看走势。点击年份切换。</div>'+
    '<div class="subtab-bar" id="trendYearSubTab">'+
      '<button class="subtab-btn'+(trendYearSt===0?' active':'')+'" data-st="0" onclick="switchTrendYearSub(0)">属性走势</button>'+
      '<button class="subtab-btn'+(trendYearSt===3?' active':'')+'" data-st="3" onclick="switchTrendYearSub(3)">属性走势02</button>'+
      '<button class="subtab-btn'+(trendYearSt===1?' active':'')+'" data-st="1" onclick="switchTrendYearSub(1)">号码走势</button>'+
      '<button class="subtab-btn'+(trendYearSt===2?' active':'')+'" data-st="2" onclick="switchTrendYearSub(2)">遗漏报表</button>'+
    '</div>'+
    '<div class="year-btns" id="trendYearBtns"></div><div id="trendYearBody"></div></div>';
}
function fillTrendYear(idx,st){
  if(st!==undefined) trendYearSt=st;
  st=trendYearSt; trendYearIdx=idx;
  var y=DATA.years[idx], nY=DATA.years.length;
  var bar=document.getElementById('trendYearSubTab');
  if(bar) bar.querySelectorAll('.subtab-btn').forEach(function(b){b.classList.toggle('active',parseInt(b.dataset.st)===st);});
  document.querySelectorAll('#trendYearBtns .year-btn').forEach(function(b,pos){b.classList.toggle('active',(nY-1-pos)===idx);});
  var s=y.stats, body='<div style="margin:6px 0 12px;color:#666;font-size:13px">'+y.year+'年 共 '+y.n+' 期（'+y.from+' ~ '+y.to+'）</div>';
  if(st===1){ var mx2=Math.min(s.trend.labels.length,200); body+=renderNumPanel(s.trend,mx2); }
  else if(st===2){ body+=renderGapPanel(s); }
  else if(st===3){ body+=renderTrendBody2(s.trend); }
  else{ body+=renderTrendBody(s.trend); }
  document.getElementById('trendYearBody').innerHTML=body;
  document.getElementById('trendYearBody').scrollTop=0;
  if(st===1) setTimeout(function(){ drawNumTrendHead(document.getElementById('numTrendHead'),mx2); drawNumTrendBody(document.getElementById('numTrendBody'),s.trend); },50);
}

/* ---- 历史开奖记录（按月切换） ---- */
function renderHistory(){
  return '<div class="card"><h2>历史开奖记录</h2>'+
    '<div class="note">先选年份，再从左侧菜单选当年月份，查看每期开奖详细结果（含生肖/颜色/大小/单双等属性）</div>'+
    '<div class="year-btns" id="histYearBtns"></div>'+
    '<div class="side-layout"><div class="side-nav" id="histMonthNav"></div>'+
    '<div class="side-body hist-wrap"><div id="histBody"></div></div></div></div>';
}
/* 历史记录状态：按年分组 DATA.history 的下标 */
var HIST_YEARS=null;
function histYearMap(){
  if(HIST_YEARS) return HIST_YEARS;
  var map={}, order=[];
  DATA.history.forEach(function(mo,idx){
    var y=mo.ym.slice(0,4);
    if(!map[y]){map[y]=[];order.push(y);}
    map[y].push(idx); // idx 指向 DATA.history
  });
  HIST_YEARS={map:map, order:order};
  return HIST_YEARS;
}
function fillHistYear(y){
  var hy=histYearMap();
  // 顶部年份高亮
  document.querySelectorAll('#histYearBtns .year-btn').forEach(function(b){b.classList.toggle('active',b.textContent===y+'年');});
  // 左侧月份菜单（当年，新→旧，DATA.history 本就新→旧）
  var months=hy.map[y];
  var nav=document.getElementById('histMonthNav');
  nav.innerHTML='';
  months.forEach(function(idx,pos){
    var b=document.createElement('button');b.className='sn-item'+(pos===0?' active':'');
    b.textContent=DATA.history[idx].ym;
    b.addEventListener('click',function(){
      nav.querySelectorAll('.sn-item').forEach(function(x){x.classList.remove('active');});
      b.classList.add('active');
      fillHistory(idx);
    });
    nav.appendChild(b);
  });
  fillHistory(months[0]); // 默认当年最新月
}
function fillHistory(idx){
  var mo=DATA.history[idx];
  var cols=['周期','日序','日期','期数','生肖','特码','大小','单双','波色','野兽','号头','号尾','颜色单双','组合'];
  var h='<table class="hist-tb"><thead><tr>';
  cols.forEach(function(c){h+='<th>'+c+'</th>';});
  h+='</tr></thead><tbody>';
  // 该月内按日期正序（旧→新），与参考图一致
  var rows=mo.rows.slice().reverse();
  rows.forEach(function(r,i){
    var col=boseCls(r.bose);
    h+='<tr>'
      +'<td>'+r.id+'</td>'
      +'<td>序'+('0'+(i+1)).slice(-2)+'</td>'
      +'<td>'+r.date.replace(/-/g,'/')+'</td>'
      +'<td>'+r.qishu+'期</td>'
      +'<td>'+r.tx+'</td>'
      +'<td class="'+col+'" style="font-weight:bold">'+r.tema+'</td>'
      +'<td>'+r.dx+'</td>'
      +'<td>'+r.ds+'</td>'
      +'<td class="'+col+'">'+r.bose+'</td>'
      +'<td>'+r.qs+'</td>'
      +'<td>'+r.tou+'</td>'
      +'<td>'+r.wei+'</td>'
      +'<td>'+r.colds+'</td>'
      +'<td>'+r.combo+'</td>'
      +'</tr>';
  });
  h+='</tbody></table>';
  document.getElementById('histBody').innerHTML=h;
}

var TABS=[
  {name:'首页概览',mode:'all',render:function(){return renderOverview(DATA.all);}},
  {name:'频率统计',mode:'all',render:function(){return renderFreq(DATA.all);}},
  {name:'遗漏/冷热',mode:'all',render:function(){return renderMiss(DATA.all);}},
  {name:'走势图',mode:'all',render:function(){return renderTrend(DATA.all);}},
  {name:'首页概览',mode:'year',render:renderOverviewYear},
  {name:'频率统计',mode:'year',render:renderYear},
  {name:'遗漏/冷热',mode:'year',render:renderMissYear},
  {name:'走势图',mode:'year',render:renderTrendYear},
  {name:'历史记录',mode:'both',render:renderHistory},
  {name:'连开/重号',mode:'both',render:function(){return renderLiankai(DATA.all);}},
  {name:'Test',mode:'year',render:renderGapDistYear},
];

function showTab(i){
  tabEls.forEach(function(b,idx){b.classList.toggle('active',idx===i);});
  pageEls.forEach(function(p,idx){p.classList.toggle('active',idx===i);});
  var page=pageEls[i];
  if(!page.dataset.done){
    page.innerHTML=TABS[i].render();
    attachSort(page);
    attachSideNav(page);
    if(i===6){
      var myb=page.querySelector('#missYearBtns');
      for(var km=DATA.years.length-1;km>=0;km--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillMissYear(idx);});myb.appendChild(b);
        })(km);
      }
      fillMissYear(DATA.years.length-1);
    }
    if(i===4){
      var oyb=page.querySelector('#overviewYearBtns');
      for(var ko=DATA.years.length-1;ko>=0;ko--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillOverviewYear(idx);});oyb.appendChild(b);
        })(ko);
      }
      fillOverviewYear(DATA.years.length-1);
    }
    if(i===5){
      var yb=page.querySelector('#yearBtns');
      // 从新到旧排序（2026→2020）：倒序遍历，idx 仍指向 DATA.years 真实下标
      for(var k=DATA.years.length-1;k>=0;k--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillYear(idx);});yb.appendChild(b);
        })(k);
      }
      fillYear(DATA.years.length-1); // 默认最新年
    }
    if(i===7){
      var tyb=page.querySelector('#trendYearBtns');
      for(var k2=DATA.years.length-1;k2>=0;k2--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillTrendYear(idx);});tyb.appendChild(b);
        })(k2);
      }
      fillTrendYear(DATA.years.length-1);
    }
    if(i===10){
      var gyb=page.querySelector('#gapDistYearBtns');
      for(var kg=DATA.years.length-1;kg>=0;kg--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillGapDistYear(idx);});gyb.appendChild(b);
        })(kg);
      }
      fillGapDistYear(DATA.years.length-1);
    }
    if(TABS[i].name==='历史记录'){
      var hy=histYearMap();
      var hyb=page.querySelector('#histYearBtns');
      hy.order.forEach(function(y){
        var b=document.createElement('button');b.className='year-btn';b.textContent=y+'年';
        b.addEventListener('click',function(){fillHistYear(y);});hyb.appendChild(b);
      });
      fillHistYear(hy.order[0]); // 默认最新年
    }
    page.dataset.done='1';
    // 号码走势初始绘制
    if(TABS[i].name==='走势图' && trendSt===1){
      setTimeout(function(){ var h=document.getElementById('numTrendHead'),b=document.getElementById('numTrendBody'); if(h&&b){ var mx0=Math.min(DATA.all.trend.labels.length,200); drawNumTrendHead(h,mx0); drawNumTrendBody(b,DATA.all.trend); } },100);
    }
  }
}

var curMode='all';
var tabEls=[], pageEls=[];
function setMode(mode){
  curMode=mode;
  document.querySelectorAll('.mode-btn').forEach(function(b){b.classList.toggle('active',b.dataset.mode===mode);});
  var visIdx=0, firstVis=-1;
  TABS.forEach(function(t,i){
    var show=t.mode===mode||t.mode==='both';
    tabEls[i].style.display=show?'':'none';
    if(show){if(firstVis<0)firstVis=visIdx;visIdx++;}
  });
  showTab(firstVis>=0?TABS.findIndex(function(t,i){return (t.mode===mode||t.mode==='both');}):0);
}

(function init(){
  var nav=document.getElementById('tabNav'), pages=document.getElementById('pages');
  // 模式切换栏
  var modeBar=document.createElement('div');modeBar.className='mode-bar';
  var allBtn=document.createElement('button');allBtn.className='mode-btn active';allBtn.textContent='全部预览';allBtn.dataset.mode='all';
  allBtn.addEventListener('click',function(){setMode('all');});
  var yearBtn=document.createElement('button');yearBtn.className='mode-btn';yearBtn.textContent='按年维度';yearBtn.dataset.mode='year';
  yearBtn.addEventListener('click',function(){setMode('year');});
  modeBar.appendChild(allBtn);modeBar.appendChild(yearBtn);
  nav.parentNode.insertBefore(modeBar,nav);
  // Tab 按钮行
  var tabRow=document.createElement('div');tabRow.className='tab-row';nav.appendChild(tabRow);
  TABS.forEach(function(t,i){
    var b=document.createElement('button');b.className='tab-btn';b.textContent=t.name;
    b.addEventListener('click',function(){showTab(i);});tabRow.appendChild(b);
    tabEls.push(b);
    var p=document.createElement('div');p.className='tab-page';pages.appendChild(p);
    pageEls.push(p);
  });
  setMode('all');
})();
</script>
</body>
</html>"""


def build_history(rows):
    """按月分组的完整开奖明细（新→旧），供历史记录 Tab。
    列：周期(id)/日序/日期/期数/生肖/颜色(特码)/波色/大小/单双/色波/野兽/号头/号尾/颜色单双/组合"""
    QIN_L = set('牛马羊鸡狗猪')
    months = []  # [{ym, rows:[...]}], 新→旧
    order = []
    bucket = {}
    for r in rows:  # rows 已新→旧
        d = r['date']  # YYYY-MM-DD
        ym = d[:7] if len(d) >= 7 else str(r['year'])
        if ym not in bucket:
            bucket[ym] = []
            order.append(ym)
        t = r['tema']
        bose = r['bose']
        col = {'红波': '红', '蓝波': '蓝', '绿波': '绿'}.get(bose, '')
        dx = '大' if t >= 25 else '小'
        ds = '单' if t % 2 else '双'
        bucket[ym].append({
            'id': r['id'], 'date': d, 'qishu': r['qishu'],
            'tx': r['tx'], 'tema': '%02d' % t, 'bose': bose,
            'dx': dx, 'ds': ds,
            'qs': '家禽' if r['tx'] in QIN_L else '野兽',
            'tou': '%d头' % (t // 10), 'wei': '%d尾' % (t % 10),
            'colds': col + ds,   # 颜色单双
            'combo': dx + ds,    # 组合
        })
    for ym in order:
        months.append({'ym': ym, 'rows': bucket[ym]})
    return months


def main():
    if not os.path.exists(SRC):
        print('ERROR: 找不到', SRC); sys.exit(1)
    rows = load_rows(SRC)
    if not rows:
        print('ERROR: 明细无数据'); sys.exit(1)

    data = {
        'all': build_stats(rows),
        'years': build_year_stats(rows),
        'history': build_history(rows),
        'zodiac_map': load_zodiac_map(),
    }
    base = os.path.splitext(os.path.basename(SRC))[0]
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
    name = '%s-report-%s' % (base, ts)
    out = os.path.join(OUT_DIR, name + '.html')
    v = 1
    while os.path.exists(out):
        out = os.path.join(OUT_DIR, '%s-v%d.html' % (name, v)); v += 1

    title = '%s 分析报告' % base
    html = render_html(title, data)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(html)
    print('生成成功:', out)
    print('总期数:', data['all']['overview']['total'], ' 年份数:', len(data['years']))


if __name__ == '__main__':
    main()
