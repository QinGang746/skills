#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate full HTML with all 1000 questions."""

import json, os

data_path = os.path.join(os.path.dirname(__file__), '..', '03-output', 'questions.json')
with open(data_path, 'r', encoding='utf-8') as f:
    data = json.load(f)

questions_json = json.dumps(data, ensure_ascii=False)

HTML = r'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AIGC高级应用工程师 — 在线题库 (1000题)</title>
<style>
/* ============================================================
   CSS Variables
   ============================================================ */
:root {
  --sidebar-bg: #f8fafc; --sidebar-text: #475569; --sidebar-active: #6366f1; --sidebar-hover: #e2e8f0;
  --bg: #f1f5f9; --card-bg: #fff; --text: #1a1a2e; --text-secondary: #64748b;
  --border: #e2e8f0; --primary: #6366f1; --primary-light: #eef2ff;
  --correct: #10b981; --correct-bg: #ecfdf5; --correct-border: #a7f3d0;
  --wrong: #ef4444; --wrong-bg: #fef2f2; --wrong-border: #fecaca;
  --missed: #f59e0b; --missed-bg: #fffbeb;
  --shadow: 0 1px 3px rgba(0,0,0,.06); --radius: 10px;
  --chip-bg: #e2e8f0; --chip-active-bg: #6366f1; --chip-active-text: #fff;
  --sidebar-width: 210px;
}
@media (prefers-color-scheme: dark) {
  :root {
    --sidebar-bg: #1a2235; --sidebar-text: #94a3b8; --sidebar-active: #818cf8; --sidebar-hover: #232d40;
    --bg: #0f172a; --card-bg: #1e293b; --text: #e2e8f0; --text-secondary: #94a3b8;
    --border: #334155; --primary: #818cf8; --primary-light: #1e1b4b;
    --correct: #34d399; --correct-bg: #064e3b; --correct-border: #065f46;
    --wrong: #f87171; --wrong-bg: #7f1d1d; --wrong-border: #991b1b;
    --missed: #fbbf24; --missed-bg: #78350f;
    --shadow: 0 1px 3px rgba(0,0,0,.3); --chip-bg: #334155;
  }
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Noto Sans SC",sans-serif;background:var(--bg);color:var(--text);line-height:1.6;min-height:100vh}
::-webkit-scrollbar{width:8px}
::-webkit-scrollbar-thumb{background:#94a3b8;border-radius:4px}
::-webkit-scrollbar-thumb:hover{background:#64748b}

/* ============================================================
   Layout
   ============================================================ */
.app-layout{display:flex;min-height:100vh}

/* ---- Sidebar ---- */
.sidebar{width:var(--sidebar-width);min-width:var(--sidebar-width);background:var(--sidebar-bg);display:flex;flex-direction:column;padding:16px 0;position:fixed;top:0;left:0;bottom:0;z-index:100;overflow-y:auto;border-right:1px solid var(--border)}
.sidebar-title{color:var(--text);font-size:.9rem;font-weight:700;padding:0 16px 12px;border-bottom:1px solid var(--border);margin-bottom:10px}
.sidebar-section{padding:0 8px;margin-bottom:12px}
.sidebar-label{color:var(--text-secondary);font-size:.68rem;text-transform:uppercase;letter-spacing:1px;padding:6px 10px;margin-top:2px}
.sidebar-item{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:7px;color:var(--text);cursor:pointer;font-size:.84rem;transition:all .12s;border:none;background:none;width:100%;text-align:left;margin-bottom:1px}
.sidebar-item:hover{background:var(--sidebar-hover)}
.sidebar-item.active{background:var(--sidebar-active);color:#fff}
.sidebar-item .icon{font-size:1rem;width:20px;text-align:center}
.sidebar-item .badge{font-size:.68rem;background:var(--chip-bg);padding:1px 7px;border-radius:10px;margin-left:auto;color:var(--text-secondary)}
.sidebar-item.active .badge{background:rgba(255,255,255,.25);color:#fff}
.sidebar-divider{height:1px;background:var(--border);margin:6px 8px}
.sidebar-tools{display:flex;flex-direction:column;gap:1px;padding:0 8px}
.tool-item{display:flex;align-items:center;gap:8px;padding:7px 12px;border-radius:7px;color:var(--text);cursor:pointer;font-size:.8rem;transition:all .12s;border:none;background:none;width:100%;text-align:left}
.tool-item:hover{background:var(--sidebar-hover)}
.tool-item.active-mode{background:var(--wrong);color:#fff}
.tool-item .icon{font-size:.9rem;width:20px;text-align:center}

/* ---- Main Content ---- */
.main-content{flex:1;margin-left:var(--sidebar-width);display:flex;flex-direction:column;min-height:100vh}
.main-header{position:sticky;top:0;z-index:50;background:var(--bg);padding:12px 20px;border-bottom:1px solid var(--border)}
.main-header h1{font-size:1.05rem;font-weight:700;margin-bottom:8px;color:var(--text)}
.tag-filters{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px}
.tag-chip{border:none;padding:3px 10px;border-radius:12px;background:var(--chip-bg);color:var(--text-secondary);cursor:pointer;font-size:.73rem;transition:all .12s;white-space:nowrap}
.tag-chip:hover{background:var(--primary);color:#fff}
.tag-chip.active{background:var(--chip-active-bg);color:var(--chip-active-text)}

.stats-row{display:flex;gap:16px;flex-wrap:wrap;font-size:.78rem;color:var(--text-secondary)}
.stats-row span{white-space:nowrap}
.stats-row .val{font-weight:700;color:var(--primary)}

.question-list{flex:1;padding:16px 20px 80px}
.question-card{background:var(--card-bg);border:1px solid var(--border);border-radius:var(--radius);padding:14px 18px;margin-bottom:10px;box-shadow:var(--shadow);transition:border-color .2s}
.question-card:hover{border-color:var(--primary)}
.question-card.answered-correct{border-left:10px solid var(--correct)}
.question-card.answered-wrong{border-left:10px solid var(--wrong)}

.q-header{display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap}
.q-num{display:inline-flex;align-items:center;justify-content:center;min-width:26px;height:26px;border-radius:50%;background:var(--primary-light);color:var(--primary);font-weight:700;font-size:.78rem;padding:0 5px}
.q-tags{display:flex;gap:3px;flex-wrap:wrap}
.q-tag{font-size:.65rem;padding:1px 7px;border-radius:8px;background:var(--chip-bg);color:var(--text-secondary)}
.q-body{font-size:.88rem;line-height:1.65;margin-bottom:10px;white-space:pre-wrap}

/* Options */
.q-options{display:flex;flex-direction:column;gap:4px;margin-bottom:10px}
.opt-label{display:flex;align-items:flex-start;gap:8px;padding:6px 12px;border:1px solid var(--border);border-radius:7px;cursor:pointer;transition:all .12s;font-size:.84rem}
.opt-label:hover{border-color:var(--primary);background:var(--primary-light)}
.opt-label input[type="radio"],.opt-label input[type="checkbox"]{margin-top:2px;accent-color:var(--primary);width:14px;height:14px}
.opt-label.selected{border-color:var(--primary);background:var(--primary-light)}
.opt-label.result-ok{border-color:var(--correct);background:var(--correct-bg)}
.opt-label.result-bad{border-color:var(--wrong);background:var(--wrong-bg)}
.opt-label.result-miss{border-color:var(--missed);background:var(--missed-bg)}

/* True/False */
.tf-actions{display:flex;flex-direction:column;gap:6px;margin-bottom:10px}
.tf-btn{padding:8px 14px;border:2px solid var(--border);border-radius:8px;font-size:.88rem;font-weight:700;cursor:pointer;transition:all .12s;text-align:left;background:var(--card-bg);color:var(--text)}
.tf-btn:hover{transform:translateY(-1px)}
.tf-btn.btn-true:hover{border-color:var(--correct);background:var(--correct-bg)}
.tf-btn.btn-false:hover{border-color:var(--wrong);background:var(--wrong-bg)}
.tf-btn.selected-true{background:var(--correct-bg);border-color:var(--correct);color:var(--correct)}
.tf-btn.selected-false{background:var(--wrong-bg);border-color:var(--wrong);color:var(--wrong)}

/* Buttons */
.btn-submit{padding:6px 18px;border:none;border-radius:7px;background:var(--primary);color:#fff;font-size:.82rem;font-weight:600;cursor:pointer;transition:all .12s}
.btn-submit:hover{opacity:.9}
.btn-submit:disabled{opacity:.4;cursor:not-allowed}
.btn-reveal{padding:6px 18px;border:none;border-radius:7px;background:#0891b2;color:#fff;font-size:.82rem;font-weight:600;cursor:pointer;transition:all .12s}
.btn-reveal:hover{opacity:.9}
.btn-reveal:disabled{opacity:.4;cursor:not-allowed}

.short-input{width:100%;min-height:80px;padding:10px;border:1px solid var(--border);border-radius:7px;font-size:.85rem;line-height:1.6;resize:vertical;font-family:inherit;background:var(--card-bg);color:var(--text)}
.short-input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px var(--primary-light)}

/* Result */
.q-result{display:none;margin-top:10px;padding:10px 14px;border-radius:7px;animation:fadeIn .2s}
.q-result.show{display:block}
.q-result.correct{background:var(--correct-bg);border:1px solid var(--correct-border)}
.q-result.wrong{background:var(--wrong-bg);border:1px solid var(--wrong-border)}
.q-result.compare{background:var(--primary-light);border:1px solid var(--border)}
.result-icon{font-size:.9rem;font-weight:700;margin-bottom:4px}
.result-detail{font-size:.8rem;margin-bottom:4px}
.q-explanation{margin-top:8px;padding-top:8px;border-top:1px dashed var(--border);font-size:.8rem;line-height:1.6;color:var(--text-secondary)}
.compare-view{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:8px}
.compare-view h4{font-size:.75rem;color:var(--text-secondary);margin-bottom:3px}
.compare-box{background:var(--card-bg);border:1px solid var(--border);border-radius:7px;padding:10px;font-size:.8rem;line-height:1.6;white-space:pre-wrap;max-height:160px;overflow-y:auto}
@media(max-width:640px){.compare-view{grid-template-columns:1fr}}

/* ---- Bottom Toolbar (fixed) ---- */
.bottom-bar{position:fixed;bottom:0;left:var(--sidebar-width);right:0;z-index:50;background:var(--card-bg);border-top:1px solid var(--border);padding:10px 20px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;box-shadow:0 -2px 10px rgba(0,0,0,.05)}
.bottom-bar .btn-submit-all{padding:8px 20px;border:none;border-radius:7px;background:var(--primary);color:#fff;font-size:.84rem;font-weight:600;cursor:pointer;transition:all .12s}
.bottom-bar .btn-submit-all:hover{opacity:.9}
.bottom-bar .btn-submit-all:disabled{opacity:.4;cursor:not-allowed}
.bottom-bar .btn-submit-all.all-done{background:var(--correct)}
.bottom-bar .btn-nav{padding:6px 16px;border:1px solid var(--border);border-radius:7px;background:var(--card-bg);color:var(--text);cursor:pointer;font-size:.82rem;transition:all .12s}
.bottom-bar .btn-nav:hover:not(:disabled){border-color:var(--primary);color:var(--primary)}
.bottom-bar .btn-nav:disabled{opacity:.35;cursor:not-allowed}
.bottom-bar .page-info{font-size:.8rem;color:var(--text-secondary);margin-left:auto}

/* ---- Modal ---- */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:300;justify-content:center;align-items:center;padding:20px}
.modal-overlay.show{display:flex}
.modal{background:var(--card-bg);border-radius:16px;padding:28px;max-width:520px;width:100%;max-height:85vh;overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.3)}
.modal h2{font-size:1.1rem;margin-bottom:12px}
.modal p{font-size:.9rem;margin-bottom:8px;color:var(--text-secondary)}
.modal .modal-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:20px}
.modal .btn-cancel{padding:9px 20px;border:1px solid var(--border);border-radius:8px;background:var(--card-bg);color:var(--text);cursor:pointer;font-size:.88rem}
.modal .btn-confirm{padding:9px 20px;border:none;border-radius:8px;background:var(--primary);color:#fff;cursor:pointer;font-size:.88rem;font-weight:600}

/* Stats modal */
.stat-table{width:100%;border-collapse:collapse;font-size:.85rem}
.stat-table th,.stat-table td{padding:7px 10px;border-bottom:1px solid var(--border);text-align:left}
.stat-table th{color:var(--text-secondary);font-weight:600;font-size:.78rem}

@keyframes fadeIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}

/* ---- Mobile ---- */
@media(max-width:768px){
  .sidebar{width:180px;min-width:180px}
  .main-content{margin-left:180px}
  .bottom-bar{left:180px;padding:8px 12px}
  .main-header{padding:10px 14px}
  .question-list{padding:12px 14px 70px}
  .question-card{padding:12px 14px}
}
@media(max-width:600px){
  .app-layout{flex-direction:column}
  .sidebar{position:relative;width:100%;min-width:auto;flex-direction:row;flex-wrap:wrap;padding:8px;gap:4px;overflow-x:auto;bottom:auto;border-right:none;border-bottom:1px solid var(--border);--sidebar-width:100%}
  .sidebar-title{display:none}
  .sidebar-section,.sidebar-tools{display:flex;flex-direction:row;gap:3px;padding:0;margin:0}
  .sidebar-item,.tool-item{padding:5px 10px;font-size:.73rem;white-space:nowrap;margin:0}
  .sidebar-label,.sidebar-divider{display:none}
  .sidebar-item .badge,.tool-item .badge{display:none}
  .main-content{margin-left:0}
  .bottom-bar{left:0;padding:8px 12px}
}
</style>
</head>
<body>

<div class="app-layout">
  <!-- ============================================================
       Sidebar
       ============================================================ -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-title">📚 AIGC 题库</div>

    <div class="sidebar-section">
      <div class="sidebar-label">题型</div>
      <button class="sidebar-item active" data-type="judgment">
        <span class="icon">📋</span>判断题<span class="badge">250</span>
      </button>
      <button class="sidebar-item" data-type="single">
        <span class="icon">📝</span>单选题<span class="badge">250</span>
      </button>
      <button class="sidebar-item" data-type="multi">
        <span class="icon">☑️</span>多选题<span class="badge">250</span>
      </button>
      <button class="sidebar-item" data-type="short">
        <span class="icon">📄</span>简答题<span class="badge">250</span>
      </button>
    </div>

    <div class="sidebar-divider"></div>

    <div class="sidebar-tools">
      <div class="sidebar-label">工具</div>
      <button class="tool-item" id="btnWrongMode">
        <span class="icon">🔄</span>错题重做
      </button>
      <button class="tool-item" id="btnStats">
        <span class="icon">📊</span>成绩单
      </button>
      <button class="tool-item" id="btnShuffle">
        <span class="icon">🔀</span>随机练习
      </button>
      <button class="tool-item" id="btnReset">
        <span class="icon">🗑️</span>清除记录
      </button>
    </div>
  </aside>

  <!-- ============================================================
       Main Content
       ============================================================ -->
  <main class="main-content">
    <div class="main-header" id="mainHeader">
      <h1>AIGC高级应用工程师 — 在线题库 <small style="color:var(--text-secondary);font-weight:400;font-size:.8rem">共1000题</small></h1>
      <div class="tag-filters" id="tagFilters"></div>
      <div class="stats-row">
        <span>已答: <strong class="val" id="statAnswered">0</strong></span>
        <span>正确: <strong class="val" id="statCorrect" style="color:var(--correct)">0</strong></span>
        <span>正确率: <strong class="val" id="statRate">-</strong></span>
        <span>错题: <strong class="val" id="statWrong" style="color:var(--wrong)">0</strong></span>
      </div>
    </div>

    <div class="question-list" id="questionList"></div>

    <!-- Bottom Toolbar (fixed) -->
    <div class="bottom-bar" id="bottomBar">
      <button class="btn-submit-all" id="btnSubmitAll">📋 全部提交</button>
      <button class="btn-nav" id="btnPrev">◀ 上一页</button>
      <button class="btn-nav" id="btnNext">下一页 ▶</button>
      <span class="page-info" id="pageInfo">第 1 页</span>
      <select id="pageSizeSelect" style="padding:5px 8px;border:1px solid var(--border);border-radius:6px;font-size:.78rem;background:var(--card-bg);color:var(--text);cursor:pointer">
        <option value="20">20题/页</option>
        <option value="50" selected>50题/页</option>
        <option value="100">100题/页</option>
      </select>
      <span style="font-size:.78rem;color:var(--text-secondary)">跳转到</span>
      <input id="jumpInput" type="number" min="1" placeholder="题号" style="width:60px;padding:4px 8px;border:1px solid var(--border);border-radius:6px;font-size:.78rem;background:var(--card-bg);color:var(--text);text-align:center">
      <button class="btn-nav" id="btnJump" style="padding:4px 10px;font-size:.78rem">跳转</button>
    </div>
  </main>
</div>

<!-- Submit All Confirm Modal -->
<div class="modal-overlay" id="submitAllModal">
  <div class="modal">
    <h2>⚠️ 确认提交</h2>
    <div id="submitAllInfo"></div>
    <div class="modal-actions">
      <button class="btn-cancel" id="btnCancelSubmit">取消</button>
      <button class="btn-confirm" id="btnConfirmSubmit">确认提交</button>
    </div>
  </div>
</div>

<!-- Stats Modal -->
<div class="modal-overlay" id="statsModal">
  <div class="modal">
    <h2>📊 成绩单</h2>
    <div id="statsSummary"></div>
    <table class="stat-table">
      <thead><tr><th>知识点</th><th>已答/总</th><th>正确率</th></tr></thead>
      <tbody id="statsTableBody"></tbody>
    </table>
    <div class="modal-actions">
      <button class="btn-cancel" id="closeStats">关闭</button>
    </div>
  </div>
</div>

<!-- ============================================================
     Data
     ============================================================ -->
<script>const QUESTION_DATA = {{DATA}};</script>

<!-- ============================================================
     App Logic
     ============================================================ -->
<script>
(function() {
const DATA = QUESTION_DATA;
const TAG_LIST = DATA.meta.tagList;

let state = {
  currentType: 'judgment',
  activeTag: 'all',
  currentPage: 0,
  pageSize: 50,
  wrongMode: false,
  shuffleMode: false,
  answers: {},
  wrongSet: {},
};

function loadState() {
  try {
    const s = JSON.parse(localStorage.getItem('aigc_quiz_v3'));
    if (s) { Object.assign(state, s); }
  } catch(e) {}
}
function saveState() {
  try {
    const {answers, wrongSet, currentType, activeTag, currentPage, pageSize} = state;
    localStorage.setItem('aigc_quiz_v3', JSON.stringify({answers, wrongSet, currentType, activeTag, currentPage, pageSize}));
  } catch(e) {}
}

function qKey(q) { return state.currentType + '-' + q.id; }

function getAll() { return DATA[state.currentType] || []; }

function getFiltered() {
  let qs = getAll();
  if (state.wrongMode) qs = qs.filter(q => state.wrongSet[qKey(q)]);
  if (state.activeTag !== 'all') qs = qs.filter(q => q.tags.includes(state.activeTag));
  return qs;
}

function getPage() {
  const filtered = getFiltered();
  const start = state.currentPage * state.pageSize;
  let pageQs = filtered.slice(start, start + state.pageSize);
  if (state.shuffleMode) pageQs = [...pageQs].sort(() => Math.random() - 0.5);
  return pageQs;
}

function isCorrect(q, userAns) {
  if (q.type === 'judgment') return userAns === q.answer;
  if (q.type === 'single') return userAns === q.answer;
  if (q.type === 'multi') {
    if (!Array.isArray(userAns) || !Array.isArray(q.answer)) return false;
    if (userAns.length !== q.answer.length) return false;
    const sa = [...q.answer].sort(), ua = [...userAns].sort();
    return sa.every((v,i) => v === ua[i]);
  }
  return null;
}

function getStats() {
  const qs = getAll();
  let answered = 0, correct = 0;
  qs.forEach(q => {
    const key = qKey(q);
    if (state.answers[key] !== undefined) {
      answered++;
      const c = isCorrect(q, state.answers[key]);
      if (c === true || (q.type === 'short' && state.answers[key])) correct++;
    }
  });
  return {
    answered, correct,
    wrong: Object.keys(state.wrongSet).filter(k => k.startsWith(state.currentType + '-')).length,
    rate: answered > 0 ? Math.round((correct / answered) * 100) : null
  };
}

// ---- Render ----
function renderSidebar() {
  document.querySelectorAll('.sidebar-item').forEach(el => {
    el.classList.toggle('active', el.dataset.type === state.currentType);
  });
  const btnW = document.getElementById('btnWrongMode');
  btnW.classList.toggle('active-mode', state.wrongMode);
  if (state.wrongMode) { btnW.innerHTML = '<span class="icon">🔄</span>错题重做 (ON)'; }
  else { btnW.innerHTML = '<span class="icon">🔄</span>错题重做'; }
}

function renderTagFilters() {
  const allQs = getAll();
  // Count per tag
  const tagCounts = { all: allQs.length };
  TAG_LIST.forEach(t => { tagCounts[t] = 0; });
  allQs.forEach(q => {
    (q.tags||[]).forEach(t => { if (tagCounts[t] !== undefined) tagCounts[t]++; });
  });

  let html = '<button class="tag-chip' + (state.activeTag === 'all' ? ' active' : '') + '" data-tag="all">全部 (' + tagCounts.all + ')</button>';
  TAG_LIST.forEach(t => {
    html += '<button class="tag-chip' + (state.activeTag === t ? ' active' : '') + '" data-tag="' + t + '">' + t + ' (' + (tagCounts[t]||0) + ')</button>';
  });
  document.getElementById('tagFilters').innerHTML = html;
}

function renderStats() {
  const s = getStats();
  document.getElementById('statAnswered').textContent = s.answered;
  document.getElementById('statCorrect').textContent = s.correct;
  document.getElementById('statRate').textContent = s.rate !== null ? s.rate + '%' : '-';
  document.getElementById('statWrong').textContent = s.wrong;
}

function renderBottomBar() {
  const pageQs = getPage();
  const total = getFiltered().length;
  const totalPages = Math.ceil(total / state.pageSize) || 1;

  // Count unanswered
  let unanswered = 0, shortCount = 0;
  pageQs.forEach(q => {
    const key = qKey(q);
    if (state.answers[key] === undefined) {
      if (q.type === 'short') shortCount++;
      else unanswered++;
    }
  });

  const btn = document.getElementById('btnSubmitAll');
  const allDone = unanswered === 0 && shortCount === 0;
  if (allDone) {
    btn.textContent = '✅ 本页已全部提交';
    btn.classList.add('all-done');
  } else {
    let label = '📋 全部提交';
    if (unanswered > 0) label += ' (' + unanswered + '题未答)';
    btn.textContent = label;
    btn.classList.remove('all-done');
  }
  btn.disabled = (pageQs.length === 0);

  document.getElementById('btnPrev').disabled = state.currentPage === 0;
  document.getElementById('btnNext').disabled = state.currentPage >= totalPages - 1 || totalPages === 0;
  document.getElementById('pageInfo').textContent = totalPages === 0 ? '无题目' :
    '第 ' + (state.currentPage + 1) + '/' + totalPages + ' 页 (共' + total + '题)';

  // Page size selector
  const sel = document.getElementById('pageSizeSelect');
  if (sel) sel.value = state.pageSize;
}

function renderQuestion(q) {
  const key = qKey(q);
  const card = document.createElement('div');
  card.className = 'question-card';
  card.id = 'card-' + key;
  card.dataset.qkey = key;

  // Header
  let h = '<div class="q-header"><span class="q-num">#' + q.id + '</span>';
  h += '<div class="q-tags">';
  (q.tags||[]).forEach(t => { h += '<span class="q-tag">' + t + '</span>'; });
  h += '</div></div>';
  // Body
  h += '<div class="q-body">' + esc(q.question) + '</div>';

  // Type-specific
  if (q.type === 'judgment') {
    h += '<div class="tf-actions"><button class="tf-btn btn-true" data-act="true">✓ 正确</button><button class="tf-btn btn-false" data-act="false">✘ 错误</button></div>';
  } else if (q.type === 'single' || q.type === 'multi') {
    const itype = q.type === 'single' ? 'radio' : 'checkbox';
    h += '<div class="q-options">';
    (q.options||[]).forEach((opt, i) => {
      const letter = String.fromCharCode(65 + i);
      h += '<label class="opt-label"><input type="' + itype + '" name="opt-' + key + '" value="' + i + '"><span>' + letter + '. ' + esc(opt) + '</span></label>';
    });
    h += '</div><button class="btn-submit" data-act="submit">提交答案</button>';
  } else if (q.type === 'short') {
    h += '<textarea class="short-input" placeholder="在此写下你的答案要点..."></textarea>';
    h += '<button class="btn-reveal" data-act="reveal">查看标准答案</button>';
  }
  h += '<div class="q-result" id="result-' + key + '"></div>';

  card.innerHTML = h;

  // Restore state
  const prev = state.answers[key];
  if (prev !== undefined) {
    showResult(card, q, prev);
    if (q.type !== 'short') {
      card.querySelectorAll('input,.tf-btn,.btn-submit').forEach(el => {
        el.disabled = true; el.style.pointerEvents = 'none'; el.style.opacity = '0.7';
      });
    }
  }
  return card;
}

function showResult(card, q, userAns) {
  const resultDiv = card.querySelector('.q-result');
  if (!resultDiv) return;
  const correct = isCorrect(q, userAns);
  let cls = 'show ', icon = '', detail = '';

  if (q.type === 'judgment') {
    cls += correct ? 'correct' : 'wrong';
    icon = correct ? '✅ 正确!' : '❌ 错误!';
    const userLabel = userAns === null ? '未作答' : (userAns ? '✓ 正确' : '✘ 错误');
    detail = '正确答案: ' + (q.answer ? '✓ 正确' : '✘ 错误') + ' | 你的答案: ' + userLabel;
    card.classList.add(correct ? 'answered-correct' : 'answered-wrong');
  } else if (q.type === 'single') {
    cls += correct ? 'correct' : 'wrong';
    icon = correct ? '✅ 正确!' : '❌ 错误!';
    const userLabel = userAns === -1 ? '未作答' : String.fromCharCode(65+userAns);
    detail = '正确答案: ' + String.fromCharCode(65+q.answer) + ' | 你的答案: ' + userLabel;
    card.classList.add(correct ? 'answered-correct' : 'answered-wrong');
  } else if (q.type === 'multi') {
    const ansSet = new Set(q.answer), userSet = new Set(userAns||[]);
    let allOK = true, parts = [];
    (q.options||[]).forEach((opt, i) => {
      const inAns = ansSet.has(i), inUser = userSet.has(i);
      if (inAns && inUser) parts.push(String.fromCharCode(65+i)+' ✅选对');
      else if (inAns && !inUser) { parts.push(String.fromCharCode(65+i)+' ⚠️漏选'); allOK = false; }
      else if (!inAns && inUser) { parts.push(String.fromCharCode(65+i)+' ❌多选'); allOK = false; }
      else parts.push(String.fromCharCode(65+i)+' ✓排除');
      // highlight label
      const label = card.querySelectorAll('.opt-label')[i];
      if (label) {
        if (inAns && inUser) label.classList.add('result-ok');
        else if (inAns && !inUser) label.classList.add('result-miss');
        else if (!inAns && inUser) label.classList.add('result-bad');
      }
    });
    if (allOK && userSet.size === ansSet.size) {
      cls = 'show correct'; icon = '✅ 完全正确!'; card.classList.add('answered-correct');
    } else {
      cls += 'wrong'; icon = '⚠️ 有误!'; card.classList.add('answered-wrong');
    }
    detail = parts.join(' | ');
  } else if (q.type === 'short') {
    cls += 'compare'; icon = '📋 答案对照';
    detail = '<div class="compare-view"><div><h4>你的答案</h4><div class="compare-box">' + esc(userAns||'(未填写)') + '</div></div><div><h4>标准答案</h4><div class="compare-box">' + esc(q.answer_text||'') + '</div></div></div>';
  }

  resultDiv.className = 'q-result ' + cls;
  resultDiv.innerHTML = '<div class="result-icon">' + icon + '</div><div class="result-detail">' + detail + '</div>' +
    (q.explanation ? '<div class="q-explanation">📖 ' + esc(q.explanation) + '</div>' : '');
}

function handleAnswer(q, userAns) {
  const key = qKey(q);
  state.answers[key] = userAns;
  if (q.type !== 'short') {
    if (isCorrect(q, userAns)) delete state.wrongSet[key];
    else state.wrongSet[key] = true;
  }
  saveState();
  const card = document.getElementById('card-' + key);
  if (card) {
    showResult(card, q, userAns);
    if (q.type !== 'short') {
      card.querySelectorAll('input,.tf-btn,.btn-submit').forEach(el => {
        el.disabled = true; el.style.pointerEvents = 'none'; el.style.opacity = '0.7';
      });
    }
  }
  renderStats();
  renderBottomBar();
  renderSidebar();
}

function submitAll() {
  const pageQs = getPage();
  let unanswered = 0, shortCount = 0, hasSelection = 0;
  pageQs.forEach(q => {
    const key = qKey(q);
    if (state.answers[key] !== undefined) return;
    if (q.type === 'short') { shortCount++; return; }
    // Check if user has made any selection
    const card = document.getElementById('card-' + key);
    if (!card) { unanswered++; return; }
    if (q.type === 'judgment') {
      unanswered++; // TF always treated as unanswered in bulk (no pre-selection)
    } else if (q.type === 'single') {
      const sel = card.querySelector('input[type="radio"]:checked');
      sel ? hasSelection++ : unanswered++;
    } else if (q.type === 'multi') {
      const cbs = card.querySelectorAll('input[type="checkbox"]:checked');
      cbs.length > 0 ? hasSelection++ : unanswered++;
    }
  });
  const totalToSubmit = unanswered + hasSelection;

  let info = '<p>本页共 <b>' + pageQs.length + '</b> 题：</p>';
  const answeredCount = pageQs.length - totalToSubmit - shortCount;
  info += '<p>✅ 已答：<b>' + answeredCount + '</b> 题</p>';
  if (hasSelection > 0) info += '<p>📝 已选择待提交：<b>' + hasSelection + '</b> 题</p>';
  if (unanswered > 0) info += '<p style="color:var(--wrong)">⚠️ 未作答：<b>' + unanswered + '</b> 题（将直接判错）</p>';
  if (shortCount > 0) info += '<p style="color:var(--text-secondary)">📄 简答题：<b>' + shortCount + '</b> 题（跳过，需单独查看答案）</p>';
  if (totalToSubmit === 0) {
    info += '<p style="margin-top:10px;color:var(--correct)">本页已全部提交!</p>';
  } else {
    info += '<p style="margin-top:10px;">共 <b>' + totalToSubmit + '</b> 题待提交，确定？</p>';
  }
  document.getElementById('submitAllInfo').innerHTML = info;
  document.getElementById('submitAllModal').classList.add('show');
}

function doSubmitAll() {
  document.getElementById('submitAllModal').classList.remove('show');
  const pageQs = getPage();
  let autoWrong = 0;
  pageQs.forEach(q => {
    const key = qKey(q);
    if (state.answers[key] !== undefined) return;
    if (q.type === 'short') return;

    if (q.type === 'judgment') {
    const card = document.getElementById('card-' + key);
    const btnT = card ? card.querySelector('.btn-true.selected-true') : null;
    const btnF = card ? card.querySelector('.btn-false.selected-false') : null;
    if (btnT) { handleAnswer(q, true); }
    else if (btnF) { handleAnswer(q, false); }
    else { handleAnswer(q, null); autoWrong++; }
  } else if (q.type === 'single') {
      const card = document.getElementById('card-' + key);
      const sel = card ? card.querySelector('input[type="radio"]:checked') : null;
      if (sel) { handleAnswer(q, parseInt(sel.value)); }
      else { handleAnswer(q, -1); autoWrong++; }
    } else if (q.type === 'multi') {
      const card = document.getElementById('card-' + key);
      const cbs = card ? card.querySelectorAll('input[type="checkbox"]:checked') : [];
      const vals = Array.from(cbs).map(cb => parseInt(cb.value));
      if (vals.length > 0) { handleAnswer(q, vals); }
      else { handleAnswer(q, []); autoWrong++; }
    }
  });
  if (autoWrong > 0) {
    setTimeout(() => alert('⚠ 共 ' + autoWrong + ' 题未作答，已判为错误。'), 300);
  }
}

function refreshAll() {
  renderSidebar();
  renderTagFilters();
  renderStats();
  renderBottomBar();
  const list = document.getElementById('questionList');
  const pageQs = getPage();
  if (pageQs.length === 0) {
    list.innerHTML = '<div style="text-align:center;padding:60px 20px;color:var(--text-secondary);font-size:1rem">' +
      (state.wrongMode ? '🎉 暂无错题，继续加油!' : '该筛选条件下没有题目') + '</div>';
    return;
  }
  list.innerHTML = '';
  const frag = document.createDocumentFragment();
  pageQs.forEach(q => frag.appendChild(renderQuestion(q)));
  list.appendChild(frag);
  window.scrollTo({top:0,behavior:'smooth'});
}

// ---- Events ----
document.addEventListener('click', function(e) {
  const t = e.target;

  // Modal close handlers (check first)
  if (t.closest('#closeStats') || (t.id === 'statsModal')) {
    document.getElementById('statsModal').classList.remove('show');
    return;
  }
  if (t.closest('#btnCancelSubmit') || (t.id === 'submitAllModal')) {
    document.getElementById('submitAllModal').classList.remove('show');
    return;
  }
  if (t.closest('#btnConfirmSubmit')) { doSubmitAll(); return; }

  // Sidebar type nav
  if (t.closest('.sidebar-item') && t.closest('.sidebar-item').dataset.type) {
    const el = t.closest('.sidebar-item');
    state.currentType = el.dataset.type;
    state.currentPage = 0;
    state.wrongMode = false;
    state.shuffleMode = false;
    saveState(); refreshAll();
    return;
  }

  // Sidebar tools
  if (t.closest('#btnWrongMode')) {
    state.wrongMode = !state.wrongMode;
    state.currentPage = 0;
    state.shuffleMode = false;
    saveState(); refreshAll();
    return;
  }
  if (t.closest('#btnShuffle')) {
    state.shuffleMode = !state.shuffleMode;
    refreshAll();
    return;
  }
  if (t.closest('#btnStats')) {
    showStatsModal(); return;
  }
  if (t.closest('#btnReset')) {
    if (confirm('确定清除所有做题记录和错题吗？')) {
      state.answers = {}; state.wrongSet = {}; state.currentPage = 0;
      state.wrongMode = false; state.shuffleMode = false;
      saveState(); refreshAll();
    }
    return;
  }

  // Tag chips
  if (t.closest('.tag-chip')) {
    state.activeTag = t.closest('.tag-chip').dataset.tag;
    state.currentPage = 0;
    saveState(); refreshAll();
    return;
  }

  // TF buttons
  if (t.closest('.tf-btn')) {
    const btn = t.closest('.tf-btn');
    const card = btn.closest('.question-card');
    const key = card.dataset.qkey;
    const type = state.currentType;
    const qid = parseInt(key.replace(type+'-',''));
    const q = DATA[type].find(q => q.id === qid);
    if (!q || state.answers[key] !== undefined) return;
    handleAnswer(q, btn.dataset.act === 'true');
    return;
  }

  // Submit single/multi
  if (t.closest('.btn-submit')) {
    const card = t.closest('.question-card');
    const key = card.dataset.qkey;
    const type = state.currentType;
    const qid = parseInt(key.replace(type+'-',''));
    const q = DATA[type].find(q => q.id === qid);
    if (!q || state.answers[key] !== undefined) return;
    if (q.type === 'single') {
      const sel = card.querySelector('input[type="radio"]:checked');
      if (!sel) { alert('请选择一个选项'); return; }
      handleAnswer(q, parseInt(sel.value));
    } else if (q.type === 'multi') {
      const cbs = card.querySelectorAll('input[type="checkbox"]:checked');
      const vals = Array.from(cbs).map(cb => parseInt(cb.value));
      if (vals.length === 0) { alert('请至少选择一个选项'); return; }
      handleAnswer(q, vals);
    }
    return;
  }

  // Reveal short answer
  if (t.closest('.btn-reveal')) {
    const card = t.closest('.question-card');
    const key = card.dataset.qkey;
    const type = state.currentType;
    const qid = parseInt(key.replace(type+'-',''));
    const q = DATA[type].find(q => q.id === qid);
    if (!q) return;
    const ta = card.querySelector('.short-input');
    handleAnswer(q, ta ? ta.value : '');
    if (ta) ta.disabled = true;
    const btn = card.querySelector('.btn-reveal');
    if (btn) { btn.disabled = true; btn.textContent = '已查看'; }
    return;
  }

  // Submit All
  if (t.closest('#btnSubmitAll')) { submitAll(); return; }

  // Pagination
  if (t.closest('#btnPrev')) {
    if (state.currentPage > 0) { state.currentPage--; saveState(); refreshAll(); }
    return;
  }
  if (t.closest('#btnNext')) {
    const total = Math.ceil(getFiltered().length / state.pageSize);
    if (state.currentPage < total - 1) { state.currentPage++; saveState(); refreshAll(); }
    return;
  }

  // Page size select (handled in change event below)
  // Jump to question
  if (t.closest('#btnJump')) { jumpToQuestion(); return; }
  // Modals (handled at top of click handler)
});

document.addEventListener('change', function(e) {
  // Page size selector
  if (e.target.id === 'pageSizeSelect') {
    state.pageSize = parseInt(e.target.value);
    state.currentPage = 0;
    saveState(); refreshAll();
    return;
  }
  if (e.target.type === 'radio') {
    const card = e.target.closest('.question-card');
    if (card) {
      card.querySelectorAll('.opt-label').forEach(l => l.classList.remove('selected'));
      const label = e.target.closest('.opt-label');
      if (label && e.target.checked) label.classList.add('selected');
    }
  }
  if (e.target.type === 'checkbox') {
    const label = e.target.closest('.opt-label');
    if (label) label.classList.toggle('selected', e.target.checked);
  }
});

// Keyboard
document.addEventListener('keydown', function(e) {
  if (e.key === 'ArrowLeft' && !e.target.closest('input,textarea')) document.getElementById('btnPrev').click();
  if (e.key === 'ArrowRight' && !e.target.closest('input,textarea')) document.getElementById('btnNext').click();
  if (e.key === 'Enter' && e.target.id === 'jumpInput') jumpToQuestion();
});

// Stats modal
function showStatsModal() {
  const allQs = getAll();
  const totalAll = allQs.length;
  let totalAnswered = 0, totalCorrect = 0;

  const byTag = {};
  TAG_LIST.forEach(t => { byTag[t] = { total: 0, answered: 0, correct: 0 }; });

  allQs.forEach(q => {
    const key = qKey(q);
    (q.tags||[]).forEach(t => {
      if (!byTag[t]) return;
      byTag[t].total++;
      if (state.answers[key] !== undefined) {
        byTag[t].answered++;
        const c = isCorrect(q, state.answers[key]);
        if (c === true) byTag[t].correct++;
        else if (q.type === 'short' && state.answers[key]) byTag[t].correct++;
      }
    });
  });

  // Count overall
  allQs.forEach(q => {
    const key = qKey(q);
    if (state.answers[key] !== undefined) {
      totalAnswered++;
      const c = isCorrect(q, state.answers[key]);
      if (c === true) totalCorrect++;
      else if (q.type === 'short' && state.answers[key]) totalCorrect++;
    }
  });

  const totalWrong = totalAnswered - totalCorrect;
  const pctW = totalAnswered > 0 ? Math.round((totalCorrect / totalAnswered) * 100) : 0;

  // Overall summary (above table)
  let html = '<div style="margin-bottom:14px;padding:12px 16px;background:var(--primary-light);border-radius:10px;font-size:.88rem">';
  html += '总计 ' + totalAll + ' 题（';
  html += '<span style="color:var(--primary)">已答:' + totalAnswered + '</span>、';
  html += '<span style="color:var(--correct)">正确:' + totalCorrect + '</span>、';
  html += '<span style="color:var(--wrong)">错误:' + totalWrong + '</span>）';
  html += '<div style="margin-top:6px;height:6px;background:var(--border);border-radius:3px;overflow:hidden">';
  html += '<div style="width:' + pctW + '%;height:100%;background:' + (pctW >= 80 ? 'var(--correct)' : pctW >= 50 ? 'var(--missed)' : 'var(--wrong)') + ';border-radius:3px"></div>';
  html += '</div></div>';

  // Per-tag rows
  let rows = '';
  TAG_LIST.forEach(tag => {
    const s = byTag[tag];
    if (s.total === 0) return;
    const rate = s.answered > 0 ? Math.round((s.correct / s.answered) * 100) : 0;
    const col = rate >= 80 ? 'var(--correct)' : rate >= 50 ? 'var(--missed)' : 'var(--wrong)';
    rows += '<tr>';
    rows += '<td>' + tag + '</td>';
    rows += '<td>' + s.answered + '/' + s.total + '</td>';
    rows += '<td style="min-width:140px">';
    rows += '<span style="display:inline-block;width:' + Math.max(4, rate) + 'px;height:8px;border-radius:4px;background:' + col + ';vertical-align:middle;margin-right:6px"></span>';
    rows += '<span style="font-size:.82rem;vertical-align:middle">' + rate + '% (' + s.correct + '/' + s.answered + ')</span>';
    rows += '</td></tr>';
  });

  document.getElementById('statsSummary').innerHTML = html;
  document.getElementById('statsTableBody').innerHTML = rows;
  document.getElementById('statsModal').classList.add('show');
}

// Jump to question
function jumpToQuestion() {
  const input = document.getElementById('jumpInput');
  const num = parseInt(input.value);
  if (!num || num < 1) return;
  const allQs = getAll();
  if (allQs.length === 0) return;
  const maxQ = allQs[allQs.length - 1].id;
  if (num > maxQ) { alert('题号超出范围，最大 ' + maxQ); return; }
  const filtered = getFiltered();
  const idx = filtered.findIndex(q => q.id >= num);
  const targetPage = idx === -1 ? 0 : Math.floor(idx / state.pageSize);
  state.currentPage = targetPage;
  saveState(); refreshAll();
  setTimeout(() => {
    const targetCard = document.getElementById('card-' + state.currentType + '-' + num);
    if (targetCard) {
      targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      targetCard.style.boxShadow = '0 0 0 3px var(--primary)';
      setTimeout(() => { targetCard.style.boxShadow = ''; }, 1500);
    }
  }, 200);
  input.value = '';
}

function esc(s) {
  if (!s) return '';
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

// ---- Init ----
loadState();
refreshAll();
})();
</script>
</body>
</html>'''

final = HTML.replace('{{DATA}}', questions_json)

out_path = os.path.join(os.path.dirname(__file__), '..', '03-output', 'AIGC题库练习.html')
with open(out_path, 'w', encoding='utf-8') as f:
    f.write(final)

print(f"Done! {os.path.getsize(out_path)/1024:.0f} KB")
