#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
解析4个AIGC题库.txt → questions.json（带知识点标签）→ 生成HTML。
"""

import re
import json
import os

TAG_KEYWORDS = {
    "Transformer": [
        "Self-Attention", "Multi-Head", "多头注意力", "QKV", "Q、K、V",
        "softmax", "位置编码", "RoPE", "旋转位置", "ALiBi",
        "LayerNorm", "Layer Normalization", "残差连接", "Residual",
        "FFN", "Feed-Forward", "GELU", "Cross-Attention", "编码器-解码器",
        "Causal Mask", "因果掩码", "Masked Self-Attention",
        "√d_k", "d_k", "head dimension", "num_heads",
        "Transformer", "解码器结构", "前馈网络",
    ],
    "LLM训练": [
        "LLaMA", "RLHF", "PPO", "奖励模型", "奖励黑客",
        "ZeRO", "DeepSpeed", "混合精度", "FP16", "BF16", "Loss Scaling",
        "MoE", "混合专家", "SwiGLU", "RMSNorm", "GQA", "分组查询",
        "梯度累积", "Gradient Checkpointing", "数据并行", "流水线并行",
        "张量并行", "序列并行", "分布式训练", "预训练",
    ],
    "推理优化": [
        "KV Cache", "FlashAttention", "vLLM", "PagedAttention",
        "量化", "INT8", "INT4", "AWQ", "GPTQ", "NF4",
        "推测解码", "Speculative Decoding", "TensorRT", "ONNX",
        "Continuous Batching", "连续批处理", "Triton", "Dynamic Batching",
        "TTFT", "首Token", "Throughput", "吞吐",
        "推理", "部署", "batch size", "显存",
        "torch.compile", "预热", "Warm-up", "模型并行",
        "OpenVINO", "CPU.*推理", "Rate Limiting",
        "Llama.cpp", "模型级联", "模型蒸馏", "max_num_seqs",
        "长尾延迟", "服务器无感", "量化感知", "AWQ",
    ],
    "PEFT微调": [
        "LoRA", "QLoRA", "Prefix Tuning", "Adapter", "参数高效",
        "PEFT", "微调", "全量微调", "可训练参数",
        "DreamBooth", "Textual Inversion", "Dreambooth",
        "正则化图像", "低秩", "rank",
    ],
    "RAG": [
        "RAG", "检索", "BM25", "向量数据库", "HNSW", "IVF",
        "Embedding", "HyDE", "Self-RAG", "CRAG", "RAPTOR", "GraphRAG",
        "重排序", "Re-ranking", "MMR", "最大边际",
        "查询路由", "Query Routing", "Ragas", "Faithfulness",
        "切片", "检索增强", "多跳问题", "Lost in the Middle",
        "中间丢失", "Cross-Encoder", "双塔", "多向量检索",
        "ColBERT", "元数据过滤", "混合检索", "密集检索", "稀疏检索",
        "Context Recall", "Answer Relevancy", "Context Precision",
    ],
    "Agent": [
        "Agent", "ReAct", "Function Calling", "Tool", "工具调用",
        "Plan-and-Solve", "AutoGPT", "BabyAGI", "AutoGen",
        "LangChain", "ToT", "Tree-of-Thoughts", "CoT", "思维链",
        "多Agent", "人机协作", "Constitutional AI",
        "ConversationBufferMemory", "AgentExecutor",
        "自我反思", "代码解释器", "Few-shot",
    ],
    "图像生成": [
        "Stable Diffusion", "SDXL", "SD1.5", "ControlNet",
        "扩散模型", "VAE", "LDM", "LCM", "DiT",
        "DALL-E", "DALL·E", "Midjourney", "ComfyUI",
        "DreamBooth", "IP-Adapter", "AnimateDiff",
        "视频生成", "Sora", "3D生成", "DreamFusion",
        "CFG Scale", "Negative Prompt", "负向提示",
        "图像修复", "InstructPix2Pix", "Null-text Inversion",
        "Prompt-to-Prompt", "StyleDrop", "StyleGAN",
        "CLIP Guidance", "Fuyu", "WebUI", "A1111",
        "Zero-1-to-3", "深度图", "Canny",
    ],
    "音频": [
        "Whisper", "VALL-E", "Bark", "MusicGen", "MusicLM",
        "CLAP", "TTS", "语音", "音频", "WER", "词错误率",
        "Stable Audio", "AudioLDM", "声纹", "音乐",
        "EnCodec", "Voice Design", "ElevenLabs",
        "WavLM", "说话人", "字幕",
    ],
    "评估安全": [
        "FID", "CLIPScore", "BLEU", "ROUGE", "Distinct-n",
        "幻觉", "红队", "Red Teaming", "越狱", "Jailbreak",
        "安全", "偏见", "对齐", "Alignment",
        "MMLU", "TruthfulQA", "HaluEval", "GSM8K",
        "合规", "隐私", "护栏", "Guardrails",
        "提示注入", "Prompt Injection", "模型卡片", "Model Card",
        "Pass@k", "Perplexity", "困惑度",
        "差分隐私", "模型水印", "BOLD", "灾难性遗忘",
    ],
    "产品落地": [
        "产品", "定价", "部署", "GPU成本", "GPU算力",
        "用户体验", "私有化", "审计", "儿童",
        "医疗", "法律", "教育",
        "计费", "Token.*计费", "API限流",
        "反馈", "版权", "历史记录", "Onboarding",
        "AIGC应用工程师", "一键生成", "撤销",
        "错误提示", "降级策略", "用户引导",
        "合规要求", "法规",
    ],
}


def assign_tags(text):
    tags = set()
    for tag, keywords in TAG_KEYWORDS.items():
        for kw in keywords:
            if re.search(kw, text, re.IGNORECASE):
                tags.add(tag)
                break
    if not tags:
        tags.add("综合")
    return sorted(tags)


def read_file(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def clean_text(t):
    """合并多余空白，整理文本"""
    return re.sub(r'\s+', ' ', t).strip()


# ============================================================
# 解析判断题
# ============================================================
def parse_judgment(filepath):
    raw = read_file(filepath)
    # 用题号拆分
    parts = re.split(r'\n(?=\d+\.\s+)', raw)
    questions = []

    for part in parts:
        m = re.match(r'(\d+)\.\s+', part)
        if not m:
            continue
        qid = int(m.group(1))
        body = part[m.end():]

        # 题目文本：到 "答案：" 之前
        ans_pos = body.find('答案：')
        if ans_pos == -1:
            q_text = body
        else:
            q_text = body[:ans_pos]
        q_text = clean_text(q_text)
        q_text = re.sub(r'[（(]\s*[）)]\s*$', '', q_text).strip()

        # 答案
        ans_m = re.search(r'答案：\s*([√×])', body)
        answer = ans_m.group(1) == '√' if ans_m else None

        # 解析
        exp_m = re.search(r'解析：\s*(.*)', body, re.DOTALL)
        explanation = clean_text(exp_m.group(1)) if exp_m else ''

        tags = assign_tags(q_text + ' ' + explanation)
        questions.append({
            "id": qid, "type": "judgment",
            "question": q_text, "answer": answer,
            "explanation": explanation, "tags": tags
        })
    return questions


# ============================================================
# 解析单选题
# ============================================================
def parse_single(filepath):
    raw = read_file(filepath)
    parts = re.split(r'\n(?=第\d+题)', raw)
    questions = []

    for part in parts:
        m = re.match(r'第(\d+)题\s*', part)
        if not m:
            continue
        qid = int(m.group(1))
        body = part[m.end():]

        # 题目文本：到 A. 之前
        opt_a = re.search(r'\n?\s*A\.\s*', body)
        if opt_a:
            q_text = clean_text(body[:opt_a.start()])
            rest = body[opt_a.start():]
        else:
            q_text = clean_text(body)
            rest = ''

        # 选项
        options = []
        for letter in ['A', 'B', 'C', 'D']:
            pat = rf'{letter}\.\s*(.*?)(?=\s*[A-E]\.\s*|\s*答案：|\s*解析：|\Z)'
            om = re.search(pat, rest, re.DOTALL)
            options.append(clean_text(om.group(1)) if om else '')

        # 答案
        ans_m = re.search(r'答案：\s*([A-D])', body)
        answer = ord(ans_m.group(1)) - ord('A') if ans_m else None

        # 解析
        exp_m = re.search(r'解析：\s*(.*?)(?=\n\s*第\d+题|\Z)', body, re.DOTALL)
        explanation = clean_text(exp_m.group(1)) if exp_m else ''
        explanation = re.sub(r'\s*第\d+题.*$', '', explanation).strip()

        tags = assign_tags(q_text + ' ' + ' '.join(options) + ' ' + explanation)
        questions.append({
            "id": qid, "type": "single",
            "question": q_text, "options": options,
            "answer": answer, "explanation": explanation, "tags": tags
        })
    return questions


# ============================================================
# 解析多选题
# ============================================================
def parse_multi(filepath):
    raw = read_file(filepath)
    parts = re.split(r'\n(?=\d+\.\s+)', raw)
    questions = []

    for part in parts:
        m = re.match(r'(\d+)\.\s+', part)
        if not m:
            continue
        qid = int(m.group(1))
        body = part[m.end():]

        # 题目文本
        opt_a = re.search(r'\n?\s*A\.\s*', body)
        if opt_a:
            q_text = clean_text(body[:opt_a.start()])
            rest = body[opt_a.start():]
        else:
            ans_pos = body.find('答案：')
            q_text = clean_text(body[:ans_pos]) if ans_pos != -1 else clean_text(body)
            rest = ''

        q_text = re.sub(r'[（(]\s*[）)]\s*$', '', q_text).strip()

        # 选项
        options = []
        for letter in ['A', 'B', 'C', 'D']:
            pat = rf'{letter}\.\s*(.*?)(?=\s*[A-E]\.\s*|\s*答案：|\s*解析：|\Z)'
            om = re.search(pat, body, re.DOTALL)
            options.append(clean_text(om.group(1)) if om else '')

        # 答案（用、分隔）
        ans_m = re.search(r'答案：\s*([A-D、，,]+)', body)
        if ans_m:
            ans_str = ans_m.group(1)
            answer = [ord(c.strip()) - ord('A') for c in re.split(r'[、，,]', ans_str) if c.strip()]
        else:
            answer = []

        # 解析
        exp_m = re.search(r'解析：\s*(.*?)(?=\n\s*\d+\.\s+|\Z)', body, re.DOTALL)
        explanation = clean_text(exp_m.group(1)) if exp_m else ''

        tags = assign_tags(q_text + ' ' + ' '.join(options) + ' ' + explanation)
        questions.append({
            "id": qid, "type": "multi",
            "question": q_text, "options": options,
            "answer": answer, "explanation": explanation, "tags": tags
        })
    return questions


# ============================================================
# 解析简答题
# ============================================================
def parse_short(filepath):
    raw = read_file(filepath)
    parts = re.split(r'\n(?=\d+\.\s+)', raw)
    questions = []

    for part in parts:
        m = re.match(r'(\d+)\.\s+', part)
        if not m:
            continue
        qid = int(m.group(1))
        body = part[m.end():]

        # 题目到"答案："
        ans_pos = body.find('答案：')
        if ans_pos != -1:
            q_text = clean_text(body[:ans_pos])
        else:
            q_text = clean_text(body)

        # 答案文本
        answer_text = ''
        explanation = ''
        if ans_pos != -1:
            rest = body[ans_pos:]
            ans_m = re.search(r'答案：\s*(.*?)(?=解析：|\Z)', rest, re.DOTALL)
            if ans_m:
                answer_text = clean_text(ans_m.group(1))

            exp_m = re.search(r'解析：\s*(.*?)(?=\n\s*\d+\.\s+|\Z)', rest, re.DOTALL)
            if exp_m:
                explanation = clean_text(exp_m.group(1))

        tags = assign_tags(q_text + ' ' + answer_text + ' ' + explanation)
        questions.append({
            "id": qid, "type": "short",
            "question": q_text, "answer_text": answer_text,
            "explanation": explanation, "tags": tags
        })
    return questions


# ============================================================
# 统计分析
# ============================================================
def show_stats(data, name):
    print(f"\n{'='*50}")
    print(f"  {name}: {len(data)} questions")

    # Check ID continuity
    ids = set(q['id'] for q in data)
    expected = set(range(1, 251))
    missing = expected - ids
    extra = ids - expected
    if missing:
        print(f"  WARN missing: {sorted(missing)[:20]}{'...' if len(missing)>20 else ''}")
    if extra:
        print(f"  WARN extra: {sorted(extra)[:20]}")
    if not missing and not extra:
        print(f"  OK 250/250 parsed successfully")

    # Tag distribution
    tag_counts = {}
    for q in data:
        for t in q.get('tags', []):
            tag_counts[t] = tag_counts.get(t, 0) + 1
    print(f"  Tag distribution:")
    for tag in sorted(TAG_KEYWORDS.keys()):
        cnt = tag_counts.get(tag, 0)
        bar = '#' * (cnt // 5)
        print(f"    {tag:<10s} {cnt:>3d} {bar}")

    # Show first 3 questions as sample
    print(f"  First 3 samples:")
    for q in data[:3]:
        q_preview = q['question'][:60]
        ans = q.get('answer')
        if ans is None:
            ans = q.get('answer_text', '')[:40]
        print(f"    #{q['id']}: {q_preview}... -> answer: {ans}")
        print(f"        tags: {q['tags']}")


# ============================================================
# 主流程
# ============================================================
def main():
    base = os.path.join(os.path.dirname(__file__), '..', '01-data')

    judgment = parse_judgment(os.path.join(base, 'AI应用工程师-判断题.txt'))
    show_stats(judgment, "判断题")

    single = parse_single(os.path.join(base, 'AI应用工程师-单选题.txt'))
    show_stats(single, "单选题")

    multi = parse_multi(os.path.join(base, 'AI应用工程师-多选题.txt'))
    show_stats(multi, "多选题")

    short_q = parse_short(os.path.join(base, 'AI应用工程师-简答题.txt'))
    show_stats(short_q, "简答题")

    all_data = {
        "judgment": judgment,
        "single": single,
        "multi": multi,
        "short": short_q,
        "meta": {
            "total": len(judgment) + len(single) + len(multi) + len(short_q),
            "tagList": sorted(TAG_KEYWORDS.keys())
        }
    }

    json_path = os.path.join(os.path.dirname(__file__), '..', '03-output', 'questions.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)

    print(f"\n{'='*50}")
    print(f"OK Output: {json_path}")
    print(f"OK Total: {all_data['meta']['total']} questions ({len(judgment)}TF + {len(single)}SC + {len(multi)}MC + {len(short_q)}SA)")
    print(f"OK Tags: {', '.join(sorted(TAG_KEYWORDS.keys()))}")

    return all_data


if __name__ == '__main__':
    main()
