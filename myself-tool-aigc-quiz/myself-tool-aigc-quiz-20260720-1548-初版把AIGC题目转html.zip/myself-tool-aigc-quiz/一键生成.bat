@echo off
cd /d "%~dp0"

echo ========================================
echo   AIGC Quiz - One Click Build
echo ========================================
echo.

echo [1/2] Parsing question data...
python "02-scripts\parse_and_generate.py"
if %errorlevel% neq 0 (
    echo [FAIL] Parse error
    pause
    exit /b 1
)
echo [OK] Data parsed
echo.

echo [2/2] Generating HTML...
python "02-scripts\generate_html.py"
if %errorlevel% neq 0 (
    echo [FAIL] HTML generation error
    pause
    exit /b 1
)
echo [OK] HTML generated
echo.

echo ========================================
echo   Done! Opening HTML...
echo ========================================

start "" "03-output\AIGC题库练习.html"

pause
