# myself-tool-aigc-quiz

AIGC高级应用工程师 在线题库 — 单文件 HTML 练习系统。

## 快速使用

直接双击 `03-output/AIGC题库练习.html`（1000题）或 `03-output/AIGC题库-预览版.html`（20题预览），浏览器打开即用。

## 目录结构

```
myself-tool-aigc-quiz/
├── 01-data/                     ← 原始数据
│   ├── AI应用工程师判断题.doc
│   ├── AI应用工程师单选题.doc
│   ├── AI应用工程师多选题.doc
│   ├── AI应用工程师简答题.doc
│   ├── AI应用工程师-判断题.txt  ← 从 .doc 提取的文本
│   ├── AI应用工程师-单选题.txt
│   ├── AI应用工程师-多选题.txt
│   └── AI应用工程师-简答题.txt
│
├── 02-scripts/                  ← 工具脚本
│   ├── parse_and_generate.py    ← 步骤1：解析 txt → 03-output/questions.json
│   ├── generate_html.py         ← 步骤2：生成 1000题 HTML
│   └── gen_preview.py           ← 步骤2b：生成 20题预览 HTML
│
├── 03-output/                   ← 产物
│   ├── AIGC题库练习.html        ← 🎯 1000题完整版
│   ├── AIGC题库-预览版.html     ← 🎯 20题预览版
│   └── questions.json           ← 结构化题库数据
│
└── README.md
```

## 重新生成

```bash
cd 02-scripts

# 步骤1：解析源文件（如 .txt 有更新才需要）
python parse_and_generate.py

# 步骤2：生成 HTML
python gen_preview.py         # → ../03-output/AIGC题库-预览版.html
python generate_html.py       # → ../03-output/AIGC题库练习.html
```

脚本路径已全部用相对路径，可在任意位置运行。

## 功能

- 左栏题型导航 + 标签筛选（带统计数）
- 分页大小可调（20/50/100题/页）
- 全部提交按钮（弹窗确认，未答题视作答错，简答题跳过）
- 判断/单选/多选 即时判分 + 解析
- 简答题 写完后对照标准答案
- 错题收集 + 错题重做模式
- 成绩单、随机练习、暗色模式、移动端适配
- localStorage 进度持久化
- 键盘翻页（← →）
