---
name: 9xiao-report
description: |
  9肖预测数据报表 —— 支持两种模式：(A) 单文件 Test02.xlsx 多Sheet HTML；(B) excel-source/ 多文件两级Tab HTML。
  触发场景：
  (1) "帮我优化这个表格"、"更新 HTML"、"重新生成"、"根据这个excel生成html"
  (2) 用户用 Excel 坐标（如 A1:D2、G5）定位单元格
  (3) 用户要求调整样式、合并、边框、行背景色、固定表头
  关键词：9肖、生肖、报表、合并单元格、多Sheet、两级Tab、波色
allowed-tools:
  - Read
  - Write
  - Bash
  - Edit
---

# 9xiao-report — 多 Sheet / 多文件 HTML 报表

## 两种工作模式

| 模式 | 数据源 | 脚本 | 输出 |
|------|--------|------|------|
| A: 单文件 | `Test02.xlsx` | `read_xlsx.py` → `generate_html.py` | 单级 Tab HTML |
| B: 多文件 | `excel-source/*.xlsx` | `merge_excel_source.py` → `generate_html.py` | 两级 Tab HTML |

## 文件结构

```
myself-linshi/
├── read_xlsx.py              # 模式A: 双 workbook 读单文件 → JSON
├── merge_excel_source.py     # 模式B: 合并 excel-source/ 所有文件 → JSON
├── normalize_3months.py      # 规范化脚本：旧格式 → Test02 格式
├── _xlsx_data.json           # 中间数据
├── generate_html.py          # 主生成器（通用，含格式自动检测）
├── excel-source/             # 月度历史文件 (2025-11 ~ 2026-07)
├── excel-source-normalized/  # 规范化后的文件（临时）
└── Test-*.html               # 产物（带时间戳）
```

## 使用方式

**模式 B（推荐）**：
```bash
cd myself-linshi
python merge_excel_source.py && python generate_html.py
```

**模式 A**：
```bash
# 改 read_xlsx.py 中 xlsx_path 指向目标文件
python read_xlsx.py && python generate_html.py
```

## 两级 Tab 结构（模式 B）

- **一级 Tab**：月份（文件名解析：`历史记录：26年-02月.xlsx` → `2026-02`），新→旧排序
  - 固定顶部，sticky
- **二级 Tab**：Sheet 名（9肖-精选版/普通版01/02/4肖6肖7肖/其它预测）
  - 固定底部，居左排列

## 格式自动检测

`render_sheet()` 检测 `rows[2]` 中是否含 "注意" 或 "http"：
- **Test02 格式**（有 URL 行）：`rows[1]=标题, rows[2]=URL, rows[3]=表头, data=rows[5:]`
- **源格式**（无 URL 行）：`rows[1]=标题+URLs, rows[2]=表头, data=rows[4:]`

## render_sheet 渲染细节

- **合并表头**：行1(title)+行2(URL)+行3(列头)，`sec-header`/`gray-row`/`col-header-row`
- **列组边框**：纯右边框 `2px solid #999`，thead 用 class，tbody 用 nth-child(col+2)
- **列头改名**：`开奖\n生肖`→`生肖`, `波号\n颜色`→`特码`, `开奖\n大小`→`大小`, `开奖\n单双`→`单双`, `家禽\n野兽`→`家野`, `开奖颜色`→`波色`
- **中/不中**：kc=6→M/N, kc≠6→N/O
- **波色背景**：J列(特码)按号码→波色，M列(其它预测)按名称→波色
- **未命中置灰**：结果=未命中→预测列灰底 `#e0e0e0`；波色组(width=4)置灰2格
- **生肖统计行**：colspan=4, 灰底居中, 显式边框覆盖 nth-child 偏移
- **表头 sticky**：top:0/22px/48px/74px（相对表格容器）

## 样式约定

| 元素 | 值 |
|------|-----|
| 表头行1-2 | `#D9D9D9` 灰 |
| 表头行3 | `#7BB3E0` 蓝底白字 |
| E 列 | `#fff` 白底 `!important`，无加粗上下边框 |
| A 列 | 左边框加粗 |
| 命中/未命中 | 绿底 `#e2efda`/红底 `#fce4ec` |
| 红/蓝/绿波 | `#FD7272`/`#2FC8EE`/`#65EC74` |
| URL | `<a>` target="_blank"，href=Excel 超链接 |

## 反模式

| 错误 | 正确 |
|------|------|
| 样式用 `replace('">',...)` 拼接 | `list.append` + `";".join()` |
| nth-child 给 thead 加边框 | thead class，tbody nth-child |
| colspan 后 nth-child 偏移 | 显式 border-right 全覆盖 |
| card 上加 overflow-x | `.table-wrap` 加 overflow，sticky 才生效 |
| 忘跳过 `~$` 临时文件 | `not f.startswith('~$')` |

## 禁令

- MUST NOT 在 HTML 中引入外部 CDN
- MUST NOT 删除旧 HTML 产物
- MUST NOT 手写列偏移常量
