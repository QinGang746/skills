#!/usr/bin/env python3
"""Two-level tab HTML: months L1 → sheets L2, full SKILL.md rich renderer"""
import json, re
from datetime import datetime

JSON_PATH = "E:/qgTest_ClaudeCode/myself-linshi/_xlsx_data.json"
_ts = datetime.now().strftime("%Y%m%d-%H%M")
HTML_PATH = f"E:/qgTest_ClaudeCode/myself-linshi/Test-{_ts}.html"

with open(JSON_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)

months = data["months"]
RED_BO = {1,2,7,8,12,13,18,19,23,24,29,30,34,35,40,45,46}
BLUE_BO = {3,4,9,10,14,15,20,25,26,31,36,37,41,42,47,48}
GREEN_BO = {5,6,11,16,17,21,22,27,28,32,33,38,39,43,44,49}
BOSE_BG = {"红波": "#FD7272", "蓝波": "#2FC8EE", "绿波": "#65EC74"}

def bose_of(num):
    try: n = int(str(num).strip())
    except: return None, None
    if n in RED_BO: return "红波", BOSE_BG["红波"]
    if n in BLUE_BO: return "蓝波", BOSE_BG["蓝波"]
    if n in GREEN_BO: return "绿波", BOSE_BG["绿波"]
    return None, None

def hit_cls(val):
    if val == "命中": return "hit"
    if val == "未命中": return "miss"
    return ""

def col_letter(n):
    if n < 26: return chr(65 + n)
    return chr(64 + n // 26) + chr(65 + n % 26)

def render_sheet(rows, hyperlinks, ncols, tab_id):
    """Full SKILL.md renderer with auto-format detection"""
    # Detect format: Test02 (r3 has URL) vs source (r3 is headers)
    has_url_row = False
    if len(rows) > 2:
        r3 = rows[2]
        has_url_row = any("注意" in str(r3[i]) or "http" in str(r3[i]) for i in range(len(r3)))

    if has_url_row:
        title_row = rows[1] if len(rows) > 1 else []
        url_row = rows[2] if len(rows) > 2 else []
        header_row = list(rows[3]) if len(rows) > 3 else []
        data_start = 5
        url_hl_key = "3"
    else:
        title_row = rows[1] if len(rows) > 1 else []
        url_row = None
        header_row = list(rows[2]) if len(rows) > 2 else []
        data_start = 4
        url_hl_key = "2"

    # Column renames
    renames = {"开奖\n生肖": "生肖", "波号\n颜色": "特码", "开奖\n大小": "大小", "开奖\n单双": "单双", "家禽\n野兽": "家野", "开奖颜色": "波色"}
    for i in range(len(header_row)):
        if header_row[i] in renames:
            header_row[i] = renames[header_row[i]]

    # Auto-detect groups from title row col 14+
    groups = []
    i = 14
    while i < ncols:
        raw = title_row[i].strip() if i < len(title_row) else ""
        if raw:
            next_i = i + 1
            while next_i < ncols and (next_i >= len(title_row) or not title_row[next_i].strip()):
                next_i += 1
            w = next_i - i if next_i < ncols else 3
            m_url = re.search(r'(https?://\S+)', raw)
            pure_title = raw[:m_url.start()].strip() if m_url else raw
            url_text = m_url.group(1) if m_url else ""
            if url_row:
                url_text = url_row[i] if i < len(url_row) else ""
            href = hyperlinks.get(f"{url_hl_key},{i+1}", url_text)
            groups.append({"start": i, "width": w, "title": pure_title, "url_text": url_text, "href": href})
            i = next_i
        else:
            i += 1

    first_start = groups[0]["start"] if groups else 14
    kc = first_start - 8
    last_fixed = first_start - 1
    br = {3, 7, last_fixed}
    for g in groups:
        br.add(g["start"] + g["width"] - 1)

    # Rename 中/不中
    if kc == 6 and len(header_row) > 13:
        header_row[12] = "中"; header_row[13] = "不中"
    elif len(header_row) > 14:
        header_row[13] = "中"; header_row[14] = "不中"

    # ── Row 1: merged titles ──
    r1 = []
    r1.append(f'<th colspan="4" rowspan="2" class="br-l br-r">版本命中率</th>')
    r1.append('<th class="col-e br-r"></th>')
    r1.append(f'<th colspan="3" rowspan="2" class="br-l br-r">共30天</th>')
    r1.append(f'<th colspan="{kc}" class="br-r">开奖</th>')
    for g in groups:
        r1.append(f'<th colspan="{g["width"]}" class="br-r" style="text-align:left;">{g["title"]}</th>')
    last_end = groups[-1]["start"] + groups[-1]["width"] if groups else 14
    if last_end < ncols:
        r1.append(f'<th colspan="{ncols - last_end}"></th>')
    r1_html = "".join(r1)

    # ── Row 2: URL row ──
    r2 = []
    r2.append('<td class="col-e br-r"></td>')
    r2_note = (url_row[8] if url_row and len(url_row) > 8 else title_row[8] if len(title_row) > 8 else "")
    r2.append(f'<td colspan="{kc}" class="br-r" style="font-size:11px;">{r2_note}</td>')
    for g in groups:
        href = g["href"]; txt = g["url_text"]
        cell = f'<a href="{href}" target="_blank" style="color:#1a73e8;">{txt}</a>' if href and txt else (txt or "")
        r2.append(f'<td colspan="{g["width"]}" class="br-r url-cell" style="text-align:left;">{cell}</td>')
    if last_end < ncols:
        r2.append(f'<td colspan="{ncols - last_end}"></td>')
    r2_html = "".join(r2)

    # ── Row 3: column headers ──
    cl = "".join(f'<th>{col_letter(i)}</th>' for i in range(ncols))
    r3_parts = []
    for i in range(ncols):
        cls = []
        if i == 0: cls.append("br-l")
        if i == 4: cls.append("col-e br-r")
        if i in br: cls.append("br-r")
        r3_parts.append(f'<th class="{" ".join(cls)}">{header_row[i] if i < len(header_row) else ""}</th>')
    r3_html = "".join(r3_parts)

    # ── Gray cols on miss ──
    gray_cols = set()
    for g in groups:
        if g["width"] == 4:
            gray_cols.add((g["start"], g["start"] + 2))
            gray_cols.add((g["start"] + 1, g["start"] + 2))
        else:
            gray_cols.add((g["start"], g["start"] + 1))

    # ── Data rows ──
    data_html_parts = []
    base_row = 3
    for idx in range(data_start, len(rows)):
        row = rows[idx]
        if all(v == "" for v in row): continue
        rn = base_row + (idx - data_start) + 1
        first_cell = row[0].strip() if len(row) > 0 else ""
        prev_first = rows[idx-1][0].strip() if idx > data_start and len(rows[idx-1]) > 0 else ""

        if "生肖统计" in first_cell:
            thick = br | {4}
            dc = [f'<td class="row-num">{rn}</td>',
                  f'<td colspan="4" style="background:#D9D9D9;font-weight:bold;text-align:center;border-right:2px solid #999;border-top:2px solid #999;border-bottom:2px solid #999;">{first_cell}</td>']
            for i in range(4, ncols):
                val = row[i] if i < len(row) else ""
                if i == 9 and val and val.strip().isdigit() and len(val.strip()) == 1: val = "0" + val.strip()
                cls = hit_cls(val); styles = []
                for col, res_col in gray_cols:
                    if i == col and row[res_col].strip() == "未命中": styles.append("background:#e0e0e0"); break
                if i == 9:
                    _, bc = bose_of(val)
                    if bc: styles.append(f"background:{bc}")
                if i == 12 and val in BOSE_BG: styles.append(f"background:{BOSE_BG[val]}")
                styles.append(f"border-right:{'2px solid #999' if i in thick else '1px solid #d4d4d4'}")
                extra = f' style="{";".join(styles)}"'
                dc.append(f'<td class="{cls}"{extra}>{val}</td>' if cls else f'<td{extra}>{val}</td>')
            data_html_parts.append(f'<tr>{"".join(dc)}</tr>')
            continue

        cells = [f'<td class="row-num">{rn}</td>']
        for i in range(ncols):
            val = row[i] if i < len(row) else ""
            if i == 9 and val and val.strip().isdigit() and len(val.strip()) == 1: val = "0" + val.strip()
            cls = hit_cls(val); styles = []
            if "生肖统计" in prev_first and i < 4:
                styles.append("background:#7BB3E0;color:#fff;font-weight:600;border-top:2px solid #999;border-bottom:2px solid #999")
            else:
                for col, res_col in gray_cols:
                    if i == col and row[res_col].strip() == "未命中": styles.append("background:#e0e0e0"); break
            if i == 9:
                _, bc = bose_of(val)
                if bc: styles.append(f"background:{bc}")
            if i == 12 and val in BOSE_BG: styles.append(f"background:{BOSE_BG[val]}")
            extra = f' style="{";".join(styles)}"' if styles else ""
            cells.append(f'<td class="{cls}"{extra}>{val}</td>' if cls else f'<td{extra}>{val}</td>')
        data_html_parts.append(f'<tr>{"".join(cells)}</tr>')
    data_html = "\n".join(data_html_parts)

    # ── Column border CSS ──
    br_css = []
    br_css.append(f"#{tab_id} tbody td:nth-child(2){{border-left:2px solid #999;}}")
    br_css.append(f"#{tab_id} tbody td:nth-child(5){{border-right:2px solid #999;}}")
    br_css.append(f"#{tab_id} tbody td:nth-child(6){{border-right:2px solid #999;}}")
    br_css.append(f"#{tab_id} tbody td:nth-child(9){{border-right:2px solid #999;}}")
    br_css.append(f"#{tab_id} tbody td:nth-child({last_fixed + 2}){{border-right:2px solid #999;}}")
    for g in groups:
        ce = g["start"] + g["width"] + 1
        br_css.append(f"#{tab_id} tbody td:nth-child({ce}){{border-right:2px solid #999;}}")

    tbl = f"""<div class="table-wrap"><table>
        <thead>
          <tr class="coord-row"><th class="coord-col"></th>{cl}</tr>
          <tr class="sec-header"><td class="row-num">1</td>{r1_html}</tr>
          <tr class="gray-row" style="font-size:11px;"><td class="row-num">2</td>{r2_html}</tr>
          <tr class="col-header-row"><td class="row-num">3</td>{r3_html}</tr>
        </thead>
        <tbody>{data_html}</tbody>
    </table></div>"""
    return tbl, "\n".join(br_css)

# ── Build HTML ──
mlabels = list(months.keys())
tabs_btns = []; tabs_pages = []; all_br = []

for mi, ml in enumerate(mlabels):
    tid_m = f"m{mi}"; active = " active" if mi == 0 else ""
    tabs_btns.append(f'<button class="tab-btn{active}" onclick="switchMonth({mi})">{ml}</button>')
    sheets = months[ml]; snames = list(sheets.keys())
    sub_btns = []; sub_pages = []
    for si, sn in enumerate(snames):
        stid = f"m{mi}s{si}"; sa = " active" if si == 0 else ""
        sub_btns.append(f'<button class="subtab-btn{sa}" onclick="switchSubTab(\'{stid}\')">{sn}</button>')
        info = sheets[sn]
        tbl, brs = render_sheet(info["rows"], info["hyperlinks"], info["ncols"], stid)
        all_br.append(brs)
        sub_pages.append(f'<div class="subtab-page{sa}" id="{stid}"><div class="card">{tbl}</div></div>')
    tabs_pages.append(f'<div class="tab-page{active}" id="{tid_m}">{"".join(sub_pages)}<div class="subtab-nav"><div class="subtab-row">{"".join(sub_btns)}</div></div></div>')

html = f"""<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>历史记录报表</title><style>
:root{{--primary:#1a73e8;--bg:#f0f2f5;--card:#fff;}}
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{font-family:"Microsoft YaHei",Arial,sans-serif;background:var(--bg);color:#333;}}
.tab-nav{{position:sticky;top:0;z-index:30;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.08);}}
.tab-row{{display:flex;flex-wrap:wrap;padding:0 20px;overflow-x:auto;}}
.tab-btn{{padding:12px 16px;border:none;background:none;cursor:pointer;font-size:13px;color:#666;border-bottom:3px solid transparent;white-space:nowrap;}}
.tab-btn:hover{{color:var(--primary);}}
.tab-btn.active{{color:var(--primary);border-bottom-color:var(--primary);font-weight:bold;}}
.tab-page{{display:none;padding:0 20px 50px;}}
.tab-page.active{{display:block;overflow-x:auto;}}
.subtab-nav{{position:fixed;bottom:0;left:0;right:0;z-index:25;background:#f8f9fa;border-top:1px solid #e0e0e0;padding:0 20px;}}
.subtab-row{{display:flex;flex-wrap:wrap;}}
.subtab-btn{{padding:8px 14px;border:none;background:none;cursor:pointer;font-size:12px;color:#888;border-bottom:2px solid transparent;}}
.subtab-btn:hover{{color:var(--primary);}}
.subtab-btn.active{{color:var(--primary);border-bottom-color:var(--primary);font-weight:bold;}}
.subtab-page{{display:none;padding-top:12px;}}
.subtab-page.active{{display:block;}}
.card{{background:var(--card);border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);padding:18px;margin-bottom:20px;}}
.table-wrap{{overflow-x:auto;margin-top:8px;}}
table{{border-collapse:collapse;width:100%;font-size:12px;font-family:"Microsoft YaHei","Segoe UI",Arial,sans-serif;}}
th,td{{border:1px solid #d4d4d4;padding:4px 8px;text-align:center;white-space:nowrap;}}
th{{background:#f8f9fa;color:#333;font-weight:600;font-size:12px;}}
td{{background:#fff;}}
tr:hover td{{background:#e8f0fe;}}
.coord-row th{{background:#f0f0f0;color:#555;font-size:11px;font-weight:400;min-width:26px;padding:2px 6px;}}
td.row-num{{background:#f0f0f0;color:#555;font-size:11px;font-weight:400;min-width:26px;padding:2px 6px;}}
.coord-row th{{position:sticky;top:0;z-index:5;}}
.sec-header th,.sec-header td{{position:sticky;top:22px;z-index:6;}}
.gray-row th,.gray-row td{{position:sticky;top:48px;z-index:6;}}
.col-header-row th,.col-header-row td{{position:sticky;top:74px;z-index:6;}}
.sec-header th{{background:#D9D9D9;color:#333;font-size:12px;font-weight:600;}}
.sec-header td.row-num{{background:#D9D9D9;color:#333;font-weight:600;}}
.gray-row td,.gray-row th,.gray-row td.row-num{{background:#D9D9D9;color:#333;}}
.col-header-row th{{background:#7BB3E0;color:#fff;font-weight:600;font-size:12px;}}
.col-header-row td.row-num{{background:#7BB3E0;color:#fff;}}
.col-e{{background:#fff !important;border-top:1px solid #d4d4d4 !important;border-bottom:1px solid #d4d4d4 !important;}}
.br-l{{border-left:2px solid #999;}}
.br-r{{border-right:2px solid #999;}}
.sec-header th,.sec-header td{{border-top:2px solid #999;border-bottom:2px solid #999;}}
.gray-row th,.gray-row td{{border-top:2px solid #999;border-bottom:2px solid #999;}}
.col-header-row th,.col-header-row td{{border-top:2px solid #999;border-bottom:2px solid #999;}}
td.hit{{color:#217346;font-weight:bold;background:#e2efda !important;}}
td.miss{{color:#a8372a;font-weight:bold;background:#fce4ec !important;}}
td.url-cell{{font-size:11px;color:#888;max-width:160px;white-space:normal;word-break:break-all;}}
td.url-cell a{{color:#1a73e8;text-decoration:none;}}
td.url-cell a:hover{{text-decoration:underline;}}
{"".join(all_br)}
</style></head><body>
<div class="tab-nav"><div class="tab-row">{"".join(tabs_btns)}</div></div>
{"".join(tabs_pages)}
<script>
var curSub={{}};for(var i=0;i<{len(mlabels)};i++)curSub[i]=0;
function switchMonth(n){{document.querySelectorAll('.tab-btn').forEach(function(b,i){{b.classList.toggle('active',i===n);}});document.querySelectorAll('.tab-page').forEach(function(p,i){{p.classList.toggle('active',i===n);}});}}
function switchSubTab(id){{var p=id.substring(1).split('s');var m=parseInt(p[0]),s=parseInt(p[1]);curSub[m]=s;document.querySelectorAll('#m'+m+' .subtab-btn').forEach(function(b,i){{b.classList.toggle('active',i===s);}});document.querySelectorAll('#m'+m+' .subtab-page').forEach(function(p,i){{p.classList.toggle('active',i===s);}});}}
</script></body></html>"""

with open(HTML_PATH, "w", encoding="utf-8") as f:
    f.write(html)

print(f"Generated: {HTML_PATH}")
print(f"   Size: {len(html):,} chars, {len(mlabels)} months")
