"""Merge all excel-source files → JSON with month→sheets structure"""
import os, json, re, openpyxl
from collections import OrderedDict

SRC = r'E:\qgTest_ClaudeCode\myself-linshi\excel-source'
OUT = r'E:\qgTest_ClaudeCode\myself-linshi\_xlsx_data.json'

files = sorted([f for f in os.listdir(SRC) if f.endswith('.xlsx') and not f.startswith('~$')])
result = {"months": OrderedDict()}

for fname in files:
    label = fname.replace('历史记录：', '').replace('.xlsx', '')
    m = re.search(r'(\d{2})年-(\d{2})月', label)
    month_id = f"20{m.group(1)}-{m.group(2)}" if m else label

    wb_val = openpyxl.load_workbook(os.path.join(SRC, fname), data_only=True)
    wb_hl = openpyxl.load_workbook(os.path.join(SRC, fname), data_only=False)

    month_data = OrderedDict()
    for sname in wb_val.sheetnames:
        ws_val = wb_val[sname]
        ws_hl = wb_hl[sname]
        ncols = ws_val.max_column
        rows = []
        hyperlinks = {}

        for r in range(1, ws_val.max_row + 1):
            vals = [str(ws_val.cell(r, c).value) if ws_val.cell(r, c).value is not None else ''
                    for c in range(1, ncols + 1)]
            # Capture hyperlinks from row 2 and row 3
            if r in (2, 3):
                for c in range(1, ncols + 1):
                    cell_hl = ws_hl.cell(r, c)
                    if cell_hl.hyperlink:
                        hyperlinks[f"{r},{c}"] = cell_hl.hyperlink.target
            rows.append(vals)

        month_data[sname] = {"rows": rows, "hyperlinks": hyperlinks, "ncols": ncols}

    result["months"][month_id] = month_data
    wb_val.close()
    wb_hl.close()

# Sort months descending (newest first)
result["months"] = OrderedDict(sorted(result["months"].items(), reverse=True))

with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print(f"Done → {OUT}")
for m, sheets in result["months"].items():
    print(f"  {m}: {len(sheets)} sheets — {list(sheets.keys())}")
