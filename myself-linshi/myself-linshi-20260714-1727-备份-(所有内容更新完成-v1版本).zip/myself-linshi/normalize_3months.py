"""
normalize_3months.py — 将 25年-11/12月、26年-01月 规范化为 26年-06月格式

差异：
  25年-11月: 不同Sheet名, URLs嵌入标题行, 274列, 无独立URL行
  25年-12月: 格式正确但142列, r3注意文本不完整
  26年-01月: 格式正确但142列
  26年-06月: 基准, 52列, 5 Sheet, r2=标题, r3=URL, r4=表头

操作：
  25年-11月 → Sheet改名 + 拆出URL行 + 插入"注意！"行
  25年-12月 → 检查URL超链接, 保持格式
  26年-01月 → 检查URL超链接, 保持格式
"""
import os, re, shutil
import openpyxl

SRC = r'E:\qgTest_ClaudeCode\myself-linshi\excel-source'
OUT = r'E:\qgTest_ClaudeCode\myself-linshi\excel-source-normalized'

TARGET_FILES = ['历史记录：25年-11月.xlsx', '历史记录：25年-12月.xlsx', '历史记录：26年-01月.xlsx']
REF_FILE = '历史记录：26年-06月.xlsx'

# 25年-11月 Sheet 名映射
SHEET_MAP = {
    '精选9肖': '9肖-精选版',
    '11月-普通9肖': '9肖-普通版01',
    '4肖6肖': '4肖6肖7肖',
    '开奖记录(汇总)': '其它预测',
}

if not os.path.exists(OUT):
    os.makedirs(OUT)

# ── 先读基准文件，获取标准 Sheet 列表和结构 ──
ref_wb = openpyxl.load_workbook(os.path.join(SRC, REF_FILE), data_only=True)
REF_SHEETS = list(ref_wb.sheetnames)
ref_wb.close()
print(f"基准 Sheet: {REF_SHEETS}")

for fname in TARGET_FILES:
    src_path = os.path.join(SRC, fname)
    out_path = os.path.join(OUT, fname)
    label = fname.replace('历史记录：', '').replace('.xlsx', '')
    print(f"\n{'='*50}\n处理: {label}\n{'='*50}")

    wb_src = openpyxl.load_workbook(src_path)
    wb_hl = openpyxl.load_workbook(src_path, data_only=False)  # 读超链接
    wb_out = openpyxl.Workbook()
    wb_out.remove(wb_out.active)

    is_202511 = (label == '25年-11月')

    for target_name in REF_SHEETS:
        # 找到对应的源 Sheet
        src_name = None
        if is_202511:
            # 反向映射
            for old, new in SHEET_MAP.items():
                if new == target_name and old in wb_src.sheetnames:
                    src_name = old
                    break
        else:
            if target_name in wb_src.sheetnames:
                src_name = target_name

        if src_name is None:
            # 不存在的 Sheet，创建空占位
            ws = wb_out.create_sheet(title=target_name)
            ws.cell(1, 1).value = '(空)'
            print(f"  {target_name}: 不存在 → 空占位")
            continue

        ws_src = wb_src[src_name]
        ws_hl_src = wb_hl[src_name]
        ws_out = wb_out.create_sheet(title=target_name)
        ncols = ws_src.max_column
        nrows = ws_src.max_row
        print(f"  {src_name} → {target_name} ({nrows}r x {ncols}c)")

        if is_202511:
            # ── 25年-11月: 完整重构 ──
            # 命中线路图去除：仅针对精选版 (12列/组→3列)
            is_jingxuan = (target_name == '9肖-精选版')
            if is_jingxuan:
                col_map = []
                ti = 0
                for sc in range(ncols):
                    if sc < 14:
                        col_map.append(ti); ti += 1
                    else:
                        offset = (sc - 14) % 12
                        if offset in (0, 10, 11):
                            col_map.append(ti); ti += 1
                        else:
                            col_map.append(None)
                new_ncols = ti
                print(f"    列压缩: {ncols} → {new_ncols} cols (去除命中线路图)")
            else:
                col_map = list(range(ncols))
                new_ncols = ncols

            # Row 1: 复制
            for c in range(1, ncols + 1):
                tc = col_map[c-1]
                if tc is not None:
                    ws_out.cell(1, tc+1).value = ws_src.cell(1, c).value

            # Row 2: 标题行 → 拆分 URL, 同时压缩列
            for c in range(1, ncols + 1):
                tc = col_map[c-1]
                if tc is None: continue
                cell_val = str(ws_src.cell(2, c).value or '')
                m_url = re.search(r'(https?://\S+)', cell_val)
                if m_url:
                    pure_title = cell_val[:m_url.start()].strip()
                    url_part = m_url.group(1)
                    ws_out.cell(2, tc+1).value = pure_title
                    ws_out.cell(3, tc+1).value = url_part
                    if ws_hl_src.cell(2, c).hyperlink:
                        ws_out.cell(3, tc+1).hyperlink = ws_hl_src.cell(2, c).hyperlink
                else:
                    ws_out.cell(2, tc+1).value = cell_val
                    if ws_hl_src.cell(2, c).hyperlink:
                        ws_out.cell(2, tc+1).hyperlink = ws_hl_src.cell(2, c).hyperlink

            # Row 3: 插入"注意！"到 URL 行的 col 9
            ws_out.cell(3, 9).value = '注意！9点半开奖后更新 (死0-3个)'

            # Rows 4+: 压缩列
            for r in range(3, nrows + 1):
                for c in range(1, ncols + 1):
                    tc = col_map[c-1]
                    if tc is None: continue
                    cell_src = ws_src.cell(r, c)
                    out_r = r + 1
                    ws_out.cell(out_r, tc+1).value = cell_src.value
                    if cell_src.hyperlink:
                        ws_out.cell(out_r, tc+1).hyperlink = cell_src.hyperlink

            print(f"    重构完成: {nrows}→{nrows+1}行, {ncols}→{new_ncols}列")

        else:
            # ── 25年-12月, 26年-01月: 格式已对，复制并修正 URL ──
            for r in range(1, nrows + 1):
                for c in range(1, ncols + 1):
                    cell_src = ws_src.cell(r, c)
                    cell_hl_src = ws_hl_src.cell(r, c)
                    ws_out.cell(r, c).value = cell_src.value
                    if cell_hl_src.hyperlink:
                        ws_out.cell(r, c).hyperlink = cell_hl_src.hyperlink

            # 修正 r3 c9 的"注意"文本（如果不完整）
            r3c9 = str(ws_src.cell(3, 9).value or '')
            if '注意' in r3c9 and '死' not in r3c9:
                ws_out.cell(3, 9).value = '注意！9点半开奖后更新 (死0-3个)'
                print(f"    修正r3c9注意文本")

            print(f"    直接复制, 超链接已保留")

    wb_src.close()
    wb_hl.close()
    wb_out.save(out_path)
    wb_out.close()
    print(f"  → 已保存: {out_path}")

print(f"\n完成! 输出目录: {OUT}")
