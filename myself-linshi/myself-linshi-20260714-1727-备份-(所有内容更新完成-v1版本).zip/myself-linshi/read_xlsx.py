import openpyxl
import json

xlsx_path = r'E:\qgTest_ClaudeCode\myself-linshi\Test02.xlsx'

# data_only=True → computed values; data_only=False → hyperlinks accessible
wb_val = openpyxl.load_workbook(xlsx_path, data_only=True)
wb_hl = openpyxl.load_workbook(xlsx_path, data_only=False)

result = {"sheets": {}}

for name in wb_val.sheetnames:
    ws_val = wb_val[name]
    ws_hl = wb_hl[name]
    sheet_data = {
        "max_row": ws_val.max_row,
        "max_col": ws_val.max_column,
        "rows": [],
        "hyperlinks": {}
    }
    for row_idx in range(1, ws_val.max_row + 1):
        vals = []
        for col_idx in range(1, ws_val.max_column + 1):
            cell_val = ws_val.cell(row=row_idx, column=col_idx)
            vals.append(str(cell_val.value) if cell_val.value is not None else '')
            # Capture hyperlink from non-data_only workbook
            cell_hl = ws_hl.cell(row=row_idx, column=col_idx)
            if cell_hl.hyperlink:
                sheet_data["hyperlinks"][f"{row_idx},{col_idx}"] = cell_hl.hyperlink.target
        sheet_data["rows"].append(vals)
    result["sheets"][name] = sheet_data

out_path = r'E:\qgTest_ClaudeCode\myself-linshi\_xlsx_data.json'
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print("Done. Written to myself-linshi/_xlsx_data.json")
print(f"Sheets: {wb_val.sheetnames}")
for name in wb_val.sheetnames:
    hl_count = len(result["sheets"][name]["hyperlinks"])
    print(f"  {name}: {wb_val[name].max_row} rows x {wb_val[name].max_column} cols, {hl_count} hyperlinks")

wb_val.close()
wb_hl.close()
