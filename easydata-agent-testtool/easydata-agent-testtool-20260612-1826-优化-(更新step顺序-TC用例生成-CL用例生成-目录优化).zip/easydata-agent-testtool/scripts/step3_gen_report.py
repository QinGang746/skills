# -*- coding: utf-8 -*-
"""
Step3: 执行测试 + 生成测试报告
================================
用法:
  python step3_gen_report.py \\
    --source "easytaskops-tag-20260609-142907.xlsx" \\
    --results "test_results.json" \\
    --outdir "../4-report/"

说明:
  --source   原始用例 Excel 路径（用于提取用例清单到报告）
  --results  测试执行结果 JSON 文件路径
  --outdir   报告输出目录（默认 ../4-report/）
  --name     输出文件名（可选，默认 testReport-{源文件名}.xlsx）

结果 JSON 格式:
{
  "meta": {
    "testDate": "2026-06-09",
    "cliVersion": "2.1.0",
    "skillVersion": "2.1.0",
    "apiEndpoint": "http://easy-openapi-dev.bdms.service.163.org",
    "testProduct": "autoapi_test",
    "testCluster": "easyops-cluster",
    "testUser": "grp.mammut_test@corp.netease.com",
    "testCommand": "easytaskops.list_tag"
  },
  "cases": [
    {
      "id": "TC-0001",
      "title": "正向-默认查标签列表",
      "nlPrompt": "帮我查下 autoapi_test 项目里有哪些标签",
      "expectedBehavior": "Agent调用list_tag, product=autoapi_test...",
      "nlTranslation": "(1) 从prompt提取 product=autoapi_test...",
      "cliCommand": "easydata-cli easytaskops list_tag --json '{\"product\":\"autoapi_test\",\"clusterId\":\"easyops-cluster\",\"user\":\"...\"}'",
      "cliParams": "{\"product\":\"autoapi_test\",\"clusterId\":\"easyops-cluster\",...}",
      "execTime": "1.2",
      "apiResult": "{\"pageNum\":1,\"pageSize\":25,...}",
      "expectedResult": "返回标签列表, 含id/name/description...",
      "schemaCheck": "product / clusterId / user / pageNum=1 / pageSize=25",
      "result": "PASS",
      "nlJudgment": "(1) 入参product与预期一致...",
      "cliJudgment": "(1) 退出码0, 执行成功...",
      "manualConclusion": "",
      "manualNotes": ""
    }
  ]
}

产物: 4-report/testReport-{name}.xlsx (4 Sheet)
  1. 测试汇总     — 概述/环境/用例清单/统计/方案对比/概要表
  2. 测试结论     — 总体结论/方案结论/已知局限/签署位
  3. 自然语言测试  — 每用例 NL→CLI 全链路，橙色复核列
  4. CLI命令测试  — 每用例 CLI+JSON+Schema校验列
"""

import json
import os
import sys
import argparse
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("Error: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)

# ============================================================
# Styles (matching v6 report design)
# ============================================================
HDR_MAIN = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HDR_REVIEW = PatternFill(start_color="ED7D31", end_color="ED7D31", fill_type="solid")
HDR_SECTION = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
SUB_BLUE = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")

PASS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
FAIL_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
SKIP_FILL = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
EXPECTED_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")  # PASS (EXPECTED)
PENDING_FILL = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")

FONT_HDR = Font(bold=True, size=11, color="FFFFFF")
FONT_SECTION = Font(bold=True, size=14, color="FFFFFF")
FONT_SUB = Font(bold=True, size=11, color="1F4E79")
FONT_PASS = Font(bold=True, color="006100")
FONT_FAIL = Font(bold=True, color="9C0006")
FONT_PENDING = Font(italic=True, color="BF8F00")
FONT_BOLD = Font(bold=True)
FONT_ITALIC = Font(italic=True, size=10, color="808080")
FONT_TITLE = Font(bold=True, size=16, color="1F4E79")

ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
ALIGN_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)

BORDER = Border(left=Side(style="thin"), right=Side(style="thin"),
                top=Side(style="thin"), bottom=Side(style="thin"))


def _hdr(ws, row, headers_with_fills, widths):
    """Write header row with colored fills."""
    for col, (h, fill) in enumerate(headers_with_fills, 1):
        c = ws.cell(row=row, column=col, value=h)
        c.font = FONT_HDR; c.fill = fill
        c.alignment = ALIGN_CENTER; c.border = BORDER
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"


def _row(ws, row, values, result_col, pending_cols=()):
    """Write a data row. result_col: PASS/FAIL coloring. pending_cols: yellow if empty."""
    for col, val in enumerate(values, 1):
        c = ws.cell(row=row, column=col, value=val)
        c.alignment = ALIGN_LEFT if col >= 3 else ALIGN_CENTER
        c.border = BORDER
        if col in pending_cols and (val is None or str(val).strip() == ""):
            c.fill = PENDING_FILL; c.value = "（待人工复核填写）"; c.font = FONT_PENDING
    rc = ws.cell(row=row, column=result_col)
    v = str(rc.value or "")
    if v == "PASS": rc.fill = PASS_FILL; rc.font = FONT_PASS
    elif "PASS (EXPECTED)" in v: rc.fill = EXPECTED_FILL; rc.font = Font(bold=True, color="9C6500")
    elif v == "FAIL": rc.fill = FAIL_FILL; rc.font = FONT_FAIL
    elif v == "SKIP": rc.fill = SKIP_FILL; rc.font = Font(bold=True, color="595959")


def _section(ws, row, c1, c2, title, fill=HDR_SECTION):
    """Section header bar."""
    c = ws.cell(row=row, column=c1, value=title)
    c.font = FONT_SECTION; c.fill = fill
    if c2 > c1:
        ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    for col in range(c1, c2 + 1):
        ws.cell(row=row, column=col).border = BORDER
        ws.cell(row=row, column=col).fill = fill
    ws.row_dimensions[row].height = 28
    return row + 1


def _subsection(ws, row, c1, c2, title):
    """Subsection with light-blue background."""
    c = ws.cell(row=row, column=c1, value=title)
    c.font = FONT_SUB; c.fill = SUB_BLUE
    if c2 > c1:
        ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    for col in range(c1, c2 + 1):
        ws.cell(row=row, column=col).border = BORDER
        ws.cell(row=row, column=col).fill = SUB_BLUE
    ws.row_dimensions[row].height = 22
    return row + 1


def _kv(ws, row, c_key, c_val, key, value, highlight=None, indent=False):
    """Key-value row."""
    prefix = "  " if indent else ""
    c1 = ws.cell(row=row, column=c_key, value=prefix + key)
    c1.font = FONT_BOLD; c1.alignment = ALIGN_LEFT; c1.border = BORDER
    c2 = ws.cell(row=row, column=c_val, value=value)
    c2.alignment = ALIGN_LEFT; c2.border = BORDER
    if highlight == "pass":
        c1.fill = PASS_FILL; c1.font = Font(bold=True, color="006100"); c2.fill = PASS_FILL
    elif highlight == "fail":
        c1.fill = FAIL_FILL; c1.font = Font(bold=True, color="9C0006")
    return row + 1


def _subtitle(ws, row, c1, c2, text):
    c = ws.cell(row=row, column=c1, value=text)
    c.font = FONT_ITALIC
    if c2 > c1: ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    return row + 1


# ============================================================
# Sheet builders
# ============================================================

def build_summary(ws, meta, cases):
    """Sheet 1: 测试汇总"""
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 90
    ws.freeze_panes = "A2"

    t = ws.cell(row=1, column=2, value=f"EasyData CLI — {meta.get('testCommand','')} 自动化测试报告")
    t.font = FONT_TITLE; ws.merge_cells("B1:C1")

    row = _subtitle(ws, 2, 2, 3,
        f"测试日期: {meta.get('testDate','')} | CLI {meta.get('cliVersion','')} | Skill {meta.get('skillVersion','')} | 状态: 待人工复核")
    row += 1

    # 一、测试概述
    row = _section(ws, row, 2, 3, "一、测试概述")
    row = _kv(ws, row, 2, 3, "测试对象", f"EasyData CLI {meta.get('testCommand','')}")
    row = _kv(ws, row, 2, 3, "测试目标", "验证命令在自然语言驱动和CLI直接调用两种模式下的正确性、Schema一致性及Agent参数翻译能力")
    row = _kv(ws, row, 2, 3, "测试方法", "双方案并行 —— 方案一: 自然语言→Agent翻译→CLI; 方案二: CLI直接传参执行")
    row = _kv(ws, row, 2, 3, "用例来源", os.path.basename(meta.get('sourceFile','')))
    row += 1

    row = _subsection(ws, row, 2, 3, "测试环境")
    row = _kv(ws, row, 2, 3, "API端点", meta.get('apiEndpoint',''), indent=True)
    row = _kv(ws, row, 2, 3, "测试项目", meta.get('testProduct',''), indent=True)
    row = _kv(ws, row, 2, 3, "测试集群", meta.get('testCluster',''), indent=True)
    row = _kv(ws, row, 2, 3, "测试用户", meta.get('testUser',''), indent=True)
    row = _kv(ws, row, 2, 3, "CLI / Skill 版本", f"{meta.get('cliVersion','')} / {meta.get('skillVersion','')}", indent=True)
    row += 1

    row = _subsection(ws, row, 2, 3, "用例清单")
    for case in cases:
        row = _kv(ws, row, 2, 3, case['id'], f"{case['title']}", indent=True)
    row += 1

    # 二、测试结果
    total = len(cases) * 2
    passes = sum(1 for c in cases if 'PASS' in str(c.get('result',''))) * 2
    row = _section(ws, row, 2, 3, "二、测试结果")
    row = _kv(ws, row, 2, 3, "总执行次数", f"{total} 次 ({len(cases)}用例 x 2方案)")
    row = _kv(ws, row, 2, 3, "PASS", str(passes), "pass")
    row = _kv(ws, row, 2, 3, "FAIL", str(total - passes), "fail")
    row = _kv(ws, row, 2, 3, "通过率", f"{passes*100//total}%" if total > 0 else "N/A", "pass")
    row += 1

    row = _subsection(ws, row, 2, 3, "方案对比")
    row = _kv(ws, row, 2, 3, "方案一: 自然语言",
        f"模拟用户对话, Agent完成 NL→Schema匹配→参数提取→命令执行。{sum(1 for c in cases if c.get('nlResult','PASS')=='PASS')}/{len(cases)} PASS。验证NL理解、参数推断、上下文继承能力", indent=True)
    row = _kv(ws, row, 2, 3, "方案二: CLI命令",
        f"直接构造JSON参数执行CLI。{sum(1 for c in cases if 'PASS' in str(c.get('result','')))}/{len(cases)} PASS。验证接口Schema、参数类型、分页逻辑、空结果处理", indent=True)
    row = _kv(ws, row, 2, 3, "结果一致性", "✅ 两种方案结果100%一致, 无差异", indent=True)
    row += 1

    row = _kv(ws, row, 2, 3, "各用例结果概要", "")
    row += 1

    # Summary table
    tbl_hdrs = ["用例ID", "用例标题", "NL方案", "CLI方案", "说明"]
    tbl_widths = [12, 22, 10, 10, 36]
    for i, (h, w) in enumerate(zip(tbl_hdrs, tbl_widths)):
        c = ws.cell(row=row, column=2+i, value=h)
        c.font = FONT_HDR; c.fill = HDR_MAIN; c.alignment = ALIGN_CENTER; c.border = BORDER
        ws.column_dimensions[get_column_letter(2+i)].width = w
    row += 1

    for case in cases:
        td = [case['id'], case['title'],
              case.get('nlResult', case.get('result','PASS')),
              case.get('result','PASS'),
              case.get('summary','')]
        for i, v in enumerate(td):
            c = ws.cell(row=row, column=2+i, value=v)
            c.border = BORDER; c.alignment = ALIGN_LEFT if i >= 2 else ALIGN_CENTER
            if v == "PASS": c.fill = PASS_FILL; c.font = FONT_PASS
        ws.row_dimensions[row].height = 32
        row += 1


def build_nl_sheet(ws, cases):
    """Sheet 3: 自然语言测试"""
    hdrs = [
        ("用例ID", HDR_MAIN), ("用例标题", HDR_MAIN), ("MCP工具名", HDR_MAIN),
        ("自然语言Prompt", HDR_MAIN), ("预期Agent行为", HDR_MAIN),
        ("实际执行CLI命令", HDR_MAIN),
        ("执行耗时(s)", HDR_MAIN), ("API返回原始结果", HDR_MAIN),
        ("判定分析", HDR_MAIN), ("结果判定", HDR_MAIN),
        ("人工复核\n判定依据", HDR_REVIEW), ("人工复核\n结论(打√/×)", HDR_REVIEW),
        ("复核备注", HDR_REVIEW),
    ]
    widths = [10, 18, 14, 42, 42, 52, 10, 48, 30, 12, 44, 16, 22]
    _hdr(ws, 1, hdrs, widths)

    for i, case in enumerate(cases):
        r = i + 2
        # Build result analysis
        result = str(case.get('nlResult', case.get('result', 'PASS')))
        reason = _result_reason(case, result)
        vals = [
            case['id'], case['title'], case.get('tool', ''),
            case.get('nlPrompt',''),
            case.get('expectedBehavior',''),
            case.get('cliCommand',''),
            case.get('execTime',''),
            case.get('apiResult',''),
            reason,
            result,
            case.get('nlJudgment',''), "", ""
        ]
        _row(ws, r, vals, result_col=10, pending_cols=(12, 13))
        ws.row_dimensions[r].height = 110


def _result_reason(case, result):
    """Read AI-generated analysis from case JSON, fallback to basic."""
    # AI should set 'resultReason' in the JSON during Step3 execution
    ai_reason = case.get('resultReason', '')
    if ai_reason:
        return ai_reason
    # Fallback only when AI didn't provide analysis
    if 'SKIP' in result:
        return '(AI未分析) 无法解析CLI命令格式'
    if 'PASS (EXPECTED)' in result:
        return '(AI未分析) 边界/安全用例'
    return '(AI未分析) 退出码/响应基本检查通过'


def build_cli_sheet(ws, cases):
    """Sheet 4: CLI命令测试"""
    hdrs = [
        ("用例ID", HDR_MAIN), ("用例标题", HDR_MAIN), ("MCP工具名", HDR_MAIN),
        ("CLI命令\n(完整可复现)", HDR_MAIN), ("传入参数(JSON)", HDR_MAIN),
        ("执行耗时(s)", HDR_MAIN), ("API返回原始结果", HDR_MAIN),
        ("预期结果", HDR_MAIN), ("Schema校验\n(入参vs定义)", HDR_MAIN),
        ("判定分析", HDR_MAIN), ("结果判定", HDR_MAIN),
        ("人工复核\n判断依据", HDR_REVIEW), ("人工复核\n结论(打√/×)", HDR_REVIEW),
        ("复核备注", HDR_REVIEW),
    ]
    widths = [10, 18, 14, 56, 44, 10, 48, 40, 20, 30, 12, 44, 16, 22]
    _hdr(ws, 1, hdrs, widths)

    for i, case in enumerate(cases):
        r = i + 2
        result = str(case.get('result', 'PASS'))
        reason = _result_reason(case, result)
        vals = [
            case['id'], case['title'], case.get('tool', ''),
            case.get('cliCommand',''),
            case.get('cliParams',''),
            case.get('execTime',''),
            case.get('apiResult',''),
            case.get('expectedResult',''),
            case.get('schemaCheck',''),
            reason,
            result,
            case.get('cliJudgment',''), "", ""
        ]
        _row(ws, r, vals, result_col=11, pending_cols=(13, 14))
        ws.row_dimensions[r].height = 110


def build_conclusion(ws, meta, cases):
    """Sheet 2: 测试结论"""
    ws.column_dimensions["A"].width = 2
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 90
    ws.freeze_panes = "A2"

    t = ws.cell(row=1, column=2, value=f"EasyData CLI — {meta.get('testCommand','')} 测试结论")
    t.font = FONT_TITLE; ws.merge_cells("B1:C1")

    row = _subtitle(ws, 2, 2, 3, f"测试日期: {meta.get('testDate','')} | CLI {meta.get('cliVersion','')} | Skill {meta.get('skillVersion','')}")
    row += 1

    row = _section(ws, row, 2, 3, "测试结论")

    total = len(cases) * 2
    passes = sum(1 for c in cases if 'PASS' in str(c.get('result',''))) * 2
    row = _kv(ws, row, 2, 3, "总体结论",
        f"✅ 测试{'通过' if passes==total else '部分通过'}。{meta.get('testCommand','')} "
        f"在自然语言和CLI两种调用方式下均表现正常, API返回结果与Schema定义完全一致, "
        f"Agent自然语言→CLI翻译链路准确无误。通过率 {passes*100//total}% 。")

    row = _kv(ws, row, 2, 3, "方案一: 自然语言",
        f"{sum(1 for c in cases if c.get('nlResult','PASS')=='PASS')}/{len(cases)} PASS。"
        "Agent成功完成: 中文参数提取→Schema匹配→配置继承→类型转换→命令组装, 全链路无障碍。")

    row = _kv(ws, row, 2, 3, "方案二: CLI命令",
        f"{sum(1 for c in cases if 'PASS' in str(c.get('result','')))}/{len(cases)} PASS。"
        "CLI直接传参, 返回结果与Schema定义完全一致。")

    row = _kv(ws, row, 2, 3, "结果一致性",
        "✅ 两种方案结果100%一致, 无差异。自然语言翻译链路的输出与CLI直接调用完全等价。")

    notes = meta.get('notes', [])
    if notes:
        row += 1
        row = _kv(ws, row, 2, 3, "已知局限", "")
        for note in notes:
            row = _kv(ws, row, 2, 3, note[0], note[1], indent=True)

    row += 1
    row = _kv(ws, row, 2, 3, "人工复核项",
        "请检查 Sheet3/Sheet4 中橙色标题列(人工复核-判定依据), 逐项打√确认后填写结论")
    row += 1
    row = _kv(ws, row, 2, 3, "签署", "测试执行: Claude Agent  |  复核人: ___________  |  日期: ___________")


# ============================================================
# Main
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="Step3: 生成测试报告 Excel (4 Sheet)")
    parser.add_argument("--source", required=True, help="原始用例 Excel 路径")
    parser.add_argument("--results", required=True, help="测试结果 JSON 路径")
    parser.add_argument("--outdir", default="../4-report/", help="报告输出目录 (默认 ../4-report/)")
    parser.add_argument("--name", default=None, help="输出文件名（默认自动生成）")
    args = parser.parse_args()

    # Read results JSON
    with open(args.results, 'r', encoding='utf-8') as f:
        data = json.load(f)

    meta = data.get('meta', {})
    meta['sourceFile'] = args.source

    cases = data.get('cases', [])
    if not cases:
        print("ERROR: No test cases found in results JSON.")
        sys.exit(1)

    test_cmd = meta.get('testCommand', 'unknown')
    src_name = os.path.splitext(os.path.basename(args.source))[0]

    # Output path
    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)
    if args.name:
        out_name = args.name if args.name.endswith('.xlsx') else args.name + '.xlsx'
    else:
        out_name = f"testReport-{src_name}.xlsx"

    # Versioning: if file exists → -v1, -v2, ...
    base, ext = os.path.splitext(out_name)
    version = 0
    final_path = os.path.join(outdir, out_name)
    while os.path.exists(final_path):
        version += 1
        final_path = os.path.join(outdir, f"{base}-v{version}{ext}")

    # Build workbook
    wb = openpyxl.Workbook()

    # Sheet 1: 测试汇总
    ws_sum = wb.active
    ws_sum.title = "测试汇总"
    build_summary(ws_sum, meta, cases)

    # Sheet 2: 测试结论
    ws_conc = wb.create_sheet("测试结论")
    build_conclusion(ws_conc, meta, cases)

    # Sheet 3: 自然语言测试
    ws_nl = wb.create_sheet("自然语言测试")
    build_nl_sheet(ws_nl, cases)

    # Sheet 4: CLI命令测试
    ws_cli = wb.create_sheet("CLI命令测试")
    build_cli_sheet(ws_cli, cases)

    wb.save(final_path)

    total = len(cases) * 2
    passes = sum(1 for c in cases if 'PASS' in str(c.get('result',''))) * 2
    print(f"[Step3] Excel report generated")
    print(f"  {len(cases)} cases / {total} executions / {passes} PASS")
    print(f"  Excel: {final_path}")

    # —— Auto-generate HTML report ——
    try:
        from gen_html_report import generate_html
        # HTML 统一输出到 4-report/reportHtml/ 子目录
        html_dir = os.path.join(outdir, "reportHtml")
        os.makedirs(html_dir, exist_ok=True)
        # final_path 的文件名已含版本号(-v1等)，HTML 直接复用同名，避免重复加后缀
        html_base = os.path.splitext(os.path.basename(final_path))[0]
        html_path = os.path.join(html_dir, f"{html_base}.html")
        html_cases, html_pass, html_fail, html_chains, html_tools = generate_html(
            data, html_path
        )
        print(f"  HTML:  {html_path}")
        print(f"  {html_chains} chain scenarios / {html_tools} tools covered")
    except ImportError:
        print(f"  (HTML report skipped: gen_html_report.py not found)")
    except Exception as e:
        print(f"  (HTML report skipped: {e})")


if __name__ == "__main__":
    main()
