# easydata-agent-testtool 使用指南

## 这是什么

测试 **AI Agent 能不能正确理解用户意图并调用对工具** 的自动化工具。
输入 MCP 工具定义 (JSON Schema) + 你填写的真实数据 → 输出自然语言测试用例 Excel + 可执行的 YAML。

## 快速上手 (完整流程)

### 第一步: 唤起 Skill
在聊天框里直接说 (任选一种):
```
用 easydata-agent-testtool 帮我生成测试用例
```

### 第二步: AI 询问时选择步骤
AI 会先展示一张表格让你选择从哪个步骤开始:

| 步骤 | 做什么 | 什么时候用 |
|------|--------|-----------|
| Step1 | 提取 MCP Schema 必填参数 → 生成 `data/{name}.md` 模板 | 第一次用, 需要知道每个工具有哪些参数 |
| Step2 | 生成自然语言用例 Excel | 你已填好 `data/{name}.md` 中的真实数据 |
| Step3 | 转 YAML 格式 | Excel 用例已完成, 要导入评估系统执行 |
| Step4 | Excel → TC 模板 | 需要把 Step2 的 Excel 转成 TC 模板格式 |
| Step5 | TC 模板 → YAML | 已有 TC 模板格式的 Excel (非 Step2 产物), 要转成 YAML |

**工作流 A**: Step1 → **你手动填写真实数据** → Step2 → Step3
**工作流 B**: Step2 → Step4 (Excel 转 TC 模板)
**工作流 C**: Step5 独立使用 (已有 TC 模板 Excel, 直接转 YAML)

**给不同用户的建议**:

| 你的情况 | 建议 |
|---------|------|
| **第一次用, 什么都没准备** | 选 Step1, 拿到模板后填入真实数据, 再走 Step2 + Step3 |
| **已经填好 data/{name}.md 真实数据** | 选 "从 Step2 开始" |
| **只想要 Excel 手工看** | 选 "Step2", 不做 Step3 |
| **已经有别人给的 Excel** | 选 "Step3", 把 Excel 转 YAML |
| **想要 TC 模板格式的 Excel** | 选 "Step4", 把 Step2 的 Excel 转格式 |
| **已有 TC 模板格式的 Excel (13列)** | 选 "Step5", 直接按产品模块拆分转 YAML |

### 第三步: 跟着 AI 一步步走
AI 会在每个步骤执行前展示具体做什么, 你只需要:
1. 看表格确认 AI 要做什么
2. 回复 "可以" 或 "开始"
3. Step1 后: 打开 `data/{name}.md`, 把 `待填写` 改成真实数据
4. AI 执行后会告诉你产出文件在哪里

## 完整流程示例
假设你要为 `控制台 (easyconsole)` 生成测试用例:
```
你:   帮我对 easyconsole 生成 agent 测试用例
AI:   本工具提供 5 个独立步骤... 请问从哪个开始?
你:   Step1, schema 在 "所有文件/控制台-20260522-McpTool"
AI:   [Step1] 开始提取 config.json 的参数...
      | tool | required_params |
      | list_schedule_calendars | product |
      已生成 data/easyconsole.md，含 1 个工具、1 个必填参数（标记为待填写）
      请手动填写真实数据后回复"继续 Step2"
你:   (打开 data/easyconsole.md, 把 product 的待填写改成 mammut)
      继续 Step2
AI:   [Step2] generate.py path1 --schema-dir "所有文件/控制台-20260522-McpTool" --product easyconsole
      生成 N 条用例 -> output/easyconsole-20260605-xxxx.xlsx
      确认继续 Step3?
你:   继续
AI:   [Step3] generate.py path2 --excel output/easyconsole-20260605-xxxx.xlsx
      生成 N 条 YAML -> output/easyconsole-20260605-xxxx.yml
      全部完成!
```

## 各步骤详解

### Step1: 提取 MCP Schema 必填参数 → 生成参数模板
**做什么**: 读取 JSON 文件, 告诉你每个工具有哪些必填参数, 参数类型是什么, **并自动生成 `data/{serviceName}.md` 模板文件**。
**产出**:
1. 参数清单分析 (表格形式)
2. `data/{serviceName}.md` — 必填参数模板, 各参数标记为`待填写`
**你需要做的**: 打开生成的 MD 文件, 把 `待填写` 改成真实数据

**示例输出**:
```
从 config.json 提取 1 个工具:
  list_schedule_calendars: required=[product]
已生成 data/easyconsole.md, 含 1 个工具、1 个必填参数（均标记为待填写）
请手动填写真实数据后回复"继续 Step2"
```

### Step2: 生成自然语言用例 Excel
**做什么**: 读取你填好的 `data/{name}.md` + JSON Schema, 自动生成带**真实数据**的自然语言用例
**前置条件**: `data/{name}.md` 中不能有 `待填写` (必须先完成填写)
**命令**:
```bash
python easydata-agent-testtool/scripts/generate.py path1 \
  --schema-dir "所有文件/控制台-20260522-McpTool" \
  --product easyconsole
```
**产出**: `output/{name}-{YYYYMMDD}-{HHMMSS}.xlsx` (10 列, 5 个 Sheet)

**自动生成的 Prompt 示例**:
| 类别 | Prompt |
|------|--------|
| 正向 | "帮我查一下 mammut 项目的调度日历列表" |
| 缺失参数 | "帮我查一下调度日历列表，但不要提供项目" |
| 异常边界 | "帮我查一下，用不存在的 product" |
| 安全注入 | "帮我操作功能，参数里包含 ' OR '1'='1 这样的内容" |

### Step3: Excel → YAML 转换
**做什么**: 把 Step2 的 Excel 转成 `easydata-mode` YAML, 可直接导入 Agent 评估系统跑
**命令**:
```bash
python easydata-agent-testtool/scripts/generate.py path2 \
  --excel "output/{name}-{YYYYMMDD}-{HHMMSS}.xlsx"
```
**产出**: `output/{name}-{YYYYMMDD}-{HHMMSS}.yml`

### Step4: Excel → TC 模板 Excel
**做什么**: 把 Step2 的 Excel (5 Sheet) 按 `TCCase/template.xlsx` 格式转换
**命令**:
```bash
python easydata-agent-testtool/scripts/generate.py path4 \
  --excel "output/{name}.xlsx"
```
**产出**: `TCCase/TCCase-{name}.xlsx` (13 列 TC 模板格式)

### Step5: TC 模板 Excel → YAML (按模块拆分)
**做什么**: 读取 TC 模板格式的 Excel (13列: Suite一~五 + 测试用例 + 用例分级 + 前置条件 + 执行步骤 + 预期结果 + 备注 + 用例Tag), AI 分析后按 **Suite二 (产品模块)** 拆分为多个 YAML 文件
**适用场景**: 已有 TC 模板 Excel (非 Step2 产物), 需要转 YAML 导入评估系统

**AI 分析功能**:
- 🔍 **跨列工具名识别**: 从 Suite四/三/二 中自动识别 snake_case 格式的 MCP 工具名
- 🏷️ **分类推断**: 自动识别 boundary (异常边界) / stability (安全回归) / normal (正向功能)
- 📝 **Promp 生成**: 优先执行步骤, 为空则用标题

**命令**:
```bash
python easydata-agent-testtool/scripts/convert_tc_to_yaml.py \
  --excel "path/to/TC模板.xlsx" \
  --outdir "easydata-agent-testtool/output/"
```
**产出**: `output/{Excel名}-{Suite二}.yml` (每个产品模块一个文件)

## 文件存放位置
```
easydata-agent-testtool/
├── SKILL.md                             # Skill 定义 (给 AI 看的)
├── README.md                            # 本文件 (给你看的)
├── data/                                # 参数模板 + 真实数据 (按产品维护)
│   └── easyconsole.md                   # Step1 生成, 你手动填写真实值
├── scripts/
│   ├── generate.py                      # Step1 + Step2 + Step3 + Step4 引擎
│   └── convert_tc_to_yaml.py            # Step5 引擎 (TC 模板 → YAML)
├── output/                              # 产物 (每次生成不覆盖)
│   ├── easyconsole-20260605-xxxx.xlsx   # Step2 产物
│   ├── easyconsole-20260605-xxxx.yml    # Step3 产物
│   └── {Excel名}-{Suite二}.yml          # Step5 产物 (按模块拆分)
└── TCCase/
    ├── template.xlsx                    # TC 模板
    └── TCCase-{name}.xlsx              # Step4 产物
```

## 常见问题

### Q: 第一次用, 需要做什么准备?
1. 确认 `python` 能用, `openpyxl` 已安装 (`pip install openpyxl`)
2. 记住你的 Schema 文件路径 (如 `所有文件/控制台-20260522-McpTool/`)
3. 准备好你的真实数据 (product 名、集群名等)

### Q: Step1 生成的模板怎么填?
打开 `data/{name}.md`, 找到每个参数下面的 `待填写`, 替换成你项目中真实的值。比如:
```markdown
- **product** (string/resource_id): 产品账号
  - 真实值: `mammut`     ← 把"待填写"改成这个
```

### Q: 怎么加入更多真实数据?
在 `data/{name}.md` 中补充更多参数值。非必填参数也可以写进去, Step2 会用到。

### Q: 生成的 Excel 可以自己改吗?
可以。Step2 的 Excel 就是给你审查用的。你可以在 Excel 里手动修改 prompt, 改完后再走 Step3 转 YAML。

### Q: Step3 和 Step5 有什么区别?
- **Step3**: 处理 Step2 生成的 5-Sheet Excel (10 列标准格式)
- **Step5**: 处理 TC 模板格式 Excel (13 列, 含 Suite 层级), AI 跨列分析工具名, 按产品模块拆分输出

### Q: Step5 能自动识别工具名吗?
能。AI 会从 Suite四/三/二 列中识别 snake_case 格式的工具名 (如 `list_yarn_queues`, `get_datasource_list`), 过滤中文分类名 (如 `1.基础资源查询`)。匹配不到工具名时只保留 `answer_correctness` 评分器。

### Q: 其他子产品能用吗?
能。把 `--schema-dir` 换成对应的 Schema 目录, `--product` 换成对应名字。
