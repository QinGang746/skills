# easytaskops-log 参数模板

> 从 MCP Schema 自动提取。请在各参数下方填写真实数据值。
> 不填则 Step2 生成用例时 AI 自动补值。

---

## 公共参数 (全部工具共用)

- **clusterId**: 集群Id — `easyops-clusterx`
- **execId**: 调度实例ID — `4579840`
- **product**: 项目名称 — `autoapi_test`
- **user**: 调用该接口用户邮箱 — `grp.mammut_test@corp.netease.com`

---

## 重复参数 (多工具共用)

- **length** (number): 每次允许读取的最大字节数，不能超过512000 — `100000`
- **offset** (number): 读取的起始位置 — `1`

---

## get_instance_job_log

- **描述**: 获取调度实例（任务）节点日志

### 工具专属必填参数

- **attempt** (number): 重试次数 — `1`
- **job** (resource_id): 任务job标识(字符串ID) — `hive_C89A37F6`

---

## get_yarn_application_log_url

- **描述**: 获取yarn上对应application的日志链接

### 工具专属必填参数

- **applicationId** (resource_id): yarn applicationId — ``
