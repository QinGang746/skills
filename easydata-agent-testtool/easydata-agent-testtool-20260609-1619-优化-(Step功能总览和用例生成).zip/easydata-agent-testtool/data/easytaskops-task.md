# easytaskops 参数模板

> 从 MCP Schema 自动提取。请在各参数下方填写真实数据值。
> 不填则 Step2 生成用例时 AI 自动补值。

---

## 公共参数 (全部工具共用)

以下参数被几乎所有工具共用，在此统一填写：

- **clusterId**: 集群Id — `easyops-cluster`
- **product**: 项目名称 — `autoapi_test`
- **user**: 调用该接口用户邮箱 — `grp.mammut_test@corp.netease.com`

---

## 重复参数 (多工具共用)

以下参数被多个工具共用，在此统一填写：

- **attempt** (number): attempt次数 — `2`
- **baselineId** (resource_id): 基线ID — `50`
- **date** (number): 查询日期，当地时区的毫秒值 — `1780588800000`
- **dateId** (resource_id): 基线业务日期时间戳,一般为自然日零点（毫秒） — `1780588800000`
- **endTime** (number): 补数据结束时间段（毫秒时间戳） — `1780671600000`
- **execId** (resource_id): 调度实例ID，已就绪实例会有实例ID，使用execId查询 — `4579833`
- **flow** (resource_id): 任务flow标识，非必填，为空时后端根据 project 自动推导唯一 flow — `qgTest_Agent测试_上游A`
- **id** (resource_id): 补数据ID — `100000804`
- **job** (string): 任务节点标识 — `hive_C89A37F6`
- **length** (number): 每次允许读取的最大字节数，不能超过512000 — `100000`
- **offset** (number): 读取的起始位置。正序读取，从0开始，根据返回的offset+length计算出下一次请求的offset。倒序读取，从-1开始，根据返回的offset-length得到下一次请求的offset — `2`
- **project** (resource_id): 任务project标识 — `58b00591a33f42608a947c0371e38bd0`
- **startTime** (number): 补数据开始时间段（毫秒时间戳） — `1780588800000`
- **type** (string): 实例生成状态：EXEC-已生成实例（需传execId），VIRTUAL-未生成实例（需传project/flow/schedTime） — `EXEC`

---

## get_yarn_application_log_url

- **描述**: 获取yarn上对应application的日志链接，支持Spark和MapReduce等类型。返回列表每项包含：id（executor/attempt标识）、stdout/stderr（stdout/stderr日志链接对象，包含serverUrl机房网地址和officeUrl办公网地址）、logs（YARN日志聚合页面链接对象，仅MapReduce类型）、diagnostics（application级别诊断信息）。会自动提取full log链接（如果存在），优先返回完整日志地址。对于MapReduce类型，会从日志聚合页面提取stdout和stderr链接。如果未开启前缀替换则serverUrl和officeUrl都为原始链接地址。Spark任务若trackingUI=UNASSIGNED则返回仅含diagnostics的单条记录。

### 工具专属必填参数

- **applicationId** (resource_id): yarn applicationId — ``

---

## get_task_lineage

- **描述**: 获取线上任务的血缘关系，返回任务的上下游依赖DAG图，帮助分析任务间的依赖链路。支持按层级展开、按方向（上游/下游/全部）查询

### 工具专属必填参数

- **lineageType** (string): 血缘类型：ALL-上下游血缘（默认），UP-仅上游血缘，DOWN-仅下游血缘 — `ALL`

