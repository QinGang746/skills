# -*- coding: utf-8 -*-
"""
add_section_headers_by_prefix.py
================================
在报告的「自然语言测试」「CLI命令测试」两个 sheet 中，按用例标题里的
`[源sheet]` 前缀（如 [1-正向]/[2-异常]/.../[6-场景组合]）分组，
在每组第一行之前插入一行深蓝底白字分组标题行。

与旧版 add_section_headers.py 的区别：不依赖源 Excel 做标题精确匹配，
直接解析报告标题列已有的 `[...]` 前缀分组，因此一定能匹配上。

用法:
  python add_section_headers_by_prefix.py --report "4-report/testReport-xxx.xlsx"
"""
import argparse
import os
import re
import sys

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("Error: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)

SECTION_FILL = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
SECTION_FONT = Font(bold=True, size=12, color="FFFFFF")
SECTION_ALIGN = Alignment(horizontal="left", vertical="center", wrap_text=True)
BORDER = Border(left=Side(style="thin"), right=Side(style="thin"),
                top=Side(style="thin"), bottom=Side(style="thin"))

PREFIX_RE = re.compile(r'^\s*\[([^\]]+)\]')

# 友好图标 + 计数后缀在运行时拼
ICON = {
    "1-正向": "✅", "2-异常": "⚠️", "3-安全": "🔒",
    "4-回归": "🔁", "5-敏感": "🛑", "6-场景组合": "🔗",
}


def _prefix(title):
    m = PREFIX_RE.match(str(title or ""))
    return m.group(1) if m else None


def add_headers(report_path):
    wb = openpyxl.load_workbook(report_path)
    total_inserted = 0

    for sheet_name in ["自然语言测试", "CLI命令测试"]:
        if sheet_name not in wb.sheetnames:
            print(f"  [WARN] sheet '{sheet_name}' 不存在，跳过")
            continue
        ws = wb[sheet_name]
        max_col = ws.max_column

        # 统计每个前缀的用例数
        counts = {}
        order = []
        for r in range(2, ws.max_row + 1):
            p = _prefix(ws.cell(r, 2).value)
            if p:
                if p not in counts:
                    counts[p] = 0
                    order.append(p)
                counts[p] += 1

        # 完整读出所有行的值 + 样式（避免 insert_rows 的丢数据 bug）
        snapshot = []
        for r in range(1, ws.max_row + 1):
            cells = []
            for c in range(1, max_col + 1):
                cell = ws.cell(r, c)
                cells.append({
                    'value': cell.value,
                    'font': cell.font.copy(),
                    'fill': cell.fill.copy(),
                    'alignment': cell.alignment.copy(),
                    'border': cell.border.copy(),
                    'number_format': cell.number_format,
                })
            snapshot.append({'cells': cells, 'height': ws.row_dimensions[r].height})

        # 重组：表头 + 各分组(标题行 + 数据行)
        header = snapshot[0]
        data = snapshot[1:]
        new_rows = [header]
        inserted = 0
        prev = None
        for row in data:
            p = _prefix(row['cells'][1]['value'])  # col B = 标题
            if p and p != prev:
                prev = p
                label = f"{ICON.get(p,'📌')}  {p}  （{counts.get(p,0)} 条用例）"
                sec_cells = []
                for c in range(max_col):
                    sec_cells.append({
                        'value': label if c == 0 else None,
                        'font': SECTION_FONT if c == 0 else Font(color="FFFFFF"),
                        'fill': SECTION_FILL,
                        'alignment': SECTION_ALIGN if c == 0 else Alignment(),
                        'border': BORDER,
                        'number_format': 'General',
                    })
                new_rows.append({'cells': sec_cells, 'height': 26, '_section': True})
                inserted += 1
            new_rows.append(row)

        # 清空并重写
        if ws.max_row >= 1:
            ws.delete_rows(1, ws.max_row)
        # 解除可能的合并
        for mc in list(ws.merged_cells.ranges):
            ws.unmerge_cells(str(mc))

        for i, row in enumerate(new_rows, start=1):
            for c, cd in enumerate(row['cells'], start=1):
                cell = ws.cell(i, c)
                cell.value = cd['value']
                cell.font = cd['font']
                cell.fill = cd['fill']
                cell.alignment = cd['alignment']
                cell.border = cd['border']
                cell.number_format = cd['number_format']
            if row.get('height'):
                ws.row_dimensions[i].height = row['height']
            if row.get('_section'):
                ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=max_col)

        ws.freeze_panes = "A2"
        total_inserted += inserted
        print(f"  [OK] {sheet_name}: 插入 {inserted} 个分组标题行 — {', '.join(order)}")

    wb.save(report_path)
    print(f"Saved: {report_path}  (共插入 {total_inserted} 行)")


def main():
    ap = argparse.ArgumentParser(description="按标题前缀为报告添加分组标题行")
    ap.add_argument("--report", required=True, help="报告 Excel 路径")
    args = ap.parse_args()
    print(f"报告 Excel: {args.report}")
    add_headers(args.report)
    print("Done!")


if __name__ == "__main__":
    main()
