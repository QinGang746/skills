# -*- coding: utf-8 -*-
"""
step5_backfill_suite3_desc.py  —  Step5 收尾: 给 TC Excel 的 Suite三(C列) 工具名拼接中文简介
================================================================================
generate.py path4 产出的 Suite三 只有纯工具名。本脚本为每行拼接简介:
  - 单工具:  工具名（≤10字简介）             如 list_tag（查询标签列表）
  - 链路(含 → 或 /): 链路原样保留, 末尾追加（整体业务简介, 可略长）
                       如 a → b → c（补数据全链路:创建→查看→暂停→恢复）

简介来源: 下方 TOOL / CHAIN 两张映射表(AI 读 Schema description 提炼, 不机械截断)。
新增产品/工具时, 往这两张表补条目即可; 未匹配的行会在结尾打印, 据此补全。

特性:
  - 幂等: C列已含全角「（」则跳过, 可安全重跑
  - 仅改 value, 不动样式
  - --out-suffix 可写到新副本(原文件被 Excel 占用时用), 默认原地回填

用法:
  python step5_backfill_suite3_desc.py "5-tcCase/TCCase-xxx.xlsx" ["..."]
  python step5_backfill_suite3_desc.py "..." --out-suffix "-desc"   # 写新副本
"""
import openpyxl, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# 单工具简介 (≤10字)
TOOL = {
    # --- easytaskops ---
    'cancel_task_schedule': '取消任务调度', 'create_backfill_no_cascade': '创建补数据任务',
    'delete_alert_rule_for_task': '删任务报警规则', 'diagnose_exec_instance': '诊断调度实例',
    'diagnose_exec_job': '诊断节点执行', 'get_backbill': '查补数据详情',
    'get_baseline_detail': '查基线详情', 'get_baseline_diagnose_result': '基线诊断结果',
    'get_baseline_exec_detail': '基线执行状态', 'get_baseline_for_task': '查任务基线',
    'get_exec_instance': '查实例详情', 'get_exec_instance_finishing_rate': '实例完成率',
    'get_exec_instance_lineage': '实例血缘关系', 'get_exec_instance_overview': '实例大盘统计',
    'get_exec_job_applications': '查节点应用', 'get_instance_flow_log': '查实例流日志',
    'get_instance_job_log': '查节点日志', 'get_task_alert_rule': '查任务告警规则',
    'get_task_dep_diagnose': '任务依赖诊断', 'get_task_lineage': '查任务血缘',
    'get_yarn_application_log_url': 'yarn日志链接', 'kill_backbill': '终止补数据',
    'kill_exec_instance': '终止调度实例', 'list_alert_histories': '查报警历史',
    'list_alert_rule_for_task': '查任务报警规则', 'list_all_dep_diagnose': '全量依赖诊断',
    'list_backfill': '查补数据列表', 'list_baseline': '查基线列表',
    'list_baseline_exec_flows': '基线执行甘特图', 'list_baseline_failed_instance': '基线异常实例',
    'list_baseline_finish_history': '基线完成历史', 'list_baseline_task': '查基线任务',
    'list_exec_instance': '查调度实例列表', 'list_running_yarn_app': '查运行yarn应用',
    'list_tag': '查询标签列表', 'list_topk_job_runtime': '节点耗时排行',
    'list_topk_schedule_delay': '调度延迟排行', 'list_topk_task_failed': '任务出错排行',
    'list_topk_task_runtime': '任务耗时排行', 'pause_backfill': '暂停补数据',
    'pause_task_schedule': '暂停任务调度', 'rerun_exec_instance': '重跑调度实例',
    'resolve_alert_history': '处理报警记录', 'resume_backfill': '恢复补数据',
    'set_baseline_task': '设置基线关联', 'mcp_category': '工具能力分类',
    # --- easydqc ---
    'add_quality_rule': '添加质量规则', 'batch_add_quality_rules': '批量加质量规则',
    'batch_delete_compare_task': '批量删对比任务', 'cancel_data_quality_job': '取消质量作业',
    'create_compare_task': '创建对比任务', 'create_data_quality_task': '创建质量任务',
    'create_quality_issue': '创建质量工单', 'exec_compare_task_query': '执行对比查询',
    'execute_data_quality': '执行质量检测', 'get_compare_task_instance_result': '对比实例结果',
    'get_compare_task_query_result': '对比查询结果', 'get_data_quality_job_status': '查质量作业状态',
    'get_data_quality_result': '查质量结果', 'get_explore_task_instance_result': '探查实例结果',
    'get_quality_issue_detail': '查工单详情', 'list_data_quality_tasks': '查质量任务列表',
    'list_explore_task_instances': '查探查实例', 'list_explore_tasks': '查探查任务',
    'list_rule_templates': '查规则模板', 'run_compare_task': '运行对比任务',
    'run_explore_task': '运行探查任务',
}

# 链路整体简介 (按 C列原文精确匹配)
CHAIN = {
    # easydqc
    'create_compare_task → run_compare_task → get_compare_task_instance_result': '数据对比全链路:建任务→运行→查结果',
    'create_data_quality_task → add_quality_rule → execute_data_quality → get_data_quality_result → create_quality_issue': '质量监控全链路:建任务→配规则→检测→查结果→建工单',
    'create_quality_issue → get_quality_issue_detail': '质量工单创建到查看详情',
    'easytaskops:create_task → easydqc:create_data_quality_task → easydqc:execute_data_quality': '跨产品:建任务后挂质量检测',
    'exec_compare_task_query → get_compare_task_query_result': '执行对比查询到取结果',
    'list_data_quality_tasks → execute_data_quality → get_data_quality_job_status': '质量任务列表→检测→查作业状态',
    'list_rule_templates → add_quality_rule → batch_add_quality_rules': '规则模板到批量添加规则',
    'run_explore_task → list_explore_task_instances → get_explore_task_instance_result': '数据探查全链路:运行→查实例→取结果',
    # easytaskops
    'create_backfill_no_cascade → get_backbill → pause_backfill → resume_backfill': '补数据全链路:创建→查看→暂停→恢复',
    'easydqc:get_data_quality_result → easytaskops:create_backfill_no_cascade': '跨产品:质量异常后补数据',
    'list_baseline → list_baseline_failed_instance → get_baseline_diagnose_result': '基线异常诊断链路',
    'list_baseline → list_baseline_task → get_baseline_for_task': '基线到任务关联查询',
    'get_exec_instance_overview → list_topk_task_failed → diagnose_exec_instance': '大盘发现到失败诊断',
    'list_topk_task_runtime / list_topk_job_runtime / list_topk_schedule_delay': '多维耗时与调度延迟排行对照',
    'list_alert_histories → resolve_alert_history': '报警历史到处理响应',
    'diagnose_exec_instance → kill_exec_instance → rerun_exec_instance': '实例诊断→终止→重跑处置',
    'easytaskops:diagnose_exec_instance → easydqc:get_data_quality_result': '跨产品:实例诊断关联质量结果',
    'get_exec_instance → diagnose_exec_job → get_instance_job_log': '实例到节点诊断查日志',
    'list_exec_instance → get_exec_instance → diagnose_exec_instance': '实例列表到详情诊断',
    'list_exec_instance → get_exec_instance_lineage → get_instance_flow_log': '实例血缘到流日志',
    'get_exec_instance → get_exec_job_applications → get_yarn_application_log_url': '实例到yarn应用日志',
    'easytaskops:get_task_lineage → easydqc:create_data_quality_task → easydqc:execute_data_quality': '跨产品:任务血缘后挂质量检测',
    'get_baseline_for_task → set_baseline_task': '查任务基线到设置关联',
    'get_task_dep_diagnose → get_task_lineage → list_alert_rule_for_task': '任务依赖血缘报警排查',
    'pause_task_schedule → cancel_task_schedule': '暂停到取消任务调度',
    'list_running_yarn_app → get_exec_instance → kill_exec_instance': '运行yarn应用到终止实例',
}

def backfill(path, outpath=None):
    wb = openpyxl.load_workbook(path)
    ws = wb['测试用例']
    changed = miss = skip = 0
    misses = set()
    for r in range(2, ws.max_row + 1):
        v = ws.cell(r, 3).value
        if not v or not isinstance(v, str):
            continue
        if '（' in v:            # 幂等: 已回填
            skip += 1; continue
        is_chain = ('→' in v) or (' / ' in v)
        if is_chain:
            intro = CHAIN.get(v.strip())
            if intro:
                ws.cell(r, 3).value = f'{v}（{intro}）'; changed += 1
            else:
                miss += 1; misses.add(v)
        else:
            intro = TOOL.get(v.strip())
            if intro:
                ws.cell(r, 3).value = f'{v}（{intro}）'; changed += 1
            else:
                miss += 1; misses.add(v)
    save_to = outpath or path
    wb.save(save_to)
    print(f'[OK] 源:{path}')
    print(f'     存:{save_to}')
    print(f'  回填 {changed} 行 | 已存在跳过 {skip} | 未匹配 {miss}')
    for m in sorted(misses):
        print('   未匹配:', m)

import os
args = sys.argv[1:]
# 用法: 路径 ...  (可选 --out-suffix XXX 写到新副本)
suffix = None
if '--out-suffix' in args:
    i = args.index('--out-suffix')
    suffix = args[i+1]
    args = args[:i] + args[i+2:]
for p in args:
    if suffix:
        base, ext = os.path.splitext(p)
        backfill(p, base + suffix + ext)
    else:
        backfill(p)

