# -*- coding: utf-8 -*-
"""TC 模板 Excel -> easydata-mode YAML（AI分析版）

列结构:
  A=Suite一(产品) B=Suite二(模块) C=Suite三(场景) D=Suite四(工具名) E=Suite五(子类)
  F=用例标题 G=用例分级 H=前置条件 I=执行步骤 J=预期结果 K=备注 L=用例Tag M=其他

策略:
  - Suite列做 forward-fill（合并单元格继承上级值）
  - AI分析: 从执行步骤提取自然语言 prompt，从预期结果提取 expected answer
  - 工具名从 Col D 提取；为空则不填 tool_call
  - 按 Suite二 分组输出独立 YAML 文件
"""

import os, sys, re, json
from datetime import datetime
from collections import defaultdict, OrderedDict
from hashlib import sha256

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(SCRIPT_DIR)
OUTPUT_DIR = os.path.join(SKILL_DIR, "3-output")

# ---------------------------------------------------------------------------
# 前缀推导
# ---------------------------------------------------------------------------
_SKIP_VERBS = {
    "get", "list", "create", "run", "exec", "execute", "batch", "delete",
    "resolve", "apply", "query", "update", "add", "rerun", "kill", "pause",
    "cancel", "resume", "diagnose", "rename", "rollback", "release", "edit",
    "move", "modify", "check", "set", "preview", "search", "stop", "start",
    "remove", "restart", "detail", "fetch",
}


def resolve_prefixes(tool_names):
    """为工具名分配短前缀，用于 YAML id"""
    raw = {}
    for name in tool_names:
        parts = name.lower().split("_")
        core = [p for p in parts if p not in _SKIP_VERBS and len(p) > 2]
        if not core:
            core = [p for p in parts if p not in _SKIP_VERBS]
        if not core:
            core = parts
        raw[name] = core[0][:5].lower()

    result = {}
    groups = {}
    for name, pfx in raw.items():
        groups.setdefault(pfx, []).append(name)
    for pfx, names in groups.items():
        if len(names) == 1:
            result[names[0]] = pfx
        else:
            used = set()
            for name in names:
                parts = name.lower().split("_")
                core = [p for p in parts if p not in _SKIP_VERBS and len(p) > 2]
                if len(core) > 1:
                    candidate = (core[0][:4] + core[1][:2]).lower()[:8]
                    if candidate not in used:
                        result[name] = candidate
                        used.add(candidate)
                        continue
                for n in range(2, 99):
                    candidate = "{0}{1}".format(pfx, n)
                    if candidate not in result.values():
                        result[name] = candidate
                        used.add(candidate)
                        break
    return result


# ---------------------------------------------------------------------------
# 工具名识别
# ---------------------------------------------------------------------------
_SNAKE_CASE_RE = re.compile(r'^[a-z][a-z0-9]*(_[a-z][a-z0-9]*)+$')


def extract_tool_from_suite(val):
    """从 Suite 列值中提取工具名

    Suite三 常见格式:
      - 纯工具名: cancel_task_schedule
      - 工具名-中文描述: get_datasource_list-数据源列表
      - 纯中文分类: 1.基础资源查询, sql执行
    Suite四 常见格式:
      - 纯工具名: list_yarn_queues
      - 中文模块名(转发): 智能运维
    """
    if not val:
        return None
    # 如果整个值就是 snake_case 工具名
    if _SNAKE_CASE_RE.match(val):
        return val
    # 如果是 "工具名-描述" 或 "工具名：描述" 格式
    base = re.split(r'[-—：:\s]+', val, maxsplit=1)[0].strip()
    if _SNAKE_CASE_RE.match(base):
        return base
    return None


# ---------------------------------------------------------------------------
# 加载 Excel（forward-fill 合并单元格，自动识别 8/13 列格式）
# ---------------------------------------------------------------------------
def load_excel(excel_path):
    """两种格式自动识别:
    13 列: A=Suite1 B=Suite2 C=Suite3 D=Suite4 E=Suite5
           F=标题 G=优先级 H=前置条件 I=执行步骤 J=预期 K=备注 L=Tag M=其他
    8 列:  A=Suite1 B=Suite2 C=Suite3(工具名)
           D=用例标题(Prompt) E=预期结果 F=备注 G=Tag H=其他
    """
    import openpyxl
    wb = openpyxl.load_workbook(excel_path)
    all_cases = []

    for sn in wb.sheetnames:
        ws = wb[sn]
        ncols = ws.max_column
        is_compact = ncols <= 8

        ff = {1: "", 2: "", 3: "", 4: "", 5: ""}
        suite_range = [1, 2, 3] if is_compact else [1, 2, 3, 4, 5]

        for r in range(2, ws.max_row + 1):
            for c in suite_range:
                v = str(ws.cell(row=r, column=c).value or "").strip()
                if v:
                    ff[c] = v

            if is_compact:
                # 8列: D=标题 E=预期 F=备注 G=Tag H=其他
                title = str(ws.cell(row=r, column=4).value or "").strip()
                expected = str(ws.cell(row=r, column=5).value or "").strip()
                remark = str(ws.cell(row=r, column=6).value or "").strip()
                tags = str(ws.cell(row=r, column=7).value or "").strip()
                ext_id = str(ws.cell(row=r, column=8).value or "").strip()
                if not title:
                    continue

                tool_s3 = extract_tool_from_suite(ff[3])
                tool_s2 = extract_tool_from_suite(ff[2])
                tool = tool_s3 or tool_s2 or ""

                all_cases.append({
                    "suite1": ff[1], "suite2": ff[2], "suite3": ff[3],
                    "suite4_raw": "", "suite5_val": "",
                    "tool": tool, "tool_s4": None, "tool_s3": tool_s3,
                    "title": title, "priority": "P1",
                    "precondition": "", "steps": "",
                    "expected": expected, "remark": remark,
                    "tags": tags, "ext_id": ext_id,
                })
            else:
                # 13列: D=Suite4 F=标题 G=优先级 H=前置 I=步骤 J=预期 K=备注 L=Tag M=其他
                tool_raw = str(ws.cell(row=r, column=4).value or "").strip()
                title = str(ws.cell(row=r, column=6).value or "").strip()
                priority = str(ws.cell(row=r, column=7).value or "").strip()
                precondition = str(ws.cell(row=r, column=8).value or "").strip()
                steps = str(ws.cell(row=r, column=9).value or "").strip()
                expected = str(ws.cell(row=r, column=10).value or "").strip()
                remark = str(ws.cell(row=r, column=11).value or "").strip()
                tags = str(ws.cell(row=r, column=12).value or "").strip()
                ext_id = str(ws.cell(row=r, column=13).value or "").strip()

                if not title and not steps:
                    continue
                if not steps and not priority:
                    continue

                tool_s4 = extract_tool_from_suite(tool_raw) if tool_raw else None
                tool_s3 = extract_tool_from_suite(ff[3])
                tool_s2 = extract_tool_from_suite(ff[2])
                tool = tool_s4 or tool_s3 or tool_s2 or ""

                all_cases.append({
                    "suite1": ff[1], "suite2": ff[2], "suite3": ff[3],
                    "suite4_raw": tool_raw, "suite5_val": ff[5],
                    "tool": tool, "tool_s4": tool_s4, "tool_s3": tool_s3,
                    "title": title, "priority": priority or "P1",
                    "precondition": precondition, "steps": steps,
                    "expected": expected, "remark": remark,
                    "tags": tags, "ext_id": ext_id,
                })

    return all_cases


# ---------------------------------------------------------------------------
# AI 分析: 分类推断
# ---------------------------------------------------------------------------
def infer_category(case):
    """从标签/标题/步骤/预期推断测试分类"""
    tags = case.get("tags", "")
    title = case.get("title", "")
    steps = case.get("steps", "")
    expected = case.get("expected", "")
    remark = case.get("remark", "")
    combined = tags + " " + title + " " + steps + " " + expected + " " + remark

    # 安全/越权/注入 — 加入"隔壁""跨项目""无权"等越权信号
    if re.search(r"安全|越权|注入|未登录|无权限|无权|权限|非法|恶意|XSS|SQL注入|DROP\s|OR\s+1=1|'OR\s+'|隔壁|跨项目|其他.*项目|别人.*项目|不属于.*项目", combined, re.IGNORECASE):
        return "stability"
    # 异常/边界
    if re.search(r"异常|边界|不存在|非法[值参]|空[字符串值]|负数|下限|上限|超时|断开|错误|失败|超过|不存在.*资源|不存在.*项目|不存在.*任务|不存在的.*ID|noexist|ghost", combined, re.IGNORECASE):
        return "boundary"
    # 回归/兼容
    if re.search(r"回归|兼容|字段完整|升级|迁移|版本|所有字段|全部字段|字段完整性", combined, re.IGNORECASE):
        return "stability"

    return "normal"


def infer_test_type(case):
    cat = infer_category(case)
    if cat == "stability":
        return "安全测试"
    if cat == "boundary":
        return "边界条件测试"
    return "功能测试"


# ---------------------------------------------------------------------------
# AI 分析: Prompt 构建
# ---------------------------------------------------------------------------
def build_prompt(case):
    """从执行步骤/标题构建自然语言 prompt"""
    steps = case.get("steps", "")
    title = case.get("title", "")

    if steps:
        # 清理编号前缀: "1." "1、" "1)" "1）"
        cleaned = re.sub(r'^\d+[\.\、\)）]\s*', '', steps.strip())
        cleaned = cleaned.strip().strip('"').strip("'").strip()
        if cleaned:
            return cleaned

    # 无执行步骤时，直接用标题（标题本身就是自然语言指令）
    if title:
        return title.strip()

    return ""


# ---------------------------------------------------------------------------
# AI 分析: Expected 构建
# ---------------------------------------------------------------------------
def build_expected(case, valid_tools=None):
    """从预期结果构建 expected answer 和 tool_call

    valid_tools: 合法的工具名集合（白名单），用于从文本中匹配合法工具名
    """
    if valid_tools is None:
        valid_tools = set()

    expected = case.get("expected", "")
    tool = case.get("tool", "")

    # 如果已有工具名（从 Suite四/三/二 分析得来），直接使用
    extracted_tool = tool

    # 如果 Suite 列都没有工具名，尝试从预期文本中匹配合法工具名
    if not extracted_tool and valid_tools:
        combined = expected + " " + case.get("title", "") + " " + case.get("steps", "")
        for vt in sorted(valid_tools, key=lambda x: -len(x)):  # 长名优先匹配
            if vt in combined:
                extracted_tool = vt
                break

    # 校验: 必须是 snake_case 格式才是真正的工具名
    if extracted_tool and not _SNAKE_CASE_RE.match(extracted_tool):
        extracted_tool = ""

    # 清理 expected 文本
    cleaned = re.sub(r'\d+[\.\、)）]\s*', '', expected)
    cleaned = cleaned.replace('\n', ' ').replace('\r', ' ').strip()
    if len(cleaned) > 300:
        cleaned = cleaned[:297] + "..."

    return extracted_tool, cleaned


# ---------------------------------------------------------------------------
# 生成 YAML 文件
# ---------------------------------------------------------------------------
def generate_yaml_for_group(group_name, cases, output_path, ts_ms, valid_tools=None):
    """为单个 Suite二 分组生成 YAML

    valid_tools: 合法工具名白名单，用于避免从数据文本中误匹配
    """
    if valid_tools is None:
        valid_tools = set()
    # 收集该组所有工具名 (Col D 中明确列出的)
    group_tool_names = list(set(c["tool"] for c in cases if c["tool"]))
    prefixes = resolve_prefixes(group_tool_names)

    header = (
        "# Test Set: {0}-Agent功能测试\n".format(group_name) +
        "# Generated: {0}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S")) +
        "# Mode: easydata-mode\n" +
        "# Suite二: {0}\n".format(group_name) +
        "# Cases: {0}\n".format(len(cases)) +
        "# Graders: tool_call_correctness, answer_correctness\n"
    )

    blocks = [header]
    counters = {}

    for case in cases:
        tool = case.get("tool", "")
        cat = infer_category(case)

        # 确定前缀
        if tool and tool in prefixes:
            prefix = prefixes[tool]
        else:
            # 无工具名时，用 Suite三 或标题生成前缀
            scene = case.get("suite3", "")
            title = case.get("title", "")
            # 从标题取前几个字符的拼音简写
            tag_part = case.get("tags", "").split(",")[0] if case.get("tags") else ""
            if tag_part and len(tag_part) >= 3:
                prefix = re.sub(r'[^a-z]', '', tag_part.lower())[:8]
            else:
                prefix = "tc"
            if not prefix or len(prefix) < 2:
                prefix = "tc"

        if prefix not in counters:
            counters[prefix] = {}
        if cat not in counters[prefix]:
            counters[prefix][cat] = 0
        counters[prefix][cat] += 1

        case_id = "{0}-{1}-{2:03d}-{3}".format(prefix, cat[:3], counters[prefix][cat], ts_ms)
        prompt_str = build_prompt(case)
        extracted_tool, expected_answer = build_expected(case, valid_tools)

        # 优先用提取出的工具名
        effective_tool = extracted_tool or case.get("tool", "")
        # 校验: 必须是合法的 snake_case 工具名
        has_tool = bool(effective_tool) and bool(_SNAKE_CASE_RE.match(effective_tool))

        title = case.get("title", "")
        priority = case.get("priority", "P1")

        lines = []
        lines.append("id: {0}".format(case_id))
        lines.append('description: "[{0}] {1}"'.format(priority, title))
        lines.append("input:")
        lines.append("  mode: easydata-mode")
        lines.append('  easydata_agent_url: "${EASYDATA_AGENT_URL}"')
        lines.append('  auth_cookie: "${EASYDATA_COOKIE}"')
        lines.append('  prompt: "{0}"'.format(
            prompt_str.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')
        ))
        lines.append('  user_id: "${EASYDATA_USER_ID}"')
        lines.append('  cluster_id: "${EASYDATA_CLUSTER_ID}"')
        lines.append("  max_interrupt_rounds: 5")
        lines.append("  max_text_reply_rounds: 0")

        lines.append("graders:")
        if has_tool:
            lines.append("  - tool_call_correctness")
        lines.append("  - answer_correctness")

        lines.append("expected:")
        if has_tool:
            lines.append("  tool_call:")
            lines.append('    tool: "{0}"'.format(effective_tool))
        lines.append('  answer: "{0}"'.format(
            expected_answer.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n')[:300]
        ))

        lines.append("meta:")
        lines.append("  module: {0}".format(effective_tool if (effective_tool and _SNAKE_CASE_RE.match(effective_tool)) else "unknown"))
        lines.append("  category: {0}".format(cat))
        lines.append("  priority: {0}".format(priority))
        lines.append("  test_type: {0}".format(infer_test_type(case)))

        blocks.append("\n".join(lines))

    content = "\n---\n".join(blocks) + "\n"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)
    # CRLF
    with open(output_path, "rb") as f:
        raw = f.read()
    raw = raw.replace(b"\n", b"\r\n")
    with open(output_path, "wb") as f:
        f.write(raw)

    return len(cases), counters, prefixes


# ---------------------------------------------------------------------------
# 统计报告
# ---------------------------------------------------------------------------
def print_stats(group_name, cases, counters, prefixes):
    print("\n  [{0}]".format(group_name))
    print("  用例数: {0}  工具数: {1}".format(len(cases), len(prefixes)))

    cat_count = defaultdict(int)
    pri_count = defaultdict(int)
    for c in cases:
        cat_count[infer_category(c)] += 1
        pri_count[c.get("priority", "?")] += 1

    labels = {"normal": "正向功能", "boundary": "边界异常", "stability": "安全回归"}
    cat_str = ", ".join("{0}:{1}".format(labels.get(k, k), v) for k, v in sorted(cat_count.items()))
    print("  分类: {0}".format(cat_str))

    pri_str = ", ".join("{0}:{1}".format(k, pri_count[k]) for k in ["P0", "P1", "P2", "P3"] if k in pri_count)
    print("  优先级: {0}".format(pri_str))


# ---------------------------------------------------------------------------
# 技能总览表
# ---------------------------------------------------------------------------
def _print_skill_overview(output_dir):
    """每次执行完成后打印 5 个步骤功能总览"""
    generated_yamls = []
    if os.path.isdir(output_dir):
        for f in os.listdir(output_dir):
            if f.endswith(".yml") and "EasydataAgent" in f:
                generated_yamls.append(f)

    step6_detail = "TC 模板 Excel(13/8列) ──→ 3-output/{{name}}-{{Suite二}}.yml"
    if generated_yamls:
        step6_detail += "  ({0}文件)".format(len(generated_yamls))

    print(("""
  easydata-agent-testtool  --  6 Steps Overview

  +-------+--------------------------------------------------------------------------+
  | Step  |                          Data Flow & Description                          |
  +-------+--------------------------------------------------------------------------+
  | Step1 | MCP JSON dir --> 2-data/{{name}}.md                                      |
  |       | 提取必填参数, 三级分层 (公共>=80% / 共享>=2 / 独占=1), 生成参数模板 MD      |
  +-------+--------------------------------------------------------------------------+
  | Step2 | 2-data/{{name}}.md + JSON --> 3-output/{{name}}-{{ts}}.xlsx              |
  |       | 真实数据注入, 逐工具生成自然语言用例, 6 Sheet (正向/异常/安全/回归/敏感/场景组合) |
  +-------+--------------------------------------------------------------------------+
  | Step3 | TC 用例 Excel --> 4-report/testReport-{{name}}.xlsx + .html              |
  |       | 双方案执行 (NL+CLI), 4-Sheet Excel + HTML 可视化报告 (自动双产出)            |
  +-------+--------------------------------------------------------------------------+
  | Step4 | Excel(6 sheets) --> 3-output/{{name}}.yml                                |
  |       | 自适应解析 Excel 列, 生成 easydata-mode YAML (含 tool_call + answer)       |
  +-------+--------------------------------------------------------------------------+
  | Step5 | Excel(6 sheets) --> 5-tcCase/TCCase-{{name}}.xlsx                        |
  |       | 列映射转换为 13 列 TC 模板 (Suite层级 + 用例 + 分级 + 步骤 + 预期)          |
  +-------+--------------------------------------------------------------------------+
  | Step6 | {0} |
  |       | AI 跨 Suite 列识别工具名, 分类推断 (normal / boundary / stability)         |
  +-------+--------------------------------------------------------------------------+""").format(step6_detail))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="TC模板 Excel -> easydata-mode YAML (AI分析版)")
    parser.add_argument("--excel", required=True, help="TC 模板 Excel 文件路径")
    parser.add_argument("--outdir", default=None, help="输出目录 (默认 easydata-agent-testtool/3-output/)")
    args = parser.parse_args()

    excel_path = args.excel
    if not os.path.isfile(excel_path):
        print("ERROR: excel not found: {0}".format(excel_path))
        sys.exit(1)

    out_dir = args.outdir or OUTPUT_DIR
    os.makedirs(out_dir, exist_ok=True)

    print("=" * 60)
    print("  TC 模板 Excel -> easydata-mode YAML (AI分析版)")
    print("=" * 60)
    print("  Excel: {0}".format(excel_path))

    # 加载
    all_cases = load_excel(excel_path)
    print("  读取有效用例: {0} 条".format(len(all_cases)))

    if not all_cases:
        print("ERROR: no valid cases")
        sys.exit(1)

    # 构建全局合法工具名白名单
    # 来源1: Suite四 (Col D) 中的 snake_case 工具名
    valid_tools = set(c["tool_s4"] for c in all_cases if c["tool_s4"])
    # 来源2: Suite三 (Col C) 中的 snake_case 工具名 (AI分析: 区分工具名 vs 中文分类)
    valid_tools |= set(c["tool_s3"] for c in all_cases if c["tool_s3"])
    # 来源3: Suite二 (Col B) 中极少情况也可能藏工具名
    s2_tools = set(extract_tool_from_suite(c["suite2"]) for c in all_cases)
    valid_tools |= set(t for t in s2_tools if t)
    print("  合法工具名白名单: {0} 个".format(len(valid_tools)))
    if valid_tools:
        print("    来源 Suite四: {0}, Suite三: {1}, Suite二: {2}".format(
            len(set(c["tool_s4"] for c in all_cases if c["tool_s4"])),
            len(set(c["tool_s3"] for c in all_cases if c["tool_s3"])),
            len(set(t for t in s2_tools if t))
        ))

    # 按 Suite二 分组
    groups = OrderedDict()
    for c in all_cases:
        s2 = c["suite2"] or "(未分类)"
        if s2 not in groups:
            groups[s2] = []
        groups[s2].append(c)

    print("\n  按 Suite二 分组: {0} 组".format(len(groups)))
    for gname, gcases in groups.items():
        print("    [{0}]: {1} 条".format(gname, len(gcases)))

    # 为每个分组生成 YAML
    now = datetime.now()
    ts_ms = str(int(now.timestamp() * 1000))
    excel_base = os.path.splitext(os.path.basename(excel_path))[0]

    total = 0
    print("\n" + "=" * 60)
    print("  生成结果")
    print("=" * 60)

    for gname, gcases in groups.items():
        # 生成安全的文件名
        safe_name = re.sub(r'[^\w一-鿿\-]', '_', gname).strip('_')
        if not safe_name:
            safe_name = "unnamed"
        yaml_path = os.path.join(out_dir, "{0}-{1}.yml".format(excel_base, safe_name))

        count, counters, prefixes = generate_yaml_for_group(gname, gcases, yaml_path, ts_ms, valid_tools)
        total += count
        print_stats(gname, gcases, counters, prefixes)
        print("  输出: {0}".format(yaml_path))

    print("\n  Done! 总计 {0} cases -> {1} 个 YAML 文件".format(total, len(groups)))
    print("  输出目录: {0}".format(out_dir))

    # 打印 5 个步骤功能总览
    _print_skill_overview(out_dir)
