# -*- coding: utf-8 -*-
"""
Step6+: 测试结果 JSON → HTML 可视化报告
=========================================
用法:
  python gen_html_report.py \
    --results "test_results.json" \
    --output "../report/testReport-xxx.html"

说明:
  --results  测试执行结果 JSON 文件路径（与 step6_gen_report.py 相同格式）
  --output   HTML 输出文件路径
  --title    报告标题（可选，默认从 meta 自动生成）

结果 JSON 格式与 step6_gen_report.py 完全兼容：
{
  "meta": { testDate, cliVersion, apiEndpoint, testProduct, testCluster, testUser, testCommand, notes },
  "cases": [{ id, title, tool, nlPrompt, expectedBehavior, nlTranslation,
              cliCommand, cliParams, execTime, apiResult, expectedResult,
              schemaCheck, result, nlResult, resultReason, nlJudgment, cliJudgment, summary }]
}

产物: 自包含 HTML 报告（无需外部 CSS/JS）
  - 顶部概览卡片（总用例/PASS/FAIL/链场景数/覆盖率）
  - 进度条可视化通过率
  - 多工具链场景卡片（自动从 title 提取链场景分组）
  - 关键发现表格（自动汇总 FAIL/EMPTY/PASS 分布）
  - 用例执行详情表（按链场景分组，含所有字段）
  - 测试结论（自动从 meta.notes 提取）
"""

import json
import os
import sys
import argparse
import re
from datetime import datetime
from collections import defaultdict


# ============================================================
# HTML Template
# ============================================================

HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{report_title}</title>
<style>
  :root {{
    --bg: #f0f2f5;
    --card: #fff;
    --text: #1a1a2e;
    --muted: #6b7280;
    --pass: #10b981;
    --fail: #ef4444;
    --warn: #f59e0b;
    --blue: #4472C4;
    --orange: #ED7D31;
    --chain: #8b5cf6;
    --border: #e5e7eb;
  }}
  * {{ margin:0; padding:0; box-sizing:border-box; }}
  body {{ font-family: 'Segoe UI', 'Microsoft YaHei', system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); line-height:1.6; }}
  .container {{ max-width: 1400px; margin: 0 auto; padding: 24px; }}
  .header {{ background: linear-gradient(135deg, #1e3a5f 0%, #2F5496 50%, #4472C4 100%); color: #fff; padding: 40px 48px; border-radius: 16px; margin-bottom: 24px; }}
  .header h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
  .header .subtitle {{ font-size: 14px; opacity: 0.85; }}
  .header .meta {{ display: flex; gap: 32px; margin-top: 20px; flex-wrap: wrap; }}
  .header .meta-item {{ display: flex; flex-direction: column; }}
  .header .meta-label {{ font-size: 11px; text-transform: uppercase; opacity: 0.7; letter-spacing: 1px; }}
  .header .meta-value {{ font-size: 15px; font-weight: 600; }}
  .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 16px; margin-bottom: 24px; }}
  .card {{ background: var(--card); border-radius: 12px; padding: 20px 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }}
  .card .label {{ font-size: 12px; color: var(--muted); margin-bottom: 4px; }}
  .card .value {{ font-size: 32px; font-weight: 700; }}
  .card .value.pass {{ color: var(--pass); }}
  .card .value.fail {{ color: var(--fail); }}
  .card .value.warn {{ color: var(--warn); }}
  .card .value.chain {{ color: var(--chain); }}
  .card .sub {{ font-size: 12px; color: var(--muted); margin-top: 4px; }}
  .section {{ background: var(--card); border-radius: 12px; padding: 28px 32px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }}
  .section h2 {{ font-size: 18px; font-weight: 700; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid var(--border); display: flex; align-items: center; gap: 10px; }}
  .section h2 .icon {{ width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 14px; }}
  .progress-wrap {{ margin: 12px 0; }}
  .progress-bar {{ height: 28px; border-radius: 14px; background: #e5e7eb; overflow: hidden; display: flex; }}
  .progress-bar .seg {{ display: flex; align-items: center; justify-content: center; color: #fff; font-size: 12px; font-weight: 600; }}
  .progress-bar .seg.pass {{ background: var(--pass); }}
  .progress-bar .seg.fail {{ background: var(--fail); }}
  .progress-bar .seg.empty {{ background: var(--warn); }}
  .progress-legend {{ display: flex; gap: 20px; margin-top: 8px; font-size: 12px; color: var(--muted); }}
  .progress-legend span {{ display: flex; align-items: center; gap: 6px; }}
  .progress-legend .dot {{ width: 10px; height: 10px; border-radius: 3px; display: inline-block; }}
  .progress-legend .dot.pass {{ background: var(--pass); }}
  .progress-legend .dot.fail {{ background: var(--fail); }}
  .progress-legend .dot.empty {{ background: var(--warn); }}
  .chain-list {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(420px, 1fr)); gap: 12px; }}
  .chain-item {{ border: 1px solid var(--border); border-radius: 10px; padding: 16px 20px; transition: box-shadow .2s; }}
  .chain-item:hover {{ box-shadow: 0 4px 12px rgba(0,0,0,0.08); }}
  .chain-header {{ display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }}
  .chain-num {{ background: var(--chain); color: #fff; width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; }}
  .chain-name {{ font-weight: 700; font-size: 14px; }}
  .chain-steps {{ display: flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: 12px; color: var(--muted); }}
  .chain-steps .step {{ background: #f3f4f6; padding: 3px 10px; border-radius: 20px; white-space: nowrap; }}
  .chain-steps .arrow {{ color: var(--chain); font-weight: 700; }}
  .chain-result {{ margin-top: 8px; }}
  .badge {{ display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 11px; font-weight: 600; }}
  .badge.pass {{ background: #d1fae5; color: #065f46; }}
  .badge.empty {{ background: #fef3c7; color: #92400e; }}
  .badge.fail {{ background: #fee2e2; color: #991b1b; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  thead th {{ background: var(--blue); color: #fff; padding: 10px 12px; text-align: left; font-weight: 600; font-size: 12px; position: sticky; top: 0; }}
  tbody td {{ padding: 8px 12px; border-bottom: 1px solid var(--border); vertical-align: top; }}
  tbody tr:hover {{ background: #f8fafc; }}
  .table-wrap {{ max-height: 700px; overflow-y: auto; border: 1px solid var(--border); border-radius: 8px; }}
  .tag {{ display: inline-block; padding: 1px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; white-space: nowrap; }}
  .tag.pass {{ background: #d1fae5; color: #065f46; }}
  .tag.fail {{ background: #fee2e2; color: #991b1b; }}
  .tag.empty {{ background: #fef3c7; color: #92400e; }}
  .tr-chain {{ background: #f5f3ff; }}
  .section-header {{ background: #2F5496 !important; color: #fff !important; font-weight: 700 !important; font-size: 13px !important; }}
  .env-table td {{ padding: 4px 16px; }}
  .env-table td:first-child {{ font-weight: 600; color: var(--muted); width: 140px; }}
  .footer {{ text-align: center; color: var(--muted); font-size: 12px; padding: 24px; }}
  code {{ background: #f1f5f9; padding: 1px 6px; border-radius: 4px; font-size: 12px; }}
  @media (max-width: 768px) {{
    .header {{ padding: 24px; }}
    .header h1 {{ font-size: 22px; }}
    .cards {{ grid-template-columns: repeat(2, 1fr); }}
    .chain-list {{ grid-template-columns: 1fr; }}
    .container {{ padding: 12px; }}
  }}
</style>
</head>
<body>
<div class="container">

  <!-- HEADER -->
  <div class="header">
    <h1>{header_icon} {report_title}</h1>
    <div class="subtitle">{subtitle}</div>
    <div class="meta">
      <div class="meta-item"><span class="meta-label">Test Date</span><span class="meta-value">{testDate}</span></div>
      <div class="meta-item"><span class="meta-label">Product</span><span class="meta-value">{testProduct}</span></div>
      <div class="meta-item"><span class="meta-label">Cluster</span><span class="meta-value">{testCluster}</span></div>
      <div class="meta-item"><span class="meta-label">Endpoint</span><span class="meta-value">{apiEndpoint}</span></div>
      <div class="meta-item"><span class="meta-label">User</span><span class="meta-value">{testUser}</span></div>
      <div class="meta-item"><span class="meta-label">CLI Version</span><span class="meta-value">{cliVersion}</span></div>
      <div class="meta-item"><span class="meta-label">Command Scope</span><span class="meta-value">{testCommand}</span></div>
    </div>
  </div>

  <!-- SUMMARY CARDS -->
  <div class="cards">
    <div class="card"><div class="label">Total Cases</div><div class="value chain">{total_cases}</div><div class="sub">NL + CLI dual execution</div></div>
    <div class="card"><div class="label">Total Verdicts</div><div class="value">{total_verdicts}</div><div class="sub">NL x {case_count} + CLI x {case_count}</div></div>
    <div class="card"><div class="label">PASS</div><div class="value pass">{pass_count}</div><div class="sub">{pass_pct:.1f}% pass rate</div></div>
    <div class="card"><div class="label">FAIL</div><div class="value fail">{fail_count}</div><div class="sub">{fail_detail}</div></div>
    <div class="card"><div class="label">Chain Scenarios</div><div class="value chain">{chain_count}</div><div class="sub">multi-tool workflows</div></div>
    <div class="card"><div class="label">Tools Covered</div><div class="value">{tool_count}</div><div class="sub">unique MCP tools</div></div>
  </div>

  <!-- PASS RATE BAR -->
  <div class="section">
    <h2><span class="icon" style="background:#dbeafe;color:#2563eb;">&#x1F4CA;</span> Result Distribution</h2>
    <div class="progress-wrap">
      <div class="progress-bar">
        {progress_segments}
      </div>
    </div>
    <div class="progress-legend">
      {progress_legend}
    </div>
  </div>

  <!-- CHAIN SCENARIOS -->
  <div class="section">
    <h2><span class="icon" style="background:#ede9fe;color:#7c3aed;">&#x1F517;</span> Multi-Tool Chain Scenario Results</h2>
    <div class="chain-list">
      {chain_cards}
    </div>
    {no_chain_note}
  </div>

  <!-- KEY FINDINGS -->
  <div class="section">
    <h2><span class="icon" style="background:#fce7f3;color:#db2777;">&#x1F50D;</span> Key Findings</h2>
    <table>
      <thead><tr><th style="width:60px">Type</th><th>Finding</th><th style="width:80px">Impact</th></tr></thead>
      <tbody>
        {findings_rows}
      </tbody>
    </table>
  </div>

  <!-- DETAIL TABLE -->
  <div class="section">
    <h2><span class="icon" style="background:#d1fae5;color:#059669;">&#x1F4CB;</span> Case Execution Details (NL + CLI Dual Scheme)</h2>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th style="width:55px">ID</th><th style="width:120px">Tool</th><th style="width:180px">Title</th><th>NL Prompt</th><th style="width:50px">Time(s)</th><th style="width:85px">Result</th><th style="width:65px">NL</th><th style="width:65px">CLI</th><th style="width:220px">Analysis</th></tr>
        </thead>
        <tbody>
          {detail_rows}
        </tbody>
      </table>
    </div>
  </div>

  <!-- CONCLUSION -->
  <div class="section">
    <h2><span class="icon" style="background:#fef3c7;color:#92400e;">&#x1F4DD;</span> Test Conclusion</h2>
    <table class="env-table">
      {conclusion_rows}
    </table>
  </div>

  <div class="footer">
    &#x1F916; Generated with Claude Code &middot; EasyData Agent Test Tool &middot; gen_html_report.py &middot; {gen_date}
  </div>

</div>
</body>
</html>'''


# ============================================================
# Logic
# ============================================================

def _escape_html(text):
    """Escape text for safe HTML embedding."""
    if not text:
        return ""
    return (str(text)
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#39;"))


def _truncate(text, max_len=100):
    """Truncate text for display."""
    s = str(text) if text else ""
    if len(s) > max_len:
        return s[:max_len] + "..."
    return s


def _extract_chain_groups(cases):
    """Extract chain scenario groups from case titles.

    Returns a dict: {chain_label: [case, ...]}
    Cases are grouped by chain label extracted from title patterns like:
    - 【组合场景1-Step1】...
    - 【组合场景2-Step2】...
    - 【单工具-正向】...
    """
    chain_pattern = re.compile(r'【(组合场景\d+|单工具[^】]*)】')
    ungrouped = []
    chains = defaultdict(list)

    for case in cases:
        title = case.get("title", "")
        match = chain_pattern.search(title)
        if match:
            label = match.group(1)
            chains[label].append(case)
        else:
            ungrouped.append(case)

    # Sort chains by their number
    def _sort_key(item):
        label, _ = item
        m = re.search(r'(\d+)', label)
        if m:
            return int(m.group(1))
        return 999

    sorted_chains = sorted(chains.items(), key=_sort_key)

    if ungrouped:
        sorted_chains.append(("Other", ungrouped))

    return sorted_chains


def _chain_summary(chain_label, cases):
    """Generate a summary string for a chain group."""
    total = len(cases)
    passes = sum(1 for c in cases if "PASS" in str(c.get("result", "")))
    fails = sum(1 for c in cases if "FAIL" in str(c.get("result", "")) and "EXPECTED" not in str(c.get("result", "")))
    expected_fails = sum(1 for c in cases if "FAIL(EXPECTED)" in str(c.get("result", "")))
    empties = sum(1 for c in cases if "EMPTY" in str(c.get("result", "")))

    if fails == 0 and expected_fails == 0:
        if empties > 0:
            return f'<span class="badge empty">&#x26A0;&#xFE0F; {total} steps ({empties} EMPTY)</span>'
        return f'<span class="badge pass">&#x2705; {total} steps all PASS</span>'

    parts = []
    if passes:
        parts.append(f"{passes} PASS")
    if fails:
        parts.append(f"{fails} FAIL")
    if expected_fails:
        parts.append(f"{expected_fails} expected FAIL")
    if empties:
        parts.append(f"{empties} EMPTY")
    return f'<span class="badge fail">&#x26A0;&#xFE0F; {", ".join(parts)}</span>'


def _result_tag(result_str):
    """Generate a colored tag for a result value."""
    if not result_str:
        return '<span class="tag empty">-</span>'
    s = str(result_str).upper()
    if "FAIL" in s and "EXPECTED" in s:
        return f'<span class="tag fail">FAIL(EXP)</span>'
    if "FAIL" in s:
        return f'<span class="tag fail">FAIL</span>'
    if "EMPTY" in s:
        return f'<span class="tag empty">EMPTY</span>'
    if "PASS" in s:
        return f'<span class="tag pass">PASS</span>'
    return f'<span class="tag empty">{_escape_html(result_str)}</span>'


def _auto_findings(cases, meta):
    """Auto-generate key findings from test results."""
    findings = []
    findings_impacts = []

    # Check for FAIL cases
    fail_cases = [c for c in cases if "FAIL" in str(c.get("result", ""))]
    env_fails = [c for c in fail_cases if "EXPECTED" in str(c.get("result", ""))]
    real_fails = [c for c in fail_cases if "EXPECTED" not in str(c.get("result", ""))]

    # Check for cases with interesting results
    data_found_cases = []
    for c in cases:
        api_result = str(c.get("apiResult", ""))
        result_str = str(c.get("result", ""))
        # Cases that returned real data (not error, not empty)
        if "PASS" in result_str and "EMPTY" not in result_str and "Error:" not in api_result:
            total_count_match = re.search(r'"totalCount":\s*(\d+)', api_result)
            if total_count_match and int(total_count_match.group(1)) > 0:
                data_found_cases.append(c)
            elif '"list":\s*\[[^]]' in api_result and '"list":[]' not in api_result:
                data_found_cases.append(c)
            elif api_result.startswith('[{') or api_result.startswith('{"'):
                if '"totalCount":0' not in api_result and api_result not in ('{}', '[]'):
                    data_found_cases.append(c)

    # Positive findings - chain scenarios that returned real data
    if data_found_cases:
        # Pick the most interesting ones
        chain_data_cases = [c for c in data_found_cases if '组合场景' in c.get('title', '')]
        if chain_data_cases:
            best = chain_data_cases[0]
            if "FAILED" in str(best.get("apiResult", "")):
                findings.append(
                    f'<b>FAILED Instance Located</b>: Through multi-step chain query, successfully located FAILED '
                    f'instance ({best.get("id")}) and retrieved complete node-level failure details.'
                )
                findings_impacts.append('Positive')
            elif "moreDepends" in str(best.get("apiResult", "")):
                findings.append(
                    f'<b>Dependency Issue Detected</b>: Global dependency diagnosis found tasks with redundant upstream '
                    f'dependencies, providing actionable configuration insights.'
                )
                findings_impacts.append('Positive')

        # Context propagation
        findings.append(
            '<b>Context Propagation Verified</b>: Key parameters (project/flow/execId/baselineId) correctly '
            'passed across 2-4 step chains, Agent context inheritance validated.'
        )
        findings_impacts.append('Positive')

    # Tool coverage finding
    tools = set(c.get("tool", "") for c in cases if c.get("tool"))
    schema_check_ok = sum(1 for c in cases if c.get("schemaCheck") and "Error" not in str(c.get("apiResult", "")))

    if schema_check_ok > len(cases) * 0.7:
        findings.append(
            f'<b>Schema Compliance</b>: {schema_check_ok}/{len(cases)} cases passed schema validation, '
            f'API responses match defined MCP schemas.'
        )
        findings_impacts.append('Positive')

    # Negative findings - environment limitations
    if env_fails:
        env_details = []
        for c in env_fails[:3]:
            reason = c.get("resultReason", "")
            tool = c.get("tool", "unknown")
            env_details.append(f'<b>{tool}</b>: {_escape_html(_truncate(reason, 120))}')
        findings.append('<br>'.join(env_details))
        findings_impacts.append('Blocked')

    if real_fails:
        real_details = []
        for c in real_fails:
            reason = c.get("resultReason", "")
            tool = c.get("tool", "unknown")
            real_details.append(f'<b>{tool}</b>: {_escape_html(_truncate(reason, 120))}')
        findings.append('<br>'.join(real_details))
        findings_impacts.append('Issue')

    # Empty data note
    empty_cases = [c for c in cases if "EMPTY" in str(c.get("result", ""))]
    if empty_cases:
        tools_empty = set(c.get("tool", "") for c in empty_cases)
        findings.append(
            f'<b>Empty Results</b>: {len(empty_cases)} cases returned empty results — '
            f'interfaces are functioning correctly but test environment has no data for the queried time range. '
            f'Tools: {", ".join(list(tools_empty)[:5])}'
        )
        findings_impacts.append('Neutral')

    # Notes from meta
    if meta.get("notes"):
        for note in meta["notes"]:
            if isinstance(note, list) and len(note) >= 2:
                findings.append(f'<b>{note[0]}</b>: {note[1]}')
                findings_impacts.append('Note')

    return findings, findings_impacts


def _auto_conclusion(cases, meta):
    """Auto-generate test conclusion."""
    total = len(cases) * 2  # NL + CLI
    passes = sum(1 for c in cases if "PASS" in str(c.get("nlResult", ""))) + \
             sum(1 for c in cases if "PASS" in str(c.get("result", "")))
    fail_expected = sum(1 for c in cases if "FAIL(EXPECTED)" in str(c.get("result", "")) or
                        "FAIL(EXPECTED)" in str(c.get("nlResult", "")))
    real_fails = sum(1 for c in cases if "FAIL" in str(c.get("result", "")) and "EXPECTED" not in str(c.get("result", "")))

    chain_groups = _extract_chain_groups(cases)
    chain_count = len([l for l, _ in chain_groups if l.startswith("组合场景")])

    rows = []

    if real_fails == 0:
        rows.append((
            'Overall Verdict',
            f'<b>PASS &#x2705;</b> — {passes}/{total} verdicts passed ({passes/total*100:.1f}% pass rate). '
            f'{fail_expected} expected failures due to environment limitations, not interface defects.'
        ))
    else:
        rows.append((
            'Overall Verdict',
            f'<b>PASS with Issues</b> — {passes}/{total} verdicts passed. '
            f'{real_fails} real failures + {fail_expected} expected failures.'
        ))

    rows.append((
        'Chain Validation',
        f'<b>{chain_count} multi-tool chain scenarios end-to-end validated</b>. '
        f'Context parameters (project/flow/execId/baselineId) correctly inherited across chain steps.'
    ))

    # Limitations from meta.notes
    limits = []
    if meta.get("notes"):
        for note in meta["notes"]:
            if isinstance(note, list) and len(note) >= 2:
                if "局限" in str(note[0]) or "limit" in str(note[0]).lower():
                    limits.append(note[1])

    if limits:
        rows.append(('Known Limitations', '<br>'.join(f'({i+1}) {l}' for i, l in enumerate(limits))))
    else:
        rows.append(('Known Limitations', 'See Key Findings section for environment-specific limitations.'))

    rows.append((
        'Recommendation',
        'Re-run full 12 chain scenarios in production environment, especially chains involving sensitive '
        'operations (backfill creation/pause/rerun), and verify CLI deployment of unregistered commands.'
    ))

    return rows


def generate_html(results_json, output_path, title=None):
    """Generate HTML report from test results JSON.

    Args:
        results_json: dict with 'meta' and 'cases' keys
        output_path: path to write the HTML file
        title: optional report title override
    """
    meta = results_json.get("meta", {})
    cases = results_json.get("cases", [])

    # ===== Compute stats =====
    case_count = len(cases)
    total_verdicts = case_count * 2  # NL + CLI
    pass_count = sum(1 for c in cases if "PASS" in str(c.get("result", "")))
    fail_count = sum(1 for c in cases if "FAIL" in str(c.get("result", "")))
    pass_pct = pass_count / max(case_count, 1) * 100

    # Unique tools
    tools = sorted(set(c.get("tool", "") for c in cases if c.get("tool")))

    # Chain groups
    chain_groups = _extract_chain_groups(cases)
    chain_scenarios = [l for l, _ in chain_groups if l.startswith("组合场景")]

    # ===== Fail detail =====
    env_fails = sum(1 for c in cases if "FAIL(EXPECTED)" in str(c.get("result", "")))
    real_fails = fail_count - env_fails

    if real_fails == 0:
        fail_detail = f"{env_fails} env-limited only"
    else:
        fail_detail = f"{real_fails} real + {env_fails} env-limited"

    # ===== Report title =====
    test_command = meta.get("testCommand", "easytaskops")
    if title:
        report_title = title
    else:
        report_title = f"EasyData Agent Test Report — {test_command}"

    header_icon = "&#x1F9EA;"  # test tube
    subtitle = meta.get("testCommand", "Multi-tool chain scenario validation · NL + CLI dual execution")
    if len(subtitle) > 100:
        subtitle = "Multi-tool chain scenario validation · NL + CLI dual execution"

    # ===== Progress bar =====
    pass_only = pass_count - sum(1 for c in cases if "EMPTY" in str(c.get("result", "")) and "PASS" in str(c.get("result", "")))
    empty_count = sum(1 for c in cases if "EMPTY" in str(c.get("result", "")))

    segments = []
    legend = []
    if pass_only > 0:
        pct = pass_only / max(case_count, 1) * 100
        segments.append(f'<div class="seg pass" style="width:{pct:.1f}%">PASS {pass_only}</div>')
        legend.append('<span><span class="dot pass"></span> PASS — {0}</span>'.format(pass_only))
    if empty_count > 0:
        pct = empty_count / max(case_count, 1) * 100
        segments.append(f'<div class="seg empty" style="width:{pct:.1f}%">EMPTY {empty_count}</div>')
        legend.append('<span><span class="dot empty"></span> PASS(EMPTY) — {0}</span>'.format(empty_count))
    if fail_count > 0:
        pct = fail_count / max(case_count, 1) * 100
        segments.append(f'<div class="seg fail" style="width:{pct:.1f}%">FAIL {fail_count}</div>')
        legend.append('<span><span class="dot fail"></span> FAIL — {0}</span>'.format(fail_count))

    progress_segments = "".join(segments) if segments else '<div class="seg pass" style="width:100%">No data</div>'
    progress_legend = "".join(legend) if legend else ""

    # ===== Chain cards =====
    chain_cards_html = []
    for label, chain_cases in chain_groups:
        if label == "Other":
            continue

        # Extract chain number
        num_match = re.search(r'(\d+)', label)
        num = num_match.group(1) if num_match else "?"

        # Title from first case
        title_text = chain_cases[0].get("title", label)
        # Remove the 【...】 prefix for cleaner display
        title_text = re.sub(r'【[^】]*】\s*', '', title_text)
        # Extract the meaningful part after →
        chain_name = title_text.split('→')[0].strip() if '→' in title_text else title_text[:60]

        # Build step list from tools
        steps = []
        for c in chain_cases:
            tool = c.get("tool", "?")
            if tool not in steps:
                steps.append(tool)

        steps_html = ""
        for i, s in enumerate(steps):
            if i > 0:
                steps_html += ' <span class="arrow">&#x2192;</span> '
            steps_html += f'<span class="step">{_escape_html(s)}</span>'

        # Summary
        summary = _chain_summary(label, chain_cases)

        # Result reason from last case
        last_reason = ""
        for c in reversed(chain_cases):
            reason = c.get("resultReason", "")
            if reason:
                last_reason = _escape_html(_truncate(reason, 150))
                break

        chain_cards_html.append(f'''
      <div class="chain-item">
        <div class="chain-header"><span class="chain-num">{num}</span><span class="chain-name">{_escape_html(chain_name)}</span></div>
        <div class="chain-steps">{steps_html}</div>
        <div class="chain-result">{summary} {last_reason}</div>
      </div>''')

    chain_cards = "".join(chain_cards_html) if chain_cards_html else '<p style="color:var(--muted)">No chain scenarios detected in test cases.</p>'
    no_chain_note = "" if chain_cards_html else ""

    # ===== Key findings =====
    findings, findings_impacts = _auto_findings(cases, meta)
    findings_rows = []
    for i, (finding, impact) in enumerate(zip(findings, findings_impacts)):
        tag_class = "pass"
        icon = "&#x2705;"
        if impact in ("Blocked", "Issue"):
            tag_class = "fail"
            icon = "&#x26A0;&#xFE0F;"
        elif impact == "Neutral":
            tag_class = "empty"
            icon = "&#x1F4DD;"
        findings_rows.append(
            f'<tr><td><span class="tag {tag_class}">{icon} {impact}</span></td>'
            f'<td>{finding}</td><td>{impact}</td></tr>'
        )
    findings_rows_html = "\n        ".join(findings_rows) if findings_rows else '<tr><td colspan="3">No findings.</td></tr>'

    # ===== Detail rows =====
    detail_rows = []
    last_chain = None
    for label, chain_cases in chain_groups:
        # Add section header
        clean_label = label
        if label.startswith("组合场景"):
            num_match = re.search(r'(\d+)', label)
            if num_match:
                # Get first case title to extract scenario name
                first_title = chain_cases[0].get("title", "")
                scenario_name = re.sub(r'【[^】]*】\s*', '', first_title)
                scenario_name = scenario_name.split('→')[0].strip()[:80]
                clean_label = f"&#x1F517; Scenario {num_match.group(1)}: {scenario_name}"
            else:
                clean_label = f"&#x1F517; {label}"
        elif label == "Other":
            clean_label = "&#x1F4CC; Ungrouped Cases"
        else:
            clean_label = f"&#x1F4CC; {label}"

        detail_rows.append(
            f'<tr class="tr-chain"><td colspan="9" class="section-header">{clean_label}</td></tr>'
        )

        for case in chain_cases:
            cid = _escape_html(case.get("id", "-"))
            tool = _escape_html(case.get("tool", "-"))
            title_text = _escape_html(case.get("title", "-"))
            # Remove chain prefix for cleaner display
            title_clean = re.sub(r'【[^】]*】\s*', '', title_text)
            nl_prompt = _escape_html(_truncate(case.get("nlPrompt", ""), 100))
            exec_time = _escape_html(case.get("execTime", "-"))
            result = _result_tag(str(case.get("result", "")))
            nl_result = _result_tag(str(case.get("nlResult", "")))
            cli_result = _result_tag(str(case.get("result", "")))
            analysis = _escape_html(_truncate(case.get("resultReason", case.get("summary", "")), 150))

            detail_rows.append(
                f'<tr><td>{cid}</td><td><code>{tool}</code></td>'
                f'<td style="max-width:160px">{title_clean}</td>'
                f'<td style="max-width:180px">{nl_prompt}</td>'
                f'<td>{exec_time}</td><td>{result}</td><td>{nl_result}</td><td>{cli_result}</td>'
                f'<td style="max-width:200px;font-size:12px">{analysis}</td></tr>'
            )

    detail_rows_html = "\n          ".join(detail_rows) if detail_rows else '<tr><td colspan="9">No cases found.</td></tr>'

    # ===== Conclusion =====
    conclusion_rows = _auto_conclusion(cases, meta)
    conclusion_html = "\n      ".join(
        f'<tr><td>{label}</td><td>{value}</td></tr>'
        for label, value in conclusion_rows
    )

    # ===== Fill template =====
    html = HTML_TEMPLATE.format(
        report_title=_escape_html(report_title),
        header_icon=header_icon,
        subtitle=_escape_html(subtitle),
        testDate=_escape_html(meta.get("testDate", "N/A")),
        testProduct=_escape_html(meta.get("testProduct", "N/A")),
        testCluster=_escape_html(meta.get("testCluster", "N/A")),
        apiEndpoint=_escape_html(meta.get("apiEndpoint", "N/A")),
        testUser=_escape_html(meta.get("testUser", "N/A")),
        cliVersion=_escape_html(meta.get("cliVersion", "N/A")),
        testCommand=_escape_html(meta.get("testCommand", "N/A")),
        total_cases=case_count,
        total_verdicts=total_verdicts,
        pass_count=pass_count,
        fail_count=fail_count,
        pass_pct=pass_pct,
        fail_detail=fail_detail,
        chain_count=len(chain_scenarios),
        tool_count=len(tools),
        progress_segments=progress_segments,
        progress_legend=progress_legend,
        chain_cards=chain_cards,
        no_chain_note=no_chain_note,
        findings_rows=findings_rows_html,
        detail_rows=detail_rows_html,
        conclusion_rows=conclusion_html,
        case_count=case_count,
        gen_date=datetime.now().strftime("%Y-%m-%d %H:%M"),
    )

    # Write output
    out_dir = os.path.dirname(output_path)
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return case_count, pass_count, fail_count, len(chain_scenarios), len(tools)


# ============================================================
# CLI Entry Point
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Step6+: Generate HTML visualization report from test results JSON"
    )
    parser.add_argument("--results", required=True,
                        help="Test results JSON file path (same format as step6_gen_report.py)")
    parser.add_argument("--output", required=True,
                        help="Output HTML file path")
    parser.add_argument("--title", default=None,
                        help="Report title (optional, auto-generated from meta if omitted)")
    args = parser.parse_args()

    # Load results
    if not os.path.exists(args.results):
        print(f"Error: results file not found: {args.results}")
        sys.exit(1)

    # Try utf-8-sig first to handle BOM, fall back to utf-8
    try:
        with open(args.results, "r", encoding="utf-8-sig") as f:
            results = json.load(f)
    except (UnicodeDecodeError, json.JSONDecodeError):
        with open(args.results, "r", encoding="utf-8") as f:
            results = json.load(f)

    # Generate
    case_count, pass_count, fail_count, chain_count, tool_count = generate_html(
        results, args.output, args.title
    )

    print(f"  [Step6+ HTML] Report generated!")
    print(f"  {case_count} cases / {pass_count} PASS / {fail_count} FAIL")
    print(f"  {chain_count} chain scenarios / {tool_count} tools covered")
    print(f"  Output: {args.output}")
