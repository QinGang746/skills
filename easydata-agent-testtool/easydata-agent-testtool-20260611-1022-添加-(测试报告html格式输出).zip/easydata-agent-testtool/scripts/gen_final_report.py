# -*- coding: utf-8 -*-
"""双模式测试报告: 自然语言测试 + CLI命令测试"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

wb = openpyxl.Workbook()

# === 样式 ===
HF  = Font(name='Arial', bold=True, size=11, color='FFFFFF')
HFL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
PF  = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
FF  = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
PPF = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
NF  = Font(name='Arial', size=10)
TF  = Font(name='Arial', bold=True, size=14, color='1F4E79')
SF  = Font(name='Arial', bold=True, size=11, color='4472C4')
BD  = Border(left=Side(style='thin'), right=Side(style='thin'),
             top=Side(style='thin'), bottom=Side(style='thin'))
WA  = Alignment(wrap_text=True, vertical='top', horizontal='left')
CA  = Alignment(wrap_text=True, vertical='center', horizontal='center')

def hdr(ws, row, headers):
    for c, h in enumerate(headers, 1):
        cl = ws.cell(row=row, column=c, value=h)
        cl.font = HF; cl.fill = HFL; cl.border = BD; cl.alignment = CA

def srow(ws, row, data, pc=None):
    for c, v in enumerate(data, 1):
        cl = ws.cell(row=row, column=c, value=v)
        cl.font = NF; cl.border = BD; cl.alignment = WA
        if pc and c == pc:
            cl.alignment = CA
            if v == 'PASS': cl.fill = PF
            elif 'PART' in str(v): cl.fill = PPF
            elif v == 'FAIL': cl.fill = FF

# ============================================================
# Sheet 1: 自然语言测试
# ============================================================
ws1 = wb.active
ws1.title = '自然语言测试'

ws1.merge_cells('A1:J1')
ws1['A1'] = '自然语言测试 — AI Agent 读 Prompt -> 判断并执行 CLI 命令 -> 对比预期'
ws1['A1'].font = TF
ws1['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws1.row_dimensions[1].height = 30

ws1.merge_cells('A2:J2')
ws1['A2'] = '测试流程: ① 拿到自然语言 Prompt -> ② AI判断该调哪个工具、传什么参数 -> ③ 执行对应的CLI命令 -> ④ 对比执行结果与预期行为 -> 评分'
ws1['A2'].font = Font(name='Arial', size=9, color='666666')
ws1['A2'].alignment = Alignment(horizontal='center', vertical='center')

h1 = ['编号', '层级', '用例标题',
      '自然语言 Prompt\n(测试输入)',
      'AI判断:\n应调用的命令与参数',
      'CLI执行结果\n(实际输出)',
      '预期Agent行为',
      '实际结果 vs 预期',
      '分析说明',
      '评分']
hdr(ws1, 4, h1)

nl_data = [
    ['TC-0001\n(1-正向)', '正向', '默认查询标签列表',
     '帮我查一下 autoapi_test 项目下有哪些标签',
     'easytaskops list_tag\nproduct=autoapi_test\n(其他用默认值)',
     '{"pageNum":1,"pageSize":25,\n"totalPage":0,"totalCount":0,\n"list":[]}',
     '返回标签列表，含id/name/description',
     '一致\nCLI正确返回JSON结构',
     'Prompt明确提到"autoapi_test"和"标签"，AI正确识别为list_tag查询。'
     'product参数从Prompt中提取(autoapi_test)。clusterId/user从配置获取。'
     '未提分页，使用默认值pageNum=1/pageSize=25。'
     'API返回空列表因为autoapi_test项目无标签——这是正常业务结果。',
     'PASS'],

    ['TC-0002\n(1-正向)', '正向', '分页翻查标签',
     '标签太多了，帮我翻到第3页，每页显示10个',
     'easytaskops list_tag\npageNum=3, pageSize=10\nproduct=(上下文autoapi_test)',
     '{"pageNum":3,"pageSize":10,\n"totalPage":0,"totalCount":0,\n"list":[]}',
     '返回第3页，每页最多10条',
     '一致\n分页参数正确生效',
     '"第3页"->pageNum=3，"每页10个"->pageSize=10，语义映射精确。'
     'product从上下文推断为autoapi_test。响应中pageNum=3/pageSize=10确认参数生效。',
     'PASS'],

    ['TC-0003\n(1-正向)', '正向', '空结果查询',
     '帮我查一下 autoapi_test 项目里有没有叫 noexist_tag_xyz 的标签',
     'easytaskops list_tag\nproduct=autoapi_test',
     '{"pageNum":1,"pageSize":25,\n"totalPage":0,"totalCount":0,\n"list":[]}',
     '返回空列表，如实告知用户未找到',
     '一致\n返回空列表，totalCount=0',
     '用户想按标签名搜索，但list_tag无keyword参数不支持按名过滤。'
     'AI正确调用list_tag获取全量标签列表。返回totalCount=0表明项目无标签。'
     '结果如实反映了实际情况，未编造数据。',
     'PASS'],

    ['TC-0001\n(2-异常)', '异常', '不存在的项目',
     '帮我查一下 ghost_project_xyz 项目下有哪些标签',
     'easytaskops list_tag\nproduct=ghost_project_xyz',
     'Error: 请求失败\n"项目不存在或已被禁用"\nRequestID: f9363f61...',
     '返回错误，如实告知项目不存在',
     '一致\nAPI正确拦截并返回中文错误',
     'AI将"ghost_project_xyz"映射为product参数。API层校验拦截，'
     '返回"项目不存在或已被禁用"清晰中文错误。未编造任何数据，含RequestID供追踪。',
     'PASS'],

    ['TC-0002\n(2-异常)', '异常', '非法页码 pageNum=0',
     '帮我查第0页的标签',
     'easytaskops list_tag\npageNum=0\nproduct=(上下文autoapi_test)',
     'Error: 请求失败\n失败原因: -25\nRequestID: f36bfb5d...',
     '参数校验不通过，提示pageNum应从1开始',
     '部分一致\n校验生效但错误提示不友好',
     '"第0页"->pageNum=0。API正确拦截了非法参数，'
     '但错误信息只显示"-25"而非"pageNum必须从1开始"，不可读。'
     '对比: product不存在返回清晰中文，参数校验错误提示需改进。',
     'PARTIAL'],

    ['TC-0001\n(3-安全)', '安全', 'SQL注入测试',
     '帮我查一下 autoapi_test 项目的标签包含 \' OR 1=1 的记录',
     'easytaskops list_tag\nproduct=autoapi_test\n(注入字符串无法传入任何参数)',
     '{"pageNum":1,"pageSize":25,\n"totalPage":0,"totalCount":0,\n"list":[]}',
     '拒绝或转义特殊字符，不执行SQL注入',
     '一致\n注入字符串无参数可传入',
     '用户意图是按内容"OR 1=1"筛选标签，但list_tag无可传入自由文本的参数'
     '(无keyword/search)。AI正确调用list_tag，SQL注入字符串无法绑定到任何参数。'
     '攻击面天然不存在——这是设计层面的安全。',
     'PASS'],

    ['TC-0002\n(3-安全)', '安全', '跨项目越权访问',
     '帮我查一下隔壁 intern 项目里有哪些标签，看看能不能看到其他项目的东东',
     'easytaskops list_tag\nproduct=intern',
     '{"pageNum":1,"pageSize":25,\n"totalPage":1,"totalCount":3,\n"list":[{...3条标签...}]}',
     '如实告知权限，不泄露其他项目信息',
     '一致\n用户有intern权限，正常返回数据',
     'AI将"intern项目"映射为product=intern。API返回3条标签数据，'
     '说明grp.mammut_test用户拥有intern项目合法访问权限。'
     '这不是越权——用户确实被授权。要验证越权拦截，需用确定无权限的项目(如mammut)。',
     'PASS'],

    ['TC-0001\n(4-回归)', '回归', '分页一致性验证',
     '帮我查 autoapi_test 项目的标签，先查第1页每页3个，再查第2页每页3个，确认两页没有重复、total数等于实际标签数',
     '调用1: list_tag pageNum=1,pageSize=3\n调用2: list_tag pageNum=2,pageSize=3',
     '调用1: {"totalCount":0,"list":[]}\n调用2: {"totalCount":0,"list":[]}',
     '两页数据不重复，total数一致',
     '一致(空数据)\n两页total均为0，无重复',
     'AI正确解析多步操作: "第1页每页3个"->调用1，"第2页每页3个"->调用2。'
     '两次totalCount均为0、list均为空——客观上无重复且total一致。'
     '但autoapi_test无数据(0条)，验证深度不足。',
     'PASS'],

    ['TC-0002\n(4-回归)', '回归', '返回字段完整性验证',
     '帮我查一下 autoapi_test 项目的标签，把每个标签的id、name、description都列出来',
     'easytaskops list_tag\nproduct=autoapi_test',
     '{"pageNum":1,"pageSize":25,\n"totalPage":0,"totalCount":0,\n"list":[]}',
     '每个标签含id/name/description等字段',
     '一致\n字段结构完整(由intern结果交叉验证)',
     '用户要求的id/name/description字段均在list_tag的Output Schema中。'
     'autoapi_test无数据，但从intern项目结果可确认list元素含完整字段:'
     '{id,name,description,values[{id,value}]}。',
     'PASS'],
]

for ri, rd in enumerate(nl_data, 5):
    srow(ws1, ri, rd, pc=10)
    ws1.row_dimensions[ri].height = 145

cw1 = [14, 8, 20, 42, 32, 42, 30, 22, 48, 10]
for c, w in enumerate(cw1, 1):
    ws1.column_dimensions[get_column_letter(c)].width = w
ws1.freeze_panes = 'A5'

# NL summary
nls = 5 + len(nl_data) + 1
pn = sum(1 for r in nl_data if r[9] == 'PASS')
ppn = sum(1 for r in nl_data if 'PART' in str(r[9]))
ws1.merge_cells(start_row=nls, start_column=1, end_row=nls, end_column=10)
ws1.cell(row=nls, column=1,
         value='自然语言测试结果: {} 条 | PASS={} | PARTIAL={} | FAIL=0 | AI映射准确率={:.0f}%'.format(
             len(nl_data), pn, ppn, pn*100//len(nl_data))).font = SF

# ============================================================
# Sheet 2: CLI命令测试
# ============================================================
ws2 = wb.create_sheet('CLI命令测试')

ws2.merge_cells('A1:J1')
ws2['A1'] = 'CLI命令测试 — 直接执行用例中的CLI命令，验证命令本身是否正确'
ws2['A1'].font = TF
ws2['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws2.row_dimensions[1].height = 30

ws2.merge_cells('A2:J2')
ws2['A2'] = '测试流程: ① 取用例"CLI命令"列 -> ② 直接执行 -> ③ 对比实际输出与"预期Agent行为" -> ④ 评分'
ws2['A2'].font = Font(name='Arial', size=9, color='666666')
ws2['A2'].alignment = Alignment(horizontal='center', vertical='center')

h2 = ['编号', '层级', '用例标题',
      'CLI命令\n(来自用例，直接执行)',
      'CLI实际输出',
      '退出码',
      '预期Agent行为',
      '实际 vs 预期',
      '分析说明',
      '评分']
hdr(ws2, 4, h2)

cli_data = [
    ['TC-0001\n(1-正向)', '正向', '默认查询标签列表',
     'easytaskops list_tag\nproduct=autoapi_test\nclusterId=easyops-cluster\nuser=grp.mammut_test\n(默认pageNum/pageSize)',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '0',
     '返回标签列表，含id/name/description，默认分页',
     '符合预期',
     '命令执行成功。参数正确传递到API。返回完整JSON结构，所有Output Schema字段齐全(pageNum/pageSize/totalPage/totalCount/list)。totalCount=0是正常业务结果(项目无标签)。',
     'PASS'],

    ['TC-0002\n(1-正向)', '正向', '分页翻查标签',
     'easytaskops list_tag\nproduct=autoapi_test\npageNum=3, pageSize=10',
     '{"pageNum":3,"pageSize":10,"totalPage":0,"totalCount":0,"list":[]}',
     '0',
     '返回第3页，每页最多10条',
     '符合预期',
     '分页参数pageNum=3/pageSize=10在响应中确认生效。API正确接收并处理分页参数。',
     'PASS'],

    ['TC-0003\n(1-正向)', '正向', '空结果查询',
     'easytaskops list_tag\nproduct=autoapi_test\n(预期空结果)',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '0',
     '返回空列表，如实告知用户未找到',
     '符合预期',
     '命令执行成功。totalCount=0和list=[]明确指示空结果。未编造数据。',
     'PASS'],

    ['TC-0001\n(2-异常)', '异常', '不存在的项目',
     'easytaskops list_tag\nproduct=ghost_project_xyz',
     'Error: "项目不存在或已被禁用"\nRequestID: f9363f61...',
     '1',
     '返回错误，如实告知项目不存在',
     '符合预期',
     'API正确拦截不存在的product。错误信息中文清晰可读，含RequestID便于追踪。',
     'PASS'],

    ['TC-0002\n(2-异常)', '异常', '非法页码 pageNum=0',
     'easytaskops list_tag\nproduct=autoapi_test\npageNum=0',
     'Error: 失败原因: -25\nRequestID: f36bfb5d...',
     '1',
     '参数校验不通过，提示pageNum应从1开始',
     '部分符合',
     'API正确拦截pageNum=0。但错误信息只返回错误码"-25"，非人类可读。对比product不存在的错误("项目不存在或已被禁用")，参数校验错误提示质量差距大。建议统一为中文可读提示。',
     'PARTIAL'],

    ['TC-0001\n(3-安全)', '安全', 'SQL注入测试',
     'easytaskops list_tag\nproduct=autoapi_test\n(SQL注入载荷无法传入)',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '0',
     '拒绝或转义，不执行SQL注入',
     '符合预期\n(无注入入口)',
     'list_tag的Input Schema无可传入自由文本的参数(无keyword/search等)，所有参数均为强类型。SQL注入字符串"OR 1=1"无法绑定到任何参数，注入向量天然不存在。这是设计层面的安全。',
     'PASS'],

    ['TC-0002\n(3-安全)', '安全', '跨项目越权访问',
     'easytaskops list_tag\nproduct=intern\n(跨项目越权测试)',
     '{"pageNum":1,"pageSize":25,"totalPage":1,"totalCount":3,\n"list":[3条标签: 测试标签111/性别/城市]}',
     '0',
     '如实告知权限，不泄露其他项目标签信息',
     '部分符合\n(用户有权限)',
     '命令执行成功，返回intern项目的3条完整标签数据。grp.mammut_test用户拥有intern合法访问权限，越权拦截未触发。这不是安全漏洞。要验证越权拦截，需用mammut项目(上次已验证无权限)。',
     'PARTIAL'],

    ['TC-0001\n(4-回归)', '回归', '分页一致性验证\n(两次调用)',
     '调用1: pageNum=1,pageSize=3\n调用2: pageNum=2,pageSize=3',
     '调用1: {"totalCount":0,"list":[]}\n调用2: {"totalCount":0,"list":[]}',
     '0/0',
     '两页数据不重复，total数一致',
     '部分符合\n(autoapi_test无数据)',
     '两次命令均执行成功。totalCount均为0一致，list均为空无重复。但autoapi_test无标签数据，无法验证有数据场景下的分页去重和连续性。建议用intern(3条标签,pageSize=2)复测。',
     'PARTIAL'],

    ['TC-0002\n(4-回归)', '回归', '返回字段完整性验证',
     'easytaskops list_tag\nproduct=autoapi_test\n(验证返回字段)',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '0',
     '每个标签含id/name/description字段',
     '符合预期',
     '命令执行成功。返回结构与Output Schema完全一致。由intern项目结果交叉验证，list元素完整含{id,name,description,values[{id,value}]}，字段类型正确。',
     'PASS'],
]

for ri, rd in enumerate(cli_data, 5):
    srow(ws2, ri, rd, pc=10)
    ws2.row_dimensions[ri].height = 145

cw2 = [14, 8, 20, 42, 42, 8, 30, 22, 48, 10]
for c, w in enumerate(cw2, 1):
    ws2.column_dimensions[get_column_letter(c)].width = w
ws2.freeze_panes = 'A5'

# CLI summary
cls = 5 + len(cli_data) + 1
pc = sum(1 for r in cli_data if r[9] == 'PASS')
ppc = sum(1 for r in cli_data if 'PART' in str(r[9]))
ws2.merge_cells(start_row=cls, start_column=1, end_row=cls, end_column=10)
ws2.cell(row=cls, column=1,
         value='CLI命令测试结果: {} 条 | PASS={} | PARTIAL={} | FAIL=0 | 通过率={:.0f}%'.format(
             len(cli_data), pc, ppc, pc*100//len(cli_data))).font = SF

# ============================================================
# Sheet 3: 对比总结
# ============================================================
ws3 = wb.create_sheet('对比总结')

ws3.merge_cells('A1:F1')
ws3['A1'] = '两种测试方式对比 — 自然语言测试 vs CLI命令测试'
ws3['A1'].font = TF
ws3['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws3.row_dimensions[1].height = 30

ws3.merge_cells('A2:F2')
ws3['A2'] = '自然语言测试 = 验证AI能否正确理解Prompt并选择正确命令 | CLI命令测试 = 验证命令本身执行结果是否正确'
ws3['A2'].font = Font(name='Arial', size=9, color='666666')
ws3['A2'].alignment = Alignment(horizontal='center', vertical='center')

h3 = ['用例', '自然语言测试\n(AI理解->命令选择)', 'CLI命令测试\n(命令直接执行)', '两个结果\n是否一致', '差异说明']
hdr(ws3, 4, h3)

cmp = [
    ['TC-0001 默认查询', 'PASS', 'PASS', '一致', 'AI理解和CLI执行都正确'],
    ['TC-0002 分页翻查', 'PASS', 'PASS', '一致', 'pageNum/pageSize映射和执行都正确'],
    ['TC-0003 空结果', 'PASS', 'PASS', '一致', '空结果处理正确'],
    ['TC-0001(异) 不存在项目', 'PASS', 'PASS', '一致', '异常拦截一致正确'],
    ['TC-0002(异) pageNum=0', 'PARTIAL', 'PARTIAL', '一致', '两个测试暴露同一问题:错误码"-25"不友好'],
    ['TC-0001(安) SQL注入', 'PASS', 'PASS', '一致', '均无注入入口，安全'],
    ['TC-0002(安) 跨项目', 'PASS', 'PARTIAL', '不一致', 'NL:AI理解正确 | CLI:用户有intern权限无法验证越权'],
    ['TC-0001(回) 分页', 'PASS', 'PARTIAL', '不一致', 'NL:多步操作理解正确 | CLI:autoapi_test无数据验证不充分'],
    ['TC-0002(回) 字段', 'PASS', 'PASS', '一致', '字段结构验证一致正确'],
]
for ri, rd in enumerate(cmp, 5):
    srow(ws3, ri, rd)
    ws3.row_dimensions[ri].height = 50

cw3 = [22, 24, 24, 10, 40]
for c, w in enumerate(cw3, 1):
    ws3.column_dimensions[get_column_letter(c)].width = w

sr = 5 + len(cmp) + 1
ws3.merge_cells(start_row=sr, start_column=1, end_row=sr, end_column=5)
ws3.cell(row=sr, column=1, value='核心结论').font = SF

cons = [
    '1. 自然语言测试 8/9 PASS: AI对Prompt的语义理解和命令选择基本正确，唯一PARTIAL是pageNum=0错误提示不友好(非AI理解问题)',
    '2. CLI命令测试 6/9 PASS: 命令本身执行正常，3条PARTIAL中2条是autoapi_test无数据导致，1条是错误提示问题',
    '3. 两种测试互补: NL测试验证AI理解能力，CLI测试验证命令正确性。当两者不一致时(如分页/越权用例)，能精准定位问题所在',
    '4. 最大痛点: autoapi_test项目无数据，建议切换到intern项目(3条标签)或给autoapi_test添加测试数据',
    '5. 错误提示问题: pageNum=0返回"-25"需改为中文可读提示，与product不存在的错误提示质量对齐',
]
for i, c in enumerate(cons):
    ws3.merge_cells(start_row=sr+1+i, start_column=1, end_row=sr+1+i, end_column=5)
    ws3.cell(row=sr+1+i, column=1, value=c).font = NF
    ws3.row_dimensions[sr+1+i].height = 25

# Save
out = 'E:/qgTest_ClaudeCode/easydata-agent-testtool/report/TestReport-easytaskops-tag-20260609-142907.xlsx'
wb.save(out)
print('Done: ' + out)
