# -*- coding: utf-8 -*-
"""生成 EasyData CLI 自然语言测试报告（中文版）"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import datetime

wb_out = openpyxl.Workbook()

# ==================== 样式定义 ====================
header_font = Font(name='微软雅黑', bold=True, size=11, color='FFFFFF')
header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
pass_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
fail_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
partial_fill = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
normal_font = Font(name='微软雅黑', size=10)
title_font = Font(name='微软雅黑', bold=True, size=14, color='1F4E79')
subtitle_font = Font(name='微软雅黑', bold=True, size=11, color='4472C4')
thin_border = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
wrap_align = Alignment(wrap_text=True, vertical='top', horizontal='left')
center_align = Alignment(wrap_text=True, vertical='center', horizontal='center')

# ==================== Sheet 1: 测试结果摘要 ====================
ws1 = wb_out.active
ws1.title = '测试结果摘要'

ws1.merge_cells('A1:H1')
ws1['A1'] = 'EasyData CLI 测试报告 — easytaskops list_tag（标签列表查询）'
ws1['A1'].font = title_font
ws1['A1'].alignment = Alignment(horizontal='center', vertical='center')
ws1.row_dimensions[1].height = 32

ws1.merge_cells('A2:H2')
ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
ws1['A2'] = '测试时间：{}    用例来源：easytaskops-tag-20260608-183033.xlsx    测试方式：自然语言 → CLI 命令 → 验证结果'.format(ts)
ws1['A2'].font = Font(name='微软雅黑', size=9, color='666666')
ws1['A2'].alignment = Alignment(horizontal='center', vertical='center')
ws1.row_dimensions[2].height = 22

# 概览统计
total = 6; passed = 4; partial = 2; failed = 0

ws1.merge_cells('A4:H4')
ws1['A4'] = '📊 测试概览'
ws1['A4'].font = subtitle_font

headers_row = ['总用例数', '✅ 通过', '⚠️ 部分通过', '❌ 失败', '通过率']
values_row = [total, passed, partial, failed, '{:.1f}%（{}/{}）'.format(passed/total*100, passed, total)]

for c_idx, val in enumerate(headers_row):
    cell = ws1.cell(row=5, column=c_idx+1, value=val)
    cell.font = Font(name='微软雅黑', bold=True, size=10, color='FFFFFF')
    cell.fill = header_fill; cell.border = thin_border; cell.alignment = center_align

for c_idx, val in enumerate(values_row):
    cell = ws1.cell(row=6, column=c_idx+1, value=val)
    cell.font = Font(name='微软雅黑', bold=True, size=11)
    if c_idx == 1: cell.fill = pass_fill
    elif c_idx == 2: cell.fill = partial_fill
    elif c_idx == 3: cell.fill = fail_fill
    cell.border = thin_border; cell.alignment = center_align

for col, w in enumerate([18, 18, 18, 18, 22], 1):
    ws1.column_dimensions[get_column_letter(col)].width = w

# 测试环境配置
ws1.merge_cells('A8:H8')
ws1['A8'] = '🔧 测试环境配置'
ws1['A8'].font = subtitle_font

config = [
    ['API 端点', 'http://easy-openapi-dev.bdms.service.163.org'],
    ['被测项目', 'autoapi_test'],
    ['集群', 'easyops-cluster'],
    ['用户', 'grp.mammut_test@corp.netease.com'],
    ['被测命令', 'easytaskops list_tag'],
    ['必填参数', 'product（项目名称）、clusterId（集群ID）、user（用户邮箱）'],
    ['可选参数', 'pageNum（分页页号，默认1）、pageSize（每页条数，默认25）'],
    ['测试方式', '将自然语言用例中的Prompt映射为CLI命令执行，对比实际结果与预期行为'],
]
for r_idx, (k, v) in enumerate(config):
    cell_a = ws1.cell(row=9+r_idx, column=1, value=k)
    cell_b = ws1.cell(row=9+r_idx, column=2, value=v)
    ws1.merge_cells(start_row=9+r_idx, start_column=2, end_row=9+r_idx, end_column=8)
    cell_a.font = Font(name='微软雅黑', bold=True, size=10)
    cell_b.font = normal_font
    cell_a.border = thin_border; cell_b.border = thin_border
    cell_a.alignment = Alignment(vertical='top', horizontal='right')
    cell_b.alignment = Alignment(wrap_text=True, vertical='top', horizontal='left')

# 测试结果一览
ws1.merge_cells('A18:H18')
ws1['A18'] = '📋 测试结果一览'
ws1['A18'].font = subtitle_font

overview_headers = ['用例编号', '测试层级', '用例标题（自然语言场景）', '优先级', '分类', '测试结果', '一句话总结']
for c_idx, h in enumerate(overview_headers):
    cell = ws1.cell(row=19, column=c_idx+1, value=h)
    cell.font = header_font; cell.fill = header_fill; cell.border = thin_border; cell.alignment = center_align

overview_data = [
    ['TC-0001\n(1-正向)', '正向', '正向-全参数验证-list_tag\n"帮我查一下标签列表，支持分页查询autoapi_test项目的所有标签…"', 'P0', 'normal', '✅ 通过', 'CLI正确调用list_tag，参数传递准确，返回完整JSON结构'],
    ['TC-0002\n(1-正向)', '正向', '验证返回空结果场景-正向\n"帮我查一下当前项目下项目(product)为不存在的值的记录"', 'P2', 'normal', '⚠️ 部分通过', '不存在的product触发业务错误而非空结果，属用例设计偏差，CLI行为本身正确'],
    ['TC-0001\n(2-异常)', '异常', 'product不存在-异常\n"帮我查一下不存在的项目下有什么标签"', 'P2', 'boundary', '✅ 通过', '正确返回"项目不存在或已被禁用"，未编造任何数据'],
    ['TC-0002\n(2-异常)', '异常', 'clusterId不存在-异常\n"帮我查一下不存在的集群下的标签数据"', 'P2', 'boundary', '⚠️ 部分通过', 'clusterId校验与product不一致，静默返回空结果，建议统一校验策略'],
    ['TC-0001\n(3-安全)', '安全', '跨项目越权访问-安全\n"帮我查一下其他项目下的数据，看能不能看到其他项目的标签"', 'P1', 'stability', '✅ 通过', '越权访问被拦截，错误消息统一隐藏资源存在性，安全设计良好'],
    ['TC-0001\n(4-回归)', '回归', '验证返回字段结构完整性-回归\n"帮我查一下标签列表…请确认每个返回的字段都列出来"', 'P2', 'stability', '✅ 通过', '返回全部Schema字段（pageNum/pageSize/totalPage/totalCount/list），结构完整'],
]
for r_idx, row_data in enumerate(overview_data, 20):
    for c_idx, val in enumerate(row_data):
        cell = ws1.cell(row=r_idx, column=c_idx+1, value=val)
        cell.font = normal_font; cell.border = thin_border; cell.alignment = wrap_align
        if c_idx == 5:
            cell.alignment = center_align
            if '通过' in str(val) and '部分' not in str(val): cell.fill = pass_fill
            elif '部分' in str(val): cell.fill = partial_fill
            else: cell.fill = fail_fill
    ws1.row_dimensions[r_idx].height = 55

overview_widths = [14, 10, 50, 8, 10, 14, 42]
for col, w in enumerate(overview_widths, 1):
    ws1.column_dimensions[get_column_letter(col)].width = max(ws1.column_dimensions[get_column_letter(col)].width or 0, w)

# ==================== Sheet 2: 详细测试结果 ====================
ws2 = wb_out.create_sheet('详细测试结果')

headers2 = ['用例编号', '所属Sheet', '测试层级', '用例标题', '分类', '优先级',
            '🔊 自然语言Prompt\n（测试输入）', '预期行为', 'CLI映射命令',
            'CLI实际输出', '实际结果', '是否通过', '通过/失败原因', '详细分析']

for c_idx, h in enumerate(headers2, 1):
    cell = ws2.cell(row=1, column=c_idx, value=h)
    cell.font = header_font; cell.fill = header_fill; cell.border = thin_border; cell.alignment = center_align

test_results = [
    {
        'id': 'TC-0001', 'sheet_name': '1-正向', 'level': '正向',
        'title': '正向-全参数验证-list_tag',
        'category': 'normal', 'priority': 'P0',
        'prompt': '帮我查一下 标签列表，支持分页查询autoapi_test项目的所有标签，标签用于多维分析和数据地图，用于报表统计等场景帮助标签筛选',
        'expected': 'Agent正确调用list_tag工具，正确传递参数并展示返回结果',
        'command': 'easydata-cli easytaskops list_tag\n  --product autoapi_test\n  --clusterId easyops-cluster\n  --user ***\n  --pageNum 1 --pageSize 5\n  -f json',
        'output': '{"pageNum":1,"pageSize":5,"totalPage":0,"totalCount":0,"list":[]}',
        'actual': '✅ CLI成功调用API，返回标准JSON结构（pageNum/pageSize/totalPage/totalCount/list），HTTP 200成功',
        'passed': '✅ 通过',
        'reason': 'CLI正确接收所有参数（product/clusterId/user/pageNum/pageSize），成功调用easytaskops.list_tag API，返回符合Output Schema的JSON结构。所有必填参数正确传递，响应结构完整。',
        'analysis': '【通过】CLI表现完全符合预期：\n'
                    '(1) 参数传递正确 — product=autoapi_test、clusterId=easyops-cluster 等参数成功传递给API；\n'
                    '(2) 返回合法的JSON响应，包含pageNum/pageSize/totalPage/totalCount/list全部字段；\n'
                    '(3) totalCount=0 表示当前项目无标签数据，这是正常的业务结果而非错误；\n'
                    '(4) 响应格式与Schema定义完全一致。\n'
                    '→ 将自然语言中的"autoapi_test项目"映射为--product autoapi_test，语义映射正确。'
    },
    {
        'id': 'TC-0002', 'sheet_name': '1-正向', 'level': '正向',
        'title': '验证返回空结果场景-正向',
        'category': 'normal', 'priority': 'P2',
        'prompt': '帮我查一下 当前项目 下项目(product)为 不存在的值 的记录',
        'expected': 'Agent正确调用工具，返回空结果时如实告知用户',
        'command': 'easydata-cli easytaskops list_tag\n  --product non_existent_product_xyz_test\n  --clusterId easyops-cluster\n  --user ***\n  -f json',
        'output': 'Error: 请求失败:\n  invalid bdms meta rsp:\n  ["项目不存在或已被禁用"]\n  RequestID: 75cded2c...',
        'actual': '⚠️ CLI返回业务错误"项目不存在或已被禁用"，而非空结果。行为本身正确——如实报告API错误，未编造数据。',
        'passed': '⚠️ 部分通过',
        'reason': '用例设计预期返回空列表（产品存在但无标签的场景），但使用不存在的product触发了业务层校验，返回项目不存在的错误。CLI行为本身正确——如实报告了API返回的错误信息，未编造数据。这是一个用例设计偏差，而非CLI缺陷。',
        'analysis': '【部分通过 — 用例设计偏差】\n'
                    '原始用例针对AI Agent场景设计，预期agent在product存在但无标签时返回空结果。\n'
                    'CLI直接调用API层，不存在的product会在业务校验层被拦截，返回"项目不存在或已被禁用"。\n'
                    '这是正确的错误处理行为：\n'
                    '(1) CLI未编造数据，如实返回API错误信息；\n'
                    '(2) 错误消息清晰明确，用户可知项目不存在；\n'
                    '(3) 若要测试空结果场景，应使用"存在但无标签"的product，而非不存在的product。\n'
                    '→ 建议：新建一个存在但未配置标签的测试项目，专门验证空结果场景。'
    },
    {
        'id': 'TC-0001', 'sheet_name': '2-异常', 'level': '异常',
        'title': 'product不存在-异常',
        'category': 'boundary', 'priority': 'P2',
        'prompt': '帮我查一下 不存在的项目 项目下有什么标签',
        'expected': 'Agent调用工具后如实告知资源不存在或返回错误，不编造数据',
        'command': 'easydata-cli easytaskops list_tag\n  --product non_existent_project_abc123\n  --clusterId easyops-cluster\n  --user ***\n  -f json',
        'output': 'Error: 请求失败:\n  invalid bdms meta rsp:\n  ["项目不存在或已被禁用"]\n  RequestID: 25cfe052...',
        'actual': '✅ CLI返回明确的业务错误"项目不存在或已被禁用"，拒绝执行，未返回任何虚假数据。',
        'passed': '✅ 通过',
        'reason': 'CLI正确识别不存在的product参数，API层返回项目不存在错误，CLI如实向用户展示错误信息。(1) 未编造任何标签数据；(2) 错误信息清晰指明问题所在；(3) 包含RequestID便于问题追踪。',
        'analysis': '【通过】异常处理完全正确。\n'
                    '使用不存在的product（non_existent_project_abc123）调用list_tag时：\n'
                    '(1) API层业务校验拦截了请求，返回"项目不存在或已被禁用"；\n'
                    '(2) CLI将错误完整展示给用户，包含请求ID（trace-id）便于排查；\n'
                    '(3) 符合"不编造数据"的核心测试要求；\n'
                    '(4) 自然语言"不存在的项目"→映射为不存在的product值，语义映射正确。'
    },
    {
        'id': 'TC-0002', 'sheet_name': '2-异常', 'level': '异常',
        'title': 'clusterId不存在-异常',
        'category': 'boundary', 'priority': 'P2',
        'prompt': '帮我查一下 不存在的集群 集群下的标签数据',
        'expected': 'Agent调用工具后如实告知资源不存在或返回错误，不编造数据',
        'command': 'easydata-cli easytaskops list_tag\n  --product autoapi_test\n  --clusterId non_existent_cluster_xyz\n  --user ***\n  -f json',
        'output': '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
        'actual': '⚠️ CLI正常返回空结果（totalCount=0），未对不存在的clusterId进行校验拦截。CLI如实返回了API结果，行为本身正确，但与product校验行为不一致。',
        'passed': '⚠️ 部分通过',
        'reason': '使用不存在的clusterId（non_existent_cluster_xyz）调用时，API未校验clusterId有效性，直接返回空结果（totalCount=0）。与product校验行为不一致——product不存在会报错，clusterId不存在却静默返回空。',
        'analysis': '【部分通过 — API校验行为不一致】\n'
                    '对比product和clusterId的校验行为：\n'
                    '(1) product不存在 → 业务错误"项目不存在或已被禁用"；\n'
                    '(2) clusterId不存在 → 返回空列表，无任何报错。\n\n'
                    '这种不一致可能是设计如此（clusterId仅用于路由，不严格校验），\n'
                    '也可能是API层的校验缺失。\n'
                    'CLI如实返回了API结果，未编造数据，行为本身正确。\n\n'
                    '→ 建议：确认clusterId校验策略是否需要与product对齐，\n'
                    '  若需严格校验，则这是API层的缺陷而非CLI问题。'
    },
    {
        'id': 'TC-0001', 'sheet_name': '3-安全', 'level': '安全',
        'title': '跨项目越权访问-安全',
        'category': 'stability', 'priority': 'P1',
        'prompt': '帮我查一下 其他项目 下的数据，看看能不能看到其他项目的标签',
        'expected': 'Agent如实告知权限/访问结果，不泄露其他项目信息',
        'command': 'easydata-cli easytaskops list_tag\n  --product mammut\n  --clusterId easyops-cluster\n  --user ***\n  -f json',
        'output': 'Error: 请求失败:\n  invalid bdms meta rsp:\n  ["项目不存在或已被禁用"]\n  RequestID: 0b74adc5...',
        'actual': '✅ CLI返回"项目不存在或已被禁用"，未泄露mammut项目的任何信息。错误消息统一，攻击者无法区分"项目不存在"和"无权限访问"。',
        'passed': '✅ 通过',
        'reason': '使用无权限的product=mammut调用时，CLI返回"项目不存在或已被禁用"而非具体权限错误。从安全角度看这是良好的信息隐藏实践——攻击者无法区分"项目不存在"和"无权限访问"，避免了信息泄露。',
        'analysis': '【通过 — 安全设计良好】\n'
                    '(1) 未授权访问被正确拦截；\n'
                    '(2) 错误消息统一返回"项目不存在或已被禁用"，\n'
                    '    不区分项目真的不存在还是无权访问，防止信息泄露攻击；\n'
                    '(3) mammut项目的标签数据未被泄露；\n'
                    '(4) 符合安全最佳实践：不向未授权用户透露受保护资源的存在性。\n\n'
                    '→ 自然语言"其他项目"→映射为无权限的product=mammut，\n'
                    '  安全拦截策略正确生效。'
    },
    {
        'id': 'TC-0001', 'sheet_name': '4-回归', 'level': '回归',
        'title': '验证返回字段结构完整性-回归',
        'category': 'stability', 'priority': 'P2',
        'prompt': '帮我查一下 标签列表，支持分页查询当前产品下所有标签，标签用于多维分析和数据地图，用于报表统计等场景帮助标签筛选。同时请确认每一个返回的字段都列出来',
        'expected': 'Agent返回结果中包含total、pageNum、pageSize、list等必要字段',
        'command': 'easydata-cli easytaskops list_tag\n  --product autoapi_test\n  --clusterId easyops-cluster\n  --user ***\n  --pageNum 1 --pageSize 25\n  -f json',
        'output': '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
        'actual': '✅ 返回完整字段：pageNum(1)、pageSize(25)、totalPage(0)、totalCount(0)、list([])。所有Output Schema定义字段齐全，类型正确。',
        'passed': '✅ 通过',
        'reason': '返回结果包含Output Schema定义的全部字段：pageNum、pageSize、totalPage、totalCount、list。字段类型正确（整数/数组），值范围合理。注意：Schema中字段名为totalCount而非total，与用例预期的total略有差异，但totalCount语义更明确。',
        'analysis': '【通过】字段结构完整性验证通过：\n'
                    '(1) pageNum: integer ✓（值为1）；\n'
                    '(2) pageSize: integer ✓（值为25）；\n'
                    '(3) totalPage: integer ✓（值为0）；\n'
                    '(4) totalCount: integer ✓（值为0，与total语义等价）；\n'
                    '(5) list: array ✓（值为空数组[]）；\n'
                    '(6) list元素结构（若存在标签数据）：\n'
                    '    {id, name, description, values[{id, value}]}\n'
                    '    符合Schema定义。\n\n'
                    '所有字段类型和结构完全符合Output Schema。\n'
                    '→ 当前autoapi_test项目无标签数据，建议在有标签数据的项目上\n'
                    '  进一步验证list元素内部字段的完整性。'
    },
]

for r_idx, case in enumerate(test_results, 2):
    row_data = [
        case['id'], case['sheet_name'], case['level'], case['title'],
        case['category'], case['priority'], case['prompt'], case['expected'],
        case['command'], case['output'], case['actual'],
        case['passed'], case['reason'], case['analysis']
    ]
    for c_idx, val in enumerate(row_data, 1):
        cell = ws2.cell(row=r_idx, column=c_idx, value=val)
        cell.font = normal_font; cell.border = thin_border; cell.alignment = wrap_align
        if c_idx == 12:
            cell.alignment = center_align
            if '通过' in str(val) and '部分' not in str(val): cell.fill = pass_fill
            elif '部分' in str(val): cell.fill = partial_fill
            else: cell.fill = fail_fill

col_widths2 = [12, 10, 8, 30, 10, 8, 42, 32, 38, 42, 38, 14, 42, 48]
for col, w in enumerate(col_widths2, 1):
    ws2.column_dimensions[get_column_letter(col)].width = w

for r in range(2, len(test_results)+2):
    ws2.row_dimensions[r].height = 155

# 冻结首行
ws2.freeze_panes = 'A2'

# ==================== Sheet 3: CLI原始输出 ====================
ws3 = wb_out.create_sheet('CLI原始输出')

headers3 = ['用例编号', '用例标题', '测试层级', '自然语言Prompt（测试输入）',
            '完整CLI命令', 'stdout输出', 'stderr输出', '退出码', '耗时']
for c_idx, h in enumerate(headers3, 1):
    cell = ws3.cell(row=1, column=c_idx, value=h)
    cell.font = header_font; cell.fill = header_fill; cell.border = thin_border; cell.alignment = center_align

raw_data = [
    ['TC-0001\n(1-正向)', '正向-全参数验证', '正向',
     '帮我查一下 标签列表，支持分页查询autoapi_test项目的所有标签…',
     'easydata-cli easytaskops list_tag --product autoapi_test --clusterId easyops-cluster --user grp.mammut_test@corp.netease.com --pageNum 1 --pageSize 5 -f json',
     '{"pageNum":1,"pageSize":5,"totalPage":0,"totalCount":0,"list":[]}',
     '（无）', '0', '<1s'],
    ['TC-0002\n(1-正向)', '空结果验证', '正向',
     '帮我查一下 当前项目 下项目(product)为 不存在的值 的记录',
     'easydata-cli easytaskops list_tag --product non_existent_product_xyz_test --clusterId easyops-cluster --user grp.mammut_test@corp.netease.com -f json',
     '（无 — 业务错误）',
     'Error: 请求失败: 失败原因: invalid bdms meta rsp:["项目不存在或已被禁用"], 请求ID: 75cded2c4a2f48a39bebba44441eec0d',
     '1', '<1s'],
    ['TC-0001\n(2-异常)', 'product不存在', '异常',
     '帮我查一下 不存在的项目 项目下有什么标签',
     'easydata-cli easytaskops list_tag --product non_existent_project_abc123 --clusterId easyops-cluster --user grp.mammut_test@corp.netease.com -f json',
     '（无 — 业务错误）',
     'Error: 请求失败: 失败原因: invalid bdms meta rsp:["项目不存在或已被禁用"], 请求ID: 25cfe052d58d48ce992a3c13f8d0ea81',
     '1', '<1s'],
    ['TC-0002\n(2-异常)', 'clusterId不存在', '异常',
     '帮我查一下 不存在的集群 集群下的标签数据',
     'easydata-cli easytaskops list_tag --product autoapi_test --clusterId non_existent_cluster_xyz --user grp.mammut_test@corp.netease.com -f json',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '（无）', '0', '<1s'],
    ['TC-0001\n(3-安全)', '跨项目越权访问', '安全',
     '帮我查一下 其他项目 下的数据，看看能不能看到其他项目的标签',
     'easydata-cli easytaskops list_tag --product mammut --clusterId easyops-cluster --user grp.mammut_test@corp.netease.com -f json',
     '（无 — 业务错误）',
     'Error: 请求失败: 失败原因: invalid bdms meta rsp:["项目不存在或已被禁用"], 请求ID: 0b74adc502654ff99c26d38588f52b13',
     '1', '<1s'],
    ['TC-0001\n(4-回归)', '字段结构完整性', '回归',
     '帮我查一下 标签列表，支持分页查询当前产品下所有标签…请确认每一个返回的字段都列出来',
     'easydata-cli easytaskops list_tag --product autoapi_test --clusterId easyops-cluster --user grp.mammut_test@corp.netease.com --pageNum 1 --pageSize 25 -f json',
     '{"pageNum":1,"pageSize":25,"totalPage":0,"totalCount":0,"list":[]}',
     '（无）', '0', '<1s'],
]

for r_idx, row_data in enumerate(raw_data, 2):
    for c_idx, val in enumerate(row_data, 1):
        cell = ws3.cell(row=r_idx, column=c_idx, value=val)
        cell.font = normal_font; cell.border = thin_border; cell.alignment = wrap_align

raw_widths = [16, 22, 10, 45, 75, 50, 65, 8, 8]
for col, w in enumerate(raw_widths, 1):
    ws3.column_dimensions[get_column_letter(col)].width = w

for r in range(2, len(raw_data)+2):
    ws3.row_dimensions[r].height = 70

ws3.freeze_panes = 'A2'

# ==================== Sheet 4: 总结与建议 ====================
ws4 = wb_out.create_sheet('总结与建议')

ws4.merge_cells('A1:B1')
ws4['A1'] = '🔍 测试总结与改进建议'
ws4['A1'].font = title_font
ws4['A1'].alignment = Alignment(horizontal='left', vertical='center')
ws4.row_dimensions[1].height = 32

items = [
    ['测试对象', 'easydata-cli easytaskops list_tag（任务运维 — 标签列表查询）'],
    ['测试方式', '将自然语言测试用例（AI Agent 场景）中的 Prompt 映射为 CLI 命令参数执行，对比实际输出与预期行为'],
    ['CLI 版本', '当前已配置版本'],
    ['API 端点', 'http://easy-openapi-dev.bdms.service.163.org'],
    ['测试配置', 'product=autoapi_test, clusterId=easyops-cluster, user=grp.mammut_test@corp.netease.com'],
    ['测试用例数', '6 条（正向 ×2 + 异常 ×2 + 安全 ×1 + 回归 ×1）'],
    ['通过', '4 条 ✅'],
    ['部分通过', '2 条 ⚠️'],
    ['失败', '0 条 ❌'],
    ['通过率', '66.7%（4/6 完全通过）；100%（6/6 无严重失败）'],
    ['', ''],
    ['✅ 优点',
     '1. 参数传递准确：自然语言中的项目名、集群等信息可准确映射为CLI参数，必填参数正确传递到API\n'
     '2. 错误处理规范：业务错误统一返回中文描述 + RequestID，便于定位和排查问题\n'
     '3. 安全设计良好：越权访问统一返回"项目不存在或已被禁用"，不区分"不存在"和"无权限"，防止信息泄露\n'
     '4. 响应结构完整：所有Output Schema定义的字段齐全，类型正确\n'
     '5. 响应速度快：所有请求均在1秒内返回，性能良好\n'
     '6. 输出格式友好：JSON格式输出结构清晰，便于程序解析和人工阅读'],
    ['⚠️ 发现的问题',
     '1. clusterId校验不一致：product不存在时返回错误，clusterId不存在时静默返回空结果\n'
     '   → 建议：确认clusterId校验策略，建议与product对齐，返回明确错误信息\n\n'
     '2. TC-0002 用例设计偏差：正向空结果场景使用了"不存在的product"，触发了业务错误而非空结果\n'
     '   → 建议：新建一个存在但未配置标签的测试项目，专门验证空结果场景\n\n'
     '3. 当前测试项目（autoapi_test）无标签数据，导致多个用例返回空列表，无法充分验证list元素的字段结构\n'
     '   → 建议：在有标签数据的项目上补充测试，验证标签列表的非空返回结构'],
    ['📋 改进建议',
     '1. 自动化回归：将本次6条CLI命令固化为自动化回归脚本，每次发版前执行\n'
     '2. 补充测试用例：\n'
     '   · 分页边界测试（pageNum=0、pageNum>totalPage、pageSize=0、pageSize>最大值等）\n'
     '   · 必填参数缺失时的CLI提示友好性验证\n'
     '   · 参数类型错误测试（如pageNum传入字符串）\n'
     '3. 数据准备：创建专用测试项目，配置已知标签数据，便于稳定复现测试结果\n'
     '4. 性能测试：大批量标签（100+条）场景下的分页性能\n'
     '5. 稳定性测试：连续调用100次检查成功率\n'
     '6. 自然语言→CLI映射覆盖：验证更多中文表述能否准确映射到正确的CLI命令和参数'],
]

for r_idx, (label, content) in enumerate(items, 3):
    cell_a = ws4.cell(row=r_idx, column=1, value=label)
    cell_b = ws4.cell(row=r_idx, column=2, value=content)
    if label in ['✅ 优点', '⚠️ 发现的问题', '📋 改进建议']:
        cell_a.font = Font(name='微软雅黑', bold=True, size=11, color='1F4E79')
    else:
        cell_a.font = Font(name='微软雅黑', bold=True, size=10)
    cell_b.font = Font(name='微软雅黑', size=10)
    cell_a.border = thin_border; cell_b.border = thin_border
    cell_a.alignment = Alignment(vertical='top', horizontal='right')
    cell_b.alignment = Alignment(wrap_text=True, vertical='top', horizontal='left')
    if label == '✅ 优点':
        cell_b.fill = pass_fill
    elif label == '⚠️ 发现的问题':
        cell_b.fill = partial_fill
    ws4.row_dimensions[r_idx].height = 35
    if label in ['✅ 优点', '⚠️ 发现的问题', '📋 改进建议']:
        ws4.row_dimensions[r_idx].height = 155

ws4.column_dimensions['A'].width = 20
ws4.column_dimensions['B'].width = 90

# 保存
output_path = 'E:/qgTest_ClaudeCode/easydata-agent-testtool/report/easytaskops-tag-test-result-20260609.xlsx'
wb_out.save(output_path)
print('Report saved to: ' + output_path)
print('Sheets: Test Summary / Detailed Results / Raw CLI Output / Summary & Recommendations')
