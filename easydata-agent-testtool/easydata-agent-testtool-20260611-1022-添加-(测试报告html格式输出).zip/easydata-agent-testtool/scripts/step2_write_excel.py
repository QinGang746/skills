# -*- coding: utf-8 -*-
"""Step2: AI 生成的用例 JSON → 格式化 5-Sheet Excel

用法: python step2_write_excel.py --cases "path/to/cases.json" --output "path/to/output.xlsx"
"""

import os, sys, json
from collections import defaultdict


def _excel_styles():
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        os.system("{0} -m pip install openpyxl -q".format(sys.executable))
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    return openpyxl, Font, PatternFill, Alignment, Border, Side


def write_excel(cases, output_path):
    """将 AI 生成的用例列表写入 5-Sheet Excel"""
    op, Font, PatternFill, Alignment, Border, Side = _excel_styles()

    wb = op.Workbook()
    wb.remove(wb.active)

    HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    GROUP_FILL = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")
    SENSITIVE_FILL = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")

    hfont = Font(name="Microsoft YaHei", bold=True, size=11, color="FFFFFF")
    gfont = Font(name="Microsoft YaHei", bold=True, size=10, color="1F4E79")
    sfont = Font(name="Microsoft YaHei", size=10, color="C00000")
    nfont = Font(name="Microsoft YaHei", size=10)
    halign = Alignment(horizontal="center", vertical="center", wrap_text=True)
    nalign = Alignment(vertical="top", wrap_text=True)
    thin = Border(left=Side(style="thin"), right=Side(style="thin"),
                  top=Side(style="thin"), bottom=Side(style="thin"))

    headers = ["ID", "Schema文件", "MCP工具名", "测试层级", "用例标题(自然语言)",
               "自然语言Prompt", "预期Agent行为", "CLI命令", "优先级", "分类", "备注"]
    widths = [12, 18, 32, 10, 38, 45, 45, 50, 8, 12, 28]

    from openpyxl.utils import get_column_letter

    levels = ["正向", "异常", "安全", "回归", "敏感"]
    level_cases = {lv: [] for lv in levels}
    for case in cases:
        lv = case.get("level", "正向")
        if lv in level_cases:
            level_cases[lv].append(case)

    sheet_labels = [
        ("1-正向", "正向"),
        ("2-异常", "异常"),
        ("3-安全", "安全"),
        ("4-回归", "回归"),
        ("5-敏感", "敏感"),
    ]

    for sheet_name, lv in sheet_labels:
        cases_in_lv = level_cases.get(lv, [])
        if not cases_in_lv:
            continue

        ws = wb.create_sheet(title=sheet_name)

        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=1, column=ci, value=h)
            c.font = hfont; c.fill = HEADER_FILL; c.alignment = halign; c.border = thin

        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.freeze_panes = "A2"

        row, counter = 2, [0]
        last_schema = ""

        for case in cases_in_lv:
            sf = case.get("schema", "")
            if sf and sf != last_schema:
                last_schema = sf
                ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=len(headers))
                c = ws.cell(row=row, column=1, value=sf)
                c.font = gfont; c.fill = GROUP_FILL
                c.alignment = Alignment(horizontal="left", vertical="center"); c.border = thin
                for cc in range(2, len(headers)+1):
                    ws.cell(row=row, column=cc).fill = GROUP_FILL
                    ws.cell(row=row, column=cc).border = thin
                row += 1

            counter[0] += 1
            tid = "TC-{0:04d}".format(counter[0])
            is_sens = lv == "敏感"

            vals = [tid, sf, case.get("tool", ""), lv, case.get("title", ""),
                    case.get("prompt", ""), case.get("expected", ""),
                    case.get("cli_command", ""),
                    case.get("priority", ""), case.get("category", ""), case.get("remark", "")]
            for ci, val in enumerate(vals, 1):
                c = ws.cell(row=row, column=ci, value=val)
                c.font = sfont if is_sens else nfont
                c.alignment = nalign; c.border = thin
                if is_sens:
                    c.fill = SENSITIVE_FILL
            row += 1

    wb.save(output_path)
    return len(cases)


if __name__ == "__main__":
    import argparse
    from datetime import datetime
    parser = argparse.ArgumentParser(description="AI 生成的用例 JSON → 5-Sheet Excel")
    parser.add_argument("--cases", required=True, help="AI 生成的用例 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 Excel 路径 (支持 {ts} 占位符)")
    parser.add_argument("--clean", action="store_true", help="生成 Excel 后删除 cases JSON")
    args = parser.parse_args()

    output_path = args.output
    if "{ts}" in output_path:
        output_path = output_path.replace("{ts}", datetime.now().strftime("%Y%m%d-%H%M%S"))

    with open(args.cases, "r", encoding="utf-8") as f:
        cases = json.load(f)

    count = write_excel(cases, output_path)
    levels = defaultdict(int)
    for c in cases:
        levels[c.get("level", "?")] += 1

    print("  Done! {0} cases -> {1}".format(count, output_path))
    for lv in ["正向", "异常", "安全", "回归", "敏感"]:
        if lv in levels:
            print("    {0}: {1}".format(lv, levels[lv]))

    if args.clean:
        os.remove(args.cases)
        print("  Cleaned: {0}".format(args.cases))
