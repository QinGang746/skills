# -*- coding: utf-8 -*-
"""TC平台用例导入 — Playwright 自动化脚本"""
import asyncio
import os
import glob
from playwright.async_api import async_playwright

TC_IMPORT_URL = "https://tc.hz.netease.com/#/project/206/import"
OUTPUT_DIR = r"E:\qgTest_ClaudeCode\easydata-agent-testtool\output"

async def main():
    # 找到所有 easytaskops 用例文件
    files = [
        os.path.join(OUTPUT_DIR, "easytaskops-log-20260609-152643.xlsx"),
        os.path.join(OUTPUT_DIR, "easytaskops-tag-20260609-142907.xlsx"),
        os.path.join(OUTPUT_DIR, "easytaskops-task-20260609-171808.xlsx"),
    ]
    files = [f for f in files if os.path.exists(f)]
    print(f"待导入 {len(files)} 个文件:")
    for f in files:
        print(f"  - {os.path.basename(f)}")

    async with async_playwright() as p:
        # 使用持久化上下文，复用已有登录态
        user_data_dir = os.path.join(os.environ.get("TEMP", "/tmp"), "playwright-tc-import")
        context = await p.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            headless=False,  # 可见浏览器，便于人工介入
            args=["--disable-blink-features=AutomationControlled"],
            ignore_https_errors=True,
        )
        page = context.pages[0] if context.pages else await context.new_page()

        print(f"\n正在打开: {TC_IMPORT_URL}")
        await page.goto(TC_IMPORT_URL, wait_until="networkidle", timeout=30000)
        await page.wait_for_timeout(3000)

        # 截图看当前状态
        screenshot_path = os.path.join(OUTPUT_DIR, "tc_import_page.png")
        await page.screenshot(path=screenshot_path, full_page=True)
        print(f"页面截图: {screenshot_path}")

        # 检查是否需要登录
        page_title = await page.title()
        print(f"页面标题: {page_title}")

        if "login" in page_title.lower() or "登录" in page_title:
            print("\n⚠️ 需要登录！请在浏览器中完成SSO登录，然后按Enter继续...")
            input()
            await page.goto(TC_IMPORT_URL, wait_until="networkidle", timeout=30000)
            await page.wait_for_timeout(2000)

        # 查找上传按钮/区域
        # TC平台常见上传方式: input[type=file], 拖拽区域, 或"导入"按钮
        file_inputs = await page.locator('input[type="file"]').count()
        print(f"\n找到 {file_inputs} 个文件上传控件")

        # 打印页面主要内容（帮助定位导入按钮）
        buttons = await page.locator('button, a[role="button"], .el-button, .ant-btn').all()
        print(f"找到 {len(buttons)} 个按钮:")
        for btn in buttons[:10]:
            text = await btn.inner_text()
            if text.strip():
                print(f"  [{text.strip()[:50]}]")

        # 等待用户确认后关闭
        print("\n浏览器保持打开，你可以手动操作。完成后按Enter关闭...")
        input()
        await context.close()

if __name__ == "__main__":
    asyncio.run(main())
