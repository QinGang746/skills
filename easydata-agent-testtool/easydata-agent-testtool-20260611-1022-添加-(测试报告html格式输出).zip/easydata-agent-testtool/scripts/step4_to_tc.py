# -*- coding: utf-8 -*-
"""Step4: Output Excel → TC 模板 Excel

将 Step2 产出的自然语言用例 Excel 转换为 TCCase 模板格式。

列映射:
  源                                  →  模板列
  ─────────────────────────────────────────────
  Excel文件名(去后缀)                  → 用例Suite一
  MCP工具名                           → 用例Suite二
  自然语言Prompt                      → 用例标题
  优先级                              → 用例分级
  预期Agent行为                       → 预期结果
  (空)                                → 用例Suite三
  (空)                                → 用例Suite四
  (空)                                → 用例Suite五
  (空)                                → 前置条件
  (空)                                → 备注

用法:
  python step4_to_tc.py --excel "output/easytaskops-task-xxxx.xlsx"
  python step4_to_tc.py --excel "path/to/source.xlsx" --template "TCCase/template.xlsx" --output "TCCase/TCCase-xxx.xlsx"
"""

import os, sys, json
from datetime import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side


def _styles():
    """延迟导入 openpyxl 并返回样式对象"""
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        os.system("{0} -m pip install openpyxl -q".format(sys.executable))
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    return openpyxl, Font, PatternFill, Alignment, Border, Side


def step4_convert(excel_path, template_path, output_path):
    """主转换逻辑"""
    op, Font, PatternFill, Alignment, Border, Side = _styles()

    # Excel 文件名（去后缀），用作 Suite一
    excel_name = os.path.splitext(os.path.basename(excel_path))[0]

    # ── 1. 读取源 Excel ──
    src_wb = op.load_workbook(excel_path)
    all_rows = []
    for sn in src_wb.sheetnames:
        ws = src_wb[sn]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not row[4] and not row[5]:
                continue
            all_rows.append({
                'schema':   str(row[1] or '').strip(),   # B: Schema文件
                'tool':     str(row[2] or '').strip(),   # C: MCP工具名
                'level':    str(row[3] or '').strip(),   # D: 测试层级
                'title':    str(row[4] or '').strip(),   # E: 用例标题
                'prompt':    str(row[5] or '').strip(),   # F: 自然语言Prompt
                'expected': str(row[6] or '').strip(),   # G: 预期Agent行为
                'priority': str(row[7] or '').strip(),   # H: 优先级
                'category': str(row[8] or '').strip(),   # I: 分类
                'remark':   str(row[9] or '').strip() if len(row) > 9 else '',
            })

    if not all_rows:
        print("ERROR: no valid rows in source Excel")
        return 0

    # ── 2. 读取模板（取列宽和表头样式） ──
    tpl_wb = op.load_workbook(template_path)
    tpl_ws = tpl_wb['测试用例']

    # ── 3. 创建输出 ──
    out_wb = op.Workbook()
    out_ws = out_wb.active
    out_ws.title = '测试用例'

    # 复制模板列宽
    for i in range(1, 13):
        src_col = tpl_ws.column_dimensions.get(op.utils.get_column_letter(i))
        if src_col and src_col.width:
            out_ws.column_dimensions[op.utils.get_column_letter(i)].width = src_col.width

    # 表头
    hdr = [tpl_ws.cell(row=1, column=c).value for c in range(1, 13)]
    header_font = Font(name='Microsoft YaHei', bold=True, size=11)
    header_fill = PatternFill(start_color='D9E2F3', end_color='D9E2F3', fill_type='solid')
    header_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
    thin = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin'),
    )

    for ci, h in enumerate(hdr, 1):
        c = out_ws.cell(row=1, column=ci, value=h)
        c.font = header_font
        c.fill = header_fill
        c.alignment = header_align
        c.border = thin

    out_ws.freeze_panes = 'A2'

    # ── 4. 按新列映射写入数据 ──
    data_font = Font(name='Microsoft YaHei', size=10)
    data_align = Alignment(vertical='top', wrap_text=True)

    for ri, row_data in enumerate(all_rows, 2):
        vals = [
            excel_name,              # 用例Suite一 ← Excel文件名(去后缀)
            row_data['tool'],        # 用例Suite二 ← MCP工具名
            '',                      # 用例Suite三
            '',                      # 用例Suite四
            '',                      # 用例Suite五
            row_data['prompt'],       # 用例标题   ← 自然语言Prompt
            row_data['priority'],    # 用例分级   ← 优先级
            '',                      # 用例Tag
            '',                      # 前置条件
            '',                      # 执行步骤
            row_data['expected'],    # 预期结果   ← 预期Agent行为
            '',                      # 备注
        ]

        for ci, val in enumerate(vals, 1):
            c = out_ws.cell(row=ri, column=ci, value=val)
            c.font = data_font
            c.alignment = data_align
            c.border = thin

    out_wb.save(output_path)
    return len(all_rows)


# ── CLI 入口 ──
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Step4: Output Excel → TC 模板 Excel")
    parser.add_argument("--excel", required=True, help="源 Excel 路径 (Step2 产物)")
    parser.add_argument("--template", default=None, help="TC 模板路径 (默认 TCCase/template.xlsx)")
    parser.add_argument("--output", default=None, help="输出路径 (默认 TCCase/TCCase-{excel_base}.xlsx)")

    args = parser.parse_args()

    excel_path = args.excel
    if not os.path.isfile(excel_path):
        print("ERROR: excel not found: {0}".format(excel_path))
        sys.exit(1)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_dir = os.path.dirname(script_dir)

    tpl_path = args.template or os.path.join(skill_dir, "TCCase", "template.xlsx")
    if not os.path.isfile(tpl_path):
        print("ERROR: template not found: {0}".format(tpl_path))
        sys.exit(1)

    tc_dir = os.path.join(skill_dir, "TCCase")
    os.makedirs(tc_dir, exist_ok=True)

    if args.output:
        output_path = args.output
    else:
        excel_base = os.path.splitext(os.path.basename(excel_path))[0]
        output_path = os.path.join(tc_dir, "TCCase-{0}.xlsx".format(excel_base))

    print("=" * 50)
    print("  Step4: Output Excel -> TC 模板 Excel")
    print("=" * 50)
    print("  Source:   {0}".format(excel_path))
    print("  Template: {0}".format(tpl_path))
    print("  Output:   {0}".format(output_path))

    count = step4_convert(excel_path, tpl_path, output_path)

    print("\n  Done! {0} cases converted".format(count))
    print("  Output: {0}".format(output_path))
