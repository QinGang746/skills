# -*- coding: utf-8 -*-
"""
TC 平台用例导入脚本
用法: python tc_import_taskops.py
功能: 打开TC导入页 → 等待SSO登录 → 自动上传3个taskops用例Excel
"""
import asyncio
import os
import sys
from playwright.async_api import async_playwright

TC_IMPORT_URL = "https://tc.hz.netease.com/#/project/206/import"
OUTPUT_DIR = r"E:\qgTest_ClaudeCode\easydata-agent-testtool\output"

FILES = [
    os.path.join(OUTPUT_DIR, "easytaskops-tag-20260609-142907.xlsx"),
    os.path.join(OUTPUT_DIR, "easytaskops-log-20260609-152643.xlsx"),
    os.path.join(OUTPUT_DIR, "easytaskops-task-20260609-171808.xlsx"),
]


async def wait_for_login(page, timeout=120):
    """等待用户完成SSO登录（URL从login.netease.com跳回tc.hz.netease.com）"""
    print("⏳ 等待SSO登录... 请在浏览器窗口中完成登录")
    for i in range(timeout * 2):
        url = page.url
        if "tc.hz.netease.com" in url and "login" not in url:
            print("✅ 登录成功！")
            await page.wait_for_timeout(2000)
            return True
        await asyncio.sleep(0.5)
    print("❌ 登录超时")
    return False


async def upload_file(page, file_path):
    """上传单个文件到TC平台"""
    filename = os.path.basename(file_path)
    print(f"\n📤 正在导入: {filename}")

    # 等待页面加载
    await page.wait_for_timeout(1000)

    # TC平台常见上传方式:
    # 1. 拖拽上传区域 + input[type=file]
    # 2. 点击"导入"按钮弹出上传对话框
    # 3. 直接的文件选择器

    # 先尝试找上传input
    try:
        file_input = page.locator('input[type="file"]').first
        if await file_input.count() > 0:
            await file_input.set_input_files(file_path)
            print(f"  ✓ 文件已选择")
            await page.wait_for_timeout(2000)

            # 找"确认导入"/"上传"按钮
            confirm_btns = page.locator('button:has-text("导入"), button:has-text("上传"), button:has-text("确认"), button:has-text("确定")')
            if await confirm_btns.count() > 0:
                await confirm_btns.first.click()
                print(f"  ✓ 已点击确认导入")
                await page.wait_for_timeout(3000)
            return True
    except Exception as e:
        print(f"  ⚠️ 直接上传失败: {e}")

    # 尝试点击"导入"按钮
    try:
        import_btn = page.locator('button:has-text("导入"), a:has-text("导入"), span:has-text("导入")').first
        if await import_btn.count() > 0:
            await import_btn.click()
            await page.wait_for_timeout(1500)

            file_input = page.locator('input[type="file"]').first
            if await file_input.count() > 0:
                await file_input.set_input_files(file_path)
                print(f"  ✓ 通过导入按钮上传")
                await page.wait_for_timeout(2000)

                confirm_btns = page.locator('button:has-text("导入"), button:has-text("上传"), button:has-text("确认")')
                if await confirm_btns.count() > 0:
                    await confirm_btns.first.click()
                return True
    except Exception as e:
        print(f"  ⚠️ 按钮方式失败: {e}")

    print(f"  ❌ 未找到上传入口，请手动导入")
    return False


async def main():
    # 检查文件
    existing = [f for f in FILES if os.path.exists(f)]
    if not existing:
        print("[FAIL] 未找到 taskops 用例文件!")
        sys.exit(1)

    print(f"[INFO] 待导入 {len(existing)} 个文件:")
    for f in existing:
        print(f"   - {os.path.basename(f)}")

    # 持久化浏览器上下文，保存登录态
    user_data_dir = os.path.join(os.environ.get("TEMP", "/tmp"), "playwright-tc")

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            headless=False,
            args=["--disable-blink-features=AutomationControlled"],
            ignore_https_errors=True,
        )

        page = context.pages[0] if context.pages else await context.new_page()

        print(f"\n🌐 打开: {TC_IMPORT_URL}")
        await page.goto(TC_IMPORT_URL, wait_until="networkidle", timeout=30000)

        # 检查是否跳转到登录页
        if "login" in page.url:
            if not await wait_for_login(page):
                await context.close()
                sys.exit(1)
            # 登录后重新导航
            await page.goto(TC_IMPORT_URL, wait_until="networkidle", timeout=30000)

        print(f"\n📍 当前页面: {page.url}")

        # 逐个导入文件
        success = 0
        for f in existing:
            if await upload_file(page, f):
                success += 1
            # 每个文件之间等待一下
            await page.wait_for_timeout(1000)

        print(f"\n{'='*40}")
        print(f"导入完成: {success}/{len(existing)} 个文件")
        print(f"请检查浏览器确认结果，然后关闭浏览器窗口")
        print(f"{'='*40}")

        # 保持浏览器打开让用户确认
        await page.wait_for_timeout(60000)
        await context.close()


if __name__ == "__main__":
    asyncio.run(main())
