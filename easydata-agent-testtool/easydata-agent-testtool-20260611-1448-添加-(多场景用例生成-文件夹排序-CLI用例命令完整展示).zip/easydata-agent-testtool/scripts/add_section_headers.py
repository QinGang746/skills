# -*- coding: utf-8 -*-
"""
为报告的"自然语言测试"和"CLI命令测试" sheet 添加分组标题行。
按源 Excel 的 sheet 名称（1-正向, 2-异常, 3-安全, 4-回归, 5-敏感）分组，
在每组之间插入醒目的标题行。
"""

import argparse
import os
import sys

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("Error: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)

# Section header style (matching step6_gen_report.py's HDR_SECTION)
SECTION_FILL = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
SECTION_FONT = Font(bold=True, size=12, color="FFFFFF", name="微软雅黑")
SECTION_ALIGN = Alignment(horizontal="left", vertical="center", wrap_text=True)
BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin")
)


def build_source_sheet_map(source_excel_path):
    """从源 Excel 读取每个用例标题对应的源 sheet 名称"""
    wb = openpyxl.load_workbook(source_excel_path)
    mapping = {}  # title -> source_sheet_name
    for s in wb.sheetnames:
        ws = wb[s]
        for r in range(2, ws.max_row + 1):
            title = ws.cell(r, 5).value  # col 5 = 用例标题(自然语言)
            tid = ws.cell(r, 1).value
            if title and tid and str(tid).startswith('TC-'):
                mapping[title] = s
    wb.close()
    return mapping


def get_sheet_order(source_excel_path):
    """获取源 Excel 中 sheet 的顺序"""
    wb = openpyxl.load_workbook(source_excel_path)
    order = list(wb.sheetnames)
    wb.close()
    return order


def add_section_headers(report_path, source_map, sheet_order):
    """在报告的"自然语言测试"和"CLI命令测试"中添加分组标题行"""
    wb = openpyxl.load_workbook(report_path)

    for sheet_name in ["自然语言测试", "CLI命令测试"]:
        if sheet_name not in wb.sheetnames:
            print(f"  [WARN] Sheet '{sheet_name}' not found, skipping")
            continue

        ws = wb[sheet_name]
        max_col = ws.max_column

        # Step 1: Read all existing data (row by row)
        rows_data = []
        for r in range(1, ws.max_row + 1):
            row_vals = []
            for c in range(1, max_col + 1):
                cell = ws.cell(r, c)
                row_vals.append({
                    'value': cell.value,
                    'font': cell.font.copy() if cell.font else None,
                    'fill': cell.fill.copy() if cell.fill else None,
                    'alignment': cell.alignment.copy() if cell.alignment else None,
                    'border': cell.border.copy() if cell.border else None,
                })
            rows_data.append({
                'row_num': r,
                'cells': row_vals,
                'height': ws.row_dimensions[r].height,
            })

        # Step 2: Build new row list with section headers inserted
        # Row 1 = header (keep)
        # Rows 2+ = data, grouped by source sheet
        new_rows = [rows_data[0]]  # header row

        # Determine source sheet for each data row
        data_rows = rows_data[1:]  # skip header
        current_sheet = None

        for data_row in data_rows:
            # Find the title from this row (col 2 in both sheets)
            title = data_row['cells'][1]['value']  # col index 1 = col B = 用例标题
            src_sheet = source_map.get(title)

            # When source sheet changes, insert a section header
            if src_sheet and src_sheet != current_sheet:
                current_sheet = src_sheet
                # Create section header row
                section_row = {
                    'cells': [],
                    'height': 30,
                    '_is_section': True,
                    '_section_title': src_sheet,
                }
                for c in range(max_col):
                    section_row['cells'].append({
                        'value': None,
                        'font': Font(),
                        'fill': PatternFill(),
                        'alignment': Alignment(),
                        'border': Border(),
                    })
                # Set the first cell with the section title
                section_row['cells'][0]['value'] = src_sheet
                section_row['cells'][0]['font'] = SECTION_FONT
                section_row['cells'][0]['fill'] = SECTION_FILL
                section_row['cells'][0]['alignment'] = SECTION_ALIGN
                # Fill entire row with section color
                for c in range(max_col):
                    section_row['cells'][c]['fill'] = SECTION_FILL
                    section_row['cells'][c]['border'] = BORDER

                new_rows.append(section_row)
                print(f"    + Section header: [{src_sheet}]")

            new_rows.append(data_row)

        # Step 3: Clear the sheet and rewrite
        # Delete all existing rows
        ws.delete_rows(1, ws.max_row)

        # Write new rows
        for i, row_data in enumerate(new_rows):
            r = i + 1
            for c, cell_data in enumerate(row_data['cells']):
                cell = ws.cell(r, c + 1)
                cell.value = cell_data['value']
                if cell_data.get('font'):
                    cell.font = cell_data['font']
                if cell_data.get('fill'):
                    cell.fill = cell_data['fill']
                if cell_data.get('alignment'):
                    cell.alignment = cell_data['alignment']
                if cell_data.get('border'):
                    cell.border = cell_data['border']

            # Set row height
            if row_data.get('height'):
                ws.row_dimensions[r].height = row_data['height']

        # Restore column widths (need to re-apply after delete_rows)
        # Column widths are somewhat preserved, but let's ensure key widths
        col_widths_preserved = {}
        for col_idx in range(1, max_col + 1):
            col_letter = get_column_letter(col_idx)
            if ws.column_dimensions[col_letter].width:
                col_widths_preserved[col_idx] = ws.column_dimensions[col_letter].width

        # Freeze panes below header
        ws.freeze_panes = "A2"

        print(f"  [OK] '{sheet_name}': {len(data_rows)} data rows -> {len(new_rows) - 1} rows with {sum(1 for r in new_rows if r.get('_is_section'))} section headers")

    # Save
    base, ext = os.path.splitext(report_path)
    out_path = report_path
    wb.save(out_path)
    print(f"Saved: {out_path}")
    return out_path


def main():
    parser = argparse.ArgumentParser(description="为测试报告添加分组标题行")
    parser.add_argument("--report", required=True, help="报告 Excel 路径")
    parser.add_argument("--source", required=True, help="源用例 Excel 路径（用于获取 sheet 分组）")
    args = parser.parse_args()

    print(f"源 Excel: {args.source}")
    print(f"报告 Excel: {args.report}")

    # Build mapping
    source_map = build_source_sheet_map(args.source)
    sheet_order = get_sheet_order(args.source)
    print(f"源 Sheet 顺序: {sheet_order}")
    print(f"用例总数: {len(source_map)}")

    # Add headers
    print("\n插入分组标题行...")
    add_section_headers(args.report, source_map, sheet_order)

    print("\nDone!")


if __name__ == "__main__":
    main()
