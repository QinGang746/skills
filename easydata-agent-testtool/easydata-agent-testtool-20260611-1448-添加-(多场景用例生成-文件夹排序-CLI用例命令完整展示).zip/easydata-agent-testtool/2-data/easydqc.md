# easydqc 参数模板

> 从 MCP Schema 自动提取。请在各参数下方填写真实数据值。
> 不填则 Step2 生成用例时 AI 自动补值。

---

## 公共参数 (全部工具共用)

以下参数被几乎所有工具共用，在此统一填写：

- **clusterId**: 集群Id — `easyops-cluster`
- **product**: 项目名称 — `autoapi_test`
- **user**: 调用该接口用户邮箱 — `grp.mammut_test@corp.netease.com`

---

## 重复参数 (多工具共用)

以下参数被多个工具共用，在此统一填写：

- **id** (resource_id): 任务实例ID — `4613227`
- **jobId** (resource_id): 执行实例ID — `283739`
- **queryType** (number): 查询类型 — `待填写`
- **taskId** (resource_id): 任务ID — `11561`

---

## create_data_quality_task

- **描述**: 创建质量监控任务，返回质量监控任务地址

### 工具专属必填参数

- **dbName** (resource_id): 库名 — `autoapi_test`
- **tableName** (resource_id): 表名 — `qgtest_user_1_1`
- **datasourceType** (string): 数据源类型 — `hive`

---

## create_compare_task

- **描述**: 创建数据比对任务，用于比对两个数据源的数据一致性，返回任务ID

### 工具专属必填参数

- **name** (string): 任务名称，仅支持中文、英文、数字、'_'、'-'和'.' — `qgTest_Agent测试_比对user-1和user1-2对比`
- **compareType** (number): 比对类型：1-全量比对，2-抽样比对 — `Hive`
- **relateMode** (number): 关联模式：1-主键关联，2-MD5关联 — `待填写`
- **saveDbName** (string): 结果保存库名 — `autoapi_test`
- **originTableInfo** (string): 源表信息 — `qgtest_user_1_1`
- **targetTableInfo** (string): 目标表信息 — `qgtest_user_1_2`
- **fieldsCompare** (array): 字段比较配置 — `待填写`

---

## run_compare_task

- **描述**: 运行数据比对任务，异步执行，返回执行实例ID

### 工具专属必填参数

- **resourceType** (number): 资源类型：0-YARN，1-KUBERNETES, 2-INCEPTOR, 3-JDBC — `0`

---

## batch_delete_compare_task

- **描述**: 批量删除数据比对任务

### 工具专属必填参数

- **taskIds** (resource_id): 待删除的任务ID列表 — `172`

---

## get_compare_task_query_result

- **描述**: 获取数据比对任务SQL查询的执行状态和结果数据

### 工具专属必填参数

- **execId** (resource_id): SQL执行ID — `4148`

---

## add_quality_rule

- **描述**: 向已有质量任务添加单条校验规则。支持三种规则类型：TEMPLATE（模板规则）、CUSTOM_FIELD（自定义字段规则）、CUSTOM_SQL（自定义SQL规则）。返回规则详情含ruleId。

### 工具专属必填参数

- **ruleType** (string): 规则类型：TEMPLATE / CUSTOM_FIELD / CUSTOM_SQL — `待填写`
- **ruleConfig** (string): 规则配置（结构随ruleType而异）。各类型详细字段定义见 batch_add_quality_rules 中对应数组元素的 properties：
- ruleType=TEMPLATE → 字段同 templateRules 数组元素
- ruleType=CUSTOM_FIELD → 字段同 customFieldRules 数组元素
- ruleType=CUSTOM_SQL → 字段同 customSqlRules 数组元素 — `待填写`

---

## list_rule_templates

- **描述**: 查询项目可用的规则模板列表。在添加规则前使用此接口确认可用模板及其ruleId，支持按数据源类型、规则级别、校验类型过滤。

### 工具专属必填参数

- **pageNum** (number): 页码（最小1） — `1`
- **pageSize** (number): 每页条数（1-100） — `25`
---

## create_quality_issue

- **描述**: 基于质量执行结果创建问题工单。将异常规则关联到指定责任人，用于追踪质量问题的修复进度。

### 工具专属必填参数

- **ruleIds** (resource_id): 关联的异常规则ID列表 — `10`
- **owner** (string): 问题责任人邮箱 — `grp.mammut_test@corp.netease.com`
- **severity** (string): 严重等级（HIGH/MEDIUM/LOW） — `HIGH`

---

## get_quality_issue_detail

- **描述**: 查询质量问题工单详情，包括问题状态、关联规则快照、操作历史记录等。

### 工具专属必填参数

- **issueId** (resource_id): 问题工单ID — `待填写`

