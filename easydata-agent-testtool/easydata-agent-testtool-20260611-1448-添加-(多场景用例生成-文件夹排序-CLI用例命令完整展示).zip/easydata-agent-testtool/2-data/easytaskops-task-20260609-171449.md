# easytaskops-task-20260609-171449 参数模板

> 从 MCP Schema 自动提取。请在各参数下方填写真实数据值。
> 不填则 Step2 生成用例时 AI 自动补值。

---

## 公共参数 (全部工具共用)

以下参数被几乎所有工具共用，在此统一填写：

- **clusterId**: 集群Id — `easyops-clusterx`
- **product**: 项目名称 — `autoapi_test`
- **project**: 任务project标识(字符串ID) — `de4273398efb4791989ac15ccd26fc93`
- **user**: 调用该接口用户邮箱 — `grp.mammut_test@corp.netease.com`



---

## 重复参数 (多工具共用)

以下参数被多个工具共用，在此统一填写：

- **flow** (resource_id): 任务flow标识(字符串ID) — `qgTest_Agent测试_上游A`

---

## get_task_lineage
- **描述**: 获取线上任务的血缘关系，返回任务的上下游依赖DAG图，帮助分析任务间的依赖链路。支持按层级展开、按方向（上游/下游/全部）查询
### 工具专属必填参数

- **lineageType** (string): 血缘类型：ALL-上下游血缘（默认），UP-仅上游血缘，DOWN-仅下游血缘 — `ALL`

