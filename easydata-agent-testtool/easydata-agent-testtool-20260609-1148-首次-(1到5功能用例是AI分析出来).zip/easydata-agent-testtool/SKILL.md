---
name: easydata-agent-testtool
description: |
  EasyData Agent 功能测试工具 — MCP Schema 到可执行 YAML 的 5 步测试生成管线。
  触发场景：
  (1) 用户说"生成 agent 测试用例"、"easydata 测试"时
  (2) 需要对 EasyData 子产品（任务运维/数据质量/数据地图等）生成 Agent 评估用例
  关键词：easydata、agent测试、测试用例、YAML、Schema、Excel、用例生成
status: active
allowed-tools:
  - Bash
  - Read
  - Write
  - Edit
  - Glob
---

# /easydata-agent-testtool — Agent 测试用例生成器

> **核心心智模型**：Easydata 平台有 N 个子产品 × M 个 MCP 工具，人工手写 Agent 评估用例（YAML）工作量大、覆盖度难保证。
> 本 skill 提供一条从 Schema → Excel → YAML 的自动化管线，每个步骤独立可执行。
>
> ```
> Schema JSON ──[Step1]──> 参数模板 MD ──[Step2]──> 自然语言 Excel
>                                                  ├──[Step3]──> YAML
>                                                  ├──[Step4]──> TC 模板 Excel
>                                                  └──[Step5]──> TC→YAML (按模块拆分)
> ```

## 角色声明

> **角色**：测试工具操作员 — 严格按 5 步管线执行，不做自由发挥
> **默认立场**：宁可多确认也不越界 — 不确定用哪个步骤、处理哪个工具时，明确展示选项让用户选择，不自行决定
> **角色外**：不负责判断生成的测试用例是否正确（那是 QA 的工作），不负责修改用户填写的真实数据（只反馈"待填写"状态），不负责 MCP Schema 本身的正确性

## 禁令（MUST NOT）

**MUST NOT** 跳过步骤确认直接执行，因为每个步骤的输入依赖上一步产物，跳步会导致数据不一致。例外：用户在消息中明确指定了完整参数（如 `step2 --tools list_tag`）时可跳过确认。

**MUST NOT** Step2 执行前不确认工具范围，因为 Schema 目录下可能包含多个 JSON 文件共数十个工具，用户 Step1 可能只关注其中一部分。例外：无。

**MUST NOT** 对已有产物静默覆盖，因为用户可能在上一次产物上做了修改。例外：同名文件追加 `-1`、`-2` 后缀（Step3）或 `-v{N}` 后缀（Step4）。

**MUST NOT** 凭印象修改脚本后再执行，必须先 Read 脚本代码确认当前状态再改。例外：无。

**MUST NOT** 把生成结果（用例数、分类分布）当作"通过"与否的结论，因为本 skill 只负责生成，不负责评判质量。例外：无。

## 前置条件

- Python 3.9+, `openpyxl`

## 目录结构

```
easydata-agent-testtool/
├── SKILL.md                    # 本文件
├── README.md                   # 用户使用指南
├── data/                       # Step1 生成, 用户填写
│   └── {serviceName}.md
├── scripts/
│   ├── generate.py             # Step1/Step3/Step4 引擎
│   ├── step2_write_excel.py    # Step2: AI 用例 JSON → 5-Sheet Excel
│   └── convert_tc_to_yaml.py   # Step5: TC 模板 Excel → YAML
├── output/                     # Step2/Step3/Step5 产物
├── TCCase/                     # Step4 产物 + 模板
│   ├── template.xlsx
│   └── TCCase-{name}.xlsx
└── report/                     # 测试报告 (可选)
```

---

## 5 步管线总览 (静态参考)

用户问"展示功能"、"工具展示"、"脚本功能"、"功能介绍"、"帮助"、"怎么用"、"管线"、"pipeline"时，直接输出以下内容，无需分析:

```
5 步管线 — 脚本功能总览

┌────────┬──────────────────────────┬────────┬──────────────────────────────────────────────┐
│  步骤   │          命令             │  方式  │                   功能                       │
├────────┼──────────────────────────┼────────┼──────────────────────────────────────────────┤
│ Step1  │ generate.py step1        │ 脚本   │ MCP JSON Schema → data/{name}.md              │
│        │ --schema-dir / --name    │        │ 三级分层提取必填参数模板                       │
│        │ [--json 指定文件]         │        │                                              │
├────────┼──────────────────────────┼────────┼──────────────────────────────────────────────┤
│ Step2  │ AI 分析 +                │ ★AI   │ data/{name}.md + Schema → 自然语言 Excel      │
│        │ step2_write_excel.py     │ 驱动   │ 按业务覆盖度框架逐工具分析能力生成用例          │
│        │ --cases JSON --output    │        │ AI 写 cases.json → 脚本写 5-Sheet Excel       │
├────────┼──────────────────────────┼────────┼──────────────────────────────────────────────┤
│ Step3  │ generate.py path2        │ 脚本   │ Excel(5 sheet, 10列) → .yml                  │
│        │ --excel                  │        │ 自适应解析 → easydata-mode YAML               │
├────────┼──────────────────────────┼────────┼──────────────────────────────────────────────┤
│ Step4  │ generate.py path4        │ 脚本   │ Excel(5 sheet) → TCCase/{name}.xlsx           │
│        │ --excel                  │        │ 列映射 → 13列 TC 模板, 按Suite二升序          │
├────────┼──────────────────────────┼────────┼──────────────────────────────────────────────┤
│ Step5  │ convert_tc_to_yaml.py    │ 脚本   │ TC模板(13/8列) → 按 Suite二 拆分 .yml        │
│        │ --excel [--outdir]       │        │ AI 跨 Suite 列识别工具名 + 分类推断            │
└────────┴──────────────────────────┴────────┴──────────────────────────────────────────────┘

┌───────────────────────┬──────────┬───────────┬─────────────────────────────────────┐
│         脚本          │ 文件大小 │ 覆盖步骤  │                说明                 │
├───────────────────────┼──────────┼───────────┼─────────────────────────────────────┤
│ generate.py           │ 59KB     │ Step1/3/4 │ 保留 path1 命令但 Step2 已不用      │
├───────────────────────┼──────────┼───────────┼─────────────────────────────────────┤
│ step2_write_excel.py  │ 5KB      │ Step2     │ ★ 新增：AI 用例 JSON → 格式化 Excel │
├───────────────────────┼──────────┼───────────┼─────────────────────────────────────┤
│ convert_tc_to_yaml.py │ 22KB     │ Step5     │ TC 模板 → 按模块拆分 YAML           │
└───────────────────────┴──────────┴───────────┴─────────────────────────────────────┘
```

---

## 工作流程

> **使用场景判断**：
> - 用户提供了 Schema JSON 目录，从头开始 → 从 Step1 开始
> - 用户已有填好真实数据的 `data/{name}.md` → 从 Step2 开始
> - 用户已有 Excel 用例文件 → 从 Step3 或 Step5 开始
> - 用户已有 Step2 产物想转 TC 格式 → Step4

**核心规则**: 每个步骤独立可执行，执行前后均展示输入输出表格。

---

### Step 1: Schema → data/{serviceName}.md

读 MCP JSON Schema，三级分层提取必填参数，生成模板 MD。

**脚本**:

```bash
# 处理目录下全部 JSON
python easydata-agent-testtool/scripts/generate.py step1 \
  --schema-dir "所有文件/{product}" --name {serviceName}

# 仅处理指定 JSON 文件
python easydata-agent-testtool/scripts/generate.py step1 \
  --schema-dir "所有文件/{product}" --name {serviceName} \
  --json "文件名.json"
```

**三级分层**:

| 层级 | 条件 | 位置 |
|------|------|------|
| 公共参数 | ≥80% 工具 | 顶部 |
| 重复参数 | ≥2 且 <80% | 中部 |
| 独占参数 | 仅 1 工具 | 工具专属区域 |

- 无独占参数的工具不出现
- 不输出 Schema文件/HTTP方法等冗余信息

**验证**: 执行后检查 `data/{name}.md` 是否存在，工具数和必填参数数是否 > 0。

> Step1 执行完直接结束，不自动进入 Step2。

---

### Step 2: AI 分析生成自然语言用例 Excel (5 Sheet)

**AI 驱动** — 不依赖脚本硬编码，由 AI 按业务场景覆盖度框架逐工具分析生成。

**流程**:

1. **Read** `data/{serviceName}.md` + Schema JSON → 理解工具的业务能力
2. **分析** 每个工具: 识别能力（分页/搜索/排序/写入/返回字段数）→ 按覆盖度框架匹配场景
3. **生成** 用例 JSON（每条含 schema/tool/level/title/prompt/expected/priority/category/remark）
4. **写入** Excel:

```bash
python easydata-agent-testtool/scripts/step2_write_excel.py \
  --cases "output/{name}-cases.json" \
  --output "output/{name}-{ts}.xlsx"
```

**执行前必须确认**: 展示目录下工具数量 v.s. Step1 同名文件覆盖的工具，询问用户处理全部还是仅同名工具。

**覆盖度** (业务场景驱动，非参数遍历):

每个工具围绕其业务闭环设计场景。通用维度 + 工具特有维度组合。

**通用维度** (每个工具必覆盖):

| 维度 | 场景 | Prompt 示例 | 优先级 | 说明 |
|------|------|-----------|--------|------|
| 正向-默认 | 只传必填参数 | "帮我查下项目里有哪些标签" | P0 | 最高频操作，验证默认行为 |
| 正向-空结果 | 不存在的资源查询 | "查下叫 ghost_tag_xyz 的标签" | P2 | 验证空结果如实返回 |
| 异常-不存在 | 不存在的项目/集群 | "查下 ghost_project 的标签" | P2 | 边界处理 |
| 安全-注入 | SQL/脚本注入 | 搜索条件含 `' OR '1'='1` | P2 | 安全基线 |
| 安全-越权 | 跨项目访问 | "查下隔壁 intern 项目的标签" | P1 | 权限隔离验证 |

**工具特有维度** (按工具能力扩展):

| 工具能力 | 维度 | Prompt 示例 | 优先级 |
|---------|------|-----------|--------|
| 有分页参数 | 正向-翻页 | "翻到第 3 页，每页 10 个" | P1 |
| 有分页参数 | 回归-分页一致性 | 查第 1 页和第 2 页，验无重复且 total 正确 | P2 |
| 有分页参数 | 异常-非法分页 | pageNum=0 或 pageSize=0 | P2 |
| 有搜索/模糊匹配 | 正向-搜索 | "有没有叫'核心任务'的标签" | P1 |
| 有写入操作 | 敏感-确认 | 删除前须确认影响范围 | P0 |
| 写入+查询 | 回归-新建可见 | 创建后列表可查到 | P2 |
| 有排序参数 | 正向-排序 | "按创建时间倒序排列" | P2 |
| 返回字段 > 5 | 回归-字段完整性 | "把所有字段都列出来" | P2 |

**5 Sheet**: `1-正向` / `2-异常` / `3-安全` / `4-回归` / `5-敏感`

> **Prompt 原则**: 用例是 AI 分析生成的，使用自然伪造值（如 `ghost_project_001`、`noexist_flow_000`），而非"不存在的项目"这类测试指令式文本。每条 prompt 读起来像一个真实用户在操作。
>
> 不生成: 反问补齐、参数缺失反问、空字符串等非自然语言 Prompt。

**验证**: 执行后检查 Breakdown 是否包含 5 个层级的用例，每个工具的条数是否在预期范围内。

---

### Step 3: Excel → YAML

将 Step2 的 5-Sheet Excel 转为 `easydata-mode` YAML。

**脚本**:

```bash
python easydata-agent-testtool/scripts/generate.py path2 \
  --excel "output/{name}.xlsx"
```

YAML 与 Excel 同名，重复追加 `-1`、`-2`。

**验证**: 检查输出 YAML 条目数是否等于 Excel 数据行数（读取所有 Sheet），抽查首个条目的 prompt/tool/answer 是否完整。

---

### Step 4: Excel → TC 模板 Excel

将 Step2 的 Excel 按 `TCCase/template.xlsx` 格式转换，输出到 `TCCase/` 目录。

**列映射**:

| 模板列 | 来源 |
|--------|------|
| Suite1 | Excel 文件名 (如 `easytaskops-tag-20260608-175453`) |
| Suite2 | MCP工具名 |
| Suite3 | 测试层级 |
| Suite4 | 分类 |
| Suite5 | (空) |
| 测试用例 | 用例标题 |
| 用例分级 | 优先级 |
| 用例Tag | 分类 |
| 前置条件 | (空) |
| 执行步骤 | Prompt |
| 预期结果 | 预期Agent行为 |
| 备注 | 备注 |

**排序**: 按 Suite二 (MCP工具名) 升序。**命名**: `TCCase-{原文件名}.xlsx`

**脚本**:

```bash
python easydata-agent-testtool/scripts/generate.py path4 \
  --excel "output/{name}.xlsx"
```

**验证**: 检查输出 Excel 的 Suite1 是否为文件名、Suite2 是否升序排列、行数是否等于源 Excel 数据行数。

---

### Step 5: TC 模板 Excel → YAML (按 Suite二 拆分)

将 TC 模板格式 Excel (13/8列) 转为 `easydata-mode` YAML，**按 Suite二 分组输出多个文件**。

**适用场景**: 已有 TC 模板 Excel (非 Step2 产物)，需要转 YAML。

**处理逻辑**:

| 列 | 用途 |
|----|------|
| Suite一~五 | 目录层级（forward-fill 合并单元格），仅用于分组 |
| 用例标题 | 当执行步骤为空时，作为 prompt |
| 用例分级 | → YAML priority |
| 执行步骤 | → YAML prompt（去除编号前缀） |
| 预期结果 | → YAML expected.answer |
| 用例Tag | 辅助分类推断 |

**分类推断** (AI 分析标题/步骤/预期/标签):

| 分类 | 关键词 |
|------|--------|
| `boundary` | 不存在、异常、边界、负数、noexist、ghost |
| `stability` | 安全、越权、注入、SQL注入、OR 1=1、DROP、隔壁、跨项目、无权 |
| `normal` | 其他（默认） |

**工具名提取** (AI 跨列分析):
1. 扫描 Suite二/三/四 中所有值，识别 `snake_case` 格式的 MCP 工具名，构建白名单
   - Suite四 常见格式: `list_yarn_queues`（纯工具名）
   - Suite三 常见格式: `get_datasource_list-数据源列表`（工具名-中文描述），提取 `-` 前的工具名
   - 过滤中文分类名（如 `1.基础资源查询`、`创建任务-向导模式`）
2. 每行按优先级获取: Suite四(Col D) > Suite三(Col C) > Suite二(Col B)
3. Suite 列都为空时，从预期结果文本中匹配白名单
4. 最终校验: 合法 `snake_case` 格式（至少一个下划线）
5. 匹配不到则不填 `tool_call`，仅保留 `answer_correctness`

**脚本**:

```bash
python easydata-agent-testtool/scripts/convert_tc_to_yaml.py \
  --excel "path/to/TC模板.xlsx" \
  --outdir "easydata-agent-testtool/output/"
```

**产物**: `output/{Excel名}-{Suite二}.yml`（每个 Suite二 分组一个文件）

**验证**: 检查 YAML 条目数是否与 Excel 数据行数一致、白名单工具数是否 > 0、分类分布是否覆盖 boundary/stability/normal。

---

### 步骤执行后统一输出

**每个步骤执行结束后，打印 5 个步骤功能总览表**:

```
  easydata-agent-testtool  --  5 Steps Overview

  +-------+--------------------------------------------------------------------------+
  | Step  |                          Data Flow & Description                          |
  +-------+--------------------------------------------------------------------------+
  | Step1 | MCP JSON dir --> data/{name}.md                                          |
  |       | 提取必填参数, 三级分层 (公共>=80% / 共享>=2 / 独占=1), 生成参数模板 MD      |
  +-------+--------------------------------------------------------------------------+
  | Step2 | data/{name}.md + JSON --> output/{name}-{ts}.xlsx                        |
  |       | 真实数据注入, 逐工具生成自然语言用例, 5 Sheet (正向/异常/安全/回归/敏感)     |
  +-------+--------------------------------------------------------------------------+
  | Step3 | Excel(5 sheets, 10 cols) --> output/{name}.yml                           |
  |       | 自适应解析 Excel 列, 生成 easydata-mode YAML (含 tool_call + answer)       |
  +-------+--------------------------------------------------------------------------+
  | Step4 | Excel(5 sheets) --> TCCase/TCCase-{name}.xlsx                            |
  |       | 列映射转换为 13 列 TC 模板 (Suite层级 + 用例 + 分级 + 步骤 + 预期)          |
  +-------+--------------------------------------------------------------------------+
  | Step5 | TC Excel(13/8 cols) --> output/{name}-{Suite2}.yml                       |
  |       | AI 跨 Suite 列识别工具名, 分类推断 (normal / boundary / stability)         |
  +-------+--------------------------------------------------------------------------+
```

---

## 交互规范

| 步骤 | 功能 | 输入 | 输出 |
|------|------|------|------|
| Step1 | Schema → 参数模板 MD | MCP JSON 目录 [+ --json 指定文件] | data/{name}.md |
| Step2 | AI 分析生成用例 | data/{name}.md + JSON Schema | output/{name}-{ts}.xlsx |
| Step3 | Excel → YAML | Excel (5 sheet, 10列) | output/{name}.yml |
| Step4 | Excel → TC 模板 | Excel (5 sheet) | TCCase/TCCase-{name}.xlsx |
| Step5 | TC 模板 → YAML | TC 模板 Excel (13/8列) | output/{name}-{Suite二}.yml |

每个步骤执行前展示功能表格，执行后展示结果摘要 + 5 Steps Overview。

---

## 输出格式

每个步骤执行后输出：

```
[Step N / Step N 验证]  ← 第一行：步骤名
[N] cases / tools / params  ← 核心数据
输出路径: {path}             ← 产物位置
+ 5 Steps Overview 表        ← 统一总览
```

不添加"顺便发现"或"建议"等额外内容，除非是验证节点发现的具体问题。

---

## 反模式

| 错误做法 | 问题 | 正确做法 |
|---------|------|---------|
| Step2 不确认工具范围直接跑全部 | 用户只关注 Step1 的 1 个工具，却被 44 个工具的结果淹没 | 展示数量差异，让用户选择全部还是部分 |
| Step1 不传 `--json`，把目录下所有 JSON 都处理 | 用户指定了某个 JSON 文件，期望只提取它 | 先 Read JSON 确认工具数，再确认是否只处理该文件 |
| 数据文件有 `待填写` 就直接拒绝执行 Step2 | 大部分参数 AI 可以自动补值 | 检查公共参数（product/clusterId/user），有默认值则继续；没有则提示用户填写 |
| 用例 Excel 打开着就去 Step4，导致覆盖失败 | 文件被 Excel 锁定 | 输出到 `-v{N}` 备份名，提示用户关闭后覆盖 |
| Step3 只读第一个 Sheet 导致漏掉异常/安全用例 | `path2_read_excel` 原只读 `sheetnames[0]` | 遍历所有 5 个 Sheet |
| Prompt 里写"不存在的项目"这种测试指令文本 | 读起来不像真实用户查询，Agent 行为可能失真 | 用自然伪造值如 `ghost_project_001`、`noexist_flow_000` |
| 生成 YAML 后不抽查内容 | 脚本 bug 可能导致空 tool_call 或重复 prompt | 抽查首条和末条 YAML 的 prompt/tool/answer 完整性 |
| 把输出产物当作"测试通过"的结论 | 本 skill 只负责生成，不负责评判 | 产物交给用户/评估系统，不做质量结论 |

---

## 边界说明

本 skill 仅覆盖：**从 MCP Schema 到 easydata-mode YAML 的自动化生成管线**。

| 超出范围的场景 | 处理方式 |
|--------------|---------|
| 用户要求修改生成的测试用例内容 | 停止自动执行，让用户在 Excel 中手动编辑后再走 Step3/Step5 |
| 用户要求判断 YAML 用例是否正确 | 停止，告知用户应使用 Agent 评估系统执行后判断 |
| 输入的 JSON 不是 MCP Schema 格式 | 报告格式不匹配，停止 |
| 用户要求处理非 Easydata 项目的 Schema | 尝试处理，但告知用户路径/命名约定可能不匹配 |
| 调用真实的 easydata-cli 或 Agent 评估系统 | 停止，这是测试生成工具，不是执行工具 |
