# -*- coding: utf-8 -*-
"""
gen_html_from_report.py
=======================
直接从 Step6 报告 Excel（testReport-*.xlsx）重建 HTML 可视化报告。

相比 gen_html_report.py（依赖中间 results JSON、且分组正则只认 `【组合场景N】`），
本脚本：
  - 直接读报告 Excel 的「CLI命令测试」「自然语言测试」两个 sheet
  - 按用例标题里的 `[源sheet]` 前缀分组
  - 生成两个独立分区：
      ① 单场景用例（前缀 1-正向/2-异常/3-安全/4-回归/5-敏感）—— 按层级分组卡片 + 明细
      ② 多工具链场景（前缀 6-场景组合，或 tool 列含 →）—— 链路卡片 + 明细
  - 全中文 UI，状态码 PASS/FAIL 保留

用法:
  python gen_html_from_report.py --report "5-report/testReport-xxx.xlsx"
  # 默认输出同名 .html（覆盖）
"""
import argparse
import os
import re
import sys
from datetime import datetime
from collections import OrderedDict

try:
    import openpyxl
except ImportError:
    print("Error: openpyxl not installed. Run: pip install openpyxl")
    sys.exit(1)

PREFIX_RE = re.compile(r'^\s*\[([^\]]+)\]\s*')
SINGLE_PREFIXES = ["1-正向", "2-异常", "3-安全", "4-回归", "5-敏感"]
COMBO_PREFIX = "6-场景组合"

LEVEL_ICON = {
    "1-正向": "✅", "2-异常": "⚠️", "3-安全": "🔒",
    "4-回归": "🔁", "5-敏感": "🛑", "6-场景组合": "🔗",
}


def esc(t):
    if t is None:
        return ""
    return (str(t).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;"))


def trunc(t, n=160):
    s = str(t) if t else ""
    return s if len(s) <= n else s[:n] + "…"


def prefix_of(title):
    m = PREFIX_RE.match(str(title or ""))
    return m.group(1) if m else None


def strip_prefix(title):
    return PREFIX_RE.sub("", str(title or ""))


def read_report(path):
    """读报告 Excel，返回 cases 列表（合并 CLI + NL 两个 sheet 的信息）。"""
    wb = openpyxl.load_workbook(path, data_only=True)
    cli = wb["CLI命令测试"] if "CLI命令测试" in wb.sheetnames else None
    nl = wb["自然语言测试"] if "自然语言测试" in wb.sheetnames else None

    # NL sheet：ID -> nlResult / nlPrompt
    nlmap = {}
    if nl:
        for r in range(2, nl.max_row + 1):
            cid = nl.cell(r, 1).value
            title = nl.cell(r, 2).value
            if not cid or "条用例" in str(title or "") or not str(cid).startswith("TC"):
                continue
            nlmap[cid] = {
                "nlPrompt": nl.cell(r, 4).value,
                "nlResult": nl.cell(r, 10).value,
            }

    cases = []
    if cli:
        # CLI columns: 1 ID,2 标题,3 工具,4 CLI命令,5 参数,6 耗时,7 API返回,8 预期,9 schema,10 判定分析,11 结果判定
        for r in range(2, cli.max_row + 1):
            cid = cli.cell(r, 1).value
            title = cli.cell(r, 2).value
            if not cid or "条用例" in str(title or "") or not str(cid).startswith("TC"):
                continue
            tool = cli.cell(r, 3).value or ""
            nlinfo = nlmap.get(cid, {})
            cases.append({
                "id": cid,
                "title": title or "",
                "prefix": prefix_of(title) or "其他",
                "tool": tool,
                "cliCommand": cli.cell(r, 4).value or "",
                "execTime": cli.cell(r, 6).value or "",
                "apiResult": cli.cell(r, 7).value or "",
                "reason": cli.cell(r, 10).value or "",
                "result": str(cli.cell(r, 11).value or ""),
                "nlPrompt": nlinfo.get("nlPrompt", ""),
                "nlResult": str(nlinfo.get("nlResult", "") or ""),
                "isCombo": ("→" in str(tool)) or (prefix_of(title) == COMBO_PREFIX),
            })
    wb.close()
    return cases


def result_tag(v):
    s = str(v or "").upper()
    if "FAIL" in s:
        return '<span class="tag fail">FAIL</span>'
    if "EXPECTED" in s:
        return '<span class="tag exp">PASS(EXP)</span>'
    if "SKIP" in s:
        return '<span class="tag skip">SKIP</span>'
    if "PASS" in s:
        return '<span class="tag pass">PASS</span>'
    return f'<span class="tag skip">{esc(v)}</span>'


def stat_of(cases):
    p = sum(1 for c in cases if c["result"] == "PASS")
    pe = sum(1 for c in cases if "EXPECTED" in c["result"])
    f = sum(1 for c in cases if c["result"] == "FAIL")
    sk = sum(1 for c in cases if c["result"] == "SKIP")
    return p, pe, f, sk


def badge_for(cases):
    p, pe, f, sk = stat_of(cases)
    parts = []
    if p: parts.append(f'{p} 通过')
    if pe: parts.append(f'{pe} 预期内')
    if f: parts.append(f'{f} 失败')
    if sk: parts.append(f'{sk} 跳过')
    cls = "fail" if f else ("exp" if pe and not p else "pass")
    return f'<span class="badge {cls}">{" · ".join(parts) or "无"}</span>'


# ---------- HTML builders ----------

def build_single_section(cases):
    """单场景用例分区：按 1-5 层级分组。"""
    groups = OrderedDict((p, []) for p in SINGLE_PREFIXES)
    for c in cases:
        if c["prefix"] in groups:
            groups[c["prefix"]].append(c)

    cards = []
    detail_blocks = []
    for p, gc in groups.items():
        if not gc:
            continue
        icon = LEVEL_ICON.get(p, "📌")
        cards.append(f'''
      <div class="lvl-item">
        <div class="lvl-head"><span class="lvl-ic">{icon}</span><span class="lvl-name">{esc(p)}</span></div>
        <div class="lvl-cnt">{len(gc)} 条用例</div>
        <div class="lvl-res">{badge_for(gc)}</div>
      </div>''')

        # detail rows for this level
        rows = [f'<tr class="grp"><td colspan="7">{icon} {esc(p)}（{len(gc)} 条）</td></tr>']
        for c in gc:
            rows.append(
                f'<tr><td>{esc(c["id"])}</td>'
                f'<td><code>{esc(c["tool"])}</code></td>'
                f'<td>{esc(strip_prefix(c["title"]))}</td>'
                f'<td>{esc(trunc(c["nlPrompt"],90))}</td>'
                f'<td>{esc(c["execTime"])}</td>'
                f'<td>{result_tag(c["result"])}</td>'
                f'<td style="font-size:12px">{esc(trunc(c["reason"],160))}</td></tr>'
            )
        detail_blocks.append("".join(rows))

    cards_html = "".join(cards) if cards else '<p style="color:var(--muted)">无单场景用例。</p>'
    detail_html = "".join(detail_blocks) if detail_blocks else '<tr><td colspan="7">无单场景用例。</td></tr>'
    return cards_html, detail_html


def build_combo_section(cases):
    """多工具链场景分区。"""
    combos = [c for c in cases if c["isCombo"]]
    cards = []
    detail_rows = []
    for i, c in enumerate(combos, 1):
        steps = [s.strip() for s in re.split(r'→|/', str(c["tool"])) if s.strip()]
        steps_html = ' <span class="arrow">→</span> '.join(
            f'<span class="step">{esc(s)}</span>' for s in steps) or esc(c["tool"])
        name = strip_prefix(c["title"]).split("：")[0]
        cards.append(f'''
      <div class="chain-item">
        <div class="chain-header"><span class="chain-num">{i}</span><span class="chain-name">{esc(name)}</span></div>
        <div class="chain-steps">{steps_html}</div>
        <div class="chain-result">{result_tag(c["result"])} <span class="cr">{esc(trunc(c["reason"],150))}</span></div>
      </div>''')
        detail_rows.append(
            f'<tr><td>{esc(c["id"])}</td>'
            f'<td>{esc(strip_prefix(c["title"]))}</td>'
            f'<td style="font-size:11px"><code>{esc(c["tool"])}</code></td>'
            f'<td>{esc(c["execTime"])}</td>'
            f'<td>{result_tag(c["result"])}</td>'
            f'<td style="font-size:12px">{esc(trunc(c["reason"],180))}</td></tr>'
        )
    cards_html = "".join(cards) if cards else '<p style="color:var(--muted)">本次未检测到多工具链场景。</p>'
    detail_html = "".join(detail_rows) if detail_rows else '<tr><td colspan="6">无链场景用例。</td></tr>'
    return cards_html, detail_html, len(combos)


TEMPLATE = '''<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
:root{{--bg:#f0f2f5;--card:#fff;--text:#1a1a2e;--muted:#6b7280;--pass:#10b981;--fail:#ef4444;--exp:#f59e0b;--skip:#9ca3af;--blue:#4472C4;--chain:#8b5cf6;--border:#e5e7eb;}}
*{{margin:0;padding:0;box-sizing:border-box;}}
body{{font-family:'Segoe UI','Microsoft YaHei',system-ui,sans-serif;background:var(--bg);color:var(--text);line-height:1.6;}}
.container{{max-width:1400px;margin:0 auto;padding:24px;}}
.header{{background:linear-gradient(135deg,#1e3a5f,#2F5496 50%,#4472C4);color:#fff;padding:36px 44px;border-radius:16px;margin-bottom:24px;}}
.header h1{{font-size:26px;font-weight:700;margin-bottom:8px;}}
.header .subtitle{{font-size:14px;opacity:.85;}}
.header .meta{{display:flex;gap:28px;margin-top:18px;flex-wrap:wrap;}}
.header .meta-item{{display:flex;flex-direction:column;}}
.header .meta-label{{font-size:11px;text-transform:uppercase;opacity:.7;letter-spacing:1px;}}
.header .meta-value{{font-size:14px;font-weight:600;}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:16px;margin-bottom:24px;}}
.card{{background:var(--card);border-radius:12px;padding:18px 22px;box-shadow:0 1px 3px rgba(0,0,0,.06);}}
.card .label{{font-size:12px;color:var(--muted);margin-bottom:4px;}}
.card .value{{font-size:30px;font-weight:700;}}
.card .value.pass{{color:var(--pass);}} .card .value.fail{{color:var(--fail);}}
.card .value.exp{{color:var(--exp);}} .card .value.chain{{color:var(--chain);}} .card .value.skip{{color:var(--skip);}}
.card .sub{{font-size:12px;color:var(--muted);margin-top:4px;}}
.section{{background:var(--card);border-radius:12px;padding:26px 30px;margin-bottom:20px;box-shadow:0 1px 3px rgba(0,0,0,.06);}}
.section h2{{font-size:18px;font-weight:700;margin-bottom:16px;padding-bottom:12px;border-bottom:2px solid var(--border);display:flex;align-items:center;gap:10px;}}
.section h2 .ic{{width:28px;height:28px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:15px;}}
.progress-bar{{height:26px;border-radius:13px;background:#e5e7eb;overflow:hidden;display:flex;margin:8px 0;}}
.progress-bar .seg{{display:flex;align-items:center;justify-content:center;color:#fff;font-size:12px;font-weight:600;}}
.seg.pass{{background:var(--pass);}} .seg.exp{{background:var(--exp);}} .seg.fail{{background:var(--fail);}} .seg.skip{{background:var(--skip);}}
.legend{{display:flex;gap:18px;margin-top:8px;font-size:12px;color:var(--muted);flex-wrap:wrap;}}
.legend span{{display:flex;align-items:center;gap:6px;}}
.legend .dot{{width:10px;height:10px;border-radius:3px;display:inline-block;}}
.dot.pass{{background:var(--pass);}} .dot.exp{{background:var(--exp);}} .dot.fail{{background:var(--fail);}} .dot.skip{{background:var(--skip);}}
.lvl-list{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;}}
.lvl-item{{border:1px solid var(--border);border-radius:10px;padding:14px 18px;}}
.lvl-head{{display:flex;align-items:center;gap:8px;margin-bottom:6px;}}
.lvl-ic{{font-size:18px;}} .lvl-name{{font-weight:700;font-size:15px;}}
.lvl-cnt{{font-size:13px;color:var(--muted);margin-bottom:6px;}}
.chain-list{{display:grid;grid-template-columns:repeat(auto-fit,minmax(420px,1fr));gap:12px;}}
.chain-item{{border:1px solid var(--border);border-radius:10px;padding:16px 20px;}}
.chain-item:hover{{box-shadow:0 4px 12px rgba(0,0,0,.08);}}
.chain-header{{display:flex;align-items:center;gap:10px;margin-bottom:10px;}}
.chain-num{{background:var(--chain);color:#fff;width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;}}
.chain-name{{font-weight:700;font-size:14px;}}
.chain-steps{{display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:12px;color:var(--muted);}}
.chain-steps .step{{background:#f3f4f6;padding:3px 10px;border-radius:20px;white-space:nowrap;}}
.chain-steps .arrow{{color:var(--chain);font-weight:700;}}
.chain-result{{margin-top:8px;}} .chain-result .cr{{font-size:12px;color:var(--muted);}}
.badge{{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600;}}
.badge.pass{{background:#d1fae5;color:#065f46;}} .badge.exp{{background:#fef3c7;color:#92400e;}} .badge.fail{{background:#fee2e2;color:#991b1b;}}
table{{width:100%;border-collapse:collapse;font-size:13px;}}
thead th{{background:var(--blue);color:#fff;padding:10px 12px;text-align:left;font-weight:600;font-size:12px;position:sticky;top:0;}}
tbody td{{padding:8px 12px;border-bottom:1px solid var(--border);vertical-align:top;}}
tbody tr:hover{{background:#f8fafc;}}
tr.grp td{{background:#2F5496;color:#fff;font-weight:700;font-size:13px;}}
.table-wrap{{max-height:620px;overflow-y:auto;border:1px solid var(--border);border-radius:8px;}}
.tag{{display:inline-block;padding:1px 8px;border-radius:12px;font-size:11px;font-weight:600;white-space:nowrap;}}
.tag.pass{{background:#d1fae5;color:#065f46;}} .tag.fail{{background:#fee2e2;color:#991b1b;}}
.tag.exp{{background:#fef3c7;color:#92400e;}} .tag.skip{{background:#e5e7eb;color:#374151;}}
code{{background:#f1f5f9;padding:1px 6px;border-radius:4px;font-size:12px;}}
.env-table td{{padding:4px 16px;}} .env-table td:first-child{{font-weight:600;color:var(--muted);width:140px;}}
.footer{{text-align:center;color:var(--muted);font-size:12px;padding:24px;}}
</style></head><body><div class="container">
  <div class="header">
    <h1>🧪 {title}</h1>
    <div class="subtitle">{subtitle}</div>
    <div class="meta">
      <div class="meta-item"><span class="meta-label">测试日期</span><span class="meta-value">{testDate}</span></div>
      <div class="meta-item"><span class="meta-label">测试项目</span><span class="meta-value">{testProduct}</span></div>
      <div class="meta-item"><span class="meta-label">集群</span><span class="meta-value">{testCluster}</span></div>
      <div class="meta-item"><span class="meta-label">命令范围</span><span class="meta-value">{testCommand}</span></div>
    </div>
  </div>

  <div class="cards">
    <div class="card"><div class="label">用例总数</div><div class="value chain">{total}</div><div class="sub">单场景 {single_n} + 链场景 {combo_n}</div></div>
    <div class="card"><div class="label">通过 PASS</div><div class="value pass">{passn}</div><div class="sub">{pass_pct:.1f}% 通过率</div></div>
    <div class="card"><div class="label">预期内 PASS(EXP)</div><div class="value exp">{expn}</div><div class="sub">边界/安全用例</div></div>
    <div class="card"><div class="label">失败 FAIL</div><div class="value fail">{failn}</div><div class="sub">需人工复核</div></div>
    <div class="card"><div class="label">跳过 SKIP</div><div class="value skip">{skipn}</div><div class="sub">敏感未下发</div></div>
    <div class="card"><div class="label">覆盖工具</div><div class="value">{tooln}</div><div class="sub">去重 MCP 工具</div></div>
  </div>

  <div class="section">
    <h2><span class="ic" style="background:#dbeafe;color:#2563eb;">📊</span> 结果分布</h2>
    <div class="progress-bar">{segments}</div>
    <div class="legend">{legend}</div>
  </div>

  <div class="section">
    <h2><span class="ic" style="background:#d1fae5;color:#059669;">📍</span> 单场景用例（按测试层级）</h2>
    <div class="lvl-list">{single_cards}</div>
    <div style="margin-top:16px"></div>
    <div class="table-wrap"><table>
      <thead><tr><th style="width:80px">ID</th><th style="width:140px">工具</th><th style="width:200px">标题</th><th>自然语言Prompt</th><th style="width:55px">耗时</th><th style="width:90px">结果</th><th style="width:240px">判定分析</th></tr></thead>
      <tbody>{single_detail}</tbody>
    </table></div>
  </div>

  <div class="section">
    <h2><span class="ic" style="background:#ede9fe;color:#7c3aed;">🔗</span> 多工具链场景结果</h2>
    <div class="chain-list">{combo_cards}</div>
    <div style="margin-top:16px"></div>
    <div class="table-wrap"><table>
      <thead><tr><th style="width:80px">ID</th><th style="width:240px">链路标题</th><th>工具链</th><th style="width:55px">耗时</th><th style="width:90px">结果</th><th style="width:260px">判定分析</th></tr></thead>
      <tbody>{combo_detail}</tbody>
    </table></div>
  </div>

  <div class="section">
    <h2><span class="ic" style="background:#fef3c7;color:#92400e;">📝</span> 测试结论</h2>
    <table class="env-table">{conclusion}</table>
  </div>

  <div class="footer">🤖 由 Claude Code 生成 · EasyData Agent 测试工具 · gen_html_from_report.py · {gen_date}</div>
</div></body></html>'''


def main():
    ap = argparse.ArgumentParser(description="从报告 Excel 重建 HTML（含单场景+链场景两栏）")
    ap.add_argument("--report", required=True, help="报告 Excel 路径")
    ap.add_argument("--output", default=None, help="HTML 输出路径（默认同名 .html）")
    args = ap.parse_args()

    cases = read_report(args.report)
    if not cases:
        print("ERROR: 报告中未读到用例")
        sys.exit(1)

    single = [c for c in cases if not c["isCombo"]]
    combos = [c for c in cases if c["isCombo"]]
    p, pe, f, sk = stat_of(cases)
    total = len(cases)
    tools = set()
    for c in cases:
        for t in re.split(r'→|/', str(c["tool"])):
            t = t.strip()
            if t:
                tools.add(t)

    # progress segments
    segs, leg = [], []
    for n, cls, name in [(p, "pass", "通过"), (pe, "exp", "预期内"),
                         (f, "fail", "失败"), (sk, "skip", "跳过")]:
        if n:
            pct = n / total * 100
            segs.append(f'<div class="seg {cls}" style="width:{pct:.1f}%">{name} {n}</div>')
            leg.append(f'<span><span class="dot {cls}"></span> {name} — {n}</span>')

    single_cards, single_detail = build_single_section(single)
    combo_cards, combo_detail, combo_n = build_combo_section(combos)

    # derive meta from filename
    base = os.path.splitext(os.path.basename(args.report))[0].replace("testReport-", "")
    svc = base.split("-")[0]

    concl = [
        ("总体结论", f'共 {total} 条用例：{p} 通过 / {pe} 预期内通过 / {f} 失败 / {sk} 跳过。'
                  f'失败项均为真实接口/参数发现，需 QA 人工复核（详见 Excel 报告橙色复核列）。'),
        ("单场景覆盖", f'{len(single)} 条单场景用例，覆盖 正向/异常/安全/回归/敏感 五个层级。'
                    f'敏感破坏性操作按要求未真实下发（记 SKIP，预期为 Agent 须二次确认）。'),
        ("链场景覆盖", f'{combo_n} 条多工具链场景，验证跨工具上下文继承（前步返回 id 作后步入参）。'),
        ("说明", "本报告由 Step6 报告 Excel 直接重建；结果判定口径：退出码≠0 或返回含 Error → FAIL；"
               "异常/安全/边界用例返回错误 → PASS(预期内)；正常返回 → PASS。"),
    ]
    conclusion_html = "".join(f'<tr><td>{esc(k)}</td><td>{v}</td></tr>' for k, v in concl)

    html = TEMPLATE.format(
        title=f"EasyData Agent 测试报告 — {svc}",
        subtitle="单场景用例 + 多工具链场景 · NL/CLI 双方案",
        testDate="2026-06-11", testProduct="autoapi_test",
        testCluster="easyops-cluster", testCommand=svc,
        total=total, single_n=len(single), combo_n=combo_n,
        passn=p, expn=pe, failn=f, skipn=sk, tooln=len(tools),
        pass_pct=p / total * 100,
        segments="".join(segs), legend="".join(leg),
        single_cards=single_cards, single_detail=single_detail,
        combo_cards=combo_cards, combo_detail=combo_detail,
        conclusion=conclusion_html,
        gen_date=datetime.now().strftime("%Y-%m-%d %H:%M"),
    )

    out = args.output or os.path.splitext(args.report)[0] + ".html"
    with open(out, "w", encoding="utf-8") as fp:
        fp.write(html)
    print(f"[OK] HTML 生成: {out}")
    print(f"  总 {total} 条 | 单场景 {len(single)} | 链场景 {combo_n} | PASS {p} / EXP {pe} / FAIL {f} / SKIP {sk}")


if __name__ == "__main__":
    main()
