# -*- coding: utf-8 -*-
"""
step3_gen_html_report.py —— step3·子步②（机械）：把 step3_run_curl.py 产出的 Excel 执行报告渲染成 HTML。

设计原则：
  * 与执行解耦——本脚本【不发请求】，只读已有的 Excel 报告，转成可视化 HTML。
  * 这样 HTML 样式调整、重新出图都不必重跑 curl。

输入：3-report/执行报告-{...}.xlsx（step3_run_curl.py 的产物，含「执行汇总」「执行明细」两个 Sheet）。
输出：3-report/reportHtml/执行报告-{...}.html（文件名沿用来源 Excel 的 base 名）。

用法：
  python step3_gen_html_report.py --excel "../3-report/执行报告-v1.23.0-大盘统计-{ts}.xlsx" [--outdir 目录]
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import html
import argparse

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from _common import unique_path

STATUS_COLOR = {
    'PASS': 'C6EFCE', 'PASS(预期)': 'D9EAD3', 'FAIL': 'FFC7CE',
    'ERROR': 'FFC7CE', 'SKIP': 'D9D9D9', '需人工复核': 'FFEB9C',
}
VERDICTS = ['PASS', 'PASS(预期)', 'FAIL', 'ERROR', '需人工复核', 'SKIP']


def read_report(excel_path):
    """
    读执行报告 Excel，返回 (rows, counts)。
    兼容两种结构：
      * 多 sheet（按用例分类拆分，当前 step3 产物）——遍历所有含「用例标题」表头的 sheet，跳过「执行汇总」
      * 单 sheet（旧「执行明细」结构）
    """
    from openpyxl import load_workbook
    from collections import Counter
    wb = load_workbook(excel_path, data_only=True)

    def _read_sheet(ws, rows, cnt):
        header = {}
        for ci, cell in enumerate(ws[1], start=1):
            if cell.value:
                header[str(cell.value).strip()] = ci
        if '用例标题' not in header:
            return  # 非明细 sheet（如「执行汇总」），跳过
        def gi(row, name):
            ci = header.get(name)
            return row[ci - 1] if ci and ci - 1 < len(row) else ''
        for row in ws.iter_rows(min_row=2, values_only=True):
            if not gi(row, '用例标题'):
                continue
            verdict = str(gi(row, '判定') or '')
            cnt[verdict] += 1
            rows.append({
                'module': gi(row, '模块') or '', 'type': gi(row, '类型') or '',
                'title': gi(row, '用例标题') or '', 'priority': gi(row, '分级') or '',
                'http_status': gi(row, 'HTTP状态') or '', 'elapsed': gi(row, '耗时(s)') or '',
                'verdict': verdict, 'body': gi(row, '响应体') or '',
                'expected': gi(row, '预期结果') or '', 'curl': gi(row, '执行命令(curl)') or '',
                'analysis': gi(row, '判定分析(AI)') or '', 'error': gi(row, '错误信息') or '',
            })

    rows, cnt = [], Counter()
    for ws in wb.worksheets:
        _read_sheet(ws, rows, cnt)
    return rows, cnt


def render_html(rows, cnt, source_name):
    from collections import OrderedDict

    total = len(rows)
    passed = cnt.get('PASS', 0) + cnt.get('PASS(预期)', 0)
    pass_rate = round(passed / total * 100) if total else 0

    # 卡片配色（与 STATUS_COLOR 呼应，加深用于文字/边）
    card_accent = {
        'PASS': '#2e7d32', 'PASS(预期)': '#558b2f', 'FAIL': '#c62828',
        'ERROR': '#c62828', '需人工复核': '#f9a825', 'SKIP': '#757575',
    }
    cards = []
    for k in VERDICTS:
        n = cnt.get(k, 0)
        ac = card_accent.get(k, '#555')
        bg = '#' + STATUS_COLOR.get(k, 'FFFFFF')
        cards.append(
            f'<div class="card" style="border-top:3px solid {ac}">'
            f'<div class="num" style="color:{ac}">{n}</div>'
            f'<div class="lbl"><span class="dot" style="background:{bg}"></span>{html.escape(k)}</div>'
            f'</div>'
        )
    cards_html = ''.join(cards)

    def status_pill(v):
        bg = '#' + STATUS_COLOR.get(v, 'EEEEEE')
        ac = card_accent.get(v, '#333')
        return f'<span class="pill" style="background:{bg};color:{ac}">{html.escape(v)}</span>'

    def cell_block(text, cls=''):
        text = str(text or '')
        if not text:
            return '<td></td>'
        return f'<td><div class="block {cls}">{html.escape(text)}</div></td>'

    # 按「接口(模块)」分 section，section 内再按「用例类型」分组、每组前插一行分类小标题
    # —— 与 Excel 执行报告的「接口拆 sheet + 分类标题行」布局一致。
    import re as _re
    _METHOD_RE = _re.compile(r'\s+(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b', _re.I)

    def _iface_short(iface):
        m = _METHOD_RE.search(iface)
        name = (iface[:m.start()] if m else iface).strip()
        return name or iface

    ifaces = OrderedDict()
    for r in rows:
        iface = (r.get('module') or '通用').strip() or '通用'
        cat = (r.get('type') or '其他').strip() or '其他'
        ifaces.setdefault(iface, OrderedDict()).setdefault(cat, []).append(r)

    sections = []
    gi = 0
    for iface, cat_groups in ifaces.items():
        gi += 1
        all_items = [r for items in cat_groups.values() for r in items]
        gp = sum(1 for r in all_items if r['verdict'] in ('PASS', 'PASS(预期)'))
        body_rows = []
        seq = 0
        for cat, items in cat_groups.items():
            cgp = sum(1 for r in items if r['verdict'] in ('PASS', 'PASS(预期)'))
            # 分类小标题行（整行跨列）
            body_rows.append(
                f'<tr class="cat"><td colspan="12">{html.escape(cat)}'
                f'<span class="cmeta">{cgp}/{len(items)} 通过</span></td></tr>')
            for r in items:
                seq += 1
                body_rows.append(f"""<tr>
  <td class="idx">{seq}</td>
  <td class="mod">{html.escape(str(r['module']))}</td>
  <td>{html.escape(str(r['title']))}</td>
  <td class="ctr">{html.escape(str(r['priority']))}</td>
  <td class="ctr">{html.escape(str(r['http_status']))}</td>
  <td class="ctr">{html.escape(str(r['elapsed']))}</td>
  <td class="ctr">{status_pill(r['verdict'])}</td>
  {cell_block(r.get('analysis'), 'analysis')}
  {cell_block(str(r['body'])[:1500], 'mono')}
  {cell_block(r['expected'])}
  {cell_block(r['curl'], 'mono')}
  {cell_block(r['error'])}
</tr>""")
        sections.append(f"""
<section class="grp">
  <h2><span class="gnum">{gi}</span>{html.escape(_iface_short(iface))}
    <span class="gmeta">{gp}/{len(all_items)} 通过</span></h2>
  <div class="tablewrap">
  <table>
    <colgroup>
      <col class="c-idx"><col class="c-mod"><col class="c-title"><col class="c-pri">
      <col class="c-http"><col class="c-cost"><col class="c-verdict">
      <col class="c-analysis"><col class="c-body"><col class="c-exp"><col class="c-curl"><col class="c-err">
    </colgroup>
    <thead><tr>
      <th>#</th><th>接口模块</th><th>用例标题</th><th>分级</th><th>HTTP</th><th>耗时(s)</th>
      <th>判定</th><th>判定分析(AI)</th><th>响应体</th><th>预期</th><th>curl</th><th>错误</th>
    </tr></thead>
    <tbody>{''.join(body_rows)}</tbody>
  </table>
  </div>
</section>""")

    return f"""<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>接口执行报告 · {html.escape(source_name)}</title>
<style>
:root{{--brand:#2F5496;--ink:#1f2933;--muted:#6b7280;--line:#e5e7eb;--bg:#f4f6fb}}
*{{box-sizing:border-box}}
body{{font-family:'Microsoft YaHei','Segoe UI',Arial,sans-serif;margin:0;color:var(--ink);background:var(--bg)}}
.wrap{{max-width:1280px;margin:0 auto;padding:0 24px 48px}}
header.hero{{background:linear-gradient(135deg,#2F5496 0%,#3f6fc4 100%);color:#fff;padding:28px 0 22px;margin-bottom:24px;box-shadow:0 2px 12px rgba(47,84,150,.25)}}
header.hero .wrap{{padding-top:0;padding-bottom:0}}
.hero h1{{margin:0 0 6px;font-size:22px;font-weight:700}}
.hero .sub{{font-size:13px;opacity:.9}}
.hero .rate{{float:right;text-align:center;background:rgba(255,255,255,.15);border-radius:12px;padding:10px 18px;margin-top:-4px}}
.hero .rate b{{display:block;font-size:30px;line-height:1}}
.hero .rate span{{font-size:11px;opacity:.9}}
.cards{{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 8px}}
.card{{background:#fff;border:1px solid var(--line);border-radius:12px;padding:16px 22px;text-align:center;min-width:108px;box-shadow:0 1px 4px rgba(0,0,0,.04)}}
.card .num{{font-size:30px;font-weight:800;line-height:1}}
.card .lbl{{font-size:12px;color:var(--muted);margin-top:6px;display:flex;align-items:center;justify-content:center;gap:5px}}
.card .dot{{width:9px;height:9px;border-radius:50%;display:inline-block;border:1px solid rgba(0,0,0,.12)}}
section.grp{{background:#fff;border:1px solid var(--line);border-radius:12px;margin-top:20px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.04)}}
section.grp h2{{font-size:15px;margin:0;padding:13px 18px;background:#eef2fb;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px}}
.gnum{{background:var(--brand);color:#fff;width:22px;height:22px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-size:12px}}
.gmeta{{margin-left:auto;font-size:12px;color:var(--muted);font-weight:400}}
.tablewrap{{overflow-x:auto}}
table{{border-collapse:collapse;table-layout:fixed;min-width:1400px;width:100%;font-size:12.5px}}
/* 固定列宽，避免中文标题被挤压重叠；总宽超出容器时整表横向滚动 */
col.c-idx{{width:40px}} col.c-mod{{width:200px}} col.c-title{{width:190px}}
col.c-pri{{width:48px}} col.c-http{{width:58px}} col.c-cost{{width:70px}} col.c-verdict{{width:92px}}
col.c-analysis{{width:280px}} col.c-body{{width:280px}} col.c-exp{{width:180px}} col.c-curl{{width:260px}} col.c-err{{width:150px}}
th,td{{border-bottom:1px solid var(--line);padding:8px 10px;vertical-align:top;text-align:left;overflow-wrap:break-word;word-break:break-word}}
th{{background:#fafbfd;color:#374151;position:sticky;top:0;font-weight:600;white-space:nowrap;z-index:1}}
tbody tr:nth-child(even){{background:#fafbfd}}
tbody tr:hover{{background:#f0f5ff}}
tr.cat td{{background:#8eaadb;color:#fff;font-weight:700;font-size:12.5px;padding:6px 12px}}
tr.cat:hover td{{background:#8eaadb}}
.cmeta{{margin-left:10px;font-weight:400;font-size:11.5px;opacity:.92}}
td.idx,td.ctr{{text-align:center;color:var(--muted);white-space:nowrap}}
td.mod{{color:#374151;font-size:11.5px}}
.pill{{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}}
.block{{max-height:150px;overflow:auto;white-space:pre-wrap;word-break:break-all}}
.block.mono{{font-family:Consolas,Menlo,monospace;font-size:11px;color:#334155;background:#f8fafc;border:1px solid var(--line);border-radius:6px;padding:6px 8px}}
.block.analysis{{font-size:12px;color:#1f2933;background:#fffdf5;border:1px solid #f0e6c8;border-left:3px solid #f9a825;border-radius:6px;padding:6px 9px;line-height:1.55}}
footer{{color:var(--muted);font-size:12px;margin-top:20px;text-align:center}}
</style></head><body>
<header class="hero"><div class="wrap">
  <div class="rate"><b>{pass_rate}%</b><span>通过率</span></div>
  <h1>接口执行报告</h1>
  <div class="sub">来源用例：{html.escape(source_name)} ｜ 用例总数 {total} ｜ 通过 {passed} ｜ 接口 {len(ifaces)} 个</div>
</div></header>
<div class="wrap">
  <div class="cards">{cards_html}</div>
  {''.join(sections)}
  <footer>判定为自动初判，异常/校验类用例预期本就返回错误码，最终结果请结合「预期」列人工复核。</footer>
</div>
</body></html>"""


def main():
    ap = argparse.ArgumentParser(description='把 Excel 执行报告渲染成 HTML')
    ap.add_argument('--excel', required=True, help='step3_run_curl.py 产出的执行报告 Excel')
    ap.add_argument('--outdir', help='HTML 输出目录（默认 ../3-report/reportHtml/）')
    args = ap.parse_args()

    if not os.path.exists(args.excel):
        print(f'[ERROR] 执行报告 Excel 不存在：{args.excel}')
        sys.exit(1)

    rows, cnt = read_report(args.excel)
    if not rows:
        print('[ERROR] Excel 里未读到执行明细行')
        sys.exit(1)

    base = os.path.splitext(os.path.basename(args.excel))[0]
    outdir = args.outdir or os.path.join(os.path.dirname(script_dir), '3-report', 'reportHtml')
    os.makedirs(outdir, exist_ok=True)

    html_path = unique_path(os.path.join(outdir, f'{base}.html'))
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(render_html(rows, cnt, base))
    print(f'[OK] HTML 报告：{html_path}')
    print(f'[OK] 判定统计：{dict(cnt)}')


if __name__ == '__main__':
    main()
