# -*- coding: utf-8 -*-
"""
step3_run_curl.py —— step3·子步①（机械）：执行用例里的 curl，产出 Excel 执行报告。

输入：step2 生成的用例 Excel（含「执行命令(curl)」列）。
做什么：
  1. 读 Excel，提取每条用例的标题/模块/分级/预期/curl 命令
  2. 逐条真实执行 curl（subprocess），捕获 HTTP 状态、响应体、耗时
  3. 依「响应体是否含 code:0 / HTTP 是否 2xx」做初步判定（PASS/FAIL/需人工复核）
  4. 产出 Excel 报告（汇总 Sheet + 明细 Sheet）

HTML 报告由 step3_gen_html_report.py 单独从本步 Excel 生成（职责分离）。
判定为辅助参考，不替代人工复核（异常/校验用例预期本就返回错误码）。

输出命名：执行报告-{文件名}-{模块}-{时间戳}.xlsx，落 3-report/。

用法：
  python step3_run_curl.py --excel "../2-output/{项目}/测试用例-xxx.xlsx" \
      --doc v1.23.0 --module 大盘统计 [--ts ...] [--outdir 目录] [--timeout 20]
  # 默认给每条 curl 兜底注入鉴权参数 authType=TEST（网关从请求参数读取）：
  #   GET 拼 query、POST 拼进 JSON body，已带同名参数则不重复；
  #   --auth-param "x=y" 改用别的参数；--no-auth-param 关闭注入

依赖：curl 命令行（系统自带）；openpyxl。
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import re
import shlex
import argparse
import subprocess

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from _common import read_cases, unique_path, build_name, resolve_ts

# 判定着色（与 HTML 报告脚本共享同一套色值约定）
STATUS_COLOR = {
    'PASS': 'C6EFCE', 'PASS(预期)': 'D9EAD3', 'FAIL': 'FFC7CE',
    'ERROR': 'FFC7CE', 'SKIP': 'D9D9D9', '需人工复核': 'FFEB9C',
}


def _inject_auth_param(argv, name, value):
    """
    把鉴权参数（name=value，默认 authType=TEST）兜底注入到 curl 的参数列表。
    网关从请求参数（非 header）读取，故按请求类型注入：
      * 有 -d/--data（POST/JSON）→ 注入进 JSON body 的顶层；body 已含该 key 则不动
      * 否则视为 GET → 拼到 URL 的 query string；URL 已含该 key 则不动
    """
    import json as _json

    joined = ' '.join(argv)
    has_in_query = bool(re.search(rf'[?&]{re.escape(name)}=', joined))

    data_idx = None
    for i, a in enumerate(argv):
        if a in ('-d', '--data', '--data-raw', '--data-binary') and i + 1 < len(argv):
            data_idx = i + 1
            break

    if data_idx is not None:
        body = argv[data_idx]
        try:
            obj = _json.loads(body)
            if isinstance(obj, dict):
                if name not in obj:
                    obj[name] = value
                    argv[data_idx] = _json.dumps(obj, ensure_ascii=False)
                return argv
        except Exception:
            pass
        if f'{name}=' not in body:
            argv[data_idx] = body + (f'&{name}={value}' if body else f'{name}={value}')
        return argv

    if has_in_query:
        return argv
    for i, a in enumerate(argv):
        if a.startswith('http://') or a.startswith('https://'):
            sep = '&' if '?' in a else '?'
            argv[i] = f'{a}{sep}{name}={value}'
            break
    return argv


def run_one(curl_cmd, timeout, auth_param='authType=TEST'):
    """执行单条 curl，返回 dict：http_status, elapsed, body, error。"""
    if not curl_cmd:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': '无 curl 命令'}

    marker = '___HTTP_META___'
    try:
        argv = shlex.split(curl_cmd, posix=True)
    except ValueError as e:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'命令解析失败：{e}'}

    argv = [a for a in argv if a != '-i']

    if auth_param and '=' in auth_param:
        name, value = auth_param.split('=', 1)
        argv = _inject_auth_param(argv, name.strip(), value.strip())

    argv += ['-s', '-w', f'{marker}%{{http_code}}|%{{time_total}}']

    try:
        proc = subprocess.run(argv, shell=False, capture_output=True, timeout=timeout)
        out = (proc.stdout or b'').decode('utf-8', errors='replace')
        err = (proc.stderr or b'').decode('utf-8', errors='replace')
        http_status, elapsed = '', ''
        if marker in out:
            body, meta = out.rsplit(marker, 1)
            parts = meta.split('|')
            http_status = parts[0].strip() if parts else ''
            elapsed = parts[1].strip() if len(parts) > 1 else ''
        else:
            body = out
        error = '' if proc.returncode == 0 else (err.strip() or f'curl 退出码 {proc.returncode}')
        return {'http_status': http_status, 'elapsed': elapsed, 'body': body.strip(), 'error': error}
    except FileNotFoundError:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': 'curl 未安装或不在 PATH'}
    except subprocess.TimeoutExpired:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'超时(>{timeout}s)'}
    except Exception as e:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'执行异常：{e}'}


def _extract_code(body):
    m = re.search(r'"code"\s*:\s*(-?\d+)', body or '')
    return m.group(1) if m else None


def _extract_msg(body):
    m = re.search(r'"msg"\s*:\s*"([^"]*)"', body or '')
    return m.group(1) if m else None


def judge(case, res):
    """
    初步判定：返回 (verdict, analysis)。
    analysis 用一句话解释「为什么是这个判定」，供人工复核——尤其当判定为 PASS 时，
    让人能看到判定依据，而不必自己回去翻响应体。
    判定仍是机械初判；负向类却返回成功、正向类无法确认等矛盾会在 analysis 里显式提示。
    """
    ctype = case['type'] or '用例'
    if not case['curl']:
        return 'SKIP', '该用例无 curl 命令，未执行。'
    if res['error']:
        return 'ERROR', f"执行失败：{res['error']}；未拿到有效响应，无法判定，需排查网络/鉴权/curl 语法。"

    body = res['body'] or ''
    code = _extract_code(body)
    msg = _extract_msg(body)
    http_status = res['http_status']
    http2xx = str(http_status).startswith('2')
    is_ok_code = code == '0'
    # 负向类（预期返回错误/被拒绝）：参数校验/业务异常/安全/边界/权限。
    # 注意「出参校验」含"校验"字却是正向用例（应成功返回），故显式排除。
    _ctype = case['type'] or ''
    is_negative = (any(k in _ctype for k in ('校验', '异常', '安全', '边界', '权限'))
                   and '出参' not in _ctype)

    if http2xx and is_ok_code:
        if is_negative:
            # 负向类却调用成功——预期/实际可能不一致，重点提醒人工
            return '需人工复核', (
                f"HTTP {http_status}、响应 code=0（调用成功）。但本用例属【{ctype}】，"
                f"按语义通常应返回错误码/被拒绝，实际却成功——存在预期与实际的差异，"
                f"不能简单判 PASS，需人工确认接口此行为是否正确（可能应为 FAIL）。")
        return 'PASS', (
            f"HTTP {http_status}、响应 code=0，调用成功并返回正常结构，符合正向预期 → PASS。"
            f"（自动仅校验到 code=0；result 字段取值/分页一致性等仍建议人工核对。）")

    if is_negative:
        if body or http2xx:
            detail = f"code={code}" if code is not None else f"HTTP {http_status}"
            if msg:
                detail += f"，msg=「{msg[:80]}」"
            return 'PASS(预期)', (
                f"本用例属【{ctype}】，预期返回错误或校验失败；实际 {detail}，"
                f"已按预期被拒绝/报错，符合预期 → PASS(预期)。")

    detail = f"实际 code={code}" if code is not None else f"HTTP {http_status}、响应体未含明确 code"
    return '需人工复核', (
        f"正向类用例但未能自动确认成功（{detail}），无法机械判定成功/失败，"
        f"需人工结合「预期」列复核。")


def write_excel(cases, results, out_path, source_name):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from collections import Counter, OrderedDict

    wb = Workbook()

    # ── Sheet1：执行汇总 ──
    ws0 = wb.active
    ws0.title = '执行汇总'
    cnt = Counter(r['verdict'] for r in results)
    ws0.append(['执行报告', source_name])
    ws0.append(['用例总数', len(results)])
    for k in ['PASS', 'PASS(预期)', 'FAIL', 'ERROR', '需人工复核', 'SKIP']:
        ws0.append([k, cnt.get(k, 0)])
    ws0.column_dimensions['A'].width = 16
    ws0.column_dimensions['B'].width = 60
    ws0['A1'].font = Font(bold=True, size=13)
    # 汇总表判定行着色
    for ri in range(3, 9):
        v = ws0.cell(row=ri, column=1).value
        color = STATUS_COLOR.get(v)
        if color:
            ws0.cell(row=ri, column=1).fill = PatternFill('solid', fgColor=color)

    headers = ['#', '模块', '类型', '用例标题', '分级', 'HTTP状态', '耗时(s)',
               '执行命令(curl)', '响应体', '预期结果', '判定', '判定分析(AI)', '错误信息', '人工复核']
    widths = {1: 5, 2: 22, 3: 14, 4: 34, 5: 8, 6: 10, 7: 9,
              8: 60, 9: 50, 10: 36, 11: 12, 12: 50, 13: 24, 14: 16}
    wrap = Alignment(wrap_text=True, vertical='top')

    def _safe_sheet_name(name, used):
        for ch in '[]:*?/\\':
            name = name.replace(ch, '_')
        name = name[:31] or 'Sheet'
        base, n = name, 1
        while name in used:
            suffix = f'_{n}'
            name = base[:31 - len(suffix)] + suffix
            n += 1
        used.add(name)
        return name

    # ── 按「接口(模块)」拆 sheet，sheet 内按「用例类型」分组、每组前插合并标题行 ──
    # 与 step2 用例 Excel 的布局保持一致（接口拆 sheet + 分类标题行）。
    import re as _re
    _METHOD_RE = _re.compile(r'\s+(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\b', _re.I)

    def _iface_short(iface):
        # 取接口可读短名：截掉 "方法 路径" 部分（如 "实例统计 GET /x" → "实例统计"）
        m = _METHOD_RE.search(iface)
        name = (iface[:m.start()] if m else iface).strip()
        return name or iface

    ncols = len(headers)
    title_fill = PatternFill('solid', fgColor='8EAADB')
    title_font = Font(bold=True, color='FFFFFF')

    # 两级分组：接口(module) → 类型(type) → [(case,result)]，保持出现顺序
    sheets = OrderedDict()
    for c, r in zip(cases, results):
        iface = (c.get('module') or '通用').strip() or '通用'
        cat = (c.get('type') or '其他').strip() or '其他'
        sheets.setdefault(iface, OrderedDict()).setdefault(cat, []).append((c, r))

    used_names = {'执行汇总'}
    for iface, cat_groups in sheets.items():
        ws = wb.create_sheet(_safe_sheet_name(_iface_short(iface), used_names))
        ws.append(headers)
        for ci, _ in enumerate(headers, start=1):
            hc = ws.cell(row=1, column=ci)
            hc.font = Font(bold=True, color='FFFFFF')
            hc.fill = PatternFill('solid', fgColor='2F5496')
            hc.alignment = Alignment(vertical='center')
        seq = 0
        for cat, items in cat_groups.items():
            # 分类标题行：跨列合并
            ri = ws.max_row + 1
            gp = sum(1 for _, r in items if r['verdict'] in ('PASS', 'PASS(预期)'))
            ws.cell(row=ri, column=1, value=f'{cat}（{gp}/{len(items)} 通过）')
            ws.merge_cells(start_row=ri, start_column=1, end_row=ri, end_column=ncols)
            tcell = ws.cell(row=ri, column=1)
            tcell.font = title_font
            tcell.fill = title_fill
            tcell.alignment = Alignment(vertical='center')
            for c, r in items:
                seq += 1
                row = [seq, c['module'], c['type'], c['title'], c['priority'],
                       r['http_status'], r['elapsed'], c['curl'],
                       r['body'][:2000], c['expected'], r['verdict'],
                       r.get('analysis', ''), r['error'], '']
                ws.append(row)
                ri = ws.max_row
                for ci in (8, 9, 10, 12):
                    ws.cell(row=ri, column=ci).alignment = wrap
                vcell = ws.cell(row=ri, column=11)
                color = STATUS_COLOR.get(r['verdict'])
                if color:
                    vcell.fill = PatternFill('solid', fgColor=color)
                # 判定分析列：随判定着同色浅背景，PASS 也能一眼看到依据
                if color:
                    ws.cell(row=ri, column=12).fill = PatternFill('solid', fgColor=color)
                ws.cell(row=ri, column=14).fill = PatternFill('solid', fgColor='FFF2CC')
        for ci, w in widths.items():
            ws.column_dimensions[get_column_letter(ci)].width = w
        ws.freeze_panes = 'A2'  # 冻结表头

    wb.save(out_path)
    return cnt


def main():
    ap = argparse.ArgumentParser(description='执行用例 curl 并生成 Excel 执行报告')
    ap.add_argument('--excel', required=True, help='用例 Excel（含 执行命令(curl) 列，默认在 2-output/{项目}/ 下）')
    ap.add_argument('--doc', default='', help='来源文档名，用于命名（如 v1.23.0）')
    ap.add_argument('--module', default='', help='模块名，用于命名（如 大盘统计）')
    ap.add_argument('--ts', default='', help='时间戳；默认沿用 1-input 的批次时间戳（序1文件名），再退回当前时刻')
    ap.add_argument('--outdir', help='报告输出目录（默认 ../3-report/）')
    ap.add_argument('--timeout', type=int, default=20, help='单条 curl 超时秒数，默认20')
    ap.add_argument('--auth-param', default='authType=TEST',
                    help='执行时兜底注入的鉴权参数，默认 "authType=TEST"；GET 拼 query、POST 拼 body，已带则不重复')
    ap.add_argument('--no-auth-param', action='store_true', help='不注入任何鉴权参数')
    ap.add_argument('--dry-run', action='store_true', help='只解析不真实执行（用于核对 curl 提取）')
    args = ap.parse_args()

    if not os.path.exists(args.excel):
        print(f'[ERROR] 用例 Excel 不存在：{args.excel}')
        sys.exit(1)

    auth_param = '' if args.no_auth_param else args.auth_param

    cases = read_cases(args.excel)
    n_curl = sum(1 for c in cases if c['curl'])
    print(f'[INFO] 读到 {len(cases)} 条用例，其中 {n_curl} 条含 curl')
    if n_curl == 0:
        print('[ERROR] 没有可执行的 curl，请确认用例 Excel 含「执行命令(curl)」列')
        sys.exit(1)

    results = []
    for i, c in enumerate(cases, start=1):
        if args.dry_run:
            res = {'http_status': '', 'elapsed': '', 'body': '(dry-run 未执行)', 'error': ''}
        else:
            res = run_one(c['curl'], args.timeout, auth_param)
        res['verdict'], res['analysis'] = judge(c, res)
        results.append(res)
        print(f'  [{i}/{len(cases)}] {res["verdict"]:<10} {c["title"][:30]}')

    outdir = args.outdir or os.path.join(os.path.dirname(script_dir), '3-report')
    os.makedirs(outdir, exist_ok=True)

    stamp = resolve_ts(args.ts)
    fname = build_name('执行报告', args.doc, args.module, stamp, '.xlsx')
    xlsx_path = unique_path(os.path.join(outdir, fname))
    cnt = write_excel(cases, results, xlsx_path, os.path.splitext(fname)[0])
    print(f'[OK] Excel 报告：{xlsx_path}')
    print(f'[OK] 判定统计：{dict(cnt)}')
    print(f'[NEXT] 由 step3_gen_html_report.py 读该 Excel 生成 HTML → 3-report/reportHtml/')


if __name__ == '__main__':
    main()
