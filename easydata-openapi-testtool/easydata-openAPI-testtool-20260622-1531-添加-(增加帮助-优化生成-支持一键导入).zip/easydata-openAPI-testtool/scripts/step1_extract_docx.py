# -*- coding: utf-8 -*-
"""
step1_extract_docx.py —— step1·子步①（机械）：把 .docx 接口文档转成纯文本，供 AI 阅读。

设计原则：
  * 本脚本【不理解】文档语义，只负责"把 Word 变成可读文本"这一机械动作。
  * 接口的识别、入参出参的提取、用例的设计全部由 AI（读这份文本）完成，
    脚本绝不写死任何接口路径/字段名/版式假设——因为接口文档不是固定的。

提取规则（尽量保留结构，便于 AI 还原表格语义）：
  * 段落（w:p）→ 一行
  * 表格（w:tbl）→ 按行输出，单元格之间用 ` | ` 分隔，表格前后加分隔标记
  * 制表符 w:tab → \t
  * 软换行 w:br → 换行
  * 自动跳过纯空行（连续空行压成一行）

用法：
  python step1_extract_docx.py --docx "path/to/openapi.docx" [--out "path/to/out.txt"]
  # 不传 --out 时，默认输出到  ../1-input/序1-转纯文本-{docx名}-{年月日-时分秒}.txt
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import re
import html
import zipfile
import argparse
from datetime import datetime

W_NS = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'


def _para_text_from_xml(p_xml):
    """从单个 <w:p> 的 XML 片段抽取文本（保留 tab / 软换行）。"""
    s = p_xml
    s = s.replace('<w:tab/>', '\t').replace('<w:tab />', '\t')
    s = re.sub(r'<w:br[^>]*/>', '\n', s)
    s = re.sub(r'<[^>]+>', '', s)
    return html.unescape(s)


def extract(docx_path):
    """
    用 ElementTree 遍历 document.xml 的 body，按出现顺序输出段落与表格。
    表格行渲染成 `cell1 | cell2 | cell3`，便于 AI 还原"名称/类型/描述/必须/默认值"这类参数表。
    """
    from xml.etree import ElementTree as ET

    z = zipfile.ZipFile(docx_path)
    raw = z.read('word/document.xml').decode('utf-8')
    root = ET.fromstring(raw)
    body = root.find(f'{W_NS}body')
    if body is None:
        body = root

    lines = []

    def para_to_text(p):
        parts = []
        for node in p.iter():
            tag = node.tag
            if tag == f'{W_NS}t':
                parts.append(node.text or '')
            elif tag == f'{W_NS}tab':
                parts.append('\t')
            elif tag == f'{W_NS}br':
                parts.append('\n')
        return ''.join(parts)

    def cell_to_text(tc):
        cell_lines = []
        for p in tc.findall(f'{W_NS}p'):
            t = para_to_text(p).strip()
            if t:
                cell_lines.append(t)
        return ' '.join(cell_lines)

    for child in body:
        tag = child.tag
        if tag == f'{W_NS}p':
            txt = para_to_text(child).rstrip()
            lines.append(txt)
        elif tag == f'{W_NS}tbl':
            lines.append('[表格开始]')
            for tr in child.findall(f'{W_NS}tr'):
                cells = [cell_to_text(tc) for tc in tr.findall(f'{W_NS}tc')]
                lines.append(' | '.join(cells))
            lines.append('[表格结束]')

    # 压缩连续空行
    out = []
    blank = False
    for l in lines:
        if l.strip() == '':
            if not blank:
                out.append('')
            blank = True
        else:
            out.append(l)
            blank = False
    return '\n'.join(out)


def main():
    ap = argparse.ArgumentParser(description='把 .docx 接口文档转为纯文本（机械步骤，供 AI 阅读）')
    ap.add_argument('--docx', required=True, help='输入 .docx 文档路径')
    ap.add_argument('--out', help='输出 .txt 路径（默认 ../1-input/序1-转纯文本-{文件名}-{时间戳}.txt）')
    args = ap.parse_args()

    if not os.path.exists(args.docx):
        print(f'[ERROR] 文档不存在：{args.docx}')
        sys.exit(1)

    text = extract(args.docx)

    if args.out:
        out_path = args.out
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        in_dir = os.path.join(os.path.dirname(script_dir), '1-input')
        os.makedirs(in_dir, exist_ok=True)
        base = os.path.splitext(os.path.basename(args.docx))[0]
        # 命名规范：序1-转纯文本-{文件名}-{年月日-时分秒}.txt（时间戳精确到秒，天然防覆盖）
        ts = datetime.now().strftime('%Y%m%d-%H%M%S')
        out_path = os.path.join(in_dir, f'序1-转纯文本-{base}-{ts}.txt')

    # 显式 --out 时仍保留防覆盖：同名追加 -v{N}
    if os.path.exists(out_path):
        root_, ext_ = os.path.splitext(out_path)
        n = 1
        while os.path.exists(f'{root_}-v{n}{ext_}'):
            n += 1
        out_path = f'{root_}-v{n}{ext_}'

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(text)

    n_lines = len(text.split('\n'))
    n_tables = text.count('[表格开始]')
    print(f'[OK] 已提取文本：{out_path}')
    print(f'[OK] 行数：{n_lines}  表格数：{n_tables}')
    print('[NEXT] 由 AI 阅读该文本，识别接口清单 → 1-input/序2-接口清单-{文件名}-{时间戳}.md')


if __name__ == '__main__':
    main()
