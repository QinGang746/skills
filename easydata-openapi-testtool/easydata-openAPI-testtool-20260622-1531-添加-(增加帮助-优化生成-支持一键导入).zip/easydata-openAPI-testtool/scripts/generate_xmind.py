# -*- coding: utf-8 -*-
"""
XMind Test Case Generator - 优化版 v2
功能：
1. 解决中文乱码、支持特殊字符
2. 支持指定文件夹生成
3. 重名文件自动添加 v1、v2 版本号
4. 根节点不展示优先级图标
5. 支持模板文件
"""

import os
# Windows 上设置 UTF-8 编码，必须在导入其他模块之前
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import zipfile
import shutil
from datetime import datetime
import uuid
import re

def gen_id():
    """生成唯一 ID"""
    return uuid.uuid4().hex

def get_timestamp():
    """获取时间戳"""
    return str(int(datetime.now().timestamp() * 1000))

def escape_xml(text):
    """
    转义 XML 特殊字符 - 增强版
    支持中文和特殊字符
    """
    if not text:
        return ""
    
    # 确保是字符串
    text = str(text)
    
    # XML 特殊字符转义（顺序很重要，& 必须最先）
    text = (text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&apos;"))
    
    return text

def merge_items(items):
    """
    合并多个项目为一个字符串
    使用 1、2、换行格式，支持中文标点
    如果原始项目已自带序号前缀（如 "1、xxx"、"1. xxx"、"(1) xxx"），
    会先剥离再统一重新编号，避免出现 "1、1、xxx" 这种双重编号。
    """
    if not items:
        return ""

    result = ""
    for i, item in enumerate(items, 1):
        clean = strip_leading_number(str(item))
        result += f"{i}、{escape_xml(clean)}\n"

    return result.rstrip('\n')


# 匹配项目开头已有的序号前缀，仅剥离明确的编号格式，避免误伤"3 次失败"这类业务文本
# 支持：'1、xxx'、'1. xxx'、'1) xxx'、'1）xxx'、'(1) xxx'、'（1）xxx'
_LEADING_NUMBER_RE = re.compile(
    r'^\s*(?:'
    r'[（(]\s*\d+\s*[)）]'   # (1) 或 （1）
    r'|\d+\s*[、.．。:：)）]'  # 1、 / 1. / 1. / 1) / 1）
    r')\s*'
)


def strip_leading_number(text):
    """
    去除字符串开头已有的编号前缀，避免二次编号。
    仅剥离明确的编号格式（如 '1、' '1.' '1)' '(1)'），
    不会误伤"3 次登录失败"、"5 分钟内"等业务文本。
    """
    if not text:
        return text
    text = str(text)
    return _LEADING_NUMBER_RE.sub('', text, count=1).lstrip()

def get_unique_filename(filepath):
    """
    生成唯一文件名，避免覆盖已有文件
    如果文件已存在，自动添加 v1、v2、v3...（无空格）
    """
    # 确保路径是 Unicode 字符串
    filepath = str(filepath)
    
    if not os.path.exists(filepath):
        return filepath
    
    # 分离路径、文件名和扩展名
    directory = os.path.dirname(filepath)
    filename = os.path.basename(filepath)
    name, ext = os.path.splitext(filename)
    
    # 检查是否已有版本号，移除旧版本号（包括带空格和不带空格的）
    version_pattern = re.compile(r'_?v\d+$')
    base_name = version_pattern.sub('', name).rstrip('_').rstrip()
    
    # 从 v1 开始尝试（无空格）
    version = 1
    while True:
        new_filename = f"{base_name}v{version}{ext}"
        new_filepath = os.path.join(directory, new_filename)
        
        if not os.path.exists(new_filepath):
            return new_filepath
        
        version += 1

def load_template(template_path):
    """
    加载模板文件
    如果模板存在，读取其中的测试结构
    """
    if not os.path.exists(template_path):
        return None
    
    try:
        with zipfile.ZipFile(template_path, 'r') as zf:
            if 'content.xml' in zf.namelist():
                content = zf.read('content.xml').decode('utf-8')
                return content
    except Exception as e:
        print(f"加载模板失败：{e}")
    
    return None

def _build_case_xml(case_info, timestamp):
    """
    渲染单个测试用例节点（含优先级、前置/步骤/预期子节点）
    """
    case_name = case_info[0]
    priority = case_info[1] if len(case_info) > 1 else 'P1'
    preconditions = case_info[2] if len(case_info) > 2 else []
    steps = case_info[3] if len(case_info) > 3 else []
    expecteds = case_info[4] if len(case_info) > 4 else []

    # 优先级映射
    priority_num = {'P0': '1', 'P1': '2', 'P2': '3', 'P3': '4'}.get(priority, '2')
    marker_id = f'priority-{priority_num}'

    case_id = gen_id()
    children_xml = ""

    # 前置条件（带 √ 标记）
    if preconditions:
        prec_text = merge_items(preconditions)
        children_xml += f'<topic id="{gen_id()}" timestamp="{timestamp}"><title>{prec_text}</title><marker-refs><marker-ref marker-id="symbol-right"/></marker-refs></topic>'

    # 执行步骤（带 ? 标记）
    if steps:
        steps_text = merge_items(steps)
        children_xml += f'<topic id="{gen_id()}" timestamp="{timestamp}"><title>{steps_text}</title><marker-refs><marker-ref marker-id="symbol-question"/></marker-refs></topic>'

    # 预期结果（无标记）
    if expecteds:
        expected_text = merge_items(expecteds)
        children_xml += f'<topic id="{gen_id()}" timestamp="{timestamp}"><title>{expected_text}</title></topic>'

    return (
        f'<topic id="{case_id}" timestamp="{timestamp}">'
        f'<title>{escape_xml(case_name)}</title>'
        f'<marker-refs><marker-ref marker-id="{marker_id}"/><marker-ref marker-id="symbol-plus"/></marker-refs>'
        f'<children><topics type="attached">{children_xml}</topics></children>'
        f'</topic>'
    )


def _build_group_node_xml(title, inner_xml, timestamp):
    """渲染分组节点（带减号，无优先级）"""
    return (
        f'<topic id="{gen_id()}" timestamp="{timestamp}">'
        f'<title>{escape_xml(title)}</title>'
        f'<marker-refs><marker-ref marker-id="symbol-minus"/></marker-refs>'
        f'<children><topics type="attached">{inner_xml}</topics></children>'
        f'</topic>'
    )


def build_xmind_structure(test_structure):
    """
    构建 XMind 节点结构

    顶层 key 视作"分组层级 1"，二级再按其类型决定继续展开。
    支持三种形态：

    A) 三层 dict：{模块: {测试类型: [用例]}} —— 推荐
       渲染：模块（Suite）→ 测试类型（Suite）→ 用例
    B) 两层 dict + 模块：{测试类型: {模块: [用例]}} —— 老格式兼容
       渲染：测试类型（Suite）→ 模块（Suite）→ 用例
    C) 两层 dict + 扁平：{测试类型: [用例]} —— 兼容
       渲染：测试类型（Suite）→ 用例

    根节点不显示优先级图标，分组节点使用减号，用例节点使用加号。
    """
    timestamp = get_timestamp()
    groups_xml = ""

    for top_key, top_val in test_structure.items():
        # 分支 A 或 B：二级是 dict
        if isinstance(top_val, dict):
            sub_xml = ""
            for sub_key, sub_val in top_val.items():
                if not sub_val:
                    continue
                if isinstance(sub_val, (list, tuple)):
                    # 形态 A（top=模块, sub=测试类型）或 B（top=测试类型, sub=模块）
                    cases_xml = "".join(_build_case_xml(c, timestamp) for c in sub_val)
                    sub_xml += _build_group_node_xml(sub_key, cases_xml, timestamp)
                else:
                    print(f'[WARN] 跳过 "{top_key}/{sub_key}"：三级值类型 {type(sub_val).__name__} 不支持')

            if sub_xml:
                groups_xml += _build_group_node_xml(top_key, sub_xml, timestamp)

        # 分支 C：扁平用例列表
        elif isinstance(top_val, (list, tuple)):
            if not top_val:
                continue
            cases_xml = "".join(_build_case_xml(c, timestamp) for c in top_val)
            groups_xml += _build_group_node_xml(top_key, cases_xml, timestamp)

        else:
            print(f'[WARN] 跳过 "{top_key}"：不支持的数据类型 {type(top_val).__name__}')
            continue

    return groups_xml, timestamp

def generate_xmind(project_name, test_structure, output_dir=None, template_path=None):
    """
    生成 XMind 文件
    
    Args:
        project_name: 项目名称
        test_structure: 测试用例结构字典
            output_dir: 输出目录，默认 test-craft/output/
        template_path: 模板文件路径（可选）
    
    Returns:
        output_path: 生成的文件路径
    """
    # 默认输出到 test-craft/output/ 目录
    if output_dir is None:
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(skill_dir, 'output')
    
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成文件名 - 使用中文名称
    filename = f"{project_name}_测试用例.xmind"
    output_path = os.path.join(output_dir, filename)
    
    # 处理重名文件
    output_path = get_unique_filename(output_path)
    
    print(f'正在生成 XMind 文件...')
    print(f'项目名称：{project_name}')
    print(f'输出目录：{output_dir}')
    print(f'文件名称：{os.path.basename(output_path)}')
    
    # 构建 XMind 内容
    groups_xml, timestamp = build_xmind_structure(test_structure)
    
    # meta.xml - 紧凑单行格式
    create_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    meta_xml = (
        f'<?xml version="1.0" encoding="UTF-8" standalone="no"?>'
        f'<meta xmlns="urn:xmind:xmap:xmlns:meta:2.0" version="2.0">'
        f'<Creator><Name>XMind</Name><Version>R3.7.8.201807240049</Version></Creator>'
        f'<Thumbnail><Origin><X>197</X><Y>486</Y></Origin><BackgroundColor>#F3F4F9</BackgroundColor></Thumbnail>'
        f'<Create><Time>{create_time}</Time></Create>'
        f'</meta>'
    )
    
    # styles.xml - 使用与模板一致的 style-id
    root_style_id = gen_id()
    styles_xml = f'''<?xml version="1.0" encoding="UTF-8" standalone="no"?><xmap-styles xmlns="urn:xmind:xmap:xmlns:style:2.0" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:svg="http://www.w3.org/2000/svg" version="2.0"><styles><style id="{root_style_id}" type="topic"><topic-properties fo:text-align="left"/></style></styles></xmap-styles>'''
    
    # content.xml - 紧凑单行格式，与 XMind 原生格式一致
    sheet_id = gen_id()
    root_topic_id = gen_id()
    root_title = escape_xml(project_name + "_测试用例")
    content_xml = (
        f'<?xml version="1.0" encoding="UTF-8" standalone="no"?>'
        f'<xmap-content xmlns="urn:xmind:xmap:xmlns:content:2.0" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:svg="http://www.w3.org/2000/svg" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:xlink="http://www.w3.org/1999/xlink" modified-by="XMind" timestamp="{timestamp}" version="2.0">'
        f'<sheet id="{sheet_id}" modified-by="XMind" timestamp="{timestamp}">'
        f'<topic id="{root_topic_id}" structure-class="org.xmind.ui.logic.right" style-id="{root_style_id}" timestamp="{timestamp}">'
        f'<title>{root_title}</title>'
        f'<children><topics type="attached">{groups_xml}</topics></children>'
        f'<marker-refs><marker-ref marker-id="symbol-minus"/></marker-refs>'
        f'</topic>'
        f'<title>\u753b\u5e03 1</title>'
        f'</sheet>'
        f'</xmap-content>'
    )
    
    # manifest.xml - 紧凑单行格式
    manifest_xml = (
        '<?xml version="1.0" encoding="UTF-8" standalone="no"?>'
        '<manifest xmlns="urn:xmind:xmap:xmlns:manifest:1.0" password-hint="">'
        '<file-entry full-path="content.xml" media-type="text/xml"/>'
        '<file-entry full-path="META-INF/" media-type=""/>'
        '<file-entry full-path="META-INF/manifest.xml" media-type="text/xml"/>'
        '<file-entry full-path="meta.xml" media-type="text/xml"/>'
        '<file-entry full-path="styles.xml" media-type=""/>'
        '</manifest>'
    )

    # 写入 ZIP 文件（UTF-8 编码）
    # 使用 UTF-8 编码写入文件名和内容，确保中文正常显示
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        # 写入 META-INF/manifest.xml（必须在 content.xml 之前写入）
        manifest_info = zipfile.ZipInfo('META-INF/manifest.xml')
        manifest_info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(manifest_info, manifest_xml.encode('utf-8'))

        # 写入 meta.xml
        meta_info = zipfile.ZipInfo('meta.xml')
        meta_info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(meta_info, meta_xml.encode('utf-8'))

        # 写入 styles.xml
        styles_info = zipfile.ZipInfo('styles.xml')
        styles_info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(styles_info, styles_xml.encode('utf-8'))

        # 写入 content.xml
        content_info = zipfile.ZipInfo('content.xml')
        content_info.compress_type = zipfile.ZIP_DEFLATED
        zf.writestr(content_info, content_xml.encode('utf-8'))
    
    # 验证文件是否成功创建
    if os.path.exists(output_path):
        file_size = os.path.getsize(output_path)
        print(f'[OK] XMind 文件已成功生成：{output_path}')
        print(f'[OK] 文件大小：{file_size} 字节')
    else:
        print(f'[ERROR] 文件创建失败：{output_path}')
    
    # 验证 XML
    import xml.dom.minidom
    try:
        xml.dom.minidom.parseString(content_xml)
        print('[OK] XML 格式验证通过')
        case_count = content_xml.count('symbol-plus')
        print(f'[OK] 用例总数：{case_count}')
    except Exception as e:
        print(f'[ERROR] XML 格式错误：{e}')
    
    return output_path

# ==================== 主程序入口 ====================

if __name__ == '__main__':
    import argparse
    import json
    
    parser = argparse.ArgumentParser(description='XMind 测试用例生成器')
    parser.add_argument('--project', type=str, required=True, help='项目名称')
    parser.add_argument('--data', type=str, help='测试数据文件路径（Python 文件，需定义 test_structure 变量）')
    parser.add_argument('--json', type=str, help='测试数据 JSON 字符串（推荐，无需临时文件）')
    parser.add_argument('--cleanup', action='store_true', help='执行后删除 --data 指定的文件（临时文件清理）')
    parser.add_argument('--output', type=str, help='输出目录（默认：test-craft/output/）')
    parser.add_argument('--template', type=str, help='模板文件路径（可选）')
    
    args = parser.parse_args()
    
    # 确定测试数据结构
    test_structure = None
    
    # 1. 优先从 JSON 字符串加载（推荐方式）
    if args.json:
        try:
            test_structure = json.loads(args.json)
            print(f'[OK] JSON 数据解析成功')
        except json.JSONDecodeError as e:
            print(f'[ERROR] JSON 解析失败：{e}')
            exit(1)
    
    # 2. 从指定的数据文件加载
    elif args.data:
        if os.path.exists(args.data):
            # 动态导入测试数据文件
            temp_file_path = args.data  # 记录文件路径用于清理
            import importlib.util
            spec = importlib.util.spec_from_file_location("testcase_data", args.data)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            test_structure = getattr(module, 'test_structure', None)
            if not test_structure:
                print('[ERROR] 数据文件中未找到 test_structure 变量')
                exit(1)
        else:
            print(f'[ERROR] 数据文件不存在：{args.data}')
            exit(1)
    else:
        # 尝试从当前工作目录加载 testcase_data.py
        cwd = os.getcwd()
        data_file = os.path.join(cwd, 'testcase_data.py')
        if os.path.exists(data_file):
            import importlib.util
            spec = importlib.util.spec_from_file_location("testcase_data", data_file)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            test_structure = getattr(module, 'test_structure', None)
        
        # 如果当前目录没有，尝试从技能目录加载
        if not test_structure:
            skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            data_file = os.path.join(skill_dir, 'testcase_data.py')
            if os.path.exists(data_file):
                import importlib.util
                spec = importlib.util.spec_from_file_location("testcase_data", data_file)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                test_structure = getattr(module, 'test_structure', None)
        
        # 如果还是没有，使用默认示例数据
        if not test_structure:
            print('[INFO] 未找到测试数据文件，使用默认示例数据')
            test_structure = {
                # 功能测试：按模块分组（dict）
                '功能测试': {
                    '列表管理': [
                        ('列表展示 - 有数据状态', 'P0', ['已进入项目组配置页面'], ['查看授权人员列表'], ['列表正常展示人员信息', '显示邮箱、业务分组、备注等字段']),
                        ('搜索功能', 'P1', ['列表中已有授权人员数据'], ['输入搜索条件', '点击搜索按钮'], ['列表展示匹配的人员', '搜索结果准确']),
                    ],
                    '批量导入': [
                        ('批量导入 - 正常导入', 'P0', ['已准备符合格式的 Excel 文件'], ['上传填写好的 Excel 文件', '确认导入'], ['导入成功', '列表更新显示新导入的人员']),
                    ],
                },
                # 其他测试类型：扁平用例列表（list），不按模块分组
                '边界条件测试': [
                    ('邮箱格式 - 无@符号', 'P1', ['正在编辑或导入'], ['输入无@符号的邮箱'], ['实时提示邮箱格式错误']),
                ],
            }
    
    # 确定输出目录（默认 test-craft/output/）
    if args.output:
        output_dir = args.output
    else:
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        output_dir = os.path.join(skill_dir, 'output')
    
    # 确定模板路径
    template_path = args.template
    if not template_path:
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        template_path = os.path.join(skill_dir, 'template.xmind')
    
    # 检查模板是否存在
    if os.path.exists(template_path):
        print(f'[OK] 使用模板：{template_path}')
    else:
        print(f'[INFO] 未找到模板文件，使用默认结构')
        template_path = None
    
    # 执行生成
    try:
        output_path = generate_xmind(
            project_name=args.project,
            test_structure=test_structure,
            output_dir=output_dir,
            template_path=template_path
        )
        print(f'\n文件已保存：{output_path}')
    except Exception as e:
        print(f'[ERROR] 生成失败：{e}')
        import traceback
        traceback.print_exc()
        exit(1)
    finally:
        # 清理临时文件（当 --cleanup 参数指定时）
        if args.cleanup and args.data and os.path.exists(args.data):
            try:
                os.remove(args.data)
                print(f'[OK] 临时文件已清理：{args.data}')
            except Exception as e:
                print(f'[WARN] 清理临时文件失败：{e}')