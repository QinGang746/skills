# -*- coding: utf-8 -*-
"""
step2_gen_excel.py —— step2（机械）：读 AI 生成的 testcase_data.py，渲染 Excel 用例（按用例分类拆 sheet）。

设计原则：
  * 本脚本【不设计用例】，只把 AI 已设计好的 test_structure 渲染成 .xlsx。
  * 每个用例分类（test_structure 的二级 key，如 正向用例/参数校验用例）渲染成一个独立 sheet。
  * step2 只产 Excel（不再产 Markdown）。

testcase_data.py 需定义 test_structure（形态 A）：
  test_structure = {
    '接口模块名/接口名': {
        '正向用例': [(用例名, 优先级, [前置], [步骤], [预期], curl), ...],
        ...
    },
  }
  用例元组第 6 个元素 curl 必填。

输出命名：测试用例-{文件名}-{模块}-{时间戳}.xlsx，直接落 2-output/（不建子文件夹）。

用法：
  python step2_gen_excel.py --project "项目名" --data "testcase_data.py" \
      --doc v1.23.0 --module 大盘统计 [--ts 20260618-103307] [--cleanup]
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import argparse

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from generate_excel import generate_excel
from _common import load_structure, count_cases, build_name, resolve_ts


def main():
    ap = argparse.ArgumentParser(description='接口测试用例渲染器（仅 Excel）')
    ap.add_argument('--project', required=True, help='项目名/接口模块名（写入 Suite一）')
    ap.add_argument('--data', required=True, help='testcase_data.py 路径')
    ap.add_argument('--doc', default='', help='来源文档名，用于命名（如 v1.23.0）')
    ap.add_argument('--module', default='', help='模块名，用于命名（如 大盘统计）')
    ap.add_argument('--ts', default='', help='时间戳；默认沿用 1-input 的批次时间戳（序1文件名），再退回当前时刻')
    ap.add_argument('--output', help='输出目录（默认 ../2-output/，不再按项目分子文件夹）')
    ap.add_argument('--cleanup', action='store_true', help='渲染后删除 --data 文件')
    args = ap.parse_args()

    data_path = os.path.abspath(args.data)
    if not os.path.exists(data_path):
        print(f'[ERROR] 数据文件不存在：{data_path}')
        sys.exit(1)

    ts = load_structure(data_path)

    # 输出直接落 2-output/（按文件名 {模块}-{时间戳} 区分模块，不建子文件夹）
    out_dir = args.output or os.path.join(os.path.dirname(script_dir), '2-output')
    os.makedirs(out_dir, exist_ok=True)

    stamp = resolve_ts(args.ts)
    fname = build_name('测试用例', args.doc, args.module, stamp, '.xlsx')

    total = count_cases(ts)
    try:
        tpl = os.path.join(script_dir, 'template.xlsx')
        tpl = tpl if os.path.exists(tpl) else None
        xlsx = generate_excel(
            project_name=args.project,
            test_structure=ts,
            output_dir=out_dir,
            template_path=tpl,
            filename=fname,
        )
        print(f'[OK] Excel 已保存：{xlsx}')
        print(f'[OK] 用例总数：{total}')
    except Exception as e:
        print(f'[ERROR] 渲染失败：{e}')
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        if args.cleanup and os.path.exists(data_path):
            try:
                os.remove(data_path)
                print(f'[OK] 临时文件已清理：{data_path}')
            except Exception as e:
                print(f'[WARN] 清理失败：{e}')


if __name__ == '__main__':
    main()
