# -*- coding: utf-8 -*-
"""
step3_run_curl.py —— step3·子步①（机械）：执行用例里的 curl，产出 Excel 执行报告。

输入：step2 生成的用例 Excel（含「执行命令(curl)」列）。
做什么：
  1. 读 Excel，提取每条用例的标题/模块/分级/预期/curl 命令
  2. 逐条真实执行 curl（subprocess），捕获 HTTP 状态、响应体、耗时
  3. 依「响应体是否含 code:0 / HTTP 是否 2xx」做初步判定（PASS/FAIL/需人工复核）
  4. 产出 Excel 报告（汇总 Sheet + 明细 Sheet）

HTML 报告由 step3_gen_html_report.py 单独从本步 Excel 生成（职责分离）。
判定为辅助参考，不替代人工复核（异常/校验用例预期本就返回错误码）。

输出命名：执行报告-{文件名}-{模块}-{时间戳}.xlsx，落 3-report/。

用法：
  python step3_run_curl.py --excel "../2-output/{项目}/测试用例-xxx.xlsx" \
      --doc v1.23.0 --module 大盘统计 [--ts ...] [--outdir 目录] [--timeout 20]
  # 默认给每条 curl 兜底注入鉴权参数 authType=TEST（网关从请求参数读取）：
  #   GET 拼 query、POST 拼进 JSON body，已带同名参数则不重复；
  #   --auth-param "x=y" 改用别的参数；--no-auth-param 关闭注入

依赖：curl 命令行（系统自带）；openpyxl。
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import re
import shlex
import argparse
import subprocess

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from _common import read_cases, unique_path, build_name, resolve_ts

# 判定着色（与 HTML 报告脚本共享同一套色值约定）
STATUS_COLOR = {
    'PASS': 'C6EFCE', 'PASS(预期)': 'D9EAD3', 'FAIL': 'FFC7CE',
    'ERROR': 'FFC7CE', 'SKIP': 'D9D9D9', '需人工复核': 'FFEB9C',
}


def _inject_auth_param(argv, name, value):
    """
    把鉴权参数（name=value，默认 authType=TEST）兜底注入到 curl 的参数列表。
    网关从请求参数（非 header）读取，故按请求类型注入：
      * 有 -d/--data（POST/JSON）→ 注入进 JSON body 的顶层；body 已含该 key 则不动
      * 否则视为 GET → 拼到 URL 的 query string；URL 已含该 key 则不动
    """
    import json as _json

    joined = ' '.join(argv)
    has_in_query = bool(re.search(rf'[?&]{re.escape(name)}=', joined))

    data_idx = None
    for i, a in enumerate(argv):
        if a in ('-d', '--data', '--data-raw', '--data-binary') and i + 1 < len(argv):
            data_idx = i + 1
            break

    if data_idx is not None:
        body = argv[data_idx]
        try:
            obj = _json.loads(body)
            if isinstance(obj, dict):
                if name not in obj:
                    obj[name] = value
                    argv[data_idx] = _json.dumps(obj, ensure_ascii=False)
                return argv
        except Exception:
            pass
        if f'{name}=' not in body:
            argv[data_idx] = body + (f'&{name}={value}' if body else f'{name}={value}')
        return argv

    if has_in_query:
        return argv
    for i, a in enumerate(argv):
        if a.startswith('http://') or a.startswith('https://'):
            sep = '&' if '?' in a else '?'
            argv[i] = f'{a}{sep}{name}={value}'
            break
    return argv


def run_one(curl_cmd, timeout, auth_param='authType=TEST'):
    """执行单条 curl，返回 dict：http_status, elapsed, body, error。"""
    if not curl_cmd:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': '无 curl 命令'}

    marker = '___HTTP_META___'
    try:
        argv = shlex.split(curl_cmd, posix=True)
    except ValueError as e:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'命令解析失败：{e}'}

    argv = [a for a in argv if a != '-i']

    if auth_param and '=' in auth_param:
        name, value = auth_param.split('=', 1)
        argv = _inject_auth_param(argv, name.strip(), value.strip())

    argv += ['-s', '-w', f'{marker}%{{http_code}}|%{{time_total}}']

    try:
        proc = subprocess.run(argv, shell=False, capture_output=True, timeout=timeout)
        out = (proc.stdout or b'').decode('utf-8', errors='replace')
        err = (proc.stderr or b'').decode('utf-8', errors='replace')
        http_status, elapsed = '', ''
        if marker in out:
            body, meta = out.rsplit(marker, 1)
            parts = meta.split('|')
            http_status = parts[0].strip() if parts else ''
            elapsed = parts[1].strip() if len(parts) > 1 else ''
        else:
            body = out
        error = '' if proc.returncode == 0 else (err.strip() or f'curl 退出码 {proc.returncode}')
        return {'http_status': http_status, 'elapsed': elapsed, 'body': body.strip(), 'error': error}
    except FileNotFoundError:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': 'curl 未安装或不在 PATH'}
    except subprocess.TimeoutExpired:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'超时(>{timeout}s)'}
    except Exception as e:
        return {'http_status': '', 'elapsed': '', 'body': '', 'error': f'执行异常：{e}'}


def judge(case, res):
    """初步判定：SKIP/ERROR/PASS/PASS(预期)/需人工复核。"""
    if not case['curl']:
        return 'SKIP'
    if res['error']:
        return 'ERROR'
    body = res['body'] or ''
    is_ok_code = bool(re.search(r'"code"\s*:\s*0', body))
    http2xx = str(res['http_status']).startswith('2')
    is_negative = any(k in (case['type'] or '') for k in ('校验', '异常', '安全', '边界'))

    if http2xx and is_ok_code:
        return 'PASS'
    if is_negative:
        if body or http2xx:
            return 'PASS(预期)'
    return '需人工复核'


def write_excel(cases, results, out_path, source_name):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from collections import Counter

    wb = Workbook()

    ws0 = wb.active
    ws0.title = '执行汇总'
    cnt = Counter(r['verdict'] for r in results)
    ws0.append(['执行报告', source_name])
    ws0.append(['用例总数', len(results)])
    for k in ['PASS', 'PASS(预期)', 'FAIL', 'ERROR', '需人工复核', 'SKIP']:
        ws0.append([k, cnt.get(k, 0)])
    ws0.column_dimensions['A'].width = 16
    ws0.column_dimensions['B'].width = 60
    ws0['A1'].font = Font(bold=True, size=13)

    ws = wb.create_sheet('执行明细')
    headers = ['#', '模块', '类型', '用例标题', '分级', 'HTTP状态', '耗时(s)',
               '执行命令(curl)', '响应体', '预期结果', '判定', '错误信息', '人工复核']
    ws.append(headers)
    for ci, _ in enumerate(headers, start=1):
        ws.cell(row=1, column=ci).font = Font(bold=True, color='FFFFFF')
        ws.cell(row=1, column=ci).fill = PatternFill('solid', fgColor='2F5496')

    wrap = Alignment(wrap_text=True, vertical='top')
    for i, (c, r) in enumerate(zip(cases, results), start=1):
        row = [i, c['module'], c['type'], c['title'], c['priority'],
               r['http_status'], r['elapsed'], c['curl'],
               r['body'][:2000], c['expected'], r['verdict'], r['error'], '']
        ws.append(row)
        ri = ws.max_row
        for ci in (8, 9, 10):
            ws.cell(row=ri, column=ci).alignment = wrap
        vcell = ws.cell(row=ri, column=11)
        color = STATUS_COLOR.get(r['verdict'])
        if color:
            vcell.fill = PatternFill('solid', fgColor=color)
        ws.cell(row=ri, column=13).fill = PatternFill('solid', fgColor='FFF2CC')

    widths = {1: 5, 2: 22, 3: 14, 4: 34, 5: 8, 6: 10, 7: 9,
              8: 60, 9: 50, 10: 36, 11: 12, 12: 24, 13: 16}
    for ci, w in widths.items():
        ws.column_dimensions[get_column_letter(ci)].width = w

    wb.save(out_path)
    return cnt


def main():
    ap = argparse.ArgumentParser(description='执行用例 curl 并生成 Excel 执行报告')
    ap.add_argument('--excel', required=True, help='用例 Excel（含 执行命令(curl) 列，默认在 2-output/{项目}/ 下）')
    ap.add_argument('--doc', default='', help='来源文档名，用于命名（如 v1.23.0）')
    ap.add_argument('--module', default='', help='模块名，用于命名（如 大盘统计）')
    ap.add_argument('--ts', default='', help='时间戳；默认沿用 1-input 的批次时间戳（序1文件名），再退回当前时刻')
    ap.add_argument('--outdir', help='报告输出目录（默认 ../3-report/）')
    ap.add_argument('--timeout', type=int, default=20, help='单条 curl 超时秒数，默认20')
    ap.add_argument('--auth-param', default='authType=TEST',
                    help='执行时兜底注入的鉴权参数，默认 "authType=TEST"；GET 拼 query、POST 拼 body，已带则不重复')
    ap.add_argument('--no-auth-param', action='store_true', help='不注入任何鉴权参数')
    ap.add_argument('--dry-run', action='store_true', help='只解析不真实执行（用于核对 curl 提取）')
    args = ap.parse_args()

    if not os.path.exists(args.excel):
        print(f'[ERROR] 用例 Excel 不存在：{args.excel}')
        sys.exit(1)

    auth_param = '' if args.no_auth_param else args.auth_param

    cases = read_cases(args.excel)
    n_curl = sum(1 for c in cases if c['curl'])
    print(f'[INFO] 读到 {len(cases)} 条用例，其中 {n_curl} 条含 curl')
    if n_curl == 0:
        print('[ERROR] 没有可执行的 curl，请确认用例 Excel 含「执行命令(curl)」列')
        sys.exit(1)

    results = []
    for i, c in enumerate(cases, start=1):
        if args.dry_run:
            res = {'http_status': '', 'elapsed': '', 'body': '(dry-run 未执行)', 'error': ''}
        else:
            res = run_one(c['curl'], args.timeout, auth_param)
        res['verdict'] = judge(c, res)
        results.append(res)
        print(f'  [{i}/{len(cases)}] {res["verdict"]:<10} {c["title"][:30]}')

    outdir = args.outdir or os.path.join(os.path.dirname(script_dir), '3-report')
    os.makedirs(outdir, exist_ok=True)

    stamp = resolve_ts(args.ts)
    fname = build_name('执行报告', args.doc, args.module, stamp, '.xlsx')
    xlsx_path = unique_path(os.path.join(outdir, fname))
    cnt = write_excel(cases, results, xlsx_path, os.path.splitext(fname)[0])
    print(f'[OK] Excel 报告：{xlsx_path}')
    print(f'[OK] 判定统计：{dict(cnt)}')
    print(f'[NEXT] 由 step3_gen_html_report.py 读该 Excel 生成 HTML → 3-report/reportHtml/')


if __name__ == '__main__':
    main()
