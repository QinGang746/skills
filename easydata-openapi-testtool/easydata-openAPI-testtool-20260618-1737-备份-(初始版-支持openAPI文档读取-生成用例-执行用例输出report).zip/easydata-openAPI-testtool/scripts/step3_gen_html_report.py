# -*- coding: utf-8 -*-
"""
step3_gen_html_report.py —— step3·子步②（机械）：把 step3_run_curl.py 产出的 Excel 执行报告渲染成 HTML。

设计原则：
  * 与执行解耦——本脚本【不发请求】，只读已有的 Excel 报告，转成可视化 HTML。
  * 这样 HTML 样式调整、重新出图都不必重跑 curl。

输入：3-report/执行报告-{...}.xlsx（step3_run_curl.py 的产物，含「执行汇总」「执行明细」两个 Sheet）。
输出：3-report/reportHtml/执行报告-{...}.html（文件名沿用来源 Excel 的 base 名）。

用法：
  python step3_gen_html_report.py --excel "../3-report/执行报告-v1.23.0-大盘统计-{ts}.xlsx" [--outdir 目录]
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import sys
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import html
import argparse

script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

from _common import unique_path

STATUS_COLOR = {
    'PASS': 'C6EFCE', 'PASS(预期)': 'D9EAD3', 'FAIL': 'FFC7CE',
    'ERROR': 'FFC7CE', 'SKIP': 'D9D9D9', '需人工复核': 'FFEB9C',
}
VERDICTS = ['PASS', 'PASS(预期)', 'FAIL', 'ERROR', '需人工复核', 'SKIP']


def read_report(excel_path):
    """读执行报告 Excel 的「执行明细」Sheet，返回 (rows, counts)。"""
    from openpyxl import load_workbook
    from collections import Counter
    wb = load_workbook(excel_path, data_only=True)
    ws = wb['执行明细'] if '执行明细' in wb.sheetnames else wb.worksheets[-1]

    header = {}
    for ci, cell in enumerate(ws[1], start=1):
        if cell.value:
            header[str(cell.value).strip()] = ci

    def gi(row, name):
        ci = header.get(name)
        return row[ci - 1] if ci and ci - 1 < len(row) else ''

    rows, cnt = [], Counter()
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not gi(row, '用例标题'):
            continue
        verdict = str(gi(row, '判定') or '')
        cnt[verdict] += 1
        rows.append({
            'module': gi(row, '模块') or '', 'type': gi(row, '类型') or '',
            'title': gi(row, '用例标题') or '', 'priority': gi(row, '分级') or '',
            'http_status': gi(row, 'HTTP状态') or '', 'elapsed': gi(row, '耗时(s)') or '',
            'verdict': verdict, 'body': gi(row, '响应体') or '',
            'expected': gi(row, '预期结果') or '', 'curl': gi(row, '执行命令(curl)') or '',
            'error': gi(row, '错误信息') or '',
        })
    return rows, cnt


def render_html(rows, cnt, source_name):
    rows_html = []
    for i, r in enumerate(rows, start=1):
        color = '#' + STATUS_COLOR.get(r['verdict'], 'FFFFFF')
        rows_html.append(f"""
        <tr>
          <td>{i}</td>
          <td>{html.escape(str(r['module']))}</td>
          <td>{html.escape(str(r['type']))}</td>
          <td>{html.escape(str(r['title']))}</td>
          <td>{html.escape(str(r['priority']))}</td>
          <td>{html.escape(str(r['http_status']))}</td>
          <td>{html.escape(str(r['elapsed']))}</td>
          <td style="background:{color};font-weight:bold">{html.escape(str(r['verdict']))}</td>
          <td><pre>{html.escape(str(r['body'])[:1500])}</pre></td>
          <td><pre>{html.escape(str(r['expected']))}</pre></td>
          <td><pre>{html.escape(str(r['curl']))}</pre></td>
          <td>{html.escape(str(r['error']))}</td>
        </tr>""")

    cards = ''.join(
        f'<div class="card"><div class="num">{cnt.get(k,0)}</div><div class="lbl">{k}</div></div>'
        for k in VERDICTS
    )

    return f"""<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">
<title>接口执行报告 - {html.escape(source_name)}</title>
<style>
body{{font-family:'Microsoft YaHei',Arial,sans-serif;margin:24px;color:#222;background:#f7f8fa}}
h1{{font-size:20px}} h2{{font-size:16px;margin-top:24px}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}}
.card{{background:#fff;border:1px solid #e0e0e0;border-radius:8px;padding:14px 22px;text-align:center;min-width:90px}}
.card .num{{font-size:26px;font-weight:bold}} .card .lbl{{font-size:12px;color:#666;margin-top:4px}}
table{{border-collapse:collapse;width:100%;background:#fff;font-size:12px}}
th,td{{border:1px solid #ddd;padding:6px 8px;vertical-align:top;text-align:left}}
th{{background:#2F5496;color:#fff;position:sticky;top:0}}
pre{{margin:0;white-space:pre-wrap;word-break:break-all;max-width:420px;font-size:11px}}
</style></head><body>
<h1>接口执行报告</h1>
<p>来源用例：{html.escape(source_name)} ｜ 用例总数：{len(rows)}</p>
<div class="cards">{cards}</div>
<h2>执行明细</h2>
<table>
<thead><tr><th>#</th><th>模块</th><th>类型</th><th>用例标题</th><th>分级</th>
<th>HTTP</th><th>耗时</th><th>判定</th><th>响应体</th><th>预期</th><th>curl</th><th>错误</th></tr></thead>
<tbody>{''.join(rows_html)}</tbody>
</table>
<p style="color:#888;margin-top:16px">判定为自动初判，异常/校验类用例请结合预期人工复核。</p>
</body></html>"""


def main():
    ap = argparse.ArgumentParser(description='把 Excel 执行报告渲染成 HTML')
    ap.add_argument('--excel', required=True, help='step3_run_curl.py 产出的执行报告 Excel')
    ap.add_argument('--outdir', help='HTML 输出目录（默认 ../3-report/reportHtml/）')
    args = ap.parse_args()

    if not os.path.exists(args.excel):
        print(f'[ERROR] 执行报告 Excel 不存在：{args.excel}')
        sys.exit(1)

    rows, cnt = read_report(args.excel)
    if not rows:
        print('[ERROR] Excel 里未读到执行明细行')
        sys.exit(1)

    base = os.path.splitext(os.path.basename(args.excel))[0]
    outdir = args.outdir or os.path.join(os.path.dirname(script_dir), '3-report', 'reportHtml')
    os.makedirs(outdir, exist_ok=True)

    html_path = unique_path(os.path.join(outdir, f'{base}.html'))
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(render_html(rows, cnt, base))
    print(f'[OK] HTML 报告：{html_path}')
    print(f'[OK] 判定统计：{dict(cnt)}')


if __name__ == '__main__':
    main()
