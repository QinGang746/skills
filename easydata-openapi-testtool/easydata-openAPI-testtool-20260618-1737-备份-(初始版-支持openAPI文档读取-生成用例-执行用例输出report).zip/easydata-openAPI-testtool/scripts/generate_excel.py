# -*- coding: utf-8 -*-
"""
Excel Test Case Generator
按 template.xlsx 模板格式输出测试用例。

模板列结构（第 1 行表头）：
  A  用例Suite一    -> 项目名称
  B  用例Suite二    -> 模块名（顶层 key；扁平 list 形态留空）
  C  用例Suite三    -> 测试类型（功能测试/边界条件测试/...）
  D  用例Suite四    -> 预留空
  E  用例Suite五    -> 预留空
  F  用例标题       -> 用例名称
  G  用例分级       -> P0/P1/P2/P3
  H  用例Tag        -> 留空
  I  前置条件       -> 多条用 1、xxx\n2、xxx 合并
  J  执行步骤       -> 同上
  K  预期结果       -> 同上
  L  备注           -> 留空

公共逻辑与 generate_xmind.py 保持一致：
- 同样支持两种 value 形态：dict[str, list[tuple]] / list[tuple]
- 同样的 strip_leading_number / merge_items 编号合并规则
- 同样的 get_unique_filename 重名版本号
"""

import os
if os.name == 'nt':
    os.environ['PYTHONUTF8'] = '1'
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import re

# 复用 xmind 脚本里的 strip_leading_number 逻辑，避免重复实现
from generate_xmind import strip_leading_number, get_unique_filename


HEADERS = [
    '用例Suite一', '用例Suite二', '用例Suite三', '用例Suite四', '用例Suite五',
    '用例标题', '用例分级', '用例Tag',
    '前置条件', '执行步骤', '预期结果', '备注',
]


def merge_lines(items):
    """
    与 xmind 的 merge_items 等价，但不做 XML 转义（excel 直接写文本）。
    """
    if not items:
        return ''
    lines = []
    for i, item in enumerate(items, 1):
        clean = strip_leading_number(str(item))
        lines.append(f'{i}、{clean}')
    return '\n'.join(lines)


def _normalize_priority(priority):
    p = str(priority).strip().upper() if priority else ''
    return p if p in {'P0', 'P1', 'P2', 'P3'} else 'P1'


def _iter_rows(project_name, test_structure):
    """
    遍历 test_structure，按行产出 dict（key = 表头）
    Suite 映射（默认）：
      Suite一 = project_name
      Suite二 = module_name（顶层 key；扁平 list 形态留空）
      Suite三 = test_type（测试类型）
      Suite四/五 = 预留空

    支持三种顶层形态：
      A) 三层 dict：{模块: {测试类型: [用例]}}  —— 推荐
      B) 两层 dict：{测试类型: [用例]}          —— 兼容老格式，模块留空
      C) 两层 dict：{测试类型: {模块: [用例]}}  —— 兼容老格式（自动翻转：把模块上提）
    """
    for top_key, top_val in test_structure.items():
        if isinstance(top_val, dict):
            # 判断是 A 还是 C：看二级值的类型
            sample_val = next(iter(top_val.values()), None)
            if isinstance(sample_val, (list, tuple)):
                # 形态 A：top_key = 模块名，二级 = {测试类型: [用例]}
                module_name = top_key
                for test_type, cases in top_val.items():
                    if not cases:
                        continue
                    for case in cases:
                        yield _row_from_case(project_name, module_name, test_type, case)
            elif isinstance(sample_val, dict):
                # 形态 C（老格式）：{测试类型: {模块: [用例]}} —— 自动翻转
                test_type = top_key
                for module_name, cases in top_val.items():
                    if not cases:
                        continue
                    for case in cases:
                        yield _row_from_case(project_name, module_name, test_type, case)
            else:
                print(f'[WARN] 跳过 "{top_key}"：二级值类型 {type(sample_val).__name__} 不支持')
        elif isinstance(top_val, (list, tuple)):
            # 形态 B：{测试类型: [用例]} —— 老的扁平形态，模块留空
            if not top_val:
                continue
            test_type = top_key
            for case in top_val:
                yield _row_from_case(project_name, '', test_type, case)
        else:
            print(f'[WARN] 跳过 "{top_key}"：不支持的数据类型 {type(top_val).__name__}')


def _row_from_case(project_name, module_name, test_type, case):
    case_name = case[0] if len(case) > 0 else ''
    priority = case[1] if len(case) > 1 else 'P1'
    preconditions = case[2] if len(case) > 2 else []
    steps = case[3] if len(case) > 3 else []
    expecteds = case[4] if len(case) > 4 else []
    # 第 6 个元素（可选）：该用例的可直接复制运行的完整 curl 命令（原样保留，不做编号合并）
    curl_cmd = case[5] if len(case) > 5 else ''

    return {
        '用例Suite一': project_name,
        '用例Suite二': module_name or '',
        '用例Suite三': test_type,
        '用例Suite四': '',
        '用例Suite五': '',
        '用例标题': str(case_name),
        '用例分级': _normalize_priority(priority),
        '用例Tag': '',
        '前置条件': merge_lines(preconditions),
        '执行步骤': merge_lines(steps),
        '预期结果': merge_lines(expecteds),
        '备注': '',
        '执行命令(curl)': str(curl_cmd or ''),
    }


def generate_excel(project_name, test_structure, output_dir=None, template_path=None, filename=None):
    """
    生成 Excel 测试用例文件。

    Args:
        project_name: 项目名称
        test_structure: 测试用例结构（与 generate_xmind 一致）
        output_dir: 输出目录，默认 test-craft/output/
        template_path: 模板 xlsx 路径，默认 test-craft/template.xlsx

    Returns:
        output_path: 生成的 .xlsx 文件路径
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment
    except ImportError:
        raise RuntimeError('缺少依赖 openpyxl，请先执行：pip install openpyxl')

    # 输出目录
    if output_dir is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_dir = os.path.join(os.path.dirname(script_dir), 'output')
    os.makedirs(output_dir, exist_ok=True)

    # 输出文件名（caller 可通过 filename 指定，否则用默认 {项目}_测试用例.xlsx）
    # 注：本生成器现按用例分类拆多 sheet，不再复用单 sheet 模板（template_path 已弃用）
    if filename:
        filename = filename if filename.lower().endswith('.xlsx') else f'{filename}.xlsx'
    else:
        filename = f'{project_name}_测试用例.xlsx'
    output_path = os.path.join(output_dir, filename)

    # 按「用例分类」(Suite三/test_type) 拆分 sheet：每个分类一个 sheet
    rows = list(_iter_rows(project_name, test_structure))
    has_curl = any(r.get('执行命令(curl)') for r in rows)
    headers = list(HEADERS) + (['执行命令(curl)'] if has_curl else [])

    # 分组：保持出现顺序
    from collections import OrderedDict
    groups = OrderedDict()
    for r in rows:
        cat = (r.get('用例Suite三') or '其他').strip() or '其他'
        groups.setdefault(cat, []).append(r)

    def _safe_sheet_name(name, used):
        # Excel sheet 名限制：<=31 字符，不含 []:*?/\
        for ch in '[]:*?/\\':
            name = name.replace(ch, '_')
        name = name[:31] or 'Sheet'
        base, n = name, 1
        while name in used:
            suffix = f'_{n}'
            name = base[:31 - len(suffix)] + suffix
            n += 1
        used.add(name)
        return name

    wrap_align = Alignment(wrap_text=True, vertical='top')
    wide_cols = ('前置条件', '执行步骤', '预期结果', '执行命令(curl)')
    width_map = {
        '用例Suite一': 24, '用例Suite二': 30, '用例Suite三': 16,
        '用例Suite四': 14, '用例Suite五': 14,
        '用例标题': 36, '用例分级': 10, '用例Tag': 14,
        '前置条件': 40, '执行步骤': 50, '预期结果': 40, '备注': 16,
        '执行命令(curl)': 70,
    }

    print(f'正在生成 Excel 文件...')
    print(f'项目名称：{project_name}')
    print(f'输出目录：{output_dir}')

    # 多 sheet 结构不复用单 sheet 模板，直接新建 workbook
    wb = Workbook()
    wb.remove(wb.active)
    from openpyxl.utils import get_column_letter
    used_names = set()
    case_count = 0
    for cat, cat_rows in groups.items():
        ws = wb.create_sheet(_safe_sheet_name(cat, used_names))
        # 表头
        for ci, h in enumerate(headers, start=1):
            ws.cell(row=1, column=ci, value=h)
        # 数据行
        ri = 2
        for row_data in cat_rows:
            for ci, h in enumerate(headers, start=1):
                value = row_data.get(h, '')
                cell = ws.cell(row=ri, column=ci, value=value)
                if h in wide_cols and value:
                    cell.alignment = wrap_align
            ri += 1
            case_count += 1
        # 列宽
        for ci, h in enumerate(headers, start=1):
            w = width_map.get(h)
            if w:
                ws.column_dimensions[get_column_letter(ci)].width = w

    output_path = get_unique_filename(output_path)
    print(f'文件名称：{os.path.basename(output_path)}')
    wb.save(output_path)

    if os.path.exists(output_path):
        size = os.path.getsize(output_path)
        print(f'[OK] Excel 文件已成功生成：{output_path}')
        print(f'[OK] 文件大小：{size} 字节')
        print(f'[OK] 分类(sheet)数：{len(groups)}')
        print(f'[OK] 用例总数：{case_count}')
    else:
        print(f'[ERROR] 文件创建失败：{output_path}')

    return output_path


if __name__ == '__main__':
    import argparse
    import sys

    parser = argparse.ArgumentParser(description='Excel 测试用例生成器')
    parser.add_argument('--project', type=str, required=True, help='项目名称')
    parser.add_argument('--data', type=str, help='测试数据文件路径（Python 文件，需定义 test_structure）')
    parser.add_argument('--output', type=str, help='输出目录（默认：test-craft/output/）')
    parser.add_argument('--template', type=str, help='模板 xlsx 路径（默认：test-craft/template.xlsx）')

    args = parser.parse_args()

    test_structure = None
    if args.data and os.path.exists(args.data):
        import importlib.util
        spec = importlib.util.spec_from_file_location('testcase_data', args.data)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        test_structure = getattr(module, 'test_structure', None)

    if not test_structure:
        print('[ERROR] 缺少 test_structure，请通过 --data 指定数据文件')
        sys.exit(1)

    generate_excel(
        project_name=args.project,
        test_structure=test_structure,
        output_dir=args.output,
        template_path=args.template,
    )
