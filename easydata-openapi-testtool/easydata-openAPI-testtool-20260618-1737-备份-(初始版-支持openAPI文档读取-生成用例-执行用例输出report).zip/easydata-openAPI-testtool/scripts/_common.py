# -*- coding: utf-8 -*-
"""
_common.py —— step4/step5 系列脚本共用的工具函数（命名、防覆盖、用例数据加载、Excel 读取）。

放这里是为了让拆分后的各 step 脚本「职责分离但不重复实现」：
  * 命名规范 build_name() 单点定义，改格式只改一处
  * _unique / _load_structure / _count_cases / read_cases 多脚本共用
"""

import os
import re
import sys
import glob
import importlib.util
from datetime import datetime


def now_ts():
    """当前时间戳：年月日-时分秒。"""
    return datetime.now().strftime('%Y%m%d-%H%M%S')


_TS_RE = re.compile(r'(\d{8}-\d{6})')


def parse_ts(name):
    """从文件名里抽出 年月日-时分秒 时间戳，没有则返回 None。"""
    m = _TS_RE.search(str(name))
    return m.group(1) if m else None


def batch_ts(input_dir=None):
    """
    取整条管线的「批次时间戳」——以 1-input 里 序1-转纯文本 文件名中的时间戳为准，
    使下游 1-input(序4-curl) / 2-output / 3-report 全部沿用同一个时间戳。
    找不到序1时退而取 1-input 下任意带时间戳的文件；再找不到返回 None（调用方回退到 now_ts）。
    """
    if input_dir is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        input_dir = os.path.join(os.path.dirname(script_dir), '1-input')
    # 优先 序1-转纯文本
    cands = sorted(glob.glob(os.path.join(input_dir, '序1-转纯文本-*')))
    if not cands:
        cands = sorted(glob.glob(os.path.join(input_dir, '*')))
    for f in cands:
        ts = parse_ts(os.path.basename(f))
        if ts:
            return ts
    return None


def resolve_ts(explicit_ts):
    """
    决定本次产物用的时间戳：
      1. 命令行显式 --ts 优先
      2. 否则沿用 1-input 的批次时间戳
      3. 都没有则用当前时刻
    """
    if explicit_ts:
        return explicit_ts
    return batch_ts() or now_ts()


def build_name(kind, doc, module, ts=None, ext=''):
    """
    统一命名：{类型}-{文件名}-{模块}-{时间戳}{ext}
      kind   类型，如 'curl案例' / '测试用例' / '接口测试用例' / '执行报告'
      doc    来源文档名（文件名），如 v1.23.0
      module 模块名，如 大盘统计
      ts     时间戳；None 则取当前时刻
      ext    扩展名，如 '.xlsx' / '.md' / '.html'（含点）
    缺省的段用占位，避免出现连续分隔符。
    """
    ts = ts or now_ts()
    parts = [kind, doc or '未命名', module or '通用', ts]
    return '-'.join(p for p in parts) + ext


def unique_path(path):
    """同名追加 -v{N}，防覆盖。"""
    if not os.path.exists(path):
        return path
    root_, ext_ = os.path.splitext(path)
    n = 1
    while os.path.exists(f'{root_}-v{n}{ext_}'):
        n += 1
    return f'{root_}-v{n}{ext_}'


def load_structure(data_path):
    """从 testcase_data.py 加载 test_structure。"""
    spec = importlib.util.spec_from_file_location('testcase_data', data_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ts = getattr(module, 'test_structure', None)
    if not ts:
        print('[ERROR] 数据文件中未找到 test_structure 变量')
        sys.exit(1)
    return ts


def count_cases(ts):
    """统计用例总数。"""
    n = 0
    for mod, types in ts.items():
        if isinstance(types, dict):
            for t, cases in types.items():
                if isinstance(cases, (list, tuple)):
                    n += len(cases)
        elif isinstance(types, (list, tuple)):
            n += len(types)
    return n


def read_cases(excel_path):
    """
    读用例 Excel，返回 [{module,type,title,priority,expected,curl}]。
    兼容两种结构：
      * 多 sheet（按用例分类拆分，step2 当前产物）——遍历所有含「用例标题」表头的 sheet
      * 单 sheet（名为「测试用例」或首个 sheet，旧产物）
    """
    from openpyxl import load_workbook
    wb = load_workbook(excel_path, data_only=True)

    def _read_sheet(ws):
        header = {}
        for ci, cell in enumerate(ws[1], start=1):
            if cell.value:
                header[str(cell.value).strip()] = ci
        if '用例标题' not in header:
            return []  # 非用例 sheet（如说明页），跳过
        out = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            def get(name):
                ci = header.get(name)
                return row[ci - 1] if ci and ci - 1 < len(row) else None
            title = get('用例标题')
            if not title:
                continue
            out.append({
                'module': get('用例Suite二') or '',
                'type': get('用例Suite三') or '',
                'title': title,
                'priority': get('用例分级') or '',
                'expected': get('预期结果') or '',
                'curl': (get('执行命令(curl)') or '').strip(),
            })
        return out

    cases = []
    for ws in wb.worksheets:
        cases.extend(_read_sheet(ws))
    return cases
