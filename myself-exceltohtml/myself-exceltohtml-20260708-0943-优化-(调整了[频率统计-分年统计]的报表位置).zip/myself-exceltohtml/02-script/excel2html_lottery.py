# -*- coding: utf-8 -*-
"""
开奖记录明细 Excel -> 交互式 HTML 仪表盘
参考 excel2html_formula.py 的浅色 Tab 风格；数据从「开奖明细」sheet 重算（口径已验证）。
只用特码维度。纯离线 HTML，无 CDN。
用法: python 02-script/excel2html_lottery.py [xlsx路径]
"""
import os
import sys
import json
from datetime import datetime, date
from collections import Counter, defaultdict
import openpyxl

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, '04-output')
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(OUT_DIR, '开奖记录-全年份合并-v5.xlsx')

PRIME = {1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47}
QIN = set('牛马羊鸡狗猪')
ZODIAC = list('鼠牛虎兔龙蛇马羊猴鸡狗猪')
WX = list('金木水火土')
WEEK = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']


def load_rows(path):
    wb = openpyxl.load_workbook(path, data_only=True)
    if '开奖明细' in wb.sheetnames:
        ws = wb['开奖明细']
    else:
        ws = wb.worksheets[0]
    rows = []
    for r in range(2, ws.max_row + 1):
        tema = ws.cell(r, 12).value
        if tema is None or str(tema).strip() == '':
            continue
        rows.append({
            'tema': int(str(tema).strip()),
            'id': ws.cell(r, 1).value,
            'tx': str(ws.cell(r, 20).value),
            'wx': str(ws.cell(r, 27).value),
            'bose': str(ws.cell(r, 13).value),
            'year': ws.cell(r, 2).value,
            'qishu': ws.cell(r, 3).value,
            'date': str(ws.cell(r, 4).value),
            'plain': [int(str(ws.cell(r, c).value).strip()) for c in range(6, 12)],
        })
    wb.close()
    return rows


def attrs_of(rows):
    temas = [r['tema'] for r in rows]
    return {
        'tema': temas,
        'tx': [r['tx'] for r in rows],
        'wx': [r['wx'] for r in rows],
        'bose': [r['bose'] for r in rows],
        'dx': ['大' if t >= 25 else '小' for t in temas],
        'ds': ['单' if t % 2 else '双' for t in temas],
        'combo': [('大' if t >= 25 else '小') + ('单' if t % 2 else '双') for t in temas],
        'tou': [str(t // 10) for t in temas],
        'wei': [str(t % 10) for t in temas],
        'qs': ['家禽' if r['tx'] in QIN else '野兽' for r in rows],
        'hs': ['质' if t in PRIME else '合' for t in temas],
        'yqd': [(r['year'], r['qishu'], r['date']) for r in rows],
        'plain': [r['plain'] for r in rows],
    }


def freq_table(seq, keys):
    n = len(seq)
    c = Counter(seq)
    return [{'k': k, 'n': c.get(k, 0), 'p': (c.get(k, 0) / n if n else 0)} for k in keys]


def gap_now(seq, key):
    for i, v in enumerate(seq):
        if v == key:
            return i
    return len(seq)


def gap_max(seq, key):
    mx = cur = 0
    for v in seq:
        if v == key:
            mx = max(mx, cur); cur = 0
        else:
            cur += 1
    return max(mx, cur)


def miss_rows(seq, keys, yqd, keyfmt=None):
    n = len(seq)
    out = []
    for k in keys:
        g = gap_now(seq, k)
        last = yqd[g] if g < n else ('', '', '')
        out.append({
            'k': keyfmt(k) if keyfmt else k,
            'gap': g,
            'cnt': sum(1 for v in seq if v == k),
            'mx': gap_max(seq, k),
            'last': [last[0], last[1], last[2]],
        })
    return out


def build_stats(rows):
    a = attrs_of(rows)
    n = len(rows)
    yqd = a['yqd']
    latest = yqd[0]

    ATTR_DEFS = [('大小', a['dx'], ['大', '小']), ('单双', a['ds'], ['单', '双']),
                 ('波色', a['bose'], ['红波', '蓝波', '绿波']),
                 ('号头', a['tou'], ['0', '1', '2', '3', '4']),
                 ('号尾', a['wei'], [str(i) for i in range(10)])]

    freqs = [
        {'title': '大小', 'note': '特码 ≥25 记"大"、≤24 记"小"', 'rows': freq_table(a['dx'], ['大', '小'])},
        {'title': '单双', 'note': '特码奇数记"单"、偶数记"双"', 'rows': freq_table(a['ds'], ['单', '双'])},
        {'title': '大小单双组合', 'note': '大小×单双 组合', 'rows': freq_table(a['combo'], ['大单', '大双', '小单', '小双'])},
        {'title': '波色', 'note': '按特码当年波色（红/蓝/绿）', 'rows': freq_table(a['bose'], ['红波', '蓝波', '绿波'])},
        {'title': '质合', 'note': '质数记"质"否则"合"', 'rows': freq_table(a['hs'], ['质', '合'])},
        {'title': '家禽野兽', 'note': '家禽 牛马羊鸡狗猪 / 野兽 鼠虎兔龙蛇猴', 'rows': freq_table(a['qs'], ['家禽', '野兽'])},
        {'title': '五行', 'note': '按特码五行', 'rows': freq_table(a['wx'], WX)},
        {'title': '号头(0-4)', 'note': '号头=特码十位', 'rows': freq_table(a['tou'], ['0', '1', '2', '3', '4'])},
        {'title': '生肖', 'note': '按特码生肖', 'rows': freq_table(a['tx'], ZODIAC)},
        {'title': '号尾(0-9)', 'note': '号尾=特码个位', 'rows': freq_table(a['wei'], [str(i) for i in range(10)])},
    ]

    miss_num = miss_rows(a['tema'], list(range(1, 50)), yqd, keyfmt=lambda x: '%02d' % x)
    miss_zod = miss_rows(a['tx'], ZODIAC, yqd)
    miss_attr = []
    for label, seq, keys in ATTR_DEFS:
        for k in keys:
            g = gap_now(seq, k); last = yqd[g] if g < n else ('', '', '')
            miss_attr.append({'k': '%s=%s' % (label, k), 'gap': g,
                              'cnt': sum(1 for v in seq if v == k), 'mx': gap_max(seq, k),
                              'last': [last[0], last[1], last[2]]})

    # 热温冷
    num_gap = {x: gap_now(a['tema'], x) for x in range(1, 50)}
    avg = sum(num_gap.values()) / 49.0
    hotcold = []
    for x in range(1, 50):
        g = num_gap[x]
        lvl = '热' if g < avg else ('冷' if g > avg else '温')
        hotcold.append({'k': '%02d' % x, 'gap': g,
                        'cnt': sum(1 for t in a['tema'] if t == x), 'lvl': lvl})

    rank_num = sorted([{'k': '%02d' % x, 'gap': num_gap[x], 'mx': gap_max(a['tema'], x)}
                       for x in range(1, 50)], key=lambda r: r['gap'], reverse=True)
    zg = {z: gap_now(a['tx'], z) for z in ZODIAC}
    rank_zod = sorted([{'k': z, 'gap': zg[z], 'mx': gap_max(a['tx'], z)} for z in ZODIAC],
                      key=lambda r: r['gap'], reverse=True)
    rank_attr = sorted([{'k': m['k'], 'gap': m['gap'], 'mx': m['mx']} for m in miss_attr],
                       key=lambda r: r['gap'], reverse=True)

    # 连开/重号
    rep = tema_in_prev = 0
    overlaps = []
    for i in range(n - 1):
        if a['tema'][i] == a['tema'][i + 1]:
            rep += 1
        cur_p = set(a['plain'][i]); prv_p = set(a['plain'][i + 1])
        overlaps.append(len(cur_p & prv_p))
        if a['tema'][i] in prv_p:
            tema_in_prev += 1
    m = n - 1
    oc = Counter(overlaps)
    liankai = {
        'm': m,
        'rep': rep, 'rep_p': rep / m if m else 0,
        'tip': tema_in_prev, 'tip_p': tema_in_prev / m if m else 0,
        'overlap': [{'k': k, 'n': oc[k], 'p': oc[k] / m if m else 0} for k in sorted(oc)],
    }

    # 概览
    fc = Counter(a['tema'])
    hot5 = sorted(range(1, 50), key=lambda x: fc.get(x, 0), reverse=True)[:5]
    cold5 = sorted(range(1, 50), key=lambda x: fc.get(x, 0))[:5]
    most_missing = max(range(1, 50), key=lambda x: num_gap[x])
    overview = {
        'total': n,
        'date_from': yqd[-1][2], 'date_to': yqd[0][2],
        'latest': [latest[0], latest[1], latest[2]],
        'hot5': [{'k': '%02d' % x, 'n': fc.get(x, 0)} for x in hot5],
        'cold5': [{'k': '%02d' % x, 'n': fc.get(x, 0)} for x in cold5],
        'most_missing': {'k': '%02d' % most_missing, 'gap': num_gap[most_missing]},
        'dist': {
            'dx': freq_table(a['dx'], ['大', '小']),
            'ds': freq_table(a['ds'], ['单', '双']),
            'bose': freq_table(a['bose'], ['红波', '蓝波', '绿波']),
            'qs': freq_table(a['qs'], ['家禽', '野兽']),
        },
    }

    # 走势图数据：各属性序列（新→旧），期数标签 + 阳历日期
    trend = {
        'labels': ['%s期' % q for (_, q, _) in yqd],   # 新→旧
        'dates': [d for (_, _, d) in yqd],             # 阳历日期 YYYY-MM-DD
        'dx': a['dx'], 'ds': a['ds'], 'bose': a['bose'], 'qs': a['qs'],
    }

    return {
        'overview': overview,
        'freqs': freqs,
        'miss_num': miss_num, 'miss_zod': miss_zod, 'miss_attr': miss_attr,
        'hotcold': hotcold, 'hc_avg': round(avg, 1),
        'rank_num': rank_num, 'rank_zod': rank_zod, 'rank_attr': rank_attr,
        'liankai': liankai,
        'trend': trend,
    }


def build_year_stats(rows):
    years = sorted(set(r['year'] for r in rows))
    out = []
    for Y in years:
        yrows = [r for r in rows if r['year'] == Y]
        s = build_stats(yrows)
        out.append({'year': Y, 'n': len(yrows),
                    'from': yrows[-1]['date'], 'to': yrows[0]['date'],
                    'stats': s})
    return out


# ---------------- HTML 模板 ----------------
def render_html(title, data):
    data_json = json.dumps(data, ensure_ascii=False)
    return HTML_TEMPLATE.replace('__TITLE__', title).replace('__DATA__', data_json)


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__</title>
<style>
:root{ --primary:#1a73e8; --navh:51px; --bg:#f0f2f5; --card:#fff; }
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Microsoft YaHei",Arial,sans-serif;background:var(--bg);color:#333;}
h1{font-size:20px;text-align:center;padding:16px;color:#222;}
.tab-nav{position:sticky;top:0;z-index:20;background:#fff;display:flex;flex-wrap:wrap;
  box-shadow:0 2px 8px rgba(0,0,0,.08);padding:0 20px;}
.tab-btn{padding:14px 20px;border:none;background:none;cursor:pointer;font-size:14px;color:#666;
  border-bottom:3px solid transparent;}
.tab-btn:hover{color:var(--primary);}
.tab-btn.active{color:var(--primary);border-bottom-color:var(--primary);font-weight:bold;}
.tab-page{display:none;padding:20px;width:96%;margin:0 auto;}
.tab-page.active{display:block;}
.card{background:var(--card);border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.06);
  padding:18px;margin-bottom:20px;}
.card h2{font-size:16px;margin-bottom:6px;color:#1a3a6b;}
.note{font-size:12px;color:#888;font-style:italic;margin-bottom:10px;}
.stat-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;}
.stat-card{background:linear-gradient(135deg,#e8f0fe,#fff);border-radius:12px;padding:16px;
  box-shadow:0 2px 8px rgba(0,0,0,.05);}
.stat-card .lbl{font-size:12px;color:#888;}
.stat-card .val{font-size:22px;font-weight:bold;color:var(--primary);margin-top:6px;}
.stat-card .sub{font-size:12px;color:#666;margin-top:4px;}
.hotcold-row{display:flex;gap:16px;flex-wrap:wrap;}
.hotcold-box{flex:1;min-width:260px;background:#fff;border-radius:10px;padding:14px;
  border-left:5px solid #e74c3c;}
.hotcold-box.cold{border-left-color:#1a73e8;}
.hotcold-box h3{font-size:14px;margin-bottom:10px;}
.hc-cards{display:flex;gap:8px;flex-wrap:wrap;}
.hc-card{width:52px;text-align:center;background:#f6f8fc;border-radius:8px;padding:8px 4px;}
.hc-card .num{font-size:18px;font-weight:bold;color:#333;}
.hc-card .cnt{font-size:11px;color:#999;}
.wave-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:720px){.wave-grid{grid-template-columns:1fr;}}
.wc-box{background:#fafbfe;border-radius:10px;padding:12px;}
.wc-box h4{font-size:13px;margin-bottom:8px;color:#555;}
.wc-cards{display:flex;gap:8px;flex-wrap:wrap;}
.wc-card{flex:1;min-width:70px;text-align:center;border-radius:8px;padding:10px 6px;}
.wc-card .k{font-size:13px;font-weight:bold;}
.wc-card .p{font-size:12px;margin-top:2px;}
table{border-collapse:collapse;width:100%;font-size:13px;}
th,td{border:1px solid #e3e6ea;padding:7px 10px;text-align:center;white-space:nowrap;}
th{background:#f1f5fb;color:#333;cursor:pointer;user-select:none;white-space:nowrap;}
th.sortable:hover{background:#e3ecfa;}
th .arr{color:#b0b8c4;font-size:11px;margin-left:3px;}
th.sortable[data-dir="asc"] .arr,th.sortable[data-dir="desc"] .arr{color:#1a73e8;}
tr:nth-child(even) td{background:#fafbfd;}
tr:hover td{background:#eef4ff;}
.bose-hong{background:#fbe0e3 !important;}
.bose-lan{background:#dcebfb !important;}
.bose-lv{background:#e6f4d5 !important;}
.lvl-hot{background:#fce4d6 !important;}
.lvl-warm{background:#fff2cc !important;}
.lvl-cold{background:#dce9f7 !important;}
.hot-val{color:#e74c3c !important;font-weight:bold;}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
@media(max-width:900px){.grid2{grid-template-columns:1fr;}}
.year-btns{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;}
.year-btn{padding:8px 16px;border:1px solid #cdd8ea;border-radius:20px;background:#fff;
  cursor:pointer;font-size:13px;}
.year-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.subttl{font-size:14px;color:#1a3a6b;margin:14px 0 6px;font-weight:bold;}
.zbars{display:flex;flex-direction:column;gap:6px;margin-top:8px;}
.zbar-row{display:flex;align-items:center;gap:8px;}
.zbar-lbl{width:34px;height:30px;line-height:30px;text-align:center;border-radius:6px;font-weight:bold;font-size:14px;flex:none;color:#444;}
.zbar-track{flex:1;background:#eef0f3;border-radius:6px;height:22px;position:relative;overflow:hidden;}
.zbar-fill{height:100%;border-radius:6px;display:flex;align-items:center;min-width:2px;}
.zbar-fill.dev{background:linear-gradient(90deg,#e74c3c,#f0776a);}
.zbar-fill.dev.zero{background:#c9ced6;}
.zbar-fill.freq{background:linear-gradient(90deg,#1a73e8,#5a9cf0);}
.zbar-fill span{color:#fff;font-size:12px;font-weight:bold;padding-left:8px;white-space:nowrap;}
.zbar-val{width:56px;text-align:right;font-size:13px;font-weight:bold;color:#333;flex:none;}
.zbar-tag{width:52px;text-align:center;font-size:11px;padding:3px 0;border-radius:4px;flex:none;color:#555;}
/* 走势图 */
.trend-wrap{display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start;}
.trend-col{flex:1;min-width:240px;border:1px solid #e3e6ea;border-radius:10px;overflow:hidden;background:#fff;}
.trend-col.c0{border-top:3px solid #E8A13B;} .trend-col.c1{border-top:3px solid #1a73e8;}
.trend-col.c2{border-top:3px solid #e74c3c;} .trend-col.c3{border-top:3px solid #2e9e5b;}
.trend-col h3{text-align:center;font-size:14px;padding:10px;color:#333;}
.trend-tb{width:100%;border-collapse:collapse;font-size:12px;}
.trend-tb th,.trend-tb td{border:1px solid #eceff3;height:26px;text-align:center;padding:0;}
.trend-tb th{background:#f7f9fc;color:#666;font-weight:normal;font-size:12px;}
.trend-tb td.qi{color:#999;font-size:11px;width:52px;background:#fafbfd;}
.trend-tb td.dt{color:#7a8493;font-size:11px;width:82px;background:#fafbfd;white-space:nowrap;}
.trend-cell{font-weight:bold;font-size:12px;}
/* 历史记录 */
.month-btns{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;}
.month-btn{padding:7px 14px;border:1px solid #cdd8ea;border-radius:20px;background:#fff;cursor:pointer;font-size:13px;}
.month-btn.active{background:var(--primary);color:#fff;border-color:var(--primary);}
.hist-wrap{overflow-x:auto;}
.hist-tb{width:100%;border-collapse:collapse;font-size:13px;white-space:nowrap;}
.hist-tb th,.hist-tb td{border:1px solid #e3e6ea;padding:7px 10px;text-align:center;}
.hist-tb th{background:#f1f5fb;color:#333;}
.hist-tb tr:nth-child(even) td{background:#fafbfd;}
.hist-tb tr:hover td{background:#eef4ff;}
/* 左侧 sticky 导航 + 右侧内容 通用布局 */
.side-layout{display:flex;gap:18px;align-items:flex-start;}
.side-nav{position:sticky;top:calc(var(--navh) + 12px);flex:none;width:150px;
  background:#fff;border:1px solid #e3e6ea;border-radius:10px;padding:8px;max-height:calc(100vh - var(--navh) - 30px);overflow-y:auto;}
.side-nav .sn-item{display:block;padding:8px 10px;font-size:13px;color:#555;border-radius:6px;cursor:pointer;
  border:none;background:none;width:100%;text-align:left;}
.side-nav .sn-item:hover{background:#eef4ff;color:var(--primary);}
.side-nav .sn-item.active{background:var(--primary);color:#fff;}
.side-nav .sn-group{font-size:11px;color:#999;padding:8px 10px 4px;font-weight:bold;}
.side-body{flex:1;min-width:0;}
.side-body .card{overflow-x:auto;}
@media(max-width:820px){.side-layout{flex-direction:column;}.side-nav{position:static;width:100%;max-height:none;display:flex;flex-wrap:wrap;gap:4px;}}
</style>
</head>
<body>
<h1>__TITLE__</h1>
<div class="tab-nav" id="tabNav"></div>
<div id="pages"></div>
<script>
var DATA = __DATA__;
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function pct(x){return (x*100).toFixed(2)+'%';}
function boseCls(k){return k==='红波'?'bose-hong':k==='蓝波'?'bose-lan':k==='绿波'?'bose-lv':'';}
function lvlCls(l){return l==='热'?'lvl-hot':l==='温'?'lvl-warm':'lvl-cold';}

/* 频率表“类型”列底色：生肖/家禽野兽用 #82C99A/#F1948A，其余柔和浅色 */
var SHOU_SET2={'鼠':1,'虎':1,'兔':1,'龙':1,'蛇':1,'猴':1};
var QIN_SET2={'牛':1,'马':1,'羊':1,'鸡':1,'狗':1,'猪':1};
/* 生肖名加野/家后缀：鼠→鼠(野)、牛→牛(家)（首页概览横条除外） */
function zodLabel(z){z=String(z);return SHOU_SET2[z]?z+'(野)':(QIN_SET2[z]?z+'(家)':z);}
function typeBgStyle(k){
  k=String(k).replace(/\((野|家)\)$/,'');  // 去掉“(野)/(家)”后缀再判色
  if(k==='野兽'||SHOU_SET2[k]) return 'background:#F1948A;color:#fff;font-weight:bold;';
  if(k==='家禽'||QIN_SET2[k]) return 'background:#82C99A;color:#fff;font-weight:bold;';
  var map={
    '大':'#fdebd0','小':'#e8ddf3','单':'#d6eaf8','双':'#fdf3d0',
    '红波':'#fbe0e3','蓝波':'#dcebfb','绿波':'#e6f4d5',
    '质':'#e8f0fb','合':'#f2ece0',
    '大单':'#fce8d5','大双':'#f6e0ee','小单':'#dbeaf6','小双':'#e6f3da',
    '金':'#fdf1cf','木':'#dff0d8','水':'#d6ebf5','火':'#fbe0dc','土':'#efe6d3'
  };
  if(map[k]) return 'background:'+map[k]+';';
  // 号头/号尾（纯数字）用极浅灰蓝交替
  if(/^\d+$/.test(k)) return 'background:'+ (parseInt(k,10)%2 ? '#eef3f9':'#f3f0f7') +';';
  return '';
}

/* 生肖野兽(红底)/家禽(绿底) */
var SHOU_SET={'鼠':1,'虎':1,'兔':1,'龙':1,'蛇':1,'猴':1};
function zodLblStyle(z){return SHOU_SET[z]?'background:#F1948A;color:#fff;':'background:#82C99A;color:#fff;';}
/* 偏差阈值标签：忽略<25≤提醒<30≤可以追 */
function devTag(g){
  if(g>=30) return {t:'可以追',bg:'#c8e6c9'};
  if(g>=25) return {t:'提醒',bg:'#fff3cd'};
  return {t:'忽略',bg:'#e8e8e8'};
}
/* 生肖偏差排行（偏差=当前遗漏期数，降序），横条 */
function zodDevBars(rankZod){
  var max=Math.max.apply(null,rankZod.map(function(r){return r.gap;}))||1;
  var h='<div class="zbars">';
  rankZod.forEach(function(r){
    var w=Math.max(r.gap/max*100,r.gap>0?4:0);
    var tag=devTag(r.gap);
    h+='<div class="zbar-row">';
    h+='<div class="zbar-lbl" style="'+zodLblStyle(r.k)+'">'+r.k+'</div>';
    h+='<div class="zbar-track"><div class="zbar-fill dev'+(r.gap===0?' zero':'')+'" style="width:'+w+'%"></div></div>';
    h+='<div class="zbar-val">+'+r.gap+'</div>';
    h+='<div class="zbar-tag" style="background:'+tag.bg+'">'+tag.t+'</div>';
    h+='</div>';
  });
  return h+'</div>';
}
/* 生肖出现频率横条（次数+占比） */
function zodFreqBars(freqRows){
  var max=Math.max.apply(null,freqRows.map(function(r){return r.n;}))||1;
  var h='<div class="zbars">';
  freqRows.forEach(function(r){
    var w=Math.max(r.n/max*100,4);
    h+='<div class="zbar-row">';
    h+='<div class="zbar-lbl" style="'+zodLblStyle(r.k)+'">'+r.k+'</div>';
    h+='<div class="zbar-track"><div class="zbar-fill freq" style="width:'+w+'%"><span>'+r.n+'</span></div></div>';
    h+='<div class="zbar-val">'+pct(r.p)+'</div>';
    h+='</div>';
  });
  return h+'</div>';
}

/* 可排序表格 */
function tableHtml(headers, rows, opts){
  opts=opts||{};
  var sortable=opts.sortAll ? headers.map(function(_,i){return i;}) : (opts.sortable||[]);
  var boseCol=opts.boseCol;        // 该列值做波色底色
  var lvlCol=opts.lvlCol;          // 热温冷底色列
  var pctCols=opts.pctCols||[];    // 百分比列
  var typeBgCol=opts.typeBgCol;    // “类型”列按取值上底色（inline style）
  var hotFn=opts.hotFn;            // (rowArr,ci,val)=>bool 需加粗标红的单元格
  var h='<table><thead><tr>';
  headers.forEach(function(hd,ci){
    var isSort=sortable.indexOf(ci)>=0;
    h+='<th class="'+(isSort?'sortable':'')+'" data-ci="'+ci+'">'+esc(hd)+(isSort?'<span class="arr">⇅</span>':'')+'</th>';
  });
  h+='</tr></thead><tbody>';
  rows.forEach(function(r){
    h+='<tr>';
    r.forEach(function(v,ci){
      var cls='', sty='';
      if(boseCol!==undefined && ci===boseCol) cls=boseCls(String(v));
      if(lvlCol!==undefined && ci===lvlCol) cls=lvlCls(String(v));
      if(typeBgCol!==undefined && ci===typeBgCol) sty=typeBgStyle(v);
      if(hotFn && hotFn(r,ci,v)) cls+=(cls?' ':'')+'hot-val';
      var disp=v;
      if(pctCols.indexOf(ci)>=0 && typeof v==='number') disp=pct(v);
      h+='<td class="'+cls+'"'+(sty?' style="'+sty+'"':'')+'>'+esc(disp)+'</td>';
    });
    h+='</tr>';
  });
  h+='</tbody></table>';
  return h;
}

/* 构造 hotFn：标红「当前遗漏≥30 或 属于gapTop3」的遗漏列 + 「历史最大遗漏∈mxTop3」列
   cfg: {gapCol, gapTop3:Set, mxCol, mxTop3:Set, lvlCol, coldMark} */
function makeMissHot(rows, cfg){
  cfg=cfg||{};
  function topSet(col, n){
    var vals=rows.map(function(r){return {i:r, v:parseFloat(r[col])};})
      .filter(function(o){return !isNaN(o.v);})
      .sort(function(a,b){return b.v-a.v;});
    var th=vals.length>=n? vals[n-1].v : (vals.length?vals[vals.length-1].v:0);
    return th;
  }
  var gapTh = cfg.gapCol!==undefined ? topSet(cfg.gapCol,3) : null;
  var mxTh  = cfg.mxCol!==undefined ? topSet(cfg.mxCol,3) : null;
  return function(rowArr, ci, val){
    if(cfg.gapCol!==undefined && ci===cfg.gapCol){
      var g=parseFloat(val);
      if(!isNaN(g) && (g>=30 || (gapTh!==null && g>=gapTh))) return true;
    }
    if(cfg.mxCol!==undefined && ci===cfg.mxCol){
      var m=parseFloat(val);
      if(!isNaN(m) && mxTh!==null && m>=mxTh) return true;
    }
    return false;
  };
}

function attachSort(container){
  container.querySelectorAll('th.sortable').forEach(function(th){
    th.addEventListener('click',function(){
      var table=th.closest('table');
      var ci=+th.dataset.ci;
      var tb=table.querySelector('tbody');
      var rows=Array.prototype.slice.call(tb.querySelectorAll('tr'));
      var dir=th.dataset.dir==='asc'?'desc':'asc';
      table.querySelectorAll('th').forEach(function(x){x.dataset.dir='';var a=x.querySelector('.arr');if(a&&x.classList.contains('sortable'))a.textContent='⇅';});
      th.dataset.dir=dir; th.querySelector('.arr').textContent=dir==='asc'?'▲':'▼';
      rows.sort(function(a,b){
        var x=a.children[ci].textContent, y=b.children[ci].textContent;
        var nx=parseFloat(x.replace('%','').replace(/[^\d.\-]/g,'')), ny=parseFloat(y.replace('%','').replace(/[^\d.\-]/g,''));
        if(!isNaN(nx)&&!isNaN(ny)){return dir==='asc'?nx-ny:ny-nx;}
        return dir==='asc'?x.localeCompare(y):y.localeCompare(x);
      });
      rows.forEach(function(r){tb.appendChild(r);});
    });
  });
}

/* ---- 左侧 sticky 锚点导航通用组件 ---- */
/* sections: [{id, label}]，bodyHtml 内各区块须带 id=对应 id */
function withSideNav(sections, bodyHtml){
  var nav='<div class="side-nav">';
  sections.forEach(function(s,i){
    nav+='<button class="sn-item'+(i===0?' active':'')+'" data-target="'+s.id+'">'+esc(s.label)+'</button>';
  });
  nav+='</div>';
  return '<div class="side-layout">'+nav+'<div class="side-body">'+bodyHtml+'</div></div>';
}
/* 绑定：点侧栏项 → 平滑滚到区块；滚动时高亮当前项 */
function attachSideNav(page){
  var nav=page.querySelector('.side-nav'); if(!nav) return;
  var items=[].slice.call(nav.querySelectorAll('.sn-item'));
  items.forEach(function(it){
    it.addEventListener('click',function(){
      var el=page.querySelector('#'+CSS.escape(it.dataset.target));
      if(el){var y=el.getBoundingClientRect().top+window.pageYOffset-60;window.scrollTo({top:y,behavior:'smooth'});}
      items.forEach(function(x){x.classList.remove('active');}); it.classList.add('active');
    });
  });
}

/* ---- 各页渲染 ---- */
function renderOverview(s){
  var o=s.overview;
  var h='<div class="card"><h2>数据概览</h2><div class="stat-cards">';
  h+='<div class="stat-card"><div class="lbl">总期数</div><div class="val">'+o.total+'</div><div class="sub">'+o.date_from+' ~ '+o.date_to+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最新一期</div><div class="val">'+o.latest[1]+'期</div><div class="sub">'+o.latest[0]+'年 '+o.latest[2]+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最热号码</div><div class="val">'+o.hot5[0].k+'</div><div class="sub">出现 '+o.hot5[0].n+' 次</div></div>';
  h+='<div class="stat-card"><div class="lbl">最冷号码</div><div class="val">'+o.cold5[0].k+'</div><div class="sub">出现 '+o.cold5[0].n+' 次</div></div>';
  h+='<div class="stat-card"><div class="lbl">最久未出</div><div class="val">'+o.most_missing.k+'</div><div class="sub">已遗漏 '+o.most_missing.gap+' 期</div></div>';
  h+='</div></div>';

  h+='<div class="card"><h2>热门 / 冷门号码</h2><div class="hotcold-row">';
  h+='<div class="hotcold-box"><h3>🔥 热门 Top5</h3><div class="hc-cards">';
  o.hot5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div>';
  h+='<div class="hotcold-box cold"><h3>❄️ 冷门 Top5</h3><div class="hc-cards">';
  o.cold5.forEach(function(x){h+='<div class="hc-card"><div class="num">'+x.k+'</div><div class="cnt">'+x.n+'次</div></div>';});
  h+='</div></div></div></div>';

  h+='<div class="card"><h2>基础属性分布</h2><div class="wave-grid">';
  function distBox(title, arr, colorMap){
    var b='<div class="wc-box"><h4>'+title+'</h4><div class="wc-cards">';
    arr.forEach(function(x){
      var bg=colorMap[x.k]||'#eef2f9';
      b+='<div class="wc-card" style="background:'+bg+'"><div class="k">'+x.k+'</div><div class="p">'+x.n+' / '+pct(x.p)+'</div></div>';
    });
    return b+'</div></div>';
  }
  h+=distBox('大小',o.dist.dx,{'大':'#fdebd0','小':'#e8ddf3'});
  h+=distBox('单双',o.dist.ds,{'单':'#d6eaf8','双':'#fdf3d0'});
  h+=distBox('波色',o.dist.bose,{'红波':'#fbe0e3','蓝波':'#dcebfb','绿波':'#e6f4d5'});
  h+=distBox('家禽野兽',o.dist.qs,{'家禽':'#82C99A','野兽':'#F1948A'});
  h+='</div></div>';

  // 底部 4 个生肖报表：总览 + 最新年·当年
  var yr=DATA.years[DATA.years.length-1];
  function zodFreqRows(stats){
    var f=stats.freqs.filter(function(x){return x.title==='生肖';})[0];
    return f?f.rows:[];
  }
  function devCard(ttl,rankZod){
    return '<div class="card"><h2>'+ttl+'</h2>'+
      '<div class="note">按“当前遗漏期数”降序（越久未出越靠前，视为偏差越大）；生肖名野兽=浅红底、家禽=浅绿底；阈值 忽略&lt;25≤提醒&lt;30≤可以追。</div>'+
      zodDevBars(rankZod)+'</div>';
  }
  function freqCard(ttl,rows){
    return '<div class="card"><h2>'+ttl+'</h2>'+
      '<div class="note">各生肖出现次数与实际占比；生肖名野兽=浅红底、家禽=浅绿底。</div>'+
      zodFreqBars(rows)+'</div>';
  }
  h+='<div class="grid2">';
  h+=devCard('生肖偏差排行（总览）',s.rank_zod);
  h+=freqCard('生肖出现频率（总览）',zodFreqRows(s));
  h+='</div>';
  h+='<div class="grid2">';
  h+=devCard('生肖偏差排行（'+yr.year+'年·当年）',yr.stats.rank_zod);
  h+=freqCard('生肖出现频率（'+yr.year+'年·当年）',zodFreqRows(yr.stats));
  h+='</div>';
  return h;
}

function renderFreq(s){
  var secs=[], body='<div class="grid2">';
  s.freqs.forEach(function(f,idx){
    var id='freq-'+idx; secs.push({id:id,label:f.title});
    body+='<div class="card" id="'+id+'"><h2>'+f.title+'</h2><div class="note">计算：'+esc(f.note)+'　（实际占比“远超平均”即 &gt;1.3×均值 时标红）</div>';
    var isZod=f.title==='生肖';
    var rows=f.rows.map(function(r){return [isZod?zodLabel(r.k):r.k, r.n, r.p];});
    var avgP=rows.length? rows.reduce(function(a,r){return a+r[2];},0)/rows.length : 0;
    var hotFn=function(rowArr,ci,val){ return ci===2 && avgP>0 && val>avgP*1.3; };
    body+=tableHtml(['类型','次数','实际占比'],rows,{sortAll:true,pctCols:[2],typeBgCol:0,hotFn:hotFn});
    body+='</div>';
  });
  body+='</div>';
  return withSideNav(secs, body);
}

function missTable(rows, labelFn){
  var data=rows.map(function(r){return [labelFn?labelFn(r.k):r.k, r.gap, r.cnt, r.mx,
      (r.last[0]?r.last[0]+'年':''), (r.last[1]?r.last[1]+'期':''), r.last[2]||''];});
  return tableHtml(['项','当前遗漏','出现次数','历史最大遗漏','最近·年','最近·期','最近·日期'],
    data,{sortAll:true,hotFn:makeMissHot(data,{gapCol:1,mxCol:3})});
}

/* 属性遗漏按类别拆分：传入 miss_attr（k形如 "大小=大"），按前缀分组 */
function attrMissSplit(missAttr){
  var groups={};
  missAttr.forEach(function(r){
    var cat=r.k.split('=')[0];
    (groups[cat]=groups[cat]||[]).push(r);
  });
  return groups;
}
function attrMissCard(title, rows){
  var data=rows.map(function(r){return [r.k, r.gap, r.cnt, r.mx,
      (r.last[0]?r.last[0]+'年':''), (r.last[1]?r.last[1]+'期':''), r.last[2]||''];});
  return '<div class="card"><h2>'+title+'</h2>'+
    tableHtml(['属性','当前遗漏','出现次数','历史最大遗漏','最近·年','最近·期','最近·日期'],
      data,{sortAll:true,hotFn:makeMissHot(data,{gapCol:1,mxCol:3})})+'</div>';
}

function renderMiss(s){
  var h='';
  // 号码遗漏 与 热温冷 左右各 50%
  h+='<div class="grid2" id="miss-num">';
  h+='<div class="card"><h2>号码遗漏 / 冷热（01-49）</h2><div class="note">当前遗漏=距今多少期未出（0=最新期开出）</div>'+missTable(s.miss_num)+'</div>';
  var hc=s.hotcold.map(function(r){return [r.k,r.gap,r.cnt,r.lvl];});
  var hcHot=function(rowArr,ci,val){
    if(ci===1){ // 冷号 或 遗漏≥30 → 标红遗漏值
      if(String(rowArr[3])==='冷') return true;
      var g=parseFloat(val); return !isNaN(g)&&g>=30;
    }
    return false;
  };
  h+='<div class="card"><h2>号码热温冷分层（平均遗漏 '+s.hc_avg+' 期）</h2><div class="note">当前遗漏 < 平均=热、= 平均=温、> 平均=冷；冷号或遗漏≥30 标红</div>'+
    tableHtml(['号码','当前遗漏','出现次数','热温冷'],hc,{sortAll:true,lvlCol:3,hotFn:hcHot})+'</div>';
  h+='</div>';
  // 生肖遗漏 与 属性遗漏(拆分)
  h+='<div class="grid2" id="miss-zod">';
  h+='<div class="card"><h2>生肖遗漏</h2>'+missTable(s.miss_zod, zodLabel)+'</div>';
  var g=attrMissSplit(s.miss_attr);
  h+=attrMissCard('属性遗漏 · 大小/单双/波色',[].concat(g['大小']||[],g['单双']||[],g['波色']||[]));
  h+='</div>';
  h+='<div class="grid2" id="miss-attr">';
  h+=attrMissCard('属性遗漏 · 号头',g['号头']||[]);
  h+=attrMissCard('属性遗漏 · 号尾',g['号尾']||[]);
  h+='</div>';
  // 排行榜（当前遗漏 col2 / 历史最大 col3 标红）
  var rankHot=function(data){return makeMissHot(data,{gapCol:2,mxCol:3});};
  h+='<div class="grid2" id="miss-rank">';
  var rnum=s.rank_num.map(function(r,i){return [i+1,r.k,r.gap,r.mx];});
  h+='<div class="card"><h2>号码遗漏排行榜</h2>'+tableHtml(['排名','号码','当前遗漏','历史最大遗漏'],
      rnum,{sortAll:true,hotFn:rankHot(rnum)})+'</div>';
  var rzod=s.rank_zod.map(function(r,i){return [i+1,zodLabel(r.k),r.gap,r.mx];});
  h+='<div class="card"><h2>生肖遗漏排行榜</h2>'+tableHtml(['排名','生肖','当前遗漏','历史最大遗漏'],
      rzod,{sortAll:true,hotFn:rankHot(rzod)})+'</div>';
  h+='</div>';
  var rattr=s.rank_attr.map(function(r,i){return [i+1,r.k,r.gap,r.mx];});
  h+='<div class="card" id="miss-rank-attr"><h2>属性遗漏排行榜</h2>'+tableHtml(['排名','属性','当前遗漏','历史最大遗漏'],
      rattr,{sortAll:true,hotFn:rankHot(rattr)})+'</div>';
  var secs=[{id:'miss-num',label:'号码遗漏/热温冷'},{id:'miss-zod',label:'生肖/属性遗漏'},
            {id:'miss-attr',label:'号头/号尾遗漏'},{id:'miss-rank',label:'号码/生肖排行榜'},
            {id:'miss-rank-attr',label:'属性排行榜'}];
  return withSideNav(secs, h);
}

function renderLiankai(s){
  var l=s.liankai;
  var rows=[['特码与上期重号',l.rep,l.rep_p],['本期特码在上期平码中',l.tip,l.tip_p]];
  l.overlap.forEach(function(o){rows.push(['平码与上期重叠'+o.k+'个',o.n,o.p]);});
  return '<div class="card"><h2>连开 / 重号（相邻期比较，共 '+l.m+' 组）</h2>'+
    '<div class="note">占比=次数 ÷ 组数</div>'+
    tableHtml(['指标','次数','占比'],rows,{sortAll:true,pctCols:[2]})+'</div>';
}

function renderYear(){
  var h='<div class="card"><h2>分年统计</h2><div class="note">每年独立统计（遗漏在该年内计算）。点击年份切换。</div>';
  h+='<div class="year-btns" id="yearBtns"></div><div id="yearBody"></div></div>';
  return h;
}
function fillYear(idx){
  var y=DATA.years[idx];
  var s=y.stats;
  var nYears=DATA.years.length;
  document.querySelectorAll('#yearBtns .year-btn').forEach(function(b,pos){
    // 按钮是倒序渲染的：DOM 位置 pos 对应 DATA 下标 nYears-1-pos
    b.classList.toggle('active',(nYears-1-pos)===idx);
  });
  var h='<div class="stat-cards" style="margin-bottom:16px">';
  h+='<div class="stat-card"><div class="lbl">'+y.year+'年 期数</div><div class="val">'+y.n+'</div><div class="sub">'+y.from+' ~ '+y.to+'</div></div>';
  h+='<div class="stat-card"><div class="lbl">最热号</div><div class="val">'+s.overview.hot5[0].k+'</div><div class="sub">'+s.overview.hot5[0].n+'次</div></div>';
  h+='<div class="stat-card"><div class="lbl">最久未出</div><div class="val">'+s.overview.most_missing.k+'</div><div class="sub">'+s.overview.most_missing.gap+'期</div></div>';
  h+='</div>';
  var body2='';
  body2+='<div class="subttl" id="yr-freq">频率统计</div><div class="grid2">';
  s.freqs.forEach(function(f){
    body2+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>'+f.title+'</h2>';
    var isZodY=f.title==='生肖';
    var frows=f.rows.map(function(r){return [isZodY?zodLabel(r.k):r.k,r.n,r.p];});
    var avgP=frows.length? frows.reduce(function(a,r){return a+r[2];},0)/frows.length : 0;
    var fHot=function(rowArr,ci,val){return ci===2&&avgP>0&&val>avgP*1.3;};
    body2+=tableHtml(['类型','次数','实际占比'],frows,{sortAll:true,pctCols:[2],typeBgCol:0,hotFn:fHot});
    body2+='</div>';
  });
  body2+='</div>';
  // 热温冷 与 遗漏榜 左右各 50%
  body2+='<div class="subttl" id="yr-hot">号码热温冷 / 遗漏榜</div><div class="grid2">';
  var yhc=s.hotcold.map(function(r){return [r.k,r.gap,r.cnt,r.lvl];});
  var yhcHot=function(rowArr,ci,val){if(ci===1){if(String(rowArr[3])==='冷')return true;var g=parseFloat(val);return !isNaN(g)&&g>=30;}return false;};
  body2+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码热温冷（本年均值 '+s.hc_avg+' 期）</h2>'+
    tableHtml(['号码','当前遗漏','出现次数','热温冷'],yhc,{sortAll:true,lvlCol:3,hotFn:yhcHot})+'</div>';
  var yrank=s.rank_num.map(function(r,i){return [i+1,r.k,r.gap,r.mx];});
  body2+='<div class="card" style="box-shadow:none;border:1px solid #eee"><h2>号码遗漏排行榜（本年）</h2>'+
    tableHtml(['排名','号码','当前遗漏','历史最大遗漏'],yrank,{sortAll:true,hotFn:makeMissHot(yrank,{gapCol:2,mxCol:3})})+'</div>';
  body2+='</div>';
  body2+='<div class="subttl" id="yr-lk">连开 / 重号（本年）</div>';
  var l=s.liankai;var rows=[['特码与上期重号',l.rep,l.rep_p],['本期特码在上期平码中',l.tip,l.tip_p]];
  l.overlap.forEach(function(o){rows.push(['平码与上期重叠'+o.k+'个',o.n,o.p]);});
  body2+=tableHtml(['指标','次数','占比'],rows,{sortAll:true,pctCols:[2]});
  h+=withSideNav([{id:'yr-freq',label:'频率统计'},{id:'yr-hot',label:'热温冷/遗漏榜'},{id:'yr-lk',label:'连开/重号'}], body2);
  var body=document.getElementById('yearBody');
  body.innerHTML=h;
  attachSort(body);
  attachSideNav(body);
}

/* ---- 走势图（属性色块） ---- */
var TREND_DEFS=[
  {key:'dx', title:'大小', cols:['大','小'], colors:{'大':'#F8C471','小':'#C39BD3'}},
  {key:'ds', title:'单双', cols:['单','双'], colors:{'单':'#85C1E9','双':'#F7DC6F'}},
  {key:'bose', title:'波色', cols:['红波','蓝波','绿波'], colors:{'红波':'#F1A2AB','蓝波':'#81BBF8','绿波':'#C1E77E'}},
  {key:'qs', title:'家禽野兽', cols:['家禽','野兽'], colors:{'家禽':'#82C99A','野兽':'#F1948A'}}
];
function textColorFor(bg){
  var m=/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(bg); if(!m) return '#333';
  var lum=0.299*parseInt(m[1],16)+0.587*parseInt(m[2],16)+0.114*parseInt(m[3],16);
  return lum>150?'#333':'#fff';
}
function trendColHtml(tr, def, ci){
  var seq=tr[def.key], labels=tr.labels, dates=tr.dates||[];
  var h='<div class="trend-col c'+ci+'"><h3 style="color:'+({0:'#E8A13B',1:'#1a73e8',2:'#e74c3c',3:'#2e9e5b'}[ci])+'">'+def.title+'</h3>';
  h+='<table class="trend-tb"><thead><tr><th>日期</th><th>期数</th>';
  def.cols.forEach(function(c){h+='<th>'+c+'</th>';});
  h+='</tr></thead><tbody>';
  for(var i=0;i<labels.length;i++){
    h+='<tr><td class="dt">'+(dates[i]||'')+'</td><td class="qi">'+labels[i]+'</td>';
    def.cols.forEach(function(c){
      if(seq[i]===c){var bg=def.colors[c];h+='<td class="trend-cell" style="background:'+bg+';color:'+textColorFor(bg)+'">'+c+'</td>';}
      else h+='<td></td>';
    });
    h+='</tr>';
  }
  return h+'</tbody></table></div>';
}
function renderTrendBody(tr){
  var h='<div class="trend-wrap">';
  TREND_DEFS.forEach(function(def,ci){h+=trendColHtml(tr,def,ci);});
  return h+'</div>';
}
function renderTrend(s){
  return '<div class="card"><h2>属性走势图</h2>'+
    '<div class="note">大小、单双、波色、家禽野兽属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</div>'+
    renderTrendBody(s.trend)+'</div>';
}
function renderTrendYear(){
  var h='<div class="card"><h2>属性走势图（分年）</h2><div class="note">按年查看属性色块走势（上=新→下=旧）。点击年份切换。</div>';
  h+='<div class="year-btns" id="trendYearBtns"></div><div id="trendYearBody"></div></div>';
  return h;
}
function fillTrendYear(idx){
  var y=DATA.years[idx], nY=DATA.years.length;
  document.querySelectorAll('#trendYearBtns .year-btn').forEach(function(b,pos){b.classList.toggle('active',(nY-1-pos)===idx);});
  document.getElementById('trendYearBody').innerHTML=
    '<div style="margin:6px 0 12px;color:#666;font-size:13px">'+y.year+'年 共 '+y.n+' 期（'+y.from+' ~ '+y.to+'）</div>'+
    renderTrendBody(y.stats.trend);
}

/* ---- 历史开奖记录（按月切换） ---- */
function renderHistory(){
  return '<div class="card"><h2>历史开奖记录</h2>'+
    '<div class="note">先选年份，再从左侧菜单选当年月份，查看每期开奖详细结果（含生肖/颜色/大小/单双等属性）</div>'+
    '<div class="year-btns" id="histYearBtns"></div>'+
    '<div class="side-layout"><div class="side-nav" id="histMonthNav"></div>'+
    '<div class="side-body hist-wrap"><div id="histBody"></div></div></div></div>';
}
/* 历史记录状态：按年分组 DATA.history 的下标 */
var HIST_YEARS=null;
function histYearMap(){
  if(HIST_YEARS) return HIST_YEARS;
  var map={}, order=[];
  DATA.history.forEach(function(mo,idx){
    var y=mo.ym.slice(0,4);
    if(!map[y]){map[y]=[];order.push(y);}
    map[y].push(idx); // idx 指向 DATA.history
  });
  HIST_YEARS={map:map, order:order};
  return HIST_YEARS;
}
function fillHistYear(y){
  var hy=histYearMap();
  // 顶部年份高亮
  document.querySelectorAll('#histYearBtns .year-btn').forEach(function(b){b.classList.toggle('active',b.textContent===y+'年');});
  // 左侧月份菜单（当年，新→旧，DATA.history 本就新→旧）
  var months=hy.map[y];
  var nav=document.getElementById('histMonthNav');
  nav.innerHTML='';
  months.forEach(function(idx,pos){
    var b=document.createElement('button');b.className='sn-item'+(pos===0?' active':'');
    b.textContent=DATA.history[idx].ym;
    b.addEventListener('click',function(){
      nav.querySelectorAll('.sn-item').forEach(function(x){x.classList.remove('active');});
      b.classList.add('active');
      fillHistory(idx);
    });
    nav.appendChild(b);
  });
  fillHistory(months[0]); // 默认当年最新月
}
function fillHistory(idx){
  var mo=DATA.history[idx];
  var cols=['周期','日序','日期','期数','生肖','特码','大小','单双','波色','野兽','号头','号尾','颜色单双','组合'];
  var h='<table class="hist-tb"><thead><tr>';
  cols.forEach(function(c){h+='<th>'+c+'</th>';});
  h+='</tr></thead><tbody>';
  // 该月内按日期正序（旧→新），与参考图一致
  var rows=mo.rows.slice().reverse();
  rows.forEach(function(r,i){
    var col=boseCls(r.bose);
    h+='<tr>'
      +'<td>'+r.id+'</td>'
      +'<td>序'+('0'+(i+1)).slice(-2)+'</td>'
      +'<td>'+r.date.replace(/-/g,'/')+'</td>'
      +'<td>'+r.qishu+'期</td>'
      +'<td>'+r.tx+'</td>'
      +'<td class="'+col+'" style="font-weight:bold">'+r.tema+'</td>'
      +'<td>'+r.dx+'</td>'
      +'<td>'+r.ds+'</td>'
      +'<td class="'+col+'">'+r.bose+'</td>'
      +'<td>'+r.qs+'</td>'
      +'<td>'+r.tou+'</td>'
      +'<td>'+r.wei+'</td>'
      +'<td>'+r.colds+'</td>'
      +'<td>'+r.combo+'</td>'
      +'</tr>';
  });
  h+='</tbody></table>';
  document.getElementById('histBody').innerHTML=h;
}

var TABS=[
  {name:'首页概览',render:function(){return renderOverview(DATA.all);}},
  {name:'频率统计',render:function(){return renderFreq(DATA.all);}},
  {name:'遗漏/冷热',render:function(){return renderMiss(DATA.all);}},
  {name:'分年统计',render:renderYear},
  {name:'走势图',render:function(){return renderTrend(DATA.all);}},
  {name:'走势图(分年)',render:renderTrendYear},
  {name:'历史记录',render:renderHistory},
  {name:'连开/重号',render:function(){return renderLiankai(DATA.all);}},
];

function showTab(i){
  document.querySelectorAll('.tab-btn').forEach(function(b,idx){b.classList.toggle('active',idx===i);});
  document.querySelectorAll('.tab-page').forEach(function(p,idx){p.classList.toggle('active',idx===i);});
  var page=document.querySelectorAll('.tab-page')[i];
  if(!page.dataset.done){
    page.innerHTML=TABS[i].render();
    attachSort(page);
    attachSideNav(page);
    if(TABS[i].name==='分年统计'){
      var yb=page.querySelector('#yearBtns');
      // 从新到旧排序（2026→2020）：倒序遍历，idx 仍指向 DATA.years 真实下标
      for(var k=DATA.years.length-1;k>=0;k--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillYear(idx);});yb.appendChild(b);
        })(k);
      }
      fillYear(DATA.years.length-1); // 默认最新年
    }
    if(TABS[i].name==='走势图(分年)'){
      var tyb=page.querySelector('#trendYearBtns');
      for(var k2=DATA.years.length-1;k2>=0;k2--){
        (function(idx){
          var b=document.createElement('button');b.className='year-btn';b.textContent=DATA.years[idx].year+'年';
          b.addEventListener('click',function(){fillTrendYear(idx);});tyb.appendChild(b);
        })(k2);
      }
      fillTrendYear(DATA.years.length-1);
    }
    if(TABS[i].name==='历史记录'){
      var hy=histYearMap();
      var hyb=page.querySelector('#histYearBtns');
      hy.order.forEach(function(y){
        var b=document.createElement('button');b.className='year-btn';b.textContent=y+'年';
        b.addEventListener('click',function(){fillHistYear(y);});hyb.appendChild(b);
      });
      fillHistYear(hy.order[0]); // 默认最新年
    }
    page.dataset.done='1';
  }
}

(function init(){
  var nav=document.getElementById('tabNav'), pages=document.getElementById('pages');
  TABS.forEach(function(t,i){
    var b=document.createElement('button');b.className='tab-btn';b.textContent=t.name;
    b.addEventListener('click',function(){showTab(i);});nav.appendChild(b);
    var p=document.createElement('div');p.className='tab-page';pages.appendChild(p);
  });
  showTab(0);
})();
</script>
</body>
</html>"""


def build_history(rows):
    """按月分组的完整开奖明细（新→旧），供历史记录 Tab。
    列：周期(id)/日序/日期/期数/生肖/颜色(特码)/波色/大小/单双/色波/野兽/号头/号尾/颜色单双/组合"""
    QIN_L = set('牛马羊鸡狗猪')
    months = []  # [{ym, rows:[...]}], 新→旧
    order = []
    bucket = {}
    for r in rows:  # rows 已新→旧
        d = r['date']  # YYYY-MM-DD
        ym = d[:7] if len(d) >= 7 else str(r['year'])
        if ym not in bucket:
            bucket[ym] = []
            order.append(ym)
        t = r['tema']
        bose = r['bose']
        col = {'红波': '红', '蓝波': '蓝', '绿波': '绿'}.get(bose, '')
        dx = '大' if t >= 25 else '小'
        ds = '单' if t % 2 else '双'
        bucket[ym].append({
            'id': r['id'], 'date': d, 'qishu': r['qishu'],
            'tx': r['tx'], 'tema': '%02d' % t, 'bose': bose,
            'dx': dx, 'ds': ds,
            'qs': '家禽' if r['tx'] in QIN_L else '野兽',
            'tou': '%d头' % (t // 10), 'wei': '%d尾' % (t % 10),
            'colds': col + ds,   # 颜色单双
            'combo': dx + ds,    # 组合
        })
    for ym in order:
        months.append({'ym': ym, 'rows': bucket[ym]})
    return months


def main():
    if not os.path.exists(SRC):
        print('ERROR: 找不到', SRC); sys.exit(1)
    rows = load_rows(SRC)
    if not rows:
        print('ERROR: 明细无数据'); sys.exit(1)

    data = {
        'all': build_stats(rows),
        'years': build_year_stats(rows),
        'history': build_history(rows),
    }
    base = os.path.splitext(os.path.basename(SRC))[0]
    ts = datetime.now().strftime('%Y%m%d-%H%M%S')
    name = '%s-report-%s' % (base, ts)
    out = os.path.join(OUT_DIR, name + '.html')
    v = 1
    while os.path.exists(out):
        out = os.path.join(OUT_DIR, '%s-v%d.html' % (name, v)); v += 1

    title = '%s 分析报告' % base
    html = render_html(title, data)
    with open(out, 'w', encoding='utf-8') as f:
        f.write(html)
    print('生成成功:', out)
    print('总期数:', data['all']['overview']['total'], ' 年份数:', len(data['years']))


if __name__ == '__main__':
    main()
