import pandas as pd
import json
from datetime import datetime
import openpyxl

import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "02-data")
# find the first .xlsx file in the data directory
_excel_files = [f for f in os.listdir(DATA_DIR) if f.lower().endswith('.xlsx')]
if not _excel_files:
    raise FileNotFoundError("No .xlsx files found in " + DATA_DIR)
EXCEL_PATH = os.path.join(DATA_DIR, _excel_files[0])

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
excel_basename = os.path.splitext(_excel_files[0])[0]
base_name = f"{excel_basename}-{timestamp}"
output_dir = os.path.join(BASE_DIR, "03-output")

candidate = os.path.join(output_dir, f"{base_name}.html")
if not os.path.exists(candidate):
    OUTPUT_PATH = candidate
else:
    v = 1
    while True:
        candidate = os.path.join(output_dir, f"{base_name}-v{v}.html")
        if not os.path.exists(candidate):
            OUTPUT_PATH = candidate
            break
        v += 1

# ============================================================
# Open workbook for styles
# ============================================================
wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
ws1 = wb.worksheets[0]
ws2 = wb.worksheets[1]


INDEXED_COLORS = {
    # openpyxl indexed color map → hex
    0: '000000', 1: 'FFFFFF', 2: 'FF0000', 3: '00FF00', 4: '0000FF',
    5: 'FFFF00', 6: 'FF00FF', 7: '00FFFF', 8: '000000', 9: 'FFFFFF',
    10: 'FF0000', 11: '00FF00', 12: '0000FF', 13: 'FFFF00', 14: 'FF00FF',
    15: '00FFFF', 16: '800000', 17: '008000', 18: '000080', 19: '808000',
    20: '800080', 21: '008080', 22: 'C0C0C0', 23: '808080',
    24: '9999FF', 25: '993366', 26: 'FFFFCC', 27: 'CCFFFF', 28: '660066',
    29: 'FF8080', 30: '0066CC', 31: 'CCCCFF', 32: '000080', 33: 'FF00FF',
    34: 'FFFF00', 35: '00FFFF', 36: '800080', 37: '800000', 38: '008080',
    39: '0000FF', 40: '00CCFF', 41: 'CCFFFF', 42: 'CCFFCC', 43: 'FFFF99',
    44: '99CCFF', 45: 'FF99CC', 46: 'CC99FF', 47: 'FFCC99', 48: '3366FF',
    49: '33CCCC', 50: '99CC00', 51: 'FFCC00', 52: 'FF9900', 53: 'FF6600',
    54: '666699', 55: '969696', 56: '003366', 57: '339966', 58: '003300',
    59: '333300', 60: '993300', 61: '993366', 62: '333399', 63: '333333',
}


def _rgb_to_hex(rgb_str):
    """Convert openpyxl RGB string (ARGB or RRGGBB) to CSS hex, skipping black/transparent."""
    if not rgb_str:
        return None
    s = str(rgb_str).strip()
    if not s or s == '00000000' or s == '0' or s == '000000':
        return None
    if len(s) == 8:
        alpha = s[:2]
        if alpha == '00':
            return None
        s = s[2:]
    if s == '000000':
        return None
    return '#' + s


def _openpyxl_color_to_hex(color_obj):
    """Convert openpyxl color object to CSS hex. Handles rgb/indexed safely, skips theme/default."""
    if color_obj is None:
        return None
    try:
        if color_obj.type == 'rgb':
            return _rgb_to_hex(color_obj.rgb)
        elif color_obj.type == 'indexed':
            idx = color_obj.index
            if idx is not None and idx in INDEXED_COLORS:
                return '#' + INDEXED_COLORS[idx]
        elif color_obj.type == 'theme':
            return None
    except Exception:
        pass
    return None


def cell_style(ws, row, col):
    """Extract inline CSS for font color / background color / bold.
    row, col are 0-based (matching pandas iloc)."""
    cell = ws.cell(row=row + 1, column=col + 1)
    css_parts = []

    fc = _openpyxl_color_to_hex(cell.font.color) if cell.font else None
    if fc and fc != '#262626':  # skip near-black default text
        css_parts.append(f'color:{fc}')

    bg = None
    try:
        fill = cell.fill
        if fill and fill.fgColor:
            bg = _openpyxl_color_to_hex(fill.fgColor)
    except Exception:
        pass
    if bg and bg != '#FFFFFF':  # skip white background
        css_parts.append(f'background-color:{bg}')

    if cell.font and cell.font.bold:
        css_parts.append('font-weight:bold')

    return ';'.join(css_parts) if css_parts else ''


def extract_styles(ws, row_range, col_range):
    """Extract styles for a rectangular range. Returns list of lists."""
    styles = []
    for i in row_range:
        row_styles = []
        for j in col_range:
            row_styles.append(cell_style(ws, i, j))
        styles.append(row_styles)
    return styles

# ============================================================
# Sheet 1: Analysis Results
# ============================================================
df1 = pd.read_excel(EXCEL_PATH, sheet_name=0, header=None)

# ---- 单双分析 (cols 0-4, rows 0-10) ----
odd_even_title = str(df1.iloc[0, 0])  # 01 单双分析
odd_even_headers = [str(df1.iloc[1, j]) for j in range(5)]
odd_even_header_styles = extract_styles(ws1, range(1, 2), range(0, 5))[0]
odd_even_data = []
for i in range(2, 11):
    row = []
    for j in range(5):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        odd_even_data.append(row)
odd_even_styles = extract_styles(ws1, range(2, 2 + len(odd_even_data)), range(0, 5))

# ---- 大小双统计 (cols 6-11, rows 0-11) ----
size_dual_title = str(df1.iloc[0, 6])
size_dual_headers = [str(df1.iloc[1, j]) for j in range(6, 12)]
size_dual_header_styles = extract_styles(ws1, range(1, 2), range(6, 12))[0]
size_dual_data = []
for i in range(2, 12):
    row = []
    for j in range(6, 12):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        size_dual_data.append(row)
size_dual_styles = extract_styles(ws1, range(2, 2 + len(size_dual_data)), range(6, 12))

# ---- 开头统计 (cols 13-18, rows 0-7) ----
head_title = str(df1.iloc[0, 13])
head_headers = [str(df1.iloc[1, j]) for j in range(13, 19)]
head_header_styles = extract_styles(ws1, range(1, 2), range(13, 19))[0]
head_data = []
for i in range(2, 8):
    row = []
    for j in range(13, 19):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        head_data.append(row)
head_styles = extract_styles(ws1, range(2, 2 + len(head_data)), range(13, 19))

# ---- 尾数统计 (cols 20-25, rows 0-12) ----
tail_title = str(df1.iloc[0, 20])
tail_headers = [str(df1.iloc[1, j]) for j in range(20, 26)]
tail_header_styles = extract_styles(ws1, range(1, 2), range(20, 26))[0]
tail_data = []
for i in range(2, 13):
    row = []
    for j in range(20, 26):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        tail_data.append(row)
tail_styles = extract_styles(ws1, range(2, 2 + len(tail_data)), range(20, 26))

# ---- 数字出现频率 (5 blocks: cols 27-31, 32-36, 37-41, 42-46, 47-51) ----
freq_title = str(df1.iloc[0, 27])
freq_headers = [str(df1.iloc[1, j]) for j in range(27, 32)]

all_freq = {}
freq_rows = []
block_starts_freq = [27, 33, 39, 45]
_dup_warned = set()
for block_start in block_starts_freq:
    for row_idx in range(2, 15):
        num_val = df1.iloc[row_idx, block_start]
        count_val = df1.iloc[row_idx, block_start + 1]
        actual_val = df1.iloc[row_idx, block_start + 2]
        theory_val = df1.iloc[row_idx, block_start + 3]
        dev_val = df1.iloc[row_idx, block_start + 4]
        if pd.notna(num_val) and pd.notna(count_val):
            try:
                num = int(float(num_val))
                if num < 1 or num > 49:
                    continue
                count = int(float(count_val))
                actual_str = str(actual_val) if pd.notna(actual_val) else ""
                theory_str = str(theory_val) if pd.notna(theory_val) else ""
                dev_str = str(dev_val) if pd.notna(dev_val) else ""
                if num in all_freq and num not in _dup_warned:
                    print(f"[WARNING] duplicate number {num} at block_start={block_start}")
                    _dup_warned.add(num)
                all_freq[num] = count
                freq_rows.append([str(num), str(count), actual_str, theory_str, dev_str])
            except:
                pass

freq_items = sorted(all_freq.items())
freq_rows.sort(key=lambda r: int(r[0]))

# ---- 生肖统计 (rows 16-29, cols 0-4) ----
zodiac_title = str(df1.iloc[16, 0])
zodiac_headers = [str(df1.iloc[17, j]) for j in range(5)]
zodiac_header_styles = extract_styles(ws1, range(17, 18), range(0, 5))[0]
zodiac_data = []
for i in range(18, 30):
    row = []
    for j in range(5):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        zodiac_data.append(row)
zodiac_stats_styles = extract_styles(ws1, range(18, 18 + len(zodiac_data)), range(0, 5))

# ---- 生肖频率 (rows 16-29, cols 6-11) ----
zodiac_freq_title = str(df1.iloc[16, 6])
zodiac_freq_headers = [str(df1.iloc[17, j]) for j in range(6, 12)]
zodiac_freq_header_styles = extract_styles(ws1, range(17, 18), range(6, 12))[0]
zodiac_freq_data = []
for i in range(18, 30):
    row = []
    for j in range(6, 12):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        zodiac_freq_data.append(row)
zodiac_freq_styles = extract_styles(ws1, range(18, 18 + len(zodiac_freq_data)), range(6, 12))

# ---- 生肖合计 (row 14) ----
total_count = str(df1.iloc[14, 14]) if pd.notna(df1.iloc[14, 14]) else "275"

# ============================================================
# Sheet 2: Historical Lottery Records
# ============================================================
df2 = pd.read_excel(EXCEL_PATH, sheet_name=1, header=None)

# 10 month blocks starting from columns: 2, 17, 32, 47, 62, 77, 92, 107, 122, 137
month_blocks = []
block_starts = [2, 17, 32, 47, 62, 77, 92, 107, 122, 137]

for bs in block_starts:
    # Read month label from row 0-3
    month_label = ""
    for r in range(4):
        v = df2.iloc[r, bs + 2]  # date column
        if pd.notna(v):
            month_label = str(v)[:10]
            if month_label:
                break

    records = []
    record_styles = []
    col_offsets = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
    for row_idx in range(4, 36):
        date_v = df2.iloc[row_idx, bs + 2]
        if pd.notna(date_v):
            records.append({
                "period": str(df2.iloc[row_idx, bs + 0]) if pd.notna(df2.iloc[row_idx, bs + 0]) else "",
                "weekday": str(df2.iloc[row_idx, bs + 1]) if pd.notna(df2.iloc[row_idx, bs + 1]) else "",
                "date": str(date_v)[:10],
                "issue": str(df2.iloc[row_idx, bs + 3]) if pd.notna(df2.iloc[row_idx, bs + 3]) else "",
                "zodiac": str(df2.iloc[row_idx, bs + 4]).strip() if pd.notna(df2.iloc[row_idx, bs + 4]) else "",
                "color": str(df2.iloc[row_idx, bs + 5]).strip() if pd.notna(df2.iloc[row_idx, bs + 5]) else "",
                "size": str(df2.iloc[row_idx, bs + 6]).strip() if pd.notna(df2.iloc[row_idx, bs + 6]) else "",
                "odd_even": str(df2.iloc[row_idx, bs + 7]).strip() if pd.notna(df2.iloc[row_idx, bs + 7]) else "",
                "color_wave": str(df2.iloc[row_idx, bs + 8]).strip() if pd.notna(df2.iloc[row_idx, bs + 8]) else "",
                "beast": str(df2.iloc[row_idx, bs + 9]).strip() if pd.notna(df2.iloc[row_idx, bs + 9]) else "",
                "head": str(df2.iloc[row_idx, bs + 10]).strip() if pd.notna(df2.iloc[row_idx, bs + 10]) else "",
                "tail": str(df2.iloc[row_idx, bs + 11]).strip() if pd.notna(df2.iloc[row_idx, bs + 11]) else "",
                "color_oe": str(df2.iloc[row_idx, bs + 12]).strip() if pd.notna(df2.iloc[row_idx, bs + 12]) else "",
                "combo": str(df2.iloc[row_idx, bs + 13]).strip() if pd.notna(df2.iloc[row_idx, bs + 13]) else "",
            })
            row_styles = {}
            field_keys = ["period", "weekday", "date", "issue", "zodiac", "color", "size", "odd_even",
                          "color_wave", "beast", "head", "tail", "color_oe", "combo"]
            for k, off in zip(field_keys, col_offsets):
                s = cell_style(ws2, row_idx, bs + off)
                if s:
                    row_styles[k] = s
            record_styles.append(row_styles)

    if records:
        month_label_final = records[0]["date"][:7] if records else ""
        month_blocks.append({
            "label": month_label_final,
            "records": records,
            "record_styles": record_styles,
        })

# ============================================================
# Compute stats for overview
# ============================================================
total_draws = int(total_count)
hot_numbers = sorted(freq_items, key=lambda x: x[1], reverse=True)[:5]
cold_numbers = sorted(freq_items, key=lambda x: x[1])[:5]

# Zodiac deviation for overview
zodiac_deviations = []
for row in zodiac_data:
    if len(row) >= 4 and row[3]:
        try:
            dev = int(row[3])
            zodiac_deviations.append({"name": row[0], "deviation": dev, "alert": row[4] if len(row) > 4 else ""})
        except:
            pass

# Merge zodac freq with zodiac names
zodiac_freq_merged = []
for i, row in enumerate(zodiac_freq_data):
    name = row[0] if row else ""
    if i < len(zodiac_data):
        zodiac_data_name = zodiac_data[i][0] if zodiac_data[i] else ""
        if zodiac_data_name and not zodiac_data_name.startswith("\u263a"):
            name = zodiac_data_name
    zodiac_freq_merged.append({"name": name, "count": row[1] if len(row) > 1 else "0",
                                "actual_rate": row[2] if len(row) > 2 else "",
                                "theory_rate": row[3] if len(row) > 3 else "",
                                "deviation": row[4] if len(row) > 4 else ""})

# ============================================================
# Generate JSON data for JS
# ============================================================
data_json = {
    "odd_even": {
        "title": odd_even_title, "headers": odd_even_headers, "data": odd_even_data,
        "styles": odd_even_styles, "header_styles": odd_even_header_styles
    },
    "size_dual": {
        "title": size_dual_title, "headers": size_dual_headers, "data": size_dual_data,
        "styles": size_dual_styles, "header_styles": size_dual_header_styles
    },
    "head": {
        "title": head_title, "headers": head_headers, "data": head_data,
        "styles": head_styles, "header_styles": head_header_styles
    },
    "tail": {
        "title": tail_title, "headers": tail_headers, "data": tail_data,
        "styles": tail_styles, "header_styles": tail_header_styles
    },
    "frequency": {"title": freq_title, "headers": freq_headers, "rows": freq_rows, "items": [[k, v] for k, v in freq_items]},
    "zodiac": {
        "title": zodiac_title, "headers": zodiac_headers, "data": zodiac_data,
        "styles": zodiac_stats_styles, "header_styles": zodiac_header_styles
    },
    "zodiac_freq": {
        "title": zodiac_freq_title, "headers": zodiac_freq_headers, "merged": zodiac_freq_merged,
        "styles": zodiac_freq_styles, "header_styles": zodiac_freq_header_styles
    },
    "total_count": total_draws,
    "hot_numbers": [[k, v] for k, v in hot_numbers],
    "cold_numbers": [[k, v] for k, v in cold_numbers],
    "zodiac_deviations": zodiac_deviations,
    "zodiac_freq_merged": zodiac_freq_merged,
    "history": month_blocks,
}

data_json_str = json.dumps(data_json, ensure_ascii=False, indent=2)

# ============================================================
# Build HTML
# ============================================================
html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分析仪表盘</title>
    <style>
        :root {{
            --bg: #f0f2f5;
            --card-bg: #fff;
            --primary: #1a73e8;
            --text: #333;
            --text-secondary: #666;
            --text-muted: #999;
            --border: #e8e8e8;
            --shadow: 0 2px 12px rgba(0,0,0,0.08);
            --radius: 12px;
            --red: #e74c3c;
            --green: #27ae60;
            --orange: #e67e22;
            --blue: #3498db;
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }}
        .tab-nav {{
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
            padding: 0 32px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 99;
            box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        }}
        .tab-btn {{
            padding: 14px 20px;
            font-size: 14px;
            border: none;
            background: none;
            cursor: pointer;
            color: var(--text-secondary);
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
            white-space: nowrap;
        }}
        .tab-btn:hover {{ color: var(--primary); }}
        .tab-btn.active {{
            color: var(--primary);
            border-bottom-color: var(--primary);
            font-weight: 600;
        }}

        .main-content {{
            padding: 24px 32px 48px;
            max-width: 1400px;
        }}

        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}

        /* Overview Cards */
        .stat-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }}
        .stat-card {{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 20px 24px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary);
        }}
        .stat-card .label {{
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }}
        .stat-card .value {{
            font-size: 28px;
            font-weight: 700;
            color: var(--text);
        }}
        .stat-card .suffix {{
            font-size: 14px;
            font-weight: 400;
            color: var(--text-secondary);
            margin-left: 4px;
        }}
        .stat-card.card-red {{ border-left-color: var(--red); }}
        .stat-card.card-green {{ border-left-color: var(--green); }}
        .stat-card.card-orange {{ border-left-color: var(--orange); }}
        .stat-card.card-blue {{ border-left-color: var(--blue); }}

        .section {{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
        }}
        .section h2 {{
            font-size: 17px;
            font-weight: 600;
            margin-bottom: 18px;
            color: var(--text);
            padding-bottom: 12px;
            border-bottom: 1px solid var(--border);
        }}
        .section-desc {{
            font-size: 12px;
            color: var(--text-muted);
            margin: -12px 0 14px 0;
            line-height: 1.5;
        }}

        /* Two-column analysis grid */
        .analysis-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }}
        .analysis-grid .section {{
            margin-bottom: 0;
            min-width: 0;
        }}

        /* Tables */
        .table-wrap {{
            overflow-x: auto;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }}
        thead th {{
            background: #f8f9fa;
            padding: 10px 12px;
            font-weight: 600;
            text-align: center;
            border: 1px solid var(--border);
            color: var(--text-secondary);
            font-size: 12px;
        }}
        tbody td {{
            padding: 9px 12px;
            text-align: center;
            border: 1px solid var(--border);
        }}
        tbody tr:hover {{ background: #f0f7ff; }}
        .dev-up {{ color: var(--red); font-weight: 600; }}
        .dev-down {{ color: var(--green); font-weight: 600; }}
        .dev-neutral {{ color: var(--text-muted); }}
        .pct-positive {{ color: var(--green); font-weight: 600; }}
        .pct-negative {{ color: var(--red); font-weight: 600; }}
        .alert-tag {{
            display: inline-block;
            background: #fff3cd;
            color: #856404;
            padding: 1px 5px;
            border-radius: 3px;
            font-size: 10px;
            margin-left: 4px;
        }}

        /* Color wave highlighting */
        .wave-red {{ background: #fde8e8; color: #c0392b; font-weight: 600; }}
        .wave-blue {{ background: #e8f0fe; color: #2471a3; font-weight: 600; }}
        .wave-green {{ background: #e8f8e8; color: #1e8449; font-weight: 600; }}

        /* Frequency Grid */
        .freq-grid {{
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
            max-width: 420px;
        }}
        .freq-ball {{
            aspect-ratio: 1;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 600;
            font-size: 13px;
            cursor: default;
            box-shadow: 0 2px 6px rgba(0,0,0,0.12);
            transition: transform 0.2s;
            padding: 4px;
        }}
        .freq-ball:hover {{ transform: scale(1.08); }}
        .freq-ball .count {{
            font-size: 9px;
            opacity: 0.85;
            margin-top: 1px;
        }}
        .freq-hot {{ background: linear-gradient(135deg, #e74c3c, #c0392b); }}
        .freq-warm {{ background: linear-gradient(135deg, #f39c12, #e67e22); }}
        .freq-cool {{ background: linear-gradient(135deg, #3498db, #2980b9); }}
        .freq-cold {{ background: linear-gradient(135deg, #95a5a6, #7f8c8d); }}

        .legend {{
            display: flex;
            gap: 20px;
            margin-top: 16px;
            flex-wrap: wrap;
            font-size: 12px;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .legend-dot {{
            width: 14px;
            height: 14px;
            border-radius: 50%;
        }}

        /* Hot/Cold rows */
        .hotcold-row {{
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }}
        .hotcold-box {{
            flex: 1;
            min-width: 260px;
        }}
        .hotcold-box h3 {{
            font-size: 14px;
            margin-bottom: 10px;
            color: var(--text-secondary);
        }}
        .number-tag {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 20px;
            margin: 3px;
            font-size: 14px;
            font-weight: 600;
            color: #fff;
        }}
        .number-tag.hot {{ background: var(--red); }}
        .number-tag.cold {{ background: var(--blue); }}

        /* Zodiac bar chart */
        .zodiac-bars {{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}
        .zodiac-bar-row {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .zodiac-bar-label {{
            width: 60px;
            text-align: right;
            font-size: 13px;
            color: var(--text-secondary);
            flex-shrink: 0;
        }}
        .zodiac-bar-track {{
            flex: 1;
            height: 22px;
            background: #f0f0f0;
            border-radius: 11px;
            overflow: hidden;
            position: relative;
        }}
        .zodiac-bar-fill {{
            height: 100%;
            border-radius: 11px;
            display: flex;
            align-items: center;
            padding-left: 10px;
            font-size: 12px;
            color: #fff;
            font-weight: 600;
            min-width: 40px;
            transition: width 0.4s ease;
        }}
        .zodiac-bar-value {{
            color: var(--text);
            flex-shrink: 0;
            min-width: 32px;
            font-size: 13px;
            text-align: right;
        }}

        /* History table */
        .history-controls {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }}
        .month-pill {{
            padding: 8px 18px;
            border-radius: 20px;
            border: 1px solid var(--border);
            background: #fff;
            cursor: pointer;
            font-size: 13px;
            color: var(--text-secondary);
            transition: all 0.2s;
        }}
        .month-pill:hover {{ border-color: var(--primary); color: var(--primary); }}
        .month-pill.active {{
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }}
        .history-table {{
            display: none;
        }}
        .history-table.active {{
            display: block;
        }}

        /* Responsive */
        @media (max-width: 768px) {{
            .main-content {{ padding: 16px; }}
            .tab-nav {{ padding: 0 12px; }}
            .tab-btn {{ padding: 12px 14px; font-size: 13px; }}
            .stat-cards {{ grid-template-columns: repeat(2, 1fr); }}
            .freq-grid {{ grid-template-columns: repeat(4, 1fr); gap: 6px; }}
            .analysis-grid {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>

<div class="tab-nav" id="tabNav"></div>

<div class="main-content" id="mainContent"></div>

<script>
var DATA = {data_json_str};

function escapeHtml(s) {{ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }}

function isDeviation(s) {{
    if (!s) return 0;
    var v = parseFloat(s);
    return isNaN(v) ? 0 : v;
}}

function devClass(s) {{
    var v = isDeviation(s);
    if (v > 0.001) return 'dev-up';
    if (v < -0.001) return 'dev-down';
    return 'dev-neutral';
}}

function devClassInt(s) {{
    var v = parseInt(s);
    if (isNaN(v)) return 'dev-neutral';
    if (v > 0) return 'dev-up';
    if (v < 0) return 'dev-down';
    return 'dev-neutral';
}}

function waveClass(val) {{
    if (val.indexOf('红波') >= 0) return 'wave-red';
    if (val.indexOf('蓝波') >= 0) return 'wave-blue';
    if (val.indexOf('绿波') >= 0) return 'wave-green';
    return '';
}}

function fmtPercent(val, isDeviation) {{
    var v = parseFloat(val);
    if (isNaN(v)) return escapeHtml(val);
    var pct = (v * 100);
    var rounded = Math.round(pct * 100) / 100;
    if (isDeviation) {{
        var sign = rounded >= 0 ? '+' : '';
        var cls = rounded > 0.001 ? 'pct-positive' : (rounded < -0.001 ? 'pct-negative' : '');
        return '<span class="' + cls + '">' + sign + rounded + '%</span>';
    }}
    return rounded + '%';
}}

function buildTable(headers, data, hasDevCol, cellStyles, headerStyles, percentCols) {{
    var h = '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < headers.length; i++) {{
        var hs = (headerStyles && headerStyles[i]) ? ' style="' + headerStyles[i] + '"' : '';
        h += '<th' + hs + '>' + escapeHtml(headers[i]) + '</th>';
    }}
    h += '</tr></thead><tbody>';
    for (var r = 0; r < data.length; r++) {{
        h += '<tr>';
        for (var c = 0; c < data[r].length; c++) {{
            var val = data[r][c];
            var cls = '';
            var st = (cellStyles && cellStyles[r] && cellStyles[r][c]) ? ' style="' + cellStyles[r][c] + '"' : '';
            if (c === 0) {{
                var wc = waveClass(val);
                if (wc) cls = ' class="' + wc + '"';
            }}
            var display = escapeHtml(val);
            if (percentCols && percentCols.indexOf(c) >= 0) {{
                display = fmtPercent(val, false);
            }}
            if (hasDevCol && c === 4) {{
                display = fmtPercent(val, true);
            }}
            h += '<td' + cls + st + '>' + display + '</td>';
        }}
        h += '</tr>';
    }}
    h += '</tbody></table></div>';
    return h;
}}

function freqClass(count) {{
    if (count >= 9) return 'freq-hot';
    if (count >= 7) return 'freq-warm';
    if (count >= 4) return 'freq-cool';
    return 'freq-cold';
}}

function freqLabel(count) {{
    if (count >= 9) return '热';
    if (count >= 7) return '温';
    if (count >= 4) return '凉';
    return '冷';
}}

// ---- Build tabs ----
var tabs = [
    {{ id: 'overview', label: '首页概览' }},
    {{ id: 'analysis', label: '综合分析' }},
    {{ id: 'history', label: '历史记录' }},
];

var tabHtml = '';
for (var i = 0; i < tabs.length; i++) {{
    tabHtml += '<button class="tab-btn' + (i===0?' active':'') + '" data-tab="' + tabs[i].id + '">' + tabs[i].label + '</button>';
}}
document.getElementById('tabNav').innerHTML = tabHtml;

// ---- Build overview ----
function buildOverview() {{
    var d = DATA;
    var hot = d.hot_numbers;
    var cold = d.cold_numbers;
    var zd = d.zodiac_deviations;
    var zodiacSorted = zd.slice().sort(function(a,b) {{ return b.deviation - a.deviation; }});

    // Compute summary counts from odd_even data
    var oddCount = 0, evenCount = 0, bigCount = 0, smallCount = 0;
    var redWave = 0, blueWave = 0, greenWave = 0;
    var d1 = d.odd_even;
    for (var i = 0; i < d1.data.length; i++) {{
        var type = d1.data[i][0];
        var cnt = parseInt(d1.data[i][1]) || 0;
        if (type.indexOf('单') >= 0) oddCount = cnt;
        if (type.indexOf('双') >= 0) evenCount = cnt;
        if (type.indexOf('大') >= 0) bigCount = cnt;
        if (type.indexOf('小') >= 0) smallCount = cnt;
        if (type.indexOf('红波') >= 0) redWave = cnt;
        if (type.indexOf('蓝波') >= 0) blueWave = cnt;
        if (type.indexOf('绿波') >= 0) greenWave = cnt;
    }}

    var html = '';

    // Stat cards
    html += '<div class="stat-cards">';
    html += '<div class="stat-card"><div class="label">总期数</div><div class="value">' + d.total_count + '<span class="suffix">期</span></div></div>';
    html += '<div class="stat-card card-red"><div class="label">最热号码</div><div class="value">' + (hot[0] ? hot[0][0] : '-') + '<span class="suffix">(' + (hot[0] ? hot[0][1] : '-') + '次)</span></div></div>';
    html += '<div class="stat-card card-blue"><div class="label">最冷号码</div><div class="value">' + (cold[0] ? cold[0][0] : '-') + '<span class="suffix">(' + (cold[0] ? cold[0][1] : '-') + '次)</span></div></div>';
    html += '<div class="stat-card card-orange"><div class="label">生肖最高偏差</div><div class="value">' + (zodiacSorted.length > 0 ? escapeHtml(zodiacSorted[0].name) : '-') + '<span class="suffix">偏差' + (zodiacSorted.length > 0 ? zodiacSorted[0].deviation : '-') + '</span></div></div>';
    html += '</div>';

    // Hot / Cold numbers
    html += '<div class="section"><h2>热门 / 冷门数字</h2>';
    html += '<p class="section-desc">出现频次最高与最低的5个号码</p>';
    html += '<div class="hotcold-row">';
    html += '<div class="hotcold-box"><h3>热门数字</h3>';
    for (var i = 0; i < hot.length; i++) {{
        html += '<span class="number-tag hot">' + hot[i][0] + ' <small>(' + hot[i][1] + '次)</small></span>';
    }}
    html += '</div>';
    html += '<div class="hotcold-box"><h3>冷门数字</h3>';
    for (var i = 0; i < cold.length; i++) {{
        html += '<span class="number-tag cold">' + cold[i][0] + ' <small>(' + cold[i][1] + '次)</small></span>';
    }}
    html += '</div></div></div>';

    // Wave summary
    html += '<div class="section"><h2>红蓝绿波分布</h2>';
    html += '<p class="section-desc">红波、蓝波、绿波及大小单双的出现次数总览</p>';
    html += '<div class="stat-cards">';
    html += '<div class="stat-card" style="border-left-color:#e74c3c;background:#fef0f0"><div class="label" style="color:#e74c3c;font-weight:600">红波</div><div class="value" style="color:#e74c3c">' + redWave + '<span class="suffix" style="color:#e74c3c">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#2471a3;background:#f0f5fa"><div class="label" style="color:#2471a3;font-weight:600">蓝波</div><div class="value" style="color:#2471a3">' + blueWave + '<span class="suffix" style="color:#2471a3">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#1e8449;background:#f0faf3"><div class="label" style="color:#1e8449;font-weight:600">绿波</div><div class="value" style="color:#1e8449">' + greenWave + '<span class="suffix" style="color:#1e8449">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#e67e22;background:#fef9f3"><div class="label" style="color:#e67e22;font-weight:600">大</div><div class="value" style="color:#e67e22">' + bigCount + '<span class="suffix" style="color:#e67e22">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#8e44ad;background:#f9f3fc"><div class="label" style="color:#8e44ad;font-weight:600">小</div><div class="value" style="color:#8e44ad">' + smallCount + '<span class="suffix" style="color:#8e44ad">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#2e86c1;background:#f0f8fe"><div class="label" style="color:#2e86c1;font-weight:600">单</div><div class="value" style="color:#2e86c1">' + oddCount + '<span class="suffix" style="color:#2e86c1">次</span></div></div>';
    html += '<div class="stat-card" style="border-left-color:#d4ac0d;background:#fefdf3"><div class="label" style="color:#d4ac0d;font-weight:600">双</div><div class="value" style="color:#d4ac0d">' + evenCount + '<span class="suffix" style="color:#d4ac0d">次</span></div></div>';
    html += '</div></div>';

    // Zodiac deviation overview
    html += '<div class="analysis-grid"><div class="section"><h2>生肖偏差排行</h2>';
    html += '<p class="section-desc">按偏差值排序，正值偏多（红）、负值偏少（绿）</p>';
    html += '<div class="zodiac-bars">';
    var maxDev = 0;
    for (var i = 0; i < zodiacSorted.length; i++) {{
        maxDev = Math.max(maxDev, Math.abs(zodiacSorted[i].deviation));
    }}
    for (var i = 0; i < zodiacSorted.length; i++) {{
        var item = zodiacSorted[i];
        var pct = maxDev > 0 ? Math.abs(item.deviation) / maxDev * 100 : 0;
        var color = item.deviation > 0 ? 'var(--red)' : (item.deviation < 0 ? 'var(--green)' : '#aaa');
        html += '<div class="zodiac-bar-row">';
        html += '<div class="zodiac-bar-label">' + escapeHtml(item.name) + '</div>';
        html += '<div class="zodiac-bar-track"><div class="zodiac-bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div>';
        html += '<div class="zodiac-bar-value" style="color:' + color + '">' + (item.deviation >= 0 ? '+' : '') + item.deviation + '</div>';
        if (item.alert) html += '<span class="alert-tag">注意</span>';
        html += '</div>';
    }}
    html += '</div></div>';

    // Zodiac freq merged
    html += '<div class="section"><h2>生肖出现频率</h2>';
    html += '<p class="section-desc">各生肖的出现次数与理论占比对比</p>';
    var zfm = d.zodiac_freq_merged;
    html += '<div class="zodiac-bars">';
    var maxCount = 0;
    for (var i = 0; i < zfm.length; i++) {{
        maxCount = Math.max(maxCount, parseInt(zfm[i].count) || 0);
    }}
    for (var i = 0; i < zfm.length; i++) {{
        var item = zfm[i];
        var cnt = parseInt(item.count) || 0;
        var pct = maxCount > 0 ? cnt / maxCount * 100 : 0;
        html += '<div class="zodiac-bar-row">';
        html += '<div class="zodiac-bar-label">' + escapeHtml(item.name.substring(0,3)) + '</div>';
        html += '<div class="zodiac-bar-track"><div class="zodiac-bar-fill" style="width:' + pct + '%;background:var(--primary)">' + cnt + '</div></div>';
        html += '<div class="zodiac-bar-value">' + fmtPercent(item.actual_rate, false) + '</div>';
        html += '</div>';
    }}
    html += '</div></div></div>';

    return html;
}}

function buildAnalysisPiece(d, percentCols, desc) {{
    var descHtml = desc ? '<p class="section-desc">' + desc + '</p>' : '';
    return '<div class="section"><h2>' + escapeHtml(d.title) + '</h2>' + descHtml +
        buildTable(d.headers, d.data, true, d.styles, d.header_styles, percentCols) + '</div>';
}}

function buildFreqSection() {{
    var d = DATA.frequency;
    var html = '<div class="section"><h2>' + escapeHtml(d.title) + '</h2>';
    html += '<p class="section-desc">49个号码的出现次数、实际占比、理论占比及偏差一览</p>';
    html += '<div class="table-wrap" style="max-height:420px;overflow-y:auto"><table><thead><tr>';
    for (var i = 0; i < d.headers.length; i++) {{
        html += '<th>' + escapeHtml(d.headers[i]) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var rows = d.rows || [];
    for (var r = 0; r < rows.length; r++) {{
        html += '<tr>';
        html += '<td>' + escapeHtml(rows[r][0]) + '</td>';
        html += '<td>' + escapeHtml(rows[r][1]) + '</td>';
        html += '<td>' + fmtPercent(rows[r][2], false) + '</td>';
        html += '<td>' + fmtPercent(rows[r][3], false) + '</td>';
        html += '<td>' + fmtPercent(rows[r][4], true) + '</td>';
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';
    return html;
}}

function buildZodiacSection() {{
    var html = '';
    var d1 = DATA.zodiac;
    html += '<div class="section"><h2>' + escapeHtml(d1.title) + '</h2>';
    html += '<p class="section-desc">十二生肖的最近出现期数、偏差值及是否需关注</p>';
    html += '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < d1.headers.length; i++) {{
        var hs = (d1.header_styles && d1.header_styles[i]) ? ' style="' + d1.header_styles[i] + '"' : '';
        html += '<th' + hs + '>' + escapeHtml(d1.headers[i]) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var styles1 = d1.styles;
    for (var r = 0; r < d1.data.length; r++) {{
        html += '<tr>';
        for (var c = 0; c < d1.data[r].length; c++) {{
            var val = d1.data[r][c];
            var cls = '';
            var st = (styles1 && styles1[r] && styles1[r][c]) ? ' style="' + styles1[r][c] + '"' : '';
            var display = escapeHtml(val);
            if (c === 3) {{
                var v = parseInt(val);
                if (!isNaN(v)) {{
                    cls = ' class="' + (v > 0 ? 'pct-positive' : (v < 0 ? 'pct-negative' : '')) + '"';
                    display = (v >= 0 ? '+' : '') + v;
                }}
            }}
            if (c === 4 && val) {{
                var alertColors = {{'忽略': 'background:#e8e8e8;color:#888', '提醒': 'background:#fff3cd;color:#856404', '可以追': 'background:#c8e6c9;color:#1b5e20'}};
                var ast = alertColors[val] || '';
                var exst = (styles1 && styles1[r] && styles1[r][c]) || '';
                st = ast || exst ? ' style="' + ast + (ast && exst ? ';' : '') + exst + '"' : '';
            }}
            html += '<td' + cls + st + '>' + display + '</td>';
        }}
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';

    var d2 = DATA.zodiac_freq;
    html += '<div class="section"><h2>' + escapeHtml(d2.title) + '</h2>';
    html += '<p class="section-desc">各生肖的出现频次、实际占比、理论占比及偏差范围</p>';
    var zfm = DATA.zodiac_freq_merged;
    html += '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < d2.headers.length; i++) {{
        var hs2 = (d2.header_styles && d2.header_styles[i]) ? ' style="' + d2.header_styles[i] + '"' : '';
        html += '<th' + hs2 + '>' + escapeHtml(d2.headers[i]) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var styles2 = d2.styles;
    for (var r = 0; r < zfm.length; r++) {{
        html += '<tr>';
        var item = zfm[r];
        for (var c = 0; c < 6; c++) {{
            var st = (styles2 && styles2[r] && styles2[r][c]) ? ' style="' + styles2[r][c] + '"' : '';
            var display = escapeHtml(item[['name','count','actual_rate','theory_rate','deviation',''][c]] || '');
            if (c === 2 || c === 3) display = fmtPercent(item[['name','count','actual_rate','theory_rate','deviation',''][c]] || '0', false);
            if (c === 4) display = fmtPercent(item.deviation || '0', true);
            html += '<td' + st + '>' + display + '</td>';
        }}
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';

    return html;
}}

function buildAnalysis() {{
    return '<div class="analysis-grid">' +
        buildAnalysisPiece(DATA.odd_even, [2, 3], '统计单、双、大、小及红蓝绿波的出现次数、实际占比与理论偏差') +
        buildAnalysisPiece(DATA.size_dual, [2, 3], '统计大小与单双交叉组合的分布情况') +
        buildAnalysisPiece(DATA.head, [2, 3], '按号头（十位数字）统计出现频次与偏差') +
        buildAnalysisPiece(DATA.tail, [2, 3], '按号尾（个位数字）统计出现频次与偏差') +
        buildFreqSection() +
        buildZodiacSection() +
    '</div>';
}}

function buildHistory() {{
    var months = DATA.history;
    var html = '<div class="section"><h2>历史开奖记录</h2>';
    html += '<p class="section-desc">按月份切换查看每期开奖的详细结果，含生肖/颜色/大小/单双等属性</p>';
    html += '<div class="history-controls">';
    for (var i = 0; i < months.length; i++) {{
        html += '<button class="month-pill' + (i===0?' active':'') + '" data-month="' + i + '">' + escapeHtml(months[i].label) + '</button>';
    }}
    html += '</div>';

    for (var i = 0; i < months.length; i++) {{
        var m = months[i];
        html += '<div class="history-table table-wrap' + (i===0?' active':'') + '" data-month="' + i + '">';
        html += '<table><thead><tr>';
        html += '<th>周期</th><th>星期</th><th>日期</th><th>期数</th><th>生肖</th><th>颜色</th><th>大小</th><th>单双</th><th>色波</th><th>野兽</th><th>号头</th><th>号尾</th><th>颜色单双</th><th>组合</th>';
        html += '</tr></thead><tbody>';
        var rstyles = m.record_styles || [];
        var fields = ['period', 'weekday', 'date', 'issue', 'zodiac', 'color', 'size', 'odd_even',
                       'color_wave', 'beast', 'head', 'tail', 'color_oe', 'combo'];
        for (var r = 0; r < m.records.length; r++) {{
            var rec = m.records[r];
            var rs = rstyles[r] || {{}};
            html += '<tr>';
            for (var f = 0; f < fields.length; f++) {{
                var key = fields[f];
                var st = rs[key] ? ' style="' + rs[key] + '"' : '';
                html += '<td' + st + '>' + escapeHtml(rec[key]) + '</td>';
            }}
            html += '</tr>';
        }}
        html += '</tbody></table></div>';
    }}
    html += '</div>';
    return html;
}}

// Content builders
var builders = {{
    overview: buildOverview,
    analysis: buildAnalysis,
    history: buildHistory,
}};

var container = document.getElementById('mainContent');

// Lazy render tabs
var rendered = {{}};
function showTab(id) {{
    if (!rendered[id]) {{
        rendered[id] = builders[id]();
    }}
    container.innerHTML = rendered[id];
}}

showTab('overview');

// Tab click
document.getElementById('tabNav').addEventListener('click', function(e) {{
    var btn = e.target.closest('.tab-btn');
    if (!btn) return;
    var id = btn.getAttribute('data-tab');
    document.querySelectorAll('.tab-btn').forEach(function(b) {{ b.classList.remove('active'); }});
    btn.classList.add('active');
    showTab(id);
}});

// Month pill click
document.addEventListener('click', function(e) {{
    var pill = e.target.closest('.month-pill');
    if (!pill) return;
    var mid = pill.getAttribute('data-month');
    document.querySelectorAll('.month-pill').forEach(function(p) {{ p.classList.remove('active'); }});
    pill.classList.add('active');
    document.querySelectorAll('.history-table').forEach(function(t) {{ t.classList.remove('active'); }});
    var tables = document.querySelectorAll('.history-table');
    for (var i = 0; i < tables.length; i++) {{
        if (tables[i].getAttribute('data-month') === mid) {{
            tables[i].classList.add('active');
            break;
        }}
    }}
}});
</script>

</body>
</html>"""

with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
    f.write(html)

print(f"Generated: {OUTPUT_PATH}")
print(f"Size: {len(html.encode('utf-8'))} bytes")
