# -*- coding: utf-8 -*-
"""
从接口拉取当前年份开奖数据，合并写入 txt-source
自动适配年份：2026→临时测试-2026.txt，2027→临时测试-2027.txt，以此类推
用法: python 02-script/fetch_data.py
"""
import json
import os
import requests
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TXT_DIR = os.path.join(BASE_DIR, '03-data', 'txt-source')
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
CUR_YEAR = datetime.now().year


def load_config():
    with open(CONFIG_FILE, encoding='utf-8') as f:
        cfg = json.load(f)
    return cfg['api']


def fetch_api():
    api = load_config()
    body = dict(api['body'])
    body['y'] = CUR_YEAR
    url = api['url']
    headers = api['headers']
    timeout = api.get('timeout', 300)
    print('[请求] %s  year=%d（接口响应较慢，请耐心等待...）' % (url, CUR_YEAR))
    try:
        r = requests.post(url, json=body, headers=headers, timeout=timeout)
        r.raise_for_status()
        data = r.json()
    except Exception as e:
        print('[失败] %s' % e)
        return None
    records = data if isinstance(data, list) else data.get('data', data.get('list', []))
    print('[成功] 返回 %d 条记录' % len(records))
    return records


def load_existing(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding='utf-8') as f:
        return json.load(f)


def save_records(records, path):
    records.sort(key=lambda r: r.get('date', ''), reverse=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False)
    print('[保存] %d 条记录 -> %s' % (len(records), path))


def main():
    target = get_target_file()
    print('=' * 50)
    print('  数据拉取  %s  目标年份: %d' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), CUR_YEAR))
    print('  写入文件: %s' % os.path.basename(target))
    print('=' * 50)

    new_records = fetch_api()
    if new_records is None:
        print('[跳过] 接口获取失败，保留现有数据')
        return

    existing = load_existing(target)
    exist_ids = {r['id'] for r in existing}
    added = 0
    for r in new_records:
        if r.get('id') not in exist_ids:
            existing.append(r)
            exist_ids.add(r['id'])
            added += 1

    if added == 0:
        print('[无变化] 无新记录')
        return

    print('[新增] %d 条记录（累计 %d 条）' % (added, len(existing)))
    save_records(existing, target)


if __name__ == '__main__':
    main()
