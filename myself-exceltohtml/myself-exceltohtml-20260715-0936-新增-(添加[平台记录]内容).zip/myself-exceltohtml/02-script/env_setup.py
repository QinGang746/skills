# -*- coding: utf-8 -*-
"""
环境检测脚本：检查 Python 版本和依赖库，自动安装缺失依赖
用法: python 02-script/env_check.py
命名规范: env_ 前缀 = 环境脚本，非 env_ 前缀 = 业务脚本
"""
import sys
import subprocess
import importlib

REQUIRED = {
    'openpyxl': 'openpyxl>=3.1.0',
    'pandas': 'pandas>=1.3.0',
    'requests': 'requests>=2.25.0',
}


def check_python():
    v = sys.version_info
    ok = v.major >= 3 and v.minor >= 7
    print('[Python] %d.%d.%d %s' % (v.major, v.minor, v.micro, 'OK' if ok else '需 >=3.7'))
    return ok


def check_pip():
    try:
        import pip
        print('[pip] %s OK' % pip.__version__)
        return True
    except ImportError:
        print('[pip] 未安装，请先安装 pip：https://pip.pypa.io')
        return False


def check_package(name, install_name):
    try:
        m = importlib.import_module(name)
        v = getattr(m, '__version__', '?')
        print('[%s] %s OK' % (name, v))
        return True
    except ImportError:
        print('[%s] 缺失' % name)
        return False


def install_package(install_name):
    print('  >> 正在安装 %s ...' % install_name)
    try:
        subprocess.check_call(
            [sys.executable, '-m', 'pip', 'install', install_name, '-q'],
            timeout=120
        )
        return True
    except Exception as e:
        print('  >> 安装失败: %s' % e)
        return False


def main():
    print('=' * 50)
    print('  myself-pyhtml  环境检测')
    print('=' * 50)

    all_ok = True

    if not check_python():
        all_ok = False
        print('\n[中止] Python 版本需 >=3.7')
        input('\n按回车键退出...')
        sys.exit(1)
    if not check_pip():
        all_ok = False
        print('\n[中止] Python/pip 环境不满足，请先安装 Python 3.7+')
        print('  下载: https://www.python.org/downloads/')
        input('\n按回车键退出...')
        sys.exit(1)

    print()
    missing = {}
    for pkg, install_name in REQUIRED.items():
        if not check_package(pkg, install_name):
            missing[pkg] = install_name

    if missing:
        print('\n[自动安装] 共 %d 个缺失依赖...' % len(missing))
        for pkg, install_name in missing.items():
            if install_package(install_name):
                print('  [%s] 安装成功' % pkg)
            else:
                print('  [%s] 安装失败，请手动执行: pip install %s' % (pkg, install_name))
                all_ok = False

        # 二次校验
        print()
        still_missing = []
        for pkg in missing:
            if not check_package(pkg, ''):
                still_missing.append(pkg)
        if still_missing:
            print('\n[警告] 以下包仍缺失: %s' % ', '.join(still_missing))
            print('  请手动执行: pip install %s' % ' '.join(REQUIRED.values()))
            all_ok = False

    if all_ok:
        print('\n[通过] 环境检测全部通过，开始执行任务...')
        sys.exit(0)
    else:
        print('\n[未通过] 请解决以上问题后重新运行')
        input('\n按回车键退出...')
        sys.exit(1)


if __name__ == '__main__':
    main()
