import argparse
import json
import csv
import os
import re
import sys
from datetime import datetime, date

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
HEADER_ALIGNMENT = Alignment(horizontal="center", vertical="center")
CELL_ALIGNMENT = Alignment(vertical="center")
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)

LUNAR_INFO = [
    0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
    0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
    0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
    0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
    0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
    0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5b0, 0x14573, 0x052b0, 0x0a9a8, 0x0e950, 0x06aa0,
    0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
    0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b6a0, 0x195a6,
    0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
    0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x05ac0, 0x0ab60, 0x096d5, 0x092e0,
    0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
    0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
    0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
    0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
    0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0,
    0x14b63, 0x09370, 0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06aa0, 0x1a6c4, 0x0aae0,
    0x092e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0, 0x0a6d0, 0x055d4,
    0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50, 0x055a0, 0x0aba4, 0x0a5b0, 0x052b0,
    0x0b273, 0x06930, 0x07337, 0x06aa0, 0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160,
    0x0e968, 0x0d520, 0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a4d0, 0x0d150, 0x0f252,
    0x0d520,
]
STEMS = "甲乙丙丁戊己庚辛壬癸"
BRANCHES = "子丑寅卯辰巳午未申酉戌亥"
ZODIAC = "鼠牛虎兔龙蛇马羊猴鸡狗猪"
LUNAR_MONTH = "正二三四五六七八九十冬腊"
LUNAR_DAY = "初一初二初三初四初五初六初七初八初九初十十一十二十三十四十五十六十七十八十九二十廿一廿二廿三廿四廿五廿六廿七廿八廿九三十"
SOLAR_BASE = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]


def detect_format(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    if ext == ".json":
        return "json"
    if ext in (".csv", ".tsv"):
        return ext.lstrip(".")
    return None


def read_json(filepath, encoding):
    with open(filepath, "r", encoding=encoding) as f:
        data = json.load(f)
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
        return data
    if isinstance(data, dict):
        return [data]
    raise ValueError("JSON content must be a list of objects or a single object.")


def read_csv(filepath, encoding, delimiter):
    rows = []
    with open(filepath, "r", encoding=encoding, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        for row in reader:
            rows.append(row)
    return rows


def build_merge_groups(split_columns, prefixes, specials, normal_count):
    groups = []
    for idx, col in enumerate(split_columns):
        prefix = prefixes[idx] if idx < len(prefixes) else col
        cols = [f"{prefix}{i + 1}" for i in range(normal_count)]
        groups.append({"label": prefix, "columns": cols})
    return groups


def split_columns_in_rows(rows, split_columns, prefixes, specials, normal_count):
    if not rows:
        return rows

    original_order = list(rows[0].keys())
    split_config = {}

    for col in split_columns:
        if col not in original_order:
            continue
        idx = split_columns.index(col)
        prefix = prefixes[idx] if idx < len(prefixes) else col
        special = specials[idx] if idx < len(specials) else f"特{col}"
        new_cols = [f"{prefix}{i + 1}" for i in range(normal_count)] + [special]
        split_config[col] = new_cols

    new_order = []
    for col in original_order:
        if col in split_config:
            new_order.extend(split_config[col])
        else:
            new_order.append(col)

    new_rows = []
    for row in rows:
        new_row = {}
        for col, val in row.items():
            if col in split_config:
                parts = [p.strip() for p in str(val).split(",")]
                new_cols = split_config[col]
                for i, nc in enumerate(new_cols):
                    new_row[nc] = parts[i] if i < len(parts) else ""
            else:
                new_row[col] = val
        new_rows.append(new_row)

    return new_rows


def lunar_year_info(year):
    return LUNAR_INFO[year - 1900]


def lunar_leap_month(year):
    return lunar_year_info(year) & 0xf


def lunar_year_days(year):
    info = lunar_year_info(year)
    days = 0
    for i in range(1, 13):
        days += 29 if (info >> (16 - i)) & 1 == 0 else 30
    leap = lunar_leap_month(year)
    if leap:
        days += 29 if (info >> 16) & 1 == 0 else 30
    return days


def solar_day_of_year(y, m, d):
    days = SOLAR_BASE[m - 1] + d
    if m > 2 and y % 4 == 0 and (y % 100 != 0 or y % 400 == 0):
        days += 1
    return days


def solar_to_lunar(solar_date):
    y, m, d = solar_date.year, solar_date.month, solar_date.day

    total_days = 0
    for sy in range(1900, y):
        if sy % 4 == 0 and (sy % 100 != 0 or sy % 400 == 0):
            total_days += 366
        else:
            total_days += 365
    total_days += solar_day_of_year(y, m, d)
    offset = total_days - 31

    lunar_y = 1900
    while True:
        year_days = lunar_year_days(lunar_y)
        if offset < year_days:
            break
        offset -= year_days
        lunar_y += 1

    leap_month = lunar_leap_month(lunar_y)
    info = lunar_year_info(lunar_y)
    is_leap = False
    lunar_m = 12
    lunar_d = offset + 1

    for m in range(1, 13):
        # regular month m
        month_days = 29 if (info >> (16 - m)) & 1 == 0 else 30
        if offset < month_days:
            lunar_m = m
            lunar_d = offset + 1
            is_leap = False
            break
        offset -= month_days

        # leap month follows month == leap_month
        if leap_month > 0 and m == leap_month:
            leap_days = 29 if (info >> 16) & 1 == 0 else 30
            if offset < leap_days:
                lunar_m = m
                lunar_d = offset + 1
                is_leap = True
                break
            offset -= leap_days

    stem = STEMS[(lunar_y - 4) % 10]
    branch = BRANCHES[(lunar_y - 4) % 12]
    zod = ZODIAC[(lunar_y - 4) % 12]

    month_name = LUNAR_MONTH[lunar_m - 1] if 1 <= lunar_m <= 12 else str(lunar_m)
    day_name = LUNAR_DAY[(lunar_d - 1) * 2:(lunar_d - 1) * 2 + 2] if 1 <= lunar_d <= 30 else str(lunar_d)
    leap_prefix = "闰" if is_leap and lunar_m == leap_month else ""

    lunar_short = f"农历{lunar_y}-{lunar_m:02d}-{lunar_d:02d}"
    return stem + branch + "年" + leap_prefix + month_name + "月" + day_name, lunar_short, zod


def add_lunar_date_column(rows, date_col="date", lunar_col="农历date"):
    if not rows:
        return rows

    new_order = []
    for col in rows[0].keys():
        new_order.append(col)
        if col == date_col:
            new_order.append(lunar_col)

    new_rows = []
    for row in rows:
        new_row = {}
        for col in rows[0].keys():
            new_row[col] = row[col]
        date_val = row.get(date_col, "")
        try:
            dt = datetime.strptime(str(date_val), "%Y-%m-%d").date()
            _, lunar_short, _ = solar_to_lunar(dt)
            new_row[lunar_col] = lunar_short
        except (ValueError, TypeError):
            new_row[lunar_col] = ""
        new_rows.append(new_row)

    reordered = []
    for row in new_rows:
        ordered_row = {}
        for col in new_order:
            ordered_row[col] = row.get(col, "")
        reordered.append(ordered_row)

    return reordered


BOSE_RGB_MAP = {
    "FFF1A2AB": "红波",
    "FF81BBF8": "蓝波",
    "FFC1E77E": "绿波",
}

BOSE_FILLS = {
    "红波": PatternFill(start_color="FFF1A2AB", end_color="FFF1A2AB", fill_type="solid"),
    "蓝波": PatternFill(start_color="FF81BBF8", end_color="FF81BBF8", fill_type="solid"),
    "绿波": PatternFill(start_color="FFC1E77E", end_color="FFC1E77E", fill_type="solid"),
}


def load_bose_table(filepath):
    wb = load_workbook(filepath)
    ws = wb.active
    table = {}
    for row_idx in range(1, ws.max_row + 1):
        label = str(ws.cell(row=row_idx, column=1).value or "")
        match = re.search(r"农历(\d{4})年.*号码", label)
        if not match:
            continue
        year = int(match.group(1))
        if year in table:
            continue
        mapping = {}
        for col_idx in range(2, ws.max_column + 1):
            num = col_idx - 1
            cell = ws.cell(row=row_idx, column=col_idx)
            fill = cell.fill
            rgb = ""
            try:
                if fill and fill.start_color and fill.start_color.rgb:
                    rgb = str(fill.start_color.rgb)
            except Exception:
                pass
            color_name = BOSE_RGB_MAP.get(rgb, "")
            if color_name:
                mapping[num] = color_name
        table[year] = mapping
    wb.close()
    return table


def add_bose_column(rows, bose_table, te_ma_col="特码", lunar_col="农历date", bose_col="波色"):
    if not rows:
        return rows, []

    new_order = []
    for col in rows[0].keys():
        new_order.append(col)
        if col == te_ma_col:
            new_order.append(bose_col)

    new_rows = []
    bose_fills = []

    for row in rows:
        new_row = {}
        for col in rows[0].keys():
            new_row[col] = row[col]

        bose_val = ""
        bose_fill = None

        lunar_str = str(row.get(lunar_col, ""))
        lunar_match = re.search(r"农历(\d{4})", lunar_str)
        te_ma_str = str(row.get(te_ma_col, "")).strip()

        if lunar_match and te_ma_str:
            lunar_year = int(lunar_match.group(1))
            try:
                te_ma_num = int(te_ma_str)
            except ValueError:
                te_ma_num = None

            if te_ma_num and lunar_year in bose_table:
                color = bose_table[lunar_year].get(te_ma_num, "")
                if color:
                    bose_val = color
                    bose_fill = BOSE_FILLS.get(color)

        new_row[bose_col] = bose_val
        bose_fills.append(bose_fill)
        new_rows.append(new_row)

    reordered = []
    for row in new_rows:
        ordered_row = {}
        for col in new_order:
            ordered_row[col] = row.get(col, "")
        reordered.append(ordered_row)

    return reordered, bose_fills


def apply_style(cell, font=None, fill=None, alignment=None, border=None):
    if font:
        cell.font = font
    if fill:
        cell.fill = fill
    if alignment:
        cell.alignment = alignment
    if border:
        cell.border = border


def auto_column_width(ws, min_width=8, max_width=40):
    for col_cells in ws.columns:
        max_len = 0
        first_cell = None
        for c in col_cells:
            try:
                _ = c.column_letter
                first_cell = c
                break
            except AttributeError:
                continue
        if first_cell is None:
            continue
        col_letter = first_cell.column_letter
        for cell in col_cells:
            try:
                val = str(cell.value) if cell.value is not None else ""
                max_len = max(max_len, len(val))
            except AttributeError:
                continue
        adjusted = min(max(max_len + 2, min_width), max_width)
        ws.column_dimensions[col_letter].width = adjusted


def write_excel(rows, output_path, sheet_name, merge_groups=None, bose_fills=None, bose_col="波色"):
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name

    if not rows:
        wb.save(output_path)
        return

    headers = list(rows[0].keys())
    merge_groups = merge_groups or []

    group_info = {}
    for g in merge_groups:
        for col in g["columns"]:
            if col in headers:
                group_info[col] = g

    header_values = []
    header_merges = []

    for i, col in enumerate(headers):
        if col in group_info:
            g = group_info[col]
            cols = g["columns"]
            if col == cols[0]:
                header_values.append(g["label"])
                end_col = i + len(cols)
                if len(cols) > 1:
                    header_merges.append((i + 1, end_col))
            else:
                header_values.append(None)
        else:
            header_values.append(col)

    for i, val in enumerate(header_values, 1):
        cell = ws.cell(row=1, column=i)
        if val is not None:
            cell.value = val
        apply_style(cell, font=HEADER_FONT, fill=HEADER_FILL, alignment=HEADER_ALIGNMENT, border=THIN_BORDER)

    for start_col, end_col in header_merges:
        ws.merge_cells(start_row=1, start_column=start_col, end_row=1, end_column=end_col)

    for row_dict in rows:
        ws.append([row_dict.get(h, "") for h in headers])

    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=len(headers)):
        for cell in row:
            apply_style(cell, alignment=CELL_ALIGNMENT, border=THIN_BORDER)

    if bose_fills and bose_col in headers:
        bose_col_idx = headers.index(bose_col) + 1
        for row_idx, fill in enumerate(bose_fills):
            if fill:
                cell = ws.cell(row=row_idx + 2, column=bose_col_idx)
                cell.fill = fill

    auto_column_width(ws)

    wb.save(output_path)


def main():
    parser = argparse.ArgumentParser(description="Convert text file to Excel (.xlsx)")
    parser.add_argument("input", help="Path to input text file")
    parser.add_argument("output", nargs="?", default=None, help="Path to output .xlsx file (default: derived from input)")
    parser.add_argument("--encoding", default="utf-8", help="Input file encoding (default: utf-8)")
    parser.add_argument("--format", dest="fmt", choices=["json", "csv", "tsv"],
                        help="Explicitly specify input format")
    parser.add_argument("--sheet-name", default="Sheet1", help="Excel sheet name (default: Sheet1)")
    parser.add_argument("--split", help="Comma-separated column names to split (e.g. num,shengxiao,wuxing)")
    parser.add_argument("--split-prefixes", help="Comma-separated prefixes for normal columns (e.g. 平码,平肖,平五行)")
    parser.add_argument("--split-special", help="Comma-separated special column labels (e.g. 特码,特肖,特五行)")
    parser.add_argument("--split-normal-count", type=int, default=6,
                        help="Number of normal (平) items before special (default: 6)")
    parser.add_argument("--timestamp", action="store_true",
                        help="Append timestamp (_YYYYMMDD-HHMMSS) to output filename")
    parser.add_argument("--lunar-date", action="store_true",
                        help="Add a NongLi date column next to the date column")
    parser.add_argument("--bose-table", default=None,
                        help="Path to tmp bose lookup table xlsx (e.g. tmp-十二生肖编号对照表.xlsx)")
    args = parser.parse_args()

    fmt = args.fmt or detect_format(args.input)
    if not fmt:
        print(f"ERROR: Cannot detect format from file extension. Use --format to specify.")
        sys.exit(1)

    if fmt == "json":
        rows = read_json(args.input, args.encoding)
    elif fmt == "csv":
        rows = read_csv(args.input, args.encoding, delimiter=",")
    elif fmt == "tsv":
        rows = read_csv(args.input, args.encoding, delimiter="\t")
    else:
        print(f"ERROR: Unsupported format: {fmt}")
        sys.exit(1)

    split_columns = []
    prefixes = []
    specials = []

    if args.split:
        split_columns = [c.strip() for c in args.split.split(",")]
        prefixes = [p.strip() for p in (args.split_prefixes or "").split(",")] if args.split_prefixes else []
        specials = [s.strip() for s in (args.split_special or "").split(",")] if args.split_special else []
        rows = split_columns_in_rows(rows, split_columns, prefixes, specials, args.split_normal_count)

    if args.lunar_date:
        rows = add_lunar_date_column(rows)

    bose_fills = None
    if args.bose_table and rows:
        bose_table = load_bose_table(args.bose_table)
        te_ma_col = (specials[0] if specials else "特码") if args.split else "num"
        rows, bose_fills = add_bose_column(rows, bose_table, te_ma_col=te_ma_col)

    merge_groups = None
    if rows and split_columns:
        merge_groups = build_merge_groups(split_columns, prefixes, specials, args.split_normal_count)

    if args.output is None:
        base = os.path.splitext(os.path.basename(args.input))[0]
        args.output = f"{base}.xlsx"

    if args.timestamp:
        base, ext = os.path.splitext(args.output)
        ts = datetime.now().strftime("%Y%m%d-%H%M")
        args.output = f"{base}-{ts}{ext}"

    write_excel(rows, args.output, args.sheet_name, merge_groups, bose_fills=bose_fills)
    print(f"Conversion complete: {args.input} -> {args.output}")
    print(f"Rows: {len(rows)}  Columns: {len(rows[0]) if rows else 0}")


if __name__ == "__main__":
    main()
