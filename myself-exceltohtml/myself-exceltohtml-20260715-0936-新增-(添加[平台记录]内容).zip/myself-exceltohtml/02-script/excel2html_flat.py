import argparse
import os
import sys
import openpyxl
from openpyxl.utils import get_column_letter
from html import escape


def excel_to_html(excel_path, output_path=None, title=None, include_sheet_names=True):
    if not os.path.exists(excel_path):
        print(f"错误: 文件不存在 - {excel_path}")
        sys.exit(1)

    wb = openpyxl.load_workbook(excel_path, data_only=True)

    if title is None:
        title = os.path.splitext(os.path.basename(excel_path))[0]

    if output_path is None:
        output_path = os.path.splitext(os.path.basename(excel_path))[0] + ".html"

    html_parts = []
    html_parts.append("""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: "Microsoft YaHei", Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }}
        h1 {{
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }}
        .sheet-container {{
            margin-bottom: 30px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.1);
            overflow: hidden;
        }}
        .sheet-title {{
            background: #1890ff;
            color: #fff;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
        }}
        .table-wrapper {{
            overflow-x: auto;
            padding: 10px;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            min-width: 600px;
        }}
        th, td {{
            border: 1px solid #d9d9d9;
            padding: 8px 12px;
            text-align: left;
            white-space: nowrap;
            min-width: 80px;
        }}
        th {{
            background: #fafafa;
            font-weight: bold;
            color: #333;
        }}
        tr:nth-child(even) td {{
            background: #fafafa;
        }}
        tr:hover td {{
            background: #e6f7ff;
        }}
    </style>
</head>
<body>
    <h1>{title}</h1>
""".format(title=escape(title)))

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]

        if include_sheet_names and len(wb.sheetnames) > 1:
            html_parts.append('    <div class="sheet-container">')
            html_parts.append(f'        <div class="sheet-title">{escape(sheet_name)}</div>')
            html_parts.append('        <div class="table-wrapper">')

        html_parts.append('        <table>')

        if ws.max_row > 0:
            for row_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=ws.max_row, max_col=ws.max_column), 1):
                html_parts.append('            <tr>')
                for cell in row:
                    tag = "th" if row_idx == 1 else "td"
                    value = cell.value if cell.value is not None else ""
                    colspan = ""
                    rowspan = ""

                    if isinstance(value, float):
                        if value == int(value):
                            value = int(value)

                    value_str = escape(str(value))

                    html_parts.append(f'                <{tag}{colspan}{rowspan}>{value_str}</{tag}>')
                html_parts.append('            </tr>')
        else:
            html_parts.append('            <tr><td>(空工作表)</td></tr>')

        html_parts.append('        </table>')

        if include_sheet_names and len(wb.sheetnames) > 1:
            html_parts.append('        </div>')
            html_parts.append('    </div>')

    html_parts.append("""
</body>
</html>""")

    html_content = "\n".join(html_parts)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    wb.close()
    return output_path


def main():
    parser = argparse.ArgumentParser(
        description="Excel 转 HTML 生成器 - 将 Excel 文件(.xlsx/.xls)转换为 HTML 页面"
    )
    parser.add_argument("input", help="输入的 Excel 文件路径")
    parser.add_argument("-o", "--output", help="输出的 HTML 文件路径", default=None)
    parser.add_argument("-t", "--title", help="HTML 页面标题", default=None)
    parser.add_argument("--no-sheet-names", action="store_true", help="不显示工作表名称")

    args = parser.parse_args()

    output_path = excel_to_html(
        excel_path=args.input,
        output_path=args.output,
        title=args.title,
        include_sheet_names=not args.no_sheet_names,
    )

    print(f"生成成功: {output_path}")


if __name__ == "__main__":
    main()
