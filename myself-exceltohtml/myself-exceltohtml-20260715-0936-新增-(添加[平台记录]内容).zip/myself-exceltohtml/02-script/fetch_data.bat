@echo off
cd /d "%~dp0.."
echo ============================================================
echo   fetch_data.bat
echo   %date% %time%
echo ============================================================
python 02-script\fetch_data.py
pause
