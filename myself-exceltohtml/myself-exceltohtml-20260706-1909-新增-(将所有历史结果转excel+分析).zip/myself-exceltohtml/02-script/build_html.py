# -*- coding: utf-8 -*-
import pandas as pd
import json
from datetime import datetime
import openpyxl

import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "03-data")
# find the first .xlsx file in the data directory (skip Excel temp lock files starting with ~$)
_excel_files = [f for f in os.listdir(DATA_DIR)
                if f.lower().endswith('.xlsx')
                and not f.startswith('~$')]
if not _excel_files:
    raise FileNotFoundError("No .xlsx files found in " + DATA_DIR)
EXCEL_PATH = os.path.join(DATA_DIR, _excel_files[0])

timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
excel_basename = os.path.splitext(_excel_files[0])[0]
base_name = f"{excel_basename}-{timestamp}"
output_dir = os.path.join(BASE_DIR, "04-output")

candidate = os.path.join(output_dir, f"{base_name}.html")
if not os.path.exists(candidate):
    OUTPUT_PATH = candidate
else:
    v = 1
    while True:
        candidate = os.path.join(output_dir, f"{base_name}-v{v}.html")
        if not os.path.exists(candidate):
            OUTPUT_PATH = candidate
            break
        v += 1

# ============================================================
# Open workbook for styles
# ============================================================
wb = openpyxl.load_workbook(EXCEL_PATH, data_only=False)
ws1 = wb.worksheets[0]
ws2 = wb.worksheets[1]


INDEXED_COLORS = {
    # openpyxl indexed color map → hex
    0: '000000', 1: 'FFFFFF', 2: 'FF0000', 3: '00FF00', 4: '0000FF',
    5: 'FFFF00', 6: 'FF00FF', 7: '00FFFF', 8: '000000', 9: 'FFFFFF',
    10: 'FF0000', 11: '00FF00', 12: '0000FF', 13: 'FFFF00', 14: 'FF00FF',
    15: '00FFFF', 16: '800000', 17: '008000', 18: '000080', 19: '808000',
    20: '800080', 21: '008080', 22: 'C0C0C0', 23: '808080',
    24: '9999FF', 25: '993366', 26: 'FFFFCC', 27: 'CCFFFF', 28: '660066',
    29: 'FF8080', 30: '0066CC', 31: 'CCCCFF', 32: '000080', 33: 'FF00FF',
    34: 'FFFF00', 35: '00FFFF', 36: '800080', 37: '800000', 38: '008080',
    39: '0000FF', 40: '00CCFF', 41: 'CCFFFF', 42: 'CCFFCC', 43: 'FFFF99',
    44: '99CCFF', 45: 'FF99CC', 46: 'CC99FF', 47: 'FFCC99', 48: '3366FF',
    49: '33CCCC', 50: '99CC00', 51: 'FFCC00', 52: 'FF9900', 53: 'FF6600',
    54: '666699', 55: '969696', 56: '003366', 57: '339966', 58: '003300',
    59: '333300', 60: '993300', 61: '993366', 62: '333399', 63: '333333',
}


def _rgb_to_hex(rgb_str):
    """Convert openpyxl RGB string (ARGB or RRGGBB) to CSS hex, skipping black/transparent."""
    if not rgb_str:
        return None
    s = str(rgb_str).strip()
    if not s or s == '00000000' or s == '0' or s == '000000':
        return None
    if len(s) == 8:
        alpha = s[:2]
        if alpha == '00':
            return None
        s = s[2:]
    if s == '000000':
        return None
    return '#' + s


def _openpyxl_color_to_hex(color_obj):
    """Convert openpyxl color object to CSS hex. Handles rgb/indexed safely, skips theme/default."""
    if color_obj is None:
        return None
    try:
        if color_obj.type == 'rgb':
            return _rgb_to_hex(color_obj.rgb)
        elif color_obj.type == 'indexed':
            idx = color_obj.index
            if idx is not None and idx in INDEXED_COLORS:
                return '#' + INDEXED_COLORS[idx]
        elif color_obj.type == 'theme':
            return None
    except Exception:
        pass
    return None


def cell_style(ws, row, col):
    """Extract inline CSS for font color / background color / bold.
    row, col are 0-based (matching pandas iloc)."""
    cell = ws.cell(row=row + 1, column=col + 1)
    css_parts = []

    fc = _openpyxl_color_to_hex(cell.font.color) if cell.font else None
    if fc and fc != '#262626':  # skip near-black default text
        css_parts.append(f'color:{fc}')

    bg = None
    try:
        fill = cell.fill
        if fill and fill.fgColor:
            bg = _openpyxl_color_to_hex(fill.fgColor)
    except Exception:
        pass
    if bg and bg != '#FFFFFF':  # skip white background
        css_parts.append(f'background-color:{bg}')

    if cell.font and cell.font.bold:
        css_parts.append('font-weight:bold')

    return ';'.join(css_parts) if css_parts else ''


def extract_styles(ws, row_range, col_range):
    """Extract styles for a rectangular range. Returns list of lists."""
    styles = []
    for i in row_range:
        row_styles = []
        for j in col_range:
            row_styles.append(cell_style(ws, i, j))
        styles.append(row_styles)
    return styles

# ============================================================
# Sheet 1: Analysis Results
# 结构（公式统计.xlsx）：区块 title 在 r2、表头在 r3、数据从 r4；生肖区 title r18/表头 r19/数据 r20
# ============================================================
df1 = pd.read_excel(EXCEL_PATH, sheet_name=0, header=None)

# ---- 【01】开奖属性 (cols 3-7, 数据 r4-12：野兽/家禽/大/小/单/双/红波/蓝波/绿波) ----
odd_even_title = str(df1.iloc[2, 3])
odd_even_headers = [str(df1.iloc[3, j]) for j in range(3, 8)]
odd_even_header_styles = extract_styles(ws1, range(3, 4), range(3, 8))[0]
odd_even_data = []
for i in range(4, 13):
    row = []
    for j in range(3, 8):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        odd_even_data.append(row)
odd_even_styles = extract_styles(ws1, range(4, 4 + len(odd_even_data)), range(3, 8))

# ---- 【02】单双统计 (cols 9-14, 数据 r4-13) ----
size_dual_title = str(df1.iloc[2, 9])
size_dual_headers = [str(df1.iloc[3, j]) for j in range(9, 15)]
size_dual_header_styles = extract_styles(ws1, range(3, 4), range(9, 15))[0]
size_dual_data = []
for i in range(4, 14):
    row = []
    for j in range(9, 15):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        size_dual_data.append(row)
size_dual_styles = extract_styles(ws1, range(4, 4 + len(size_dual_data)), range(9, 15))

# ---- 【03】号头统计 (cols 16-21, 数据 r4-8) ----
head_title = str(df1.iloc[2, 16])
head_headers = [str(df1.iloc[3, j]) for j in range(16, 22)]
head_header_styles = extract_styles(ws1, range(3, 4), range(16, 22))[0]
head_data = []
for i in range(4, 9):
    row = []
    for j in range(16, 22):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        head_data.append(row)
head_styles = extract_styles(ws1, range(4, 4 + len(head_data)), range(16, 22))

# ---- 【04】号尾统计 (cols 23-28, 数据 r4-13) ----
tail_title = str(df1.iloc[2, 23])
tail_headers = [str(df1.iloc[3, j]) for j in range(23, 29)]
tail_header_styles = extract_styles(ws1, range(3, 4), range(23, 29))[0]
tail_data = []
for i in range(4, 14):
    row = []
    for j in range(23, 29):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        tail_data.append(row)
tail_styles = extract_styles(ws1, range(4, 4 + len(tail_data)), range(23, 29))

# ---- 【05】数字出现频率 (4 blocks: 起点 30/36/42/48, 数据 r4-16) ----
freq_title = str(df1.iloc[2, 30])
freq_headers = [str(df1.iloc[3, j]) for j in range(30, 35)]

all_freq = {}
freq_rows = []
block_starts_freq = [30, 36, 42, 48]
_dup_warned = set()
for block_start in block_starts_freq:
    for row_idx in range(4, 17):
        num_val = df1.iloc[row_idx, block_start]
        count_val = df1.iloc[row_idx, block_start + 1]
        actual_val = df1.iloc[row_idx, block_start + 2]
        theory_val = df1.iloc[row_idx, block_start + 3]
        dev_val = df1.iloc[row_idx, block_start + 4]
        if pd.notna(num_val) and pd.notna(count_val):
            try:
                num = int(float(num_val))
                if num < 1 or num > 49:
                    continue
                count = int(float(count_val))
                actual_str = str(actual_val) if pd.notna(actual_val) else ""
                theory_str = str(theory_val) if pd.notna(theory_val) else ""
                dev_str = str(dev_val) if pd.notna(dev_val) else ""
                if num in all_freq and num not in _dup_warned:
                    print(f"[WARNING] duplicate number {num} at block_start={block_start}")
                    _dup_warned.add(num)
                all_freq[num] = count
                freq_rows.append([str(num), str(count), actual_str, theory_str, dev_str])
            except:
                pass

freq_items = sorted(all_freq.items())
freq_rows.sort(key=lambda r: int(r[0]))

# ---- 【06】生肖统计 (rows 20-31, cols 3-7) ----
zodiac_title = str(df1.iloc[18, 3])
zodiac_headers = [str(df1.iloc[19, j]) for j in range(3, 8)]
zodiac_header_styles = extract_styles(ws1, range(19, 20), range(3, 8))[0]
zodiac_data = []
for i in range(20, 32):
    row = []
    for j in range(3, 8):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        zodiac_data.append(row)
zodiac_stats_styles = extract_styles(ws1, range(20, 20 + len(zodiac_data)), range(3, 8))

# ---- 【07】生肖频率 (rows 20-31, cols 9-14) ----
zodiac_freq_title = str(df1.iloc[18, 9])
zodiac_freq_headers = [str(df1.iloc[19, j]) for j in range(9, 15)]
zodiac_freq_header_styles = extract_styles(ws1, range(19, 20), range(9, 15))[0]
zodiac_freq_data = []
for i in range(20, 32):
    row = []
    for j in range(9, 15):
        v = df1.iloc[i, j]
        row.append(str(v) if pd.notna(v) else "")
    if any(row):
        zodiac_freq_data.append(row)
zodiac_freq_styles = extract_styles(ws1, range(20, 20 + len(zodiac_freq_data)), range(9, 15))

# ---- 总期数 (号头/号尾汇总 r16c17) ----
total_count = str(df1.iloc[16, 17]) if pd.notna(df1.iloc[16, 17]) else "277"

# ============================================================
# Sheet 2: Historical Lottery Records
# ============================================================
df2 = pd.read_excel(EXCEL_PATH, sheet_name=1, header=None)

# 10 month blocks starting from columns: 2, 17, 32, 47, 62, 77, 92, 107, 122, 137
month_blocks = []
block_starts = [2, 17, 32, 47, 62, 77, 92, 107, 122, 137]

for bs in block_starts:
    # Read month label from row 0-3
    month_label = ""
    for r in range(4):
        v = df2.iloc[r, bs + 2]  # date column
        if pd.notna(v):
            month_label = str(v)[:10]
            if month_label:
                break

    records = []
    record_styles = []
    col_offsets = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
    for row_idx in range(4, 36):
        date_v = df2.iloc[row_idx, bs + 2]
        # 跳过表头/说明行（bs+3 期数列非"期数"文案且日期像日期才算数据行）
        issue_hdr = df2.iloc[row_idx, bs + 3]
        if isinstance(issue_hdr, str) and issue_hdr.strip() in ('期数', '开奖', ''):
            continue
        if pd.notna(date_v) and '期' not in str(date_v):
            records.append({
                "period": str(df2.iloc[row_idx, bs + 0]) if pd.notna(df2.iloc[row_idx, bs + 0]) else "",
                "weekday": str(df2.iloc[row_idx, bs + 1]) if pd.notna(df2.iloc[row_idx, bs + 1]) else "",
                "date": str(date_v)[:10],
                "issue": str(df2.iloc[row_idx, bs + 3]) if pd.notna(df2.iloc[row_idx, bs + 3]) else "",
                "zodiac": str(df2.iloc[row_idx, bs + 4]).strip() if pd.notna(df2.iloc[row_idx, bs + 4]) else "",
                "color": str(df2.iloc[row_idx, bs + 5]).strip() if pd.notna(df2.iloc[row_idx, bs + 5]) else "",
                "size": str(df2.iloc[row_idx, bs + 6]).strip() if pd.notna(df2.iloc[row_idx, bs + 6]) else "",
                "odd_even": str(df2.iloc[row_idx, bs + 7]).strip() if pd.notna(df2.iloc[row_idx, bs + 7]) else "",
                "color_wave": str(df2.iloc[row_idx, bs + 8]).strip() if pd.notna(df2.iloc[row_idx, bs + 8]) else "",
                "beast": str(df2.iloc[row_idx, bs + 9]).strip() if pd.notna(df2.iloc[row_idx, bs + 9]) else "",
                "head": str(df2.iloc[row_idx, bs + 10]).strip() if pd.notna(df2.iloc[row_idx, bs + 10]) else "",
                "tail": str(df2.iloc[row_idx, bs + 11]).strip() if pd.notna(df2.iloc[row_idx, bs + 11]) else "",
                "color_oe": str(df2.iloc[row_idx, bs + 12]).strip() if pd.notna(df2.iloc[row_idx, bs + 12]) else "",
                "combo": str(df2.iloc[row_idx, bs + 13]).strip() if pd.notna(df2.iloc[row_idx, bs + 13]) else "",
            })
            row_styles = {}
            field_keys = ["period", "weekday", "date", "issue", "zodiac", "color", "size", "odd_even",
                          "color_wave", "beast", "head", "tail", "color_oe", "combo"]
            for k, off in zip(field_keys, col_offsets):
                s = cell_style(ws2, row_idx, bs + off)
                if s:
                    row_styles[k] = s
            record_styles.append(row_styles)

    if records:
        month_label_final = records[0]["date"][:7] if records else ""
        month_blocks.append({
            "label": month_label_final,
            "records": records,
            "record_styles": record_styles,
        })

# ============================================================
# Compute stats for overview
# ============================================================
total_draws = int(total_count)
hot_numbers = sorted(freq_items, key=lambda x: x[1], reverse=True)[:5]
cold_numbers = sorted(freq_items, key=lambda x: x[1])[:5]

# Zodiac deviation for overview
zodiac_deviations = []
for row in zodiac_data:
    if len(row) >= 4 and row[3]:
        try:
            dev = int(row[3])
            zodiac_deviations.append({"name": row[0], "deviation": dev, "alert": row[4] if len(row) > 4 else ""})
        except:
            pass

# Merge zodac freq with zodiac names
zodiac_freq_merged = []
for i, row in enumerate(zodiac_freq_data):
    name = row[0] if row else ""
    if i < len(zodiac_data):
        zodiac_data_name = zodiac_data[i][0] if zodiac_data[i] else ""
        if zodiac_data_name and not zodiac_data_name.startswith("\u263a"):
            name = zodiac_data_name
    zodiac_freq_merged.append({"name": name, "count": row[1] if len(row) > 1 else "0",
                                "actual_rate": row[2] if len(row) > 2 else "",
                                "theory_rate": row[3] if len(row) > 3 else "",
                                "deviation": row[4] if len(row) > 4 else ""})

# ============================================================
# Generate JSON data for JS
# ============================================================
data_json = {
    "odd_even": {
        "title": odd_even_title, "headers": odd_even_headers, "data": odd_even_data,
        "styles": odd_even_styles, "header_styles": odd_even_header_styles
    },
    "size_dual": {
        "title": size_dual_title, "headers": size_dual_headers, "data": size_dual_data,
        "styles": size_dual_styles, "header_styles": size_dual_header_styles
    },
    "head": {
        "title": head_title, "headers": head_headers, "data": head_data,
        "styles": head_styles, "header_styles": head_header_styles
    },
    "tail": {
        "title": tail_title, "headers": tail_headers, "data": tail_data,
        "styles": tail_styles, "header_styles": tail_header_styles
    },
    "frequency": {"title": freq_title, "headers": freq_headers, "rows": freq_rows, "items": [[k, v] for k, v in freq_items]},
    "zodiac": {
        "title": zodiac_title, "headers": zodiac_headers, "data": zodiac_data,
        "styles": zodiac_stats_styles, "header_styles": zodiac_header_styles
    },
    "zodiac_freq": {
        "title": zodiac_freq_title, "headers": zodiac_freq_headers, "merged": zodiac_freq_merged,
        "styles": zodiac_freq_styles, "header_styles": zodiac_freq_header_styles
    },
    "total_count": total_draws,
    "hot_numbers": [[k, v] for k, v in hot_numbers],
    "cold_numbers": [[k, v] for k, v in cold_numbers],
    "zodiac_deviations": zodiac_deviations,
    "zodiac_freq_merged": zodiac_freq_merged,
    "history": month_blocks,
}

data_json_str = json.dumps(data_json, ensure_ascii=False, indent=2)

# ============================================================
# Build HTML
# ============================================================
html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>分析仪表盘</title>
    <style>
        :root {{
            --bg: #f0f2f5;
            --card-bg: #fff;
            --primary: #1a73e8;
            --text: #333;
            --text-secondary: #666;
            --text-muted: #999;
            --border: #e8e8e8;
            --shadow: 0 2px 12px rgba(0,0,0,0.08);
            --radius: 12px;
            --red: #e74c3c;
            --green: #27ae60;
            --orange: #e67e22;
            --blue: #3498db;
            --navh: 51px;  /* .tab-nav 高度：走势图 sticky 表头以此为 top 偏移，避免被导航栏遮挡 */
        }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            min-height: 100vh;
        }}
        .tab-nav {{
            display: flex;
            flex-wrap: wrap;
            gap: 2px;
            padding: 0 32px;
            background: #fff;
            border-bottom: 1px solid var(--border);
            position: sticky;
            top: 0;
            z-index: 99;
            box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        }}
        .tab-btn {{
            padding: 14px 20px;
            font-size: 14px;
            border: none;
            background: none;
            cursor: pointer;
            color: var(--text-secondary);
            border-bottom: 2px solid transparent;
            transition: all 0.2s;
            white-space: nowrap;
        }}
        .tab-btn:hover {{ color: var(--primary); }}
        .tab-btn.active {{
            color: var(--primary);
            border-bottom-color: var(--primary);
            font-weight: 600;
        }}

        .main-content {{
            padding: 24px 32px 48px;
            max-width: 1400px;
        }}

        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}

        /* Overview Cards */
        .stat-cards {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 28px;
        }}
        .stat-card {{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 20px 24px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--primary);
        }}
        .stat-card .label {{
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }}
        .stat-card .value {{
            font-size: 28px;
            font-weight: 700;
            color: var(--text);
        }}
        .stat-card .suffix {{
            font-size: 14px;
            font-weight: 400;
            color: var(--text-secondary);
            margin-left: 4px;
        }}
        .stat-card.card-red {{ border-left-color: var(--red); }}
        .stat-card.card-green {{ border-left-color: var(--green); }}
        .stat-card.card-orange {{ border-left-color: var(--orange); }}
        .stat-card.card-blue {{ border-left-color: var(--blue); }}

        .section {{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
        }}
        .sort-toggle {{
            display: inline-block;
            font-size: 12px;
            color: var(--text-muted);
            cursor: pointer;
            margin-left: 8px;
            padding: 2px 8px;
            border: 1px solid var(--border);
            border-radius: 12px;
            user-select: none;
            background: #fff;
        }}
        .sort-toggle:hover {{
            border-color: var(--primary);
            color: var(--primary);
        }}
        .section h2 {{
            font-size: 17px;
            font-weight: 600;
            margin-bottom: 18px;
            color: var(--text);
            padding-bottom: 12px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
        }}
        .section h2 .title-text {{
            flex: 1;
        }}
        .section-desc {{
            font-size: 12px;
            color: var(--text-muted);
            margin: -12px 0 14px 0;
            line-height: 1.5;
        }}
        .insight-box {{
            background: #fef9e7;
            border-left: 3px solid #f39c12;
            border-radius: 4px;
            padding: 8px 12px;
            margin-bottom: 14px;
            font-size: 12px;
            color: #7d6608;
            line-height: 1.6;
        }}
        .insight-box strong {{
            color: #b7950b;
        }}

        /* Two-column analysis grid */
        .analysis-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }}
        .analysis-grid .section {{
            margin-bottom: 0;
            min-width: 0;
        }}

        /* Tables */
        .table-wrap {{
            overflow-x: auto;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }}
        thead th {{
            background: #f8f9fa;
            padding: 10px 12px;
            font-weight: 600;
            text-align: center;
            border: 1px solid var(--border);
            color: var(--text-secondary);
            font-size: 12px;
            cursor: default;
        }}
        thead th[title] {{
            cursor: help;
            border-bottom-style: dashed;
            border-bottom-color: var(--text-muted);
        }}
        .th-sort {{
            cursor: pointer;
            user-select: none;
        }}
        .th-sort:hover {{
            background: #eef1f5;
        }}
        .th-sort::after {{
            content: ' ⇅';
            font-size: 14px;
            color: #aaa;
            margin-left: 4px;
            display: inline-block;
        }}
        .th-sort.asc::after {{
            content: ' ▲';
            color: var(--primary);
            font-size: 14px;
        }}
        .th-sort.desc::after {{
            content: ' ▼';
            color: var(--primary);
            font-size: 14px;
        }}
        tbody td {{
            padding: 9px 12px;
            text-align: center;
            border: 1px solid var(--border);
        }}
        tbody tr:hover {{ background: #f0f7ff; }}
        .dev-up {{ color: var(--red); font-weight: 600; }}
        .dev-down {{ color: var(--green); font-weight: 600; }}
        .dev-neutral {{ color: var(--text-muted); }}
        .pct-positive {{ color: var(--green); font-weight: 600; }}
        .pct-negative {{ color: var(--red); font-weight: 600; }}
        .alert-tag {{
            display: inline-block;
            background: #fff3cd;
            color: #856404;
            padding: 1px 5px;
            border-radius: 3px;
            font-size: 10px;
            margin-left: 4px;
        }}

        /* Color wave highlighting */
        .wave-red {{ background: #fdf0f1; color: #c0392b; font-weight: 600; }}
        .wave-blue {{ background: #e8f2fd; color: #2471a3; font-weight: 600; }}
        .wave-green {{ background: #f2fae7; color: #2e7d32; font-weight: 600; }}

        /* Frequency Grid */
        .freq-grid {{
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 8px;
            max-width: 420px;
        }}
        .freq-ball {{
            aspect-ratio: 1;
            border-radius: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-weight: 600;
            font-size: 13px;
            cursor: default;
            box-shadow: 0 2px 6px rgba(0,0,0,0.12);
            transition: transform 0.2s;
            padding: 4px;
        }}
        .freq-ball:hover {{ transform: scale(1.08); }}
        .freq-ball .count {{
            font-size: 9px;
            opacity: 0.85;
            margin-top: 1px;
        }}
        .freq-hot {{ background: linear-gradient(135deg, #e74c3c, #c0392b); }}
        .freq-warm {{ background: linear-gradient(135deg, #f39c12, #e67e22); }}
        .freq-cool {{ background: linear-gradient(135deg, #3498db, #2980b9); }}
        .freq-cold {{ background: linear-gradient(135deg, #95a5a6, #7f8c8d); }}

        .legend {{
            display: flex;
            gap: 20px;
            margin-top: 16px;
            flex-wrap: wrap;
            font-size: 12px;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 6px;
        }}
        .legend-dot {{
            width: 14px;
            height: 14px;
            border-radius: 50%;
        }}

        /* Hot/Cold rows */
        .hotcold-row {{
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }}
        .hotcold-box {{
            flex: 1;
            min-width: 260px;
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--red);
        }}
        .hotcold-box:last-child {{
            border-left-color: var(--blue);
        }}
        .hotcold-box h3 {{
            font-size: 14px;
            margin: 0 0 10px 0;
            color: var(--text-secondary);
        }}
        .hotcold-cards {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .hc-card {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 14px;
            border-radius: 10px;
            border: 1px solid var(--border);
            background: #fff;
            font-size: 14px;
        }}
        .hc-card.hot {{
            border-color: #f5c6cb;
            background: #fef5f5;
        }}
        .hc-card.hot .hc-num {{
            color: #c0392b;
            font-weight: 700;
            font-size: 16px;
        }}
        .hc-card.cold {{
            border-color: #c3d9f7;
            background: #f5f9fe;
        }}
        .hc-card.cold .hc-num {{
            color: #2471a3;
            font-weight: 700;
            font-size: 16px;
        }}
        .hc-card .hc-count {{
            color: var(--text-muted);
            font-size: 12px;
        }}

        /* Zodiac bar chart */
        .zodiac-bars {{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }}
        .zodiac-bar-row {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .zodiac-bar-label {{
            width: 60px;
            text-align: center;
            font-size: 13px;
            color: var(--text-secondary);
            flex-shrink: 0;
            padding: 2px 8px;
            border-radius: 4px;
        }}
        .zodiac-bar-track {{
            flex: 1;
            height: 22px;
            background: #f0f0f0;
            border-radius: 11px;
            overflow: hidden;
            position: relative;
        }}
        .zodiac-bar-fill {{
            height: 100%;
            border-radius: 11px;
            display: flex;
            align-items: center;
            padding-left: 10px;
            font-size: 12px;
            color: #fff;
            font-weight: 600;
            min-width: 40px;
            transition: width 0.4s ease;
        }}
        .zodiac-bar-value {{
            color: var(--text);
            flex-shrink: 0;
            min-width: 32px;
            font-size: 13px;
            text-align: right;
        }}

        /* History table */
        .history-controls {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }}
        .month-pill {{
            padding: 8px 18px;
            border-radius: 20px;
            border: 1px solid var(--border);
            background: #fff;
            cursor: pointer;
            font-size: 13px;
            color: var(--text-secondary);
            transition: all 0.2s;
        }}
        .month-pill:hover {{ border-color: var(--primary); color: var(--primary); }}
        .month-pill.active {{
            background: var(--primary);
            color: #fff;
            border-color: var(--primary);
        }}
        .history-table {{
            display: none;
        }}
        .history-table.active {{
            display: block;
        }}

        /* Wave distribution grid */
        .wave-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }}
        .wave-cell {{
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 16px 20px;
            box-shadow: var(--shadow);
            border-left: 4px solid var(--wc, #ccc);
        }}
        .wave-cell-title {{
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 1px solid var(--border);
        }}
        .wave-cards {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }}
        .wc-card {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: #fff;
            font-size: 13px;
        }}
        .wc-label {{
            color: var(--c);
            font-weight: 600;
        }}
        .wc-val {{
            color: var(--c);
            font-weight: 700;
            font-size: 16px;
        }}
        .wc-unit {{
            color: #999;
            font-size: 11px;
        }}

        /* Responsive */
        @media (max-width: 768px) {{
            .wave-grid {{ grid-template-columns: 1fr; }}
            .main-content {{ padding: 16px; }}
            .tab-nav {{ padding: 0 12px; }}
            .tab-btn {{ padding: 12px 14px; font-size: 13px; }}
            .stat-cards {{ grid-template-columns: repeat(2, 1fr); }}
            .freq-grid {{ grid-template-columns: repeat(4, 1fr); gap: 6px; }}
            .analysis-grid {{ grid-template-columns: 1fr; }}
        }}
    </style>
</head>
<body>

<div class="tab-nav" id="tabNav"></div>

<div class="main-content" id="mainContent"></div>

<script>
var DATA = {data_json_str};

function escapeHtml(s) {{ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }}

function isDeviation(s) {{
    if (!s) return 0;
    var v = parseFloat(s);
    return isNaN(v) ? 0 : v;
}}

function devClass(s) {{
    var v = isDeviation(s);
    if (v > 0.001) return 'dev-up';
    if (v < -0.001) return 'dev-down';
    return 'dev-neutral';
}}

function devClassInt(s) {{
    var v = parseInt(s);
    if (isNaN(v)) return 'dev-neutral';
    if (v > 0) return 'dev-up';
    if (v < 0) return 'dev-down';
    return 'dev-neutral';
}}

function waveClass(val) {{
    if (val.indexOf('红波') >= 0) return 'wave-red';
    if (val.indexOf('蓝波') >= 0) return 'wave-blue';
    if (val.indexOf('绿波') >= 0) return 'wave-green';
    return '';
}}

function fmtPercent(val, isDeviation) {{
    var v = parseFloat(val);
    if (isNaN(v)) return escapeHtml(val);
    var pct = (v * 100);
    var rounded = Math.round(pct * 100) / 100;
    if (isDeviation) {{
        var sign = rounded >= 0 ? '+' : '';
        var cls = rounded > 0.001 ? 'pct-positive' : (rounded < -0.001 ? 'pct-negative' : '');
        return '<span class="' + cls + '">' + sign + rounded + '%</span>';
    }}
    return rounded + '%';
}}

function headerTooltip(hdr) {{
    if (hdr.indexOf('占比') >= 0) return '实际占比=该类型出现次数÷总期数，理论占比=按数学概率计算的期望值';
    if (hdr.indexOf('偏差') >= 0) return '偏差=实际占比-理论占比，正值偏多、负值偏少';
    if (hdr.indexOf('次数') >= 0 && hdr.indexOf('最近') < 0) return '该类型在统计期内出现的总次数';
    if (hdr.indexOf('色波') >= 0) return '号码对应的颜色波形：红波/蓝波/绿波';
    if (hdr.indexOf('野兽') >= 0) return '号码对应的兽类属性：野兽/家禽';
    if (hdr.indexOf('颜色单双') >= 0) return '色波与单双的组合，如蓝双=蓝波+双数';
    if (hdr.indexOf('组合') >= 0) return '大小与单双的组合，如大单=大+单数';
    return '';
}}

function buildTable(headers, data, hasDevCol, cellStyles, headerStyles, percentCols) {{
    var sortCols = [1, 2, 3, 4];
    var h = '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < headers.length; i++) {{
        var hs = (headerStyles && headerStyles[i]) ? ' style="' + headerStyles[i] + '"' : '';
        var tt = headerTooltip(headers[i]);
        var ttAttr = tt ? ' title="' + tt + '"' : '';
        var sortCls = (sortCols.indexOf(i) >= 0) ? ' class="th-sort"' : '';
        h += '<th' + hs + ttAttr + sortCls + '>' + escapeHtml(headers[i]) + '</th>';
    }}
    h += '</tr></thead><tbody>';
    for (var r = 0; r < data.length; r++) {{
        h += '<tr>';
        for (var c = 0; c < data[r].length; c++) {{
            var val = data[r][c];
            var cls = '';
            var st = (cellStyles && cellStyles[r] && cellStyles[r][c]) ? ' style="' + cellStyles[r][c] + '"' : '';
            if (c === 0) {{
                var wc = waveClass(val);
                if (wc) cls = ' class="' + wc + '"';
            }}
            var display = escapeHtml(val);
            if (percentCols && percentCols.indexOf(c) >= 0) {{
                display = fmtPercent(val, false);
            }}
            if (hasDevCol && c === 4) {{
                display = fmtPercent(val, true);
            }}
            var sortVal = '';
            if (sortCols.indexOf(c) >= 0) {{
                var n = parseFloat(val);
                sortVal = isNaN(n) ? '' : ' data-sv="' + n + '"';
            }}
            h += '<td' + cls + st + sortVal + '>' + display + '</td>';
        }}
        h += '</tr>';
    }}
    h += '</tbody></table></div>';
    return h;
}}

function freqClass(count) {{
    if (count >= 9) return 'freq-hot';
    if (count >= 7) return 'freq-warm';
    if (count >= 4) return 'freq-cool';
    return 'freq-cold';
}}

function freqLabel(count) {{
    if (count >= 9) return '热';
    if (count >= 7) return '温';
    if (count >= 4) return '凉';
    return '冷';
}}

// ---- Build tabs ----
var tabs = [
    {{ id: 'overview', label: '首页概览' }},
    {{ id: 'analysis', label: '综合分析' }},
    {{ id: 'history', label: '历史记录' }},
    {{ id: 'numtrend', label: '号码走势' }},
    {{ id: 'attrtrend', label: '其它走势' }},
];

var tabHtml = '';
for (var i = 0; i < tabs.length; i++) {{
    tabHtml += '<button class="tab-btn' + (i===0?' active':'') + '" data-tab="' + tabs[i].id + '">' + tabs[i].label + '</button>';
}}
document.getElementById('tabNav').innerHTML = tabHtml;

function zodiacBg(name) {{
    var beast = ['鼠','虎','兔','龙','蛇','猴'];
    var sub = name.substring(0, 1);
    if (beast.indexOf(name) >= 0 || beast.indexOf(sub) >= 0) return '#fde8e8';
    return '#e8f5e9';
}}

// ---- Build overview ----
function buildOverview() {{
    var d = DATA;
    var hot = d.hot_numbers;
    var cold = d.cold_numbers;
    var zd = d.zodiac_deviations;
    var zodiacSorted = zd.slice().sort(function(a,b) {{ return b.deviation - a.deviation; }});

    // Compute summary counts from odd_even data
    var oddCount = 0, evenCount = 0, bigCount = 0, smallCount = 0;
    var redWave = 0, blueWave = 0, greenWave = 0;
    var beastCount = 0, fowlCount = 0;
    var d1 = d.odd_even;
    for (var i = 0; i < d1.data.length; i++) {{
        var type = d1.data[i][0];
        var cnt = parseInt(d1.data[i][1]) || 0;
        if (type.indexOf('单') >= 0) oddCount = cnt;
        if (type.indexOf('双') >= 0) evenCount = cnt;
        if (type.indexOf('大') >= 0) bigCount = cnt;
        if (type.indexOf('小') >= 0) smallCount = cnt;
        if (type.indexOf('红波') >= 0) redWave = cnt;
        if (type.indexOf('蓝波') >= 0) blueWave = cnt;
        if (type.indexOf('绿波') >= 0) greenWave = cnt;
        if (type.indexOf('野兽') >= 0) beastCount = cnt;
        if (type.indexOf('家畜') >= 0 || type.indexOf('家禽') >= 0) fowlCount = cnt;
    }}

    var html = '';

    // Stat cards
    html += '<div class="stat-cards">';
    html += '<div class="stat-card"><div class="label">总期数</div><div class="value">' + d.total_count + '<span class="suffix">期</span></div></div>';
    html += '<div class="stat-card card-red" title="275期内出现次数最多的号码，理论期望约5.6次"><div class="label">最热号码</div><div class="value">' + (hot[0] ? hot[0][0] : '-') + '<span class="suffix">(' + (hot[0] ? hot[0][1] : '-') + '次)</span></div></div>';
    html += '<div class="stat-card card-blue" title="275期内出现次数最少的号码"><div class="label">最冷号码</div><div class="value">' + (cold[0] ? cold[0][0] : '-') + '<span class="suffix">(' + (cold[0] ? cold[0][1] : '-') + '次)</span></div></div>';
    html += '<div class="stat-card card-orange" title="偏差值=距最近出现间隔的期数，越大表示越久未出现"><div class="label">生肖最高偏差</div><div class="value">' + (zodiacSorted.length > 0 ? escapeHtml(zodiacSorted[0].name) : '-') + '<span class="suffix">偏差' + (zodiacSorted.length > 0 ? zodiacSorted[0].deviation : '-') + '</span></div></div>';
    html += '</div>';

    // Hot / Cold numbers
    html += '<div class="section"><h2>热门 / 冷门数字</h2>';
    html += '<p class="section-desc">出现频次最高与最低的5个号码</p>';
    html += '<div class="hotcold-row">';
    html += '<div class="hotcold-box"><h3>热门数字</h3>';
    html += '<div class="hotcold-cards">';
    for (var i = 0; i < hot.length; i++) {{
        html += '<div class="hc-card hot"><span class="hc-num">' + hot[i][0] + '</span><span class="hc-count">' + hot[i][1] + '次</span></div>';
    }}
    html += '</div></div>';
    html += '<div class="hotcold-box"><h3>冷门数字</h3>';
    html += '<div class="hotcold-cards">';
    for (var i = 0; i < cold.length; i++) {{
        html += '<div class="hc-card cold"><span class="hc-num">' + cold[i][0] + '</span><span class="hc-count">' + cold[i][1] + '次</span></div>';
    }}
    html += '</div></div></div></div>';

    // Wave summary
    html += '<div class="section"><h2>红蓝绿波分布</h2>';
    html += '<p class="section-desc">红波、蓝波、绿波及大小单双的出现次数总览</p>';
    html += '<div class="wave-grid">';

    // Cell 1: 红蓝绿
    html += '<div class="wave-cell" style="--wc:#e74c3c">';
    html += '<div class="wave-cell-title" style="color:#e74c3c">红蓝绿波</div>';
    html += '<div class="wave-cards">';
    html += '<div class="wc-card" style="--c:#e74c3c;background:#fef0f0"><span class="wc-label">红波</span><span class="wc-val">' + redWave + '</span><span class="wc-unit">次</span></div>';
    html += '<div class="wc-card" style="--c:#2471a3;background:#f0f5fa"><span class="wc-label">蓝波</span><span class="wc-val">' + blueWave + '</span><span class="wc-unit">次</span></div>';
    html += '<div class="wc-card" style="--c:#1e8449;background:#f0faf3"><span class="wc-label">绿波</span><span class="wc-val">' + greenWave + '</span><span class="wc-unit">次</span></div>';
    html += '</div></div>';

    // Cell 2: 大小
    html += '<div class="wave-cell" style="--wc:#e67e22">';
    html += '<div class="wave-cell-title" style="color:#e67e22">大小</div>';
    html += '<div class="wave-cards">';
    html += '<div class="wc-card" style="--c:#e67e22;background:#fef9f3"><span class="wc-label">大</span><span class="wc-val">' + bigCount + '</span><span class="wc-unit">次</span></div>';
    html += '<div class="wc-card" style="--c:#8e44ad;background:#f9f3fc"><span class="wc-label">小</span><span class="wc-val">' + smallCount + '</span><span class="wc-unit">次</span></div>';
    html += '</div></div>';

    // Cell 3: 单双
    html += '<div class="wave-cell" style="--wc:#2e86c1">';
    html += '<div class="wave-cell-title" style="color:#2e86c1">单双</div>';
    html += '<div class="wave-cards">';
    html += '<div class="wc-card" style="--c:#2e86c1;background:#f0f8fe"><span class="wc-label">单</span><span class="wc-val">' + oddCount + '</span><span class="wc-unit">次</span></div>';
    html += '<div class="wc-card" style="--c:#d4ac0d;background:#fefdf3"><span class="wc-label">双</span><span class="wc-val">' + evenCount + '</span><span class="wc-unit">次</span></div>';
    html += '</div></div>';

    // Cell 4: 家禽/野兽
    html += '<div class="wave-cell" style="--wc:#2e7d32">';
    html += '<div class="wave-cell-title" style="color:#2e7d32">家畜 / 野兽</div>';
    html += '<div class="wave-cards">';
    html += '<div class="wc-card" style="--c:#2e7d32;background:#e8f5e9"><span class="wc-label">家畜</span><span class="wc-val">' + fowlCount + '</span><span class="wc-unit">次</span></div>';
    html += '<div class="wc-card" style="--c:#c0392b;background:#fde8e8"><span class="wc-label">野兽</span><span class="wc-val">' + beastCount + '</span><span class="wc-unit">次</span></div>';
    html += '</div></div>';

    html += '</div></div>';

    html += '</div></div>';

    // Zodiac deviation overview
    html += '<div class="analysis-grid"><div class="section"><h2><span class="title-text">生肖偏差排行</span><span class="sort-toggle" onclick="sortZodiacBars(this)" data-id="dev">排序</span></h2>';
    html += '<p class="section-desc">按偏差值排序，正值偏多（红）、负值偏少（绿）。阈值：忽略&lt;25≤提醒&lt;30≤可以追</p>';
    html += '<div class="zodiac-bars">';
    var maxDev = 0;
    for (var i = 0; i < zodiacSorted.length; i++) {{
        maxDev = Math.max(maxDev, Math.abs(zodiacSorted[i].deviation));
    }}
    for (var i = 0; i < zodiacSorted.length; i++) {{
        var item = zodiacSorted[i];
        var pct = maxDev > 0 ? Math.abs(item.deviation) / maxDev * 100 : 0;
        var color = item.deviation > 0 ? 'var(--red)' : (item.deviation < 0 ? 'var(--green)' : '#aaa');
        html += '<div class="zodiac-bar-row" data-sv="' + Math.abs(item.deviation) + '">';
        html += '<div class="zodiac-bar-label" style="background:' + zodiacBg(item.name) + '">' + escapeHtml(item.name) + '</div>';
        html += '<div class="zodiac-bar-track"><div class="zodiac-bar-fill" style="width:' + pct + '%;background:' + color + '"></div></div>';
        html += '<div class="zodiac-bar-value" style="color:' + color + '">' + (item.deviation >= 0 ? '+' : '') + item.deviation + '</div>';
        var dev = Math.abs(item.deviation);
        var tagLabel = dev >= 30 ? '可以追' : (dev >= 25 ? '提醒' : (dev > 0 ? '忽略' : ''));
        var tagStyle = dev >= 30 ? 'background:#c8e6c9;color:#1b5e20' : (dev >= 25 ? 'background:#fff3cd;color:#856404' : 'background:#e8e8e8;color:#888');
        if (tagLabel) html += '<span style="display:inline-block;padding:1px 5px;border-radius:3px;font-size:10px;margin-left:4px;' + tagStyle + '">' + tagLabel + '</span>';
        html += '</div>';
    }}
    html += '</div></div>';

    // Zodiac freq merged
    html += '<div class="section"><h2><span class="title-text">生肖出现频率</span><span class="sort-toggle" onclick="sortZodiacBars(this)" data-id="freq">排序</span></h2>';
    html += '<p class="section-desc">各生肖的出现次数与理论占比对比</p>';
    var zfm = d.zodiac_freq_merged;
    html += '<div class="zodiac-bars">';
    var maxCount = 0;
    for (var i = 0; i < zfm.length; i++) {{
        maxCount = Math.max(maxCount, parseInt(zfm[i].count) || 0);
    }}
    for (var i = 0; i < zfm.length; i++) {{
        var item = zfm[i];
        var cnt = parseInt(item.count) || 0;
        var pct = maxCount > 0 ? cnt / maxCount * 100 : 0;
        var shortName = item.name.substring(0, 3);
        html += '<div class="zodiac-bar-row" data-sv="' + cnt + '">';
        html += '<div class="zodiac-bar-label" style="background:' + zodiacBg(shortName) + '">' + escapeHtml(shortName) + '</div>';
        html += '<div class="zodiac-bar-track"><div class="zodiac-bar-fill" style="width:' + pct + '%;background:var(--primary)">' + cnt + '</div></div>';
        html += '<div class="zodiac-bar-value">' + fmtPercent(item.actual_rate, false) + '</div>';
        html += '</div>';
    }}
    html += '</div></div></div>';

    return html;
}}

function buildAnalysisPiece(d, percentCols, desc, insight) {{
    var descHtml = desc ? '<p class="section-desc">' + desc + '</p>' : '';
    var insightHtml = insight ? '<div class="insight-box"><strong>参考值：</strong>' + insight + '</div>' : '';
    return '<div class="section"><h2>' + escapeHtml(d.title) + '</h2>' + descHtml + insightHtml +
        buildTable(d.headers, d.data, true, d.styles, d.header_styles, percentCols) + '</div>';
}}

function buildFreqSection() {{
    var d = DATA.frequency;
    var html = '<div class="section"><h2>' + escapeHtml(d.title) + '</h2>';
    html += '<p class="section-desc">逐个统计1-49每个号码出现了几次，找出最热和最冷的号码。</p>';
    html += '<div class="insight-box"><strong>参考值：</strong>25号仅出1次为最冷，20、30、32、34、35也严重欠出，可作为重点关注对象。</div>';
    html += '<div class="table-wrap" style="max-height:420px;overflow-y:auto"><table><thead><tr>';
    for (var i = 0; i < d.headers.length; i++) {{
        html += '<th class="th-sort">' + escapeHtml(d.headers[i]) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var rows = d.rows || [];
    for (var r = 0; r < rows.length; r++) {{
        html += '<tr>';
        html += '<td data-sv="' + parseInt(rows[r][0]) + '">' + escapeHtml(rows[r][0]) + '</td>';
        html += '<td data-sv="' + parseInt(rows[r][1]) + '">' + escapeHtml(rows[r][1]) + '</td>';
        html += '<td data-sv="' + parseFloat(rows[r][2]) + '">' + fmtPercent(rows[r][2], false) + '</td>';
        html += '<td data-sv="' + parseFloat(rows[r][3]) + '">' + fmtPercent(rows[r][3], false) + '</td>';
        html += '<td data-sv="' + parseFloat(rows[r][4]) + '">' + fmtPercent(rows[r][4], true) + '</td>';
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';
    return html;
}}

function buildZodiacSection() {{
    var html = '';
    var d1 = DATA.zodiac;
    var zodiacTitle = escapeHtml(d1.title).replace(/[（(].*?忽略.*?[）)]/g, '');
    html += '<div class="section"><h2>' + zodiacTitle + '</h2>';
    html += '<p class="section-desc">记录每个生肖上次开出是多久前。阈值：忽略&lt;25≤提醒&lt;30≤可以追</p>';
    html += '<div class="insight-box"><strong>参考值：</strong>猴已连续41期未出，达到"可以追"级别；马遗漏20期，接近关注线。</div>';
    html += '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < d1.headers.length; i++) {{
        var hs = (d1.header_styles && d1.header_styles[i]) ? ' style="' + d1.header_styles[i] + '"' : '';
        var hdr = d1.headers[i];
        var tt = '';
        if (hdr.indexOf('偏差') >= 0) tt = ' title="距最近一次出现间隔的期数，越大表示越久未出现"';
        if (hdr.indexOf('是否注意') >= 0) tt = ' title="忽略=暂时观望；提醒=需留意趋势；可以追=偏差较大建议关注"';
        var sc = (i >= 1 && i <= 3) ? ' class="th-sort"' : '';
        html += '<th' + hs + tt + sc + '>' + escapeHtml(hdr) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var styles1 = d1.styles;
    for (var r = 0; r < d1.data.length; r++) {{
        html += '<tr>';
        for (var c = 0; c < d1.data[r].length; c++) {{
            var val = d1.data[r][c];
            var cls = '';
            var st = (styles1 && styles1[r] && styles1[r][c]) ? ' style="' + styles1[r][c] + '"' : '';
            var display = escapeHtml(val);
            var sv = '';
            if (c >= 1 && c <= 3) {{
                var n = parseFloat(val);
                if (!isNaN(n)) sv = ' data-sv="' + n + '"';
            }}
            if (c === 3) {{
                var v = parseInt(val);
                if (!isNaN(v)) {{
                    cls = ' class="' + (v > 0 ? 'pct-positive' : (v < 0 ? 'pct-negative' : '')) + '"';
                    display = (v >= 0 ? '+' : '') + v;
                }}
            }}
            if (c === 4 && val) {{
                var alertColors = {{'忽略': 'background:#e8e8e8;color:#888', '提醒': 'background:#fff3cd;color:#856404', '可以追': 'background:#c8e6c9;color:#1b5e20'}};
                var ast = alertColors[val] || '';
                var exst = (styles1 && styles1[r] && styles1[r][c]) || '';
                st = ast || exst ? ' style="' + ast + (ast && exst ? ';' : '') + exst + '"' : '';
            }}
            html += '<td' + cls + st + sv + '>' + display + '</td>';
        }}
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';

    var d2 = DATA.zodiac_freq;
    var zfm = DATA.zodiac_freq_merged;
    html += '<div class="section"><h2>' + escapeHtml(d2.title) + '</h2>';
    html += '<p class="section-desc">统计12个生肖各出现了多少次，看哪个生肖总体偏热或偏冷。</p>';
    html += '<div class="insight-box"><strong>参考值：</strong>猴（15次）和猪（16次）总频次最低，虎（30次）最热。猴既总次数最少又遗漏最长，回补信号最强。</div>';
    html += '<div class="table-wrap"><table><thead><tr>';
    for (var i = 0; i < d2.headers.length; i++) {{
        var hs2 = (d2.header_styles && d2.header_styles[i]) ? ' style="' + d2.header_styles[i] + '"' : '';
        var tt2 = headerTooltip(d2.headers[i]) ? ' title="' + headerTooltip(d2.headers[i]) + '"' : '';
        var sc2 = (i >= 1 && i <= 4) ? ' class="th-sort"' : '';
        html += '<th' + hs2 + tt2 + sc2 + '>' + escapeHtml(d2.headers[i]) + '</th>';
    }}
    html += '</tr></thead><tbody>';
    var styles2 = d2.styles;
    for (var r = 0; r < zfm.length; r++) {{
        html += '<tr>';
        var item = zfm[r];
        for (var c = 0; c < 6; c++) {{
            var st = (styles2 && styles2[r] && styles2[r][c]) ? ' style="' + styles2[r][c] + '"' : '';
            var display = escapeHtml(item[['name','count','actual_rate','theory_rate','deviation',''][c]] || '');
            if (c === 2 || c === 3) display = fmtPercent(item[['name','count','actual_rate','theory_rate','deviation',''][c]] || '0', false);
            if (c === 4) display = fmtPercent(item.deviation || '0', true);
            var sv = '';
            if (c >= 1 && c <= 4) {{
                var n = parseFloat(item[['name','count','actual_rate','theory_rate','deviation',''][c]] || '');
                if (!isNaN(n)) sv = ' data-sv="' + n + '"';
            }}
            html += '<td' + st + sv + '>' + display + '</td>';
        }}
        html += '</tr>';
    }}
    html += '</tbody></table></div></div>';

    return html;
}}

function buildAnalysis() {{
    return '<div class="analysis-grid">' +
        buildAnalysisPiece(DATA.odd_even, [2, 3],
            '统计大小、单双、波色等基础属性各出现了多少次，看哪个偏多哪个偏少。',
            '当前单号和小号偏热，双号和大号偏冷。短期内可适当关注大号、双号的回补。') +
        buildAnalysisPiece(DATA.size_dual, [2, 3],
            '把大小和单双、波色和单双两两搭配，看哪种组合出得多哪种出得少。',
            '大双组合最冷（欠出约8次），蓝双次冷。近期可重点关注大双方向的号码。') +
        buildAnalysisPiece(DATA.head, [2, 3],
            '按十位数分组（0头、1头...4头），看哪个区间的号码开得多或少。',
            '3头（30-39）严重偏冷，欠出18次，是最值得关注的回补区间。') +
        buildAnalysisPiece(DATA.tail, [2, 3],
            '按个位数分组（0尾到9尾），看尾数是几的号码开得多或少。',
            '0尾和5尾偏冷，6尾和9尾偏热。选号时可多考虑尾数为0或5的号码。') +
        buildFreqSection() +
        buildZodiacSection() +
    '</div>';
}}

function buildHistory() {{
    var months = DATA.history;
    var html = '<div class="section"><h2>历史开奖记录</h2>';
    html += '<p class="section-desc">按月份切换查看每期开奖的详细结果，含生肖/颜色/大小/单双等属性</p>';
    html += '<div class="history-controls">';
    for (var i = 0; i < months.length; i++) {{
        html += '<button class="month-pill' + (i===0?' active':'') + '" data-month="' + i + '">' + escapeHtml(months[i].label) + '</button>';
    }}
    html += '</div>';

    for (var i = 0; i < months.length; i++) {{
        var m = months[i];
        html += '<div class="history-table table-wrap' + (i===0?' active':'') + '" data-month="' + i + '">';
        html += '<table><thead><tr>';
        html += '<th>周期</th><th title="当月第几日">日序</th><th>日期</th><th>期数</th><th title="号码对应的生肖属相">生肖</th><th title="号码的颜色分类">颜色</th><th>大小</th><th>单双</th><th title="号码对应的颜色波形：红波/蓝波/绿波">色波</th><th title="号码对应的兽类属性：野兽/家禽">野兽</th><th>号头</th><th>号尾</th><th title="色波与单双的组合，如蓝单=蓝波+单数">颜色单双</th><th title="大小与单双的组合，如大双=大+双数">组合</th>';
        html += '</tr></thead><tbody>';
        var rstyles = m.record_styles || [];
        var fields = ['period', 'weekday', 'date', 'issue', 'zodiac', 'color', 'size', 'odd_even',
                       'color_wave', 'beast', 'head', 'tail', 'color_oe', 'combo'];
        for (var r = 0; r < m.records.length; r++) {{
            var rec = m.records[r];
            var rs = rstyles[r] || {{}};
            html += '<tr>';
            for (var f = 0; f < fields.length; f++) {{
                var key = fields[f];
                var st = rs[key] ? ' style="' + rs[key] + '"' : '';
                html += '<td' + st + '>' + escapeHtml(rec[key]) + '</td>';
            }}
            html += '</tr>';
        }}
        html += '</tbody></table></div>';
    }}
    html += '</div>';
    return html;
}}

function buildNumTrend() {{
    var html = '';
    var months = DATA.history;
    var allRecords = [];
    for (var m = 0; m < months.length; m++) {{
        var recs = months[m].records;
        for (var r = recs.length - 1; r >= 0; r--) {{
            var num = parseInt(recs[r].color);
            if (!isNaN(num) && num >= 1 && num <= 49) allRecords.push({{num:num, wave:recs[r].color_wave}});
        }}
    }}
    var n = allRecords.length, cellW = 24, cellH = 24;
    var cw = 49*cellW + 55, ch = n*cellH + 40;

    // X-axis sticky header (整页滚动 + sticky，与"其它走势"一致，不用内层滚动容器)
    html += '<div class="section"><h2>号码分布走势图</h2>';
    html += '<p class="section-desc">X轴=号码1-49，Y轴=期数（上=新→下=旧），命中格子按波色填充</p>';
    html += '<canvas id="t1h" width="' + cw + '" height="22" style="display:block;position:sticky;top:var(--navh);z-index:10;background:#fff;border-bottom:1px solid #333"></canvas>';
    html += '<canvas id="t1" width="' + cw + '" height="' + ch + '" style="display:block"></canvas>';
    html += '</div>';

    setTimeout(function() {{
        var c1 = document.getElementById('t1'); if (c1) drawNumTrend(allRecords, c1, cellW, cellH);
        var h1 = document.getElementById('t1h'); if (h1) drawNumTrendHeader(h1, cellW);
    }}, 50);
    return html;
}}

function buildAttrTrend() {{
    var html = '';
    var months = DATA.history;
    var allRecords = [];
    for (var m = 0; m < months.length; m++) {{
        var recs = months[m].records;
        for (var r = recs.length - 1; r >= 0; r--) {{
            var num = parseInt(recs[r].color);
            if (!isNaN(num) && num >= 1 && num <= 49) allRecords.push({{size:recs[r].size, oddeven:recs[r].odd_even, zodiac:recs[r].zodiac, colorWave:recs[r].color_wave}});
        }}
    }}
    var n = allRecords.length, cellH = 24, HEADERH = 44, ch = n*cellH + 4;

    html += '<div class="section"><h2>属性走势图</h2>';
    html += '<p class="section-desc">大小、单双、波色、家禽野兽属性按每期色块展示，X=属性 / Y=期数（上=新→下=旧）</p>';
    // Chart cards — each has its own sticky canvas header (title + category labels) on top
    html += '<div style="display:flex;gap:12px;align-items:flex-start">';
    var attrCharts = [
        {{ id: 'a1', color: '#e67e22' }},
        {{ id: 'a2', color: '#2e86c1' }},
        {{ id: 'a3', color: '#e74c3c' }},
        {{ id: 'a4', color: '#2e7d32' }}
    ];
    for (var k = 0; k < attrCharts.length; k++) {{
        var ck = attrCharts[k];
        html += '<div class="wave-cell" style="--wc:'+ck.color+';padding:8px 10px;min-width:0">';
        html += '<canvas id="'+ck.id+'h" width="180" height="'+HEADERH+'" style="width:100%;display:block;position:sticky;top:var(--navh);z-index:5;background:#fff"></canvas>';
        html += '<canvas id="'+ck.id+'" width="180" height="'+ch+'" style="width:100%;display:block"></canvas>';
        html += '</div>';
    }}
    html += '</div></div>';

    setTimeout(function() {{
        var defs = [
            {{ id: 'a1', field: 'size',      title: '大小',     color: '#e67e22', map: {{'大':'#F8C471','小':'#C39BD3'}} }},
            {{ id: 'a2', field: 'oddeven',   title: '单双',     color: '#2e86c1', map: {{'单':'#85C1E9','双':'#F7DC6F'}} }},
            {{ id: 'a3', field: 'colorWave', title: '波色',     color: '#e74c3c', map: {{'红波':'#F1A2AB','蓝波':'#81BBF8','绿波':'#C1E77E'}} }}
        ];
        for (var k = 0; k < defs.length; k++) {{
            var d = defs[k];
            var body = document.getElementById(d.id), hdr = document.getElementById(d.id + 'h');
            if (body) drawAttrCol(d.field, allRecords, body, cellH, d.map);
            if (hdr) drawAttrHeader(hdr, d.title, d.color, Object.keys(d.map));
        }}
        var bBody = document.getElementById('a4'), bHdr = document.getElementById('a4h');
        if (bBody) drawBeastCol(allRecords, bBody, cellH);
        if (bHdr) drawAttrHeader(bHdr, '家禽野兽', '#2e7d32', ['家畜','野兽']);
    }}, 50);

    return html;
}}

function drawNumTrend(records, canvas, cellW, cellH) {{
    var ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height, n = records.length;
    var pad = {{top:2,right:10,bottom:0,left:55}}, pw = W-pad.left-pad.right;
    var waveColors = {{'红波':'rgba(241,162,171,0.3)','蓝波':'rgba(129,187,248,0.3)','绿波':'rgba(193,231,126,0.3)'}};
    ctx.fillStyle = '#fff'; ctx.fillRect(pad.left, pad.top, pw, H-pad.top-pad.bottom);
    // Grid lines - black
    ctx.strokeStyle = '#333'; ctx.lineWidth = 0.5;
    for (var i = 0; i <= n; i++) {{ var y = pad.top+i*cellH; ctx.beginPath(); ctx.moveTo(pad.left,y); ctx.lineTo(pad.left+49*cellW,y); ctx.stroke(); }}
    for (var j = 0; j <= 49; j++) {{ var x = pad.left+j*cellW; ctx.beginPath(); ctx.moveTo(x,pad.top); ctx.lineTo(x,pad.top+n*cellH); ctx.stroke(); }}
    // Y labels
    ctx.fillStyle = '#999'; ctx.font = '9px sans-serif'; ctx.textAlign = 'right';
    for (var i = 0; i < n; i++) ctx.fillText((n-i) + '期', pad.left-4, pad.top+i*cellH+cellH/2+4);
    // Remove X labels from canvas (now in sticky header)
    // Fill matched cells with wave color
    for (var i = 0; i < n; i++) {{
        var x = pad.left+(records[i].num-1)*cellW, y = pad.top+i*cellH;
        var bg = waveColors[records[i].wave] || 'rgba(26,115,232,0.15)';
        ctx.fillStyle = bg;
        ctx.fillRect(x+0.5, y+0.5, cellW-1, cellH-1);
        ctx.fillStyle = '#333'; ctx.font = 'bold 9px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(records[i].num, x+cellW/2, y+cellH/2);
    }}
}}

function drawNumTrendHeader(canvas, cellW) {{
    // Draw the 1-49 header on canvas using the SAME left padding & cellW as drawNumTrend
    // so the number columns line up pixel-perfect with the grid below.
    var ctx = canvas.getContext('2d'), H = canvas.height, padLeft = 55;
    ctx.clearRect(0, 0, canvas.width, H);
    ctx.fillStyle = '#666'; ctx.font = '10px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    for (var j = 1; j <= 49; j++) {{
        ctx.fillText(j, padLeft + (j-1)*cellW + cellW/2, H/2);
    }}
}}

function textColorFor(hex) {{
    // 依据填充色亮度返回黑/白文字色，保证可读
    var h = hex.replace('#',''); if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
    var r = parseInt(h.substr(0,2),16), g = parseInt(h.substr(2,2),16), b = parseInt(h.substr(4,2),16);
    return (0.299*r + 0.587*g + 0.114*b) > 150 ? '#333' : '#fff';
}}

function drawAttrCol(field, records, canvas, cellH, colorMap) {{
    var ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height, n = records.length;
    var cats = Object.keys(colorMap), nc = cats.length;
    var pad = {{top:2,right:5,bottom:2,left:30}}, pw = W-pad.left-pad.right, cellW = pw/nc, ph = n*cellH;
    ctx.fillStyle = '#fff'; ctx.fillRect(pad.left, pad.top, pw, ph);
    // Fill matched cells + label text inside
    for (var i = 0; i < n; i++) {{
        var val = records[i][field];
        for (var c = 0; c < nc; c++) {{
            if (val.indexOf(cats[c]) >= 0) {{
                var cx = pad.left+c*cellW, cy = pad.top+i*cellH;
                ctx.fillStyle = colorMap[cats[c]];
                ctx.fillRect(cx, cy, cellW, cellH);
                ctx.fillStyle = textColorFor(colorMap[cats[c]]);
                ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                ctx.fillText(cats[c], cx+cellW/2, cy+cellH/2+1);
            }}
        }}
    }}
    // Black grid over cells (all rows + columns + outer border)
    ctx.strokeStyle = '#000'; ctx.lineWidth = 1;
    for (var r = 0; r <= n; r++) {{ var y = pad.top+r*cellH+0.5; ctx.beginPath(); ctx.moveTo(pad.left,y); ctx.lineTo(pad.left+nc*cellW,y); ctx.stroke(); }}
    for (var c = 0; c <= nc; c++) {{ var x = pad.left+c*cellW+0.5; ctx.beginPath(); ctx.moveTo(x,pad.top); ctx.lineTo(x,pad.top+n*cellH); ctx.stroke(); }}
    // Y labels
    ctx.fillStyle = '#999'; ctx.font = '9px sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
    for (var i = 0; i < n; i++) ctx.fillText((n-i) + '期', pad.left-4, pad.top+i*cellH+cellH/2+4);
}}

function drawAttrHeader(canvas, title, color, cats) {{
    // Sticky header for an attribute chart: title on top, category labels below,
    // labels aligned to the SAME pad.left & column widths as drawAttrCol.
    var ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height;
    var nc = cats.length, pad = {{left:30, right:5}}, pw = W-pad.left-pad.right, cellW = pw/nc;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = color; ctx.font = '600 12px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(title, pad.left + pw/2, 16);
    ctx.fillStyle = '#666'; ctx.font = '10px sans-serif';
    for (var c = 0; c < nc; c++) ctx.fillText(cats[c], pad.left+c*cellW+cellW/2, 35);
}}

function drawBeastCol(records, canvas, cellH) {{
    var ctx = canvas.getContext('2d'), W = canvas.width, H = canvas.height, n = records.length, nc = 2;
    var pad = {{top:2,right:5,bottom:2,left:30}}, pw = W-pad.left-pad.right, cellW = pw/nc;
    ctx.fillStyle = '#fff'; ctx.fillRect(pad.left, pad.top, pw, n*cellH);
    var beasts = ['鼠','虎','兔','龙','蛇','猴'];
    // Fill cells + label text inside
    for (var i = 0; i < n; i++) {{
        var z = records[i].zodiac, isBeast = beasts.indexOf(z) >= 0;
        var cx = pad.left+(isBeast?cellW:0), cy = pad.top+i*cellH;
        ctx.fillStyle = isBeast ? '#F1948A' : '#82C99A';
        ctx.fillRect(cx, cy, cellW, cellH);
        ctx.fillStyle = '#333';
        ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(isBeast ? '野兽' : '家畜', cx+cellW/2, cy+cellH/2+1);
    }}
    // Black grid over cells (all rows + columns + outer border)
    ctx.strokeStyle = '#000'; ctx.lineWidth = 1;
    for (var r = 0; r <= n; r++) {{ var y = pad.top+r*cellH+0.5; ctx.beginPath(); ctx.moveTo(pad.left,y); ctx.lineTo(pad.left+nc*cellW,y); ctx.stroke(); }}
    for (var c = 0; c <= nc; c++) {{ var x = pad.left+c*cellW+0.5; ctx.beginPath(); ctx.moveTo(x,pad.top); ctx.lineTo(x,pad.top+n*cellH); ctx.stroke(); }}
    // Y labels
    ctx.fillStyle = '#999'; ctx.font = '9px sans-serif'; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
    for (var i = 0; i < n; i++) ctx.fillText((n-i) + '期', pad.left-4, pad.top+i*cellH+cellH/2+4);
}}

// Content builders
var builders = {{
    overview: buildOverview,
    analysis: buildAnalysis,
    history: buildHistory,
    numtrend: buildNumTrend,
    attrtrend: buildAttrTrend,
}};

var container = document.getElementById('mainContent');

// Lazy render tabs
var rendered = {{}};
function showTab(id) {{
    if (id === 'numtrend' || id === 'attrtrend') {{
        rendered[id] = builders[id]();
    }} else if (!rendered[id]) {{
        try {{
            rendered[id] = builders[id]();
        }} catch(e) {{
            rendered[id] = '<div style="padding:20px;color:#e74c3c">渲染出错: ' + e.message + '</div>';
        }}
    }}
    container.innerHTML = rendered[id];
}}

showTab('overview');

// Tab click
document.getElementById('tabNav').addEventListener('click', function(e) {{
    var btn = e.target.closest('.tab-btn');
    if (!btn) return;
    var id = btn.getAttribute('data-tab');
    document.querySelectorAll('.tab-btn').forEach(function(b) {{ b.classList.remove('active'); }});
    btn.classList.add('active');
    showTab(id);
}});

// Sort handler for zodiac bars
function sortZodiacBars(btn) {{
    var bars = btn.closest('.section').querySelector('.zodiac-bars');
    var rows = Array.prototype.slice.call(bars.querySelectorAll('.zodiac-bar-row'));
    var dir = btn.getAttribute('data-dir') || '';
    if (!dir || dir === 'desc') {{
        btn.setAttribute('data-dir', 'asc');
        btn.textContent = '升序';
        rows.sort(function(a, b) {{ return parseFloat(a.getAttribute('data-sv')) - parseFloat(b.getAttribute('data-sv')); }});
    }} else if (dir === 'asc') {{
        btn.setAttribute('data-dir', 'desc');
        btn.textContent = '降序';
        rows.sort(function(a, b) {{ return parseFloat(b.getAttribute('data-sv')) - parseFloat(a.getAttribute('data-sv')); }});
    }}
    rows.forEach(function(row) {{ bars.appendChild(row); }});
}}

// Table sort handler
document.addEventListener('click', function(e) {{
    var th = e.target.closest('.th-sort');
    if (!th) return;
    var table = th.closest('table');
    var tbody = table.querySelector('tbody');
    var ths = table.querySelectorAll('thead th');
    var colIdx = Array.prototype.indexOf.call(ths, th);
    if (colIdx < 0) return;

    var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
    var isAsc = th.classList.contains('asc');
    var isDesc = th.classList.contains('desc');

    // Reset all headers in this table
    ths.forEach(function(h) {{ h.classList.remove('asc', 'desc'); }});

    if (!isAsc && !isDesc) {{
        // First click: ascending
        th.classList.add('asc');
        rows.sort(function(a, b) {{
            var va = parseFloat(a.children[colIdx].getAttribute('data-sv'));
            var vb = parseFloat(b.children[colIdx].getAttribute('data-sv'));
            if (isNaN(va) && isNaN(vb)) return 0;
            if (isNaN(va)) return 1;
            if (isNaN(vb)) return -1;
            return va - vb;
        }});
    }} else if (isAsc) {{
        // Second click: descending
        th.classList.add('desc');
        rows.sort(function(a, b) {{
            var va = parseFloat(a.children[colIdx].getAttribute('data-sv'));
            var vb = parseFloat(b.children[colIdx].getAttribute('data-sv'));
            if (isNaN(va) && isNaN(vb)) return 0;
            if (isNaN(va)) return 1;
            if (isNaN(vb)) return -1;
            return vb - va;
        }});
    }} else {{
        // Third click: restore original order
        th.classList.remove('asc', 'desc');
    }}

    // Re-append sorted rows
    rows.forEach(function(row) {{ tbody.appendChild(row); }});
}});

// Month pill click
document.addEventListener('click', function(e) {{
    var pill = e.target.closest('.month-pill');
    if (!pill) return;
    var mid = pill.getAttribute('data-month');
    document.querySelectorAll('.month-pill').forEach(function(p) {{ p.classList.remove('active'); }});
    pill.classList.add('active');
    document.querySelectorAll('.history-table').forEach(function(t) {{ t.classList.remove('active'); }});
    var tables = document.querySelectorAll('.history-table');
    for (var i = 0; i < tables.length; i++) {{
        if (tables[i].getAttribute('data-month') === mid) {{
            tables[i].classList.add('active');
            break;
        }}
    }}
}});
</script>

</body>
</html>"""

with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
    f.write(html)

print(f"Generated: {OUTPUT_PATH}")
print(f"Size: {len(html.encode('utf-8'))} bytes")
