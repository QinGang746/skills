# -*- coding: utf-8 -*-
"""
增量更新脚本：检查已有 Excel 是否最新，是则跳过，否则仅合并新数据重新生成。
用法: python 02-script/update_excel.py
"""
import json
import os
import sys
import subprocess
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TXT_DIR = os.path.join(BASE_DIR, '03-data', 'txt-source')
OUT_DIR = os.path.join(BASE_DIR, '04-output')
MERGE_JSON = os.path.join(OUT_DIR, 'merged.json')
XLSX_OUT = os.path.join(OUT_DIR, '开奖记录-全年份合并.xlsx')
TEMPLATE = os.path.join(BASE_DIR, '01-template', '波色号码对照表.xlsx')
TXT2EXCEL = os.path.join(BASE_DIR, '02-script', 'txt2excel.py')
EXCEL2HTML = os.path.join(BASE_DIR, '02-script', 'excel2html_lottery.py')

TXT2EXCEL_ARGS = [
    '--format', 'json',
    '--split', 'num,shengxiao,wuxing',
    '--split-prefixes', '平码,平肖,平五行',
    '--split-special', '特码,特肖,特五行',
    '--lunar-date',
    '--bose-table', TEMPLATE,
    '--sheet-name', '开奖明细',
]


def load_txt_files():
    """读取 txt-source 下所有 txt，合并按 date 倒序"""
    all_rows = []
    txt_files = sorted(f for f in os.listdir(TXT_DIR) if f.endswith('.txt'))
    for f in txt_files:
        path = os.path.join(TXT_DIR, f)
        with open(path, encoding='utf-8') as fh:
            all_rows.extend(json.load(fh))
    all_rows.sort(key=lambda r: r.get('date', ''), reverse=True)
    return all_rows, txt_files


def get_existing_max_date():
    """从已有 Excel 读取最新日期（date 列 col 4）"""
    if not os.path.exists(XLSX_OUT):
        return None
    try:
        import openpyxl
        wb = openpyxl.load_workbook(XLSX_OUT, data_only=True)
        if '开奖明细' not in wb.sheetnames:
            wb.close()
            return None
        ws = wb['开奖明细']
        # 数据从 row 2 开始，date 在 col 4，row 2 是最新（倒序）
        max_date = str(ws.cell(2, 4).value)
        wb.close()
        return max_date
    except Exception:
        return None


def run_cmd(cmd_args):
    print('  $', ' '.join(cmd_args))
    result = subprocess.run(cmd_args, capture_output=True, text=True)
    if result.returncode != 0:
        print('ERROR:', result.stderr.strip())
        sys.exit(1)
    print('  ', result.stdout.strip())


def main():
    need_full = False
    new_count = 0

    existing_date = get_existing_max_date()
    all_rows, txt_files = load_txt_files()

    if existing_date is None:
        # 首次生成：全量合并
        print('[首次] 未找到已有 Excel，全量合并 %d 个文件...' % len(txt_files))
        need_full = True
    else:
        print('[增量] 已有 Excel 最新日期: %s' % existing_date)
        # 检查是否有新数据
        new_rows = [r for r in all_rows if r.get('date', '') > existing_date]
        if not new_rows:
            print('[跳过] 无新数据，所有记录均已包含。')
            # 仍然检查 HTML 是否需要重新生成
            html_files = [f for f in os.listdir(OUT_DIR)
                          if f.startswith('开奖记录-全年份合并-report-') and f.endswith('.html')]
            if html_files:
                print('[HTML 已存在] %s' % html_files[-1])
            else:
                print('[生成 HTML] 缺少 HTML 产物，正在生成...')
                run_cmd([sys.executable, EXCEL2HTML, XLSX_OUT])
            return
        new_count = len(new_rows)
        print('[增量] 发现 %d 条新记录（%s ~ %s）' % (
            new_count,
            min(r['date'] for r in new_rows),
            max(r['date'] for r in new_rows),
        ))
        need_full = True

    if need_full:
        # 写 merged.json（全量，已按 date 倒序）
        with open(MERGE_JSON, 'w', encoding='utf-8') as fh:
            json.dump(all_rows, fh, ensure_ascii=False)
        print('[合并] 总计 %d 条记录 -> %s' % (len(all_rows), MERGE_JSON))

        # 生成 Excel
        print('[Excel] 正在生成...')
        run_cmd([sys.executable, TXT2EXCEL, MERGE_JSON, XLSX_OUT] + TXT2EXCEL_ARGS)
        print('[Excel] 已生成: %s' % XLSX_OUT)

    # 生成 HTML
    print('[HTML] 正在生成...')
    run_cmd([sys.executable, EXCEL2HTML, XLSX_OUT])


if __name__ == '__main__':
    main()
